{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.APPLE.ElementArray
       (gl_ELEMENT_ARRAY, gl_ELEMENT_ARRAY_POINTER, gl_ELEMENT_ARRAY_TYPE,
        glDrawElementArray, glDrawRangeElementArray, glElementPointer,
        glMultiDrawElementArray, glMultiDrawRangeElementArray)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ELEMENT_ARRAY :: GLenum
gl_ELEMENT_ARRAY = 35340
 
gl_ELEMENT_ARRAY_POINTER :: GLenum
gl_ELEMENT_ARRAY_POINTER = 35342
 
gl_ELEMENT_ARRAY_TYPE :: GLenum
gl_ELEMENT_ARRAY_TYPE = 35341
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawElementArray ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> IO ())
 
glDrawElementArray :: GLenum -> GLint -> GLsizei -> IO ()
glDrawElementArray = dyn_glDrawElementArray ptr_glDrawElementArray
 
{-# NOINLINE ptr_glDrawElementArray #-}
 
ptr_glDrawElementArray :: FunPtr a
ptr_glDrawElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glDrawElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawRangeElementArray
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLint -> GLsizei -> IO ())
 
glDrawRangeElementArray ::
                        GLenum -> GLuint -> GLuint -> GLint -> GLsizei -> IO ()
glDrawRangeElementArray
  = dyn_glDrawRangeElementArray ptr_glDrawRangeElementArray
 
{-# NOINLINE ptr_glDrawRangeElementArray #-}
 
ptr_glDrawRangeElementArray :: FunPtr a
ptr_glDrawRangeElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glDrawRangeElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glElementPointer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> IO ())
 
glElementPointer :: GLenum -> Ptr a -> IO ()
glElementPointer = dyn_glElementPointer ptr_glElementPointer
 
{-# NOINLINE ptr_glElementPointer #-}
 
ptr_glElementPointer :: FunPtr a
ptr_glElementPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glElementPointerAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiDrawElementArray
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ())
 
glMultiDrawElementArray ::
                        GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ()
glMultiDrawElementArray
  = dyn_glMultiDrawElementArray ptr_glMultiDrawElementArray
 
{-# NOINLINE ptr_glMultiDrawElementArray #-}
 
ptr_glMultiDrawElementArray :: FunPtr a
ptr_glMultiDrawElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glMultiDrawElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawRangeElementArray ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLuint -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ())
 
glMultiDrawRangeElementArray ::
                             GLenum ->
                               GLuint -> GLuint -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ()
glMultiDrawRangeElementArray
  = dyn_glMultiDrawRangeElementArray ptr_glMultiDrawRangeElementArray
 
{-# NOINLINE ptr_glMultiDrawRangeElementArray #-}
 
ptr_glMultiDrawRangeElementArray :: FunPtr a
ptr_glMultiDrawRangeElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glMultiDrawRangeElementArrayAPPLE"