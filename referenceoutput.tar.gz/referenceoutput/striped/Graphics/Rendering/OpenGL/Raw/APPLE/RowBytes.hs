-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.RowBytes
       (gl_PACK_ROW_BYTES, gl_UNPACK_ROW_BYTES) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PACK_ROW_BYTES :: GLenum
gl_PACK_ROW_BYTES = 35349
 
gl_UNPACK_ROW_BYTES :: GLenum
gl_UNPACK_ROW_BYTES = 35350