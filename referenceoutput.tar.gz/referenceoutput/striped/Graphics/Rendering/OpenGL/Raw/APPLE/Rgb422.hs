module Graphics.Rendering.OpenGL.Raw.APPLE.Rgb422
       (gl_RGB_422, gl_UNSIGNED_SHORT_8_8, gl_UNSIGNED_SHORT_8_8_REV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RGB_422 :: GLenum
gl_RGB_422 = 35359
 
gl_UNSIGNED_SHORT_8_8 :: GLenum
gl_UNSIGNED_SHORT_8_8 = 34234
 
gl_UNSIGNED_SHORT_8_8_REV :: GLenum
gl_UNSIGNED_SHORT_8_8_REV = 34235