{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.TextureRange
       (gl_STORAGE_CACHED, gl_STORAGE_PRIVATE, gl_STORAGE_SHARED,
        gl_TEXTURE_RANGE_LENGTH, gl_TEXTURE_RANGE_POINTER,
        gl_TEXTURE_STORAGE_HINT, glGetTexParameterPointerv, glTextureRange)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_STORAGE_CACHED :: GLenum
gl_STORAGE_CACHED = 34238
 
gl_STORAGE_PRIVATE :: GLenum
gl_STORAGE_PRIVATE = 34237
 
gl_STORAGE_SHARED :: GLenum
gl_STORAGE_SHARED = 34239
 
gl_TEXTURE_RANGE_LENGTH :: GLenum
gl_TEXTURE_RANGE_LENGTH = 34231
 
gl_TEXTURE_RANGE_POINTER :: GLenum
gl_TEXTURE_RANGE_POINTER = 34232
 
gl_TEXTURE_STORAGE_HINT :: GLenum
gl_TEXTURE_STORAGE_HINT = 34236
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTexParameterPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr (Ptr d) -> IO ())
 
glGetTexParameterPointerv ::
                          GLenum -> GLenum -> Ptr (Ptr d) -> IO ()
glGetTexParameterPointerv
  = dyn_glGetTexParameterPointerv ptr_glGetTexParameterPointerv
 
{-# NOINLINE ptr_glGetTexParameterPointerv #-}
 
ptr_glGetTexParameterPointerv :: FunPtr a
ptr_glGetTexParameterPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_texture_range"
        "glGetTexParameterPointervAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr d -> IO ())
 
glTextureRange :: GLenum -> GLsizei -> Ptr d -> IO ()
glTextureRange = dyn_glTextureRange ptr_glTextureRange
 
{-# NOINLINE ptr_glTextureRange #-}
 
ptr_glTextureRange :: FunPtr a
ptr_glTextureRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_texture_range"
        "glTextureRangeAPPLE"