module Graphics.Rendering.OpenGL.Raw.APPLE.AuxDepthStencil
       (gl_AUX_DEPTH_STENCIL) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_AUX_DEPTH_STENCIL :: GLenum
gl_AUX_DEPTH_STENCIL = 35348