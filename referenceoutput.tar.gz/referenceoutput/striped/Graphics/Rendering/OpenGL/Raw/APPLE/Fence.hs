{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.APPLE.Fence
       (gl_DRAW_PIXELS, gl_FENCE, glDeleteFences, glFinishFence,
        glFinishObject, glGenFences, glIsFence, glSetFence, glTestFence,
        glTestObject)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DRAW_PIXELS :: GLenum
gl_DRAW_PIXELS = 35338
 
gl_FENCE :: GLenum
gl_FENCE = 35339
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteFences ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteFences :: GLsizei -> Ptr GLuint -> IO ()
glDeleteFences = dyn_glDeleteFences ptr_glDeleteFences
 
{-# NOINLINE ptr_glDeleteFences #-}
 
ptr_glDeleteFences :: FunPtr a
ptr_glDeleteFences
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glDeleteFencesAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glFinishFence :: GLuint -> IO ()
glFinishFence = dyn_glFinishFence ptr_glFinishFence
 
{-# NOINLINE ptr_glFinishFence #-}
 
ptr_glFinishFence :: FunPtr a
ptr_glFinishFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glFinishFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
glFinishObject :: GLenum -> GLint -> IO ()
glFinishObject = dyn_glFinishObject ptr_glFinishObject
 
{-# NOINLINE ptr_glFinishObject #-}
 
ptr_glFinishObject :: FunPtr a
ptr_glFinishObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glFinishObjectAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenFences ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenFences :: GLsizei -> Ptr GLuint -> IO ()
glGenFences = dyn_glGenFences ptr_glGenFences
 
{-# NOINLINE ptr_glGenFences #-}
 
ptr_glGenFences :: FunPtr a
ptr_glGenFences
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glGenFencesAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsFence :: GLuint -> IO GLboolean
glIsFence = dyn_glIsFence ptr_glIsFence
 
{-# NOINLINE ptr_glIsFence #-}
 
ptr_glIsFence :: FunPtr a
ptr_glIsFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glIsFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glSetFence :: GLuint -> IO ()
glSetFence = dyn_glSetFence ptr_glSetFence
 
{-# NOINLINE ptr_glSetFence #-}
 
ptr_glSetFence :: FunPtr a
ptr_glSetFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glSetFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glTestFence :: GLuint -> IO GLboolean
glTestFence = dyn_glTestFence ptr_glTestFence
 
{-# NOINLINE ptr_glTestFence #-}
 
ptr_glTestFence :: FunPtr a
ptr_glTestFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glTestFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glTestObject :: GLenum -> GLuint -> IO GLboolean
glTestObject = dyn_glTestObject ptr_glTestObject
 
{-# NOINLINE ptr_glTestObject #-}
 
ptr_glTestObject :: FunPtr a
ptr_glTestObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glTestObjectAPPLE"