-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.FloatPixels
       (gl_ALPHA_FLOAT16, gl_ALPHA_FLOAT32, gl_COLOR_FLOAT, gl_HALF,
        gl_INTENSITY_FLOAT16, gl_INTENSITY_FLOAT32,
        gl_LUMINANCE_ALPHA_FLOAT16, gl_LUMINANCE_ALPHA_FLOAT32,
        gl_LUMINANCE_FLOAT16, gl_LUMINANCE_FLOAT32, gl_RGBA_FLOAT16,
        gl_RGBA_FLOAT32, gl_RGB_FLOAT16, gl_RGB_FLOAT32)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ALPHA_FLOAT16 :: GLenum
gl_ALPHA_FLOAT16 = 34844
 
gl_ALPHA_FLOAT32 :: GLenum
gl_ALPHA_FLOAT32 = 34838
 
gl_COLOR_FLOAT :: GLenum
gl_COLOR_FLOAT = 35343
 
gl_HALF :: GLenum
gl_HALF = 5131
 
gl_INTENSITY_FLOAT16 :: GLenum
gl_INTENSITY_FLOAT16 = 34845
 
gl_INTENSITY_FLOAT32 :: GLenum
gl_INTENSITY_FLOAT32 = 34839
 
gl_LUMINANCE_ALPHA_FLOAT16 :: GLenum
gl_LUMINANCE_ALPHA_FLOAT16 = 34847
 
gl_LUMINANCE_ALPHA_FLOAT32 :: GLenum
gl_LUMINANCE_ALPHA_FLOAT32 = 34841
 
gl_LUMINANCE_FLOAT16 :: GLenum
gl_LUMINANCE_FLOAT16 = 34846
 
gl_LUMINANCE_FLOAT32 :: GLenum
gl_LUMINANCE_FLOAT32 = 34840
 
gl_RGBA_FLOAT16 :: GLenum
gl_RGBA_FLOAT16 = 34842
 
gl_RGBA_FLOAT32 :: GLenum
gl_RGBA_FLOAT32 = 34836
 
gl_RGB_FLOAT16 :: GLenum
gl_RGB_FLOAT16 = 34843
 
gl_RGB_FLOAT32 :: GLenum
gl_RGB_FLOAT32 = 34837