-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.TransformHint
       (gl_TRANSFORM_HINT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TRANSFORM_HINT :: GLenum
gl_TRANSFORM_HINT = 34225