{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.APPLE.ObjectPurgeable
       (gl_BUFFER_OBJECT, gl_PURGEABLE, gl_RELEASED, gl_RETAINED,
        gl_UNDEFINED, gl_VOLATILE, glGetObjectParameteriv,
        glObjectPurgeable, glObjectUnpurgeable)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BUFFER_OBJECT :: GLenum
gl_BUFFER_OBJECT = 34227
 
gl_PURGEABLE :: GLenum
gl_PURGEABLE = 35357
 
gl_RELEASED :: GLenum
gl_RELEASED = 35353
 
gl_RETAINED :: GLenum
gl_RETAINED = 35355
 
gl_UNDEFINED :: GLenum
gl_UNDEFINED = 35356
 
gl_VOLATILE :: GLenum
gl_VOLATILE = 35354
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetObjectParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetObjectParameteriv ::
                       GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetObjectParameteriv
  = dyn_glGetObjectParameteriv ptr_glGetObjectParameteriv
 
{-# NOINLINE ptr_glGetObjectParameteriv #-}
 
ptr_glGetObjectParameteriv :: FunPtr a
ptr_glGetObjectParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_object_purgeable"
        "glGetObjectParameterivAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glObjectPurgeable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> IO GLenum)
 
glObjectPurgeable :: GLenum -> GLuint -> GLenum -> IO GLenum
glObjectPurgeable = dyn_glObjectPurgeable ptr_glObjectPurgeable
 
{-# NOINLINE ptr_glObjectPurgeable #-}
 
ptr_glObjectPurgeable :: FunPtr a
ptr_glObjectPurgeable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_object_purgeable"
        "glObjectPurgeableAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glObjectUnpurgeable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> IO GLenum)
 
glObjectUnpurgeable :: GLenum -> GLuint -> GLenum -> IO GLenum
glObjectUnpurgeable
  = dyn_glObjectUnpurgeable ptr_glObjectUnpurgeable
 
{-# NOINLINE ptr_glObjectUnpurgeable #-}
 
ptr_glObjectUnpurgeable :: FunPtr a
ptr_glObjectUnpurgeable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_object_purgeable"
        "glObjectUnpurgeableAPPLE"