-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.ClientStorage
       (gl_UNPACK_CLIENT_STORAGE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_UNPACK_CLIENT_STORAGE :: GLenum
gl_UNPACK_CLIENT_STORAGE = 34226