module Graphics.Rendering.OpenGL.Raw.APPLE.ClientStorage
       (gl_UNPACK_CLIENT_STORAGE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_UNPACK_CLIENT_STORAGE :: GLenum
gl_UNPACK_CLIENT_STORAGE = 34226