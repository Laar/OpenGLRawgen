{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.FlushBufferRange
       (gl_BUFFER_FLUSHING_UNMAP, gl_BUFFER_SERIALIZED_MODIFY,
        glBufferParameteri, glFlushMappedBufferRange)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BUFFER_FLUSHING_UNMAP :: GLenum
gl_BUFFER_FLUSHING_UNMAP = 35347
 
gl_BUFFER_SERIALIZED_MODIFY :: GLenum
gl_BUFFER_SERIALIZED_MODIFY = 35346
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
glBufferParameteri :: GLenum -> GLenum -> GLint -> IO ()
glBufferParameteri = dyn_glBufferParameteri ptr_glBufferParameteri
 
{-# NOINLINE ptr_glBufferParameteri #-}
 
ptr_glBufferParameteri :: FunPtr a
ptr_glBufferParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_flush_buffer_range"
        "glBufferParameteriAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFlushMappedBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> IO ())
 
glFlushMappedBufferRange ::
                         GLenum -> GLintptr -> GLsizeiptr -> IO ()
glFlushMappedBufferRange
  = dyn_glFlushMappedBufferRange ptr_glFlushMappedBufferRange
 
{-# NOINLINE ptr_glFlushMappedBufferRange #-}
 
ptr_glFlushMappedBufferRange :: FunPtr a
ptr_glFlushMappedBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_flush_buffer_range"
        "glFlushMappedBufferRangeAPPLE"