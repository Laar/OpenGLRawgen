-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureCubeMapArray
       (gl_INT_SAMPLER_CUBE_MAP_ARRAY, gl_PROXY_TEXTURE_CUBE_MAP_ARRAY,
        gl_SAMPLER_CUBE_MAP_ARRAY, gl_SAMPLER_CUBE_MAP_ARRAY_SHADOW,
        gl_TEXTURE_BINDING_CUBE_MAP_ARRAY, gl_TEXTURE_CUBE_MAP_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_INT_SAMPLER_CUBE_MAP_ARRAY :: GLenum
gl_INT_SAMPLER_CUBE_MAP_ARRAY = 36878
 
gl_PROXY_TEXTURE_CUBE_MAP_ARRAY :: GLenum
gl_PROXY_TEXTURE_CUBE_MAP_ARRAY = 36875
 
gl_SAMPLER_CUBE_MAP_ARRAY :: GLenum
gl_SAMPLER_CUBE_MAP_ARRAY = 36876
 
gl_SAMPLER_CUBE_MAP_ARRAY_SHADOW :: GLenum
gl_SAMPLER_CUBE_MAP_ARRAY_SHADOW = 36877
 
gl_TEXTURE_BINDING_CUBE_MAP_ARRAY :: GLenum
gl_TEXTURE_BINDING_CUBE_MAP_ARRAY = 36874
 
gl_TEXTURE_CUBE_MAP_ARRAY :: GLenum
gl_TEXTURE_CUBE_MAP_ARRAY = 36873
 
gl_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY :: GLenum
gl_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY = 36879