module Graphics.Rendering.OpenGL.Raw.ARB.Imaging
       (gl_ONE_MINUS_CONSTANT_COLOR, gl_ONE_MINUS_CONSTANT_ALPHA, gl_MIN,
        gl_MAX, gl_FUNC_SUBTRACT, gl_FUNC_REVERSE_SUBTRACT, gl_FUNC_ADD,
        gl_CONSTANT_COLOR, gl_CONSTANT_ALPHA, gl_BLEND_EQUATION,
        gl_BLEND_COLOR)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_ONE_MINUS_CONSTANT_COLOR, gl_ONE_MINUS_CONSTANT_ALPHA, gl_MIN,
        gl_MAX, gl_FUNC_SUBTRACT, gl_FUNC_REVERSE_SUBTRACT, gl_FUNC_ADD,
        gl_CONSTANT_COLOR, gl_CONSTANT_ALPHA, gl_BLEND_EQUATION,
        gl_BLEND_COLOR)