-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DepthTexture
       (gl_DEPTH_COMPONENT16, gl_DEPTH_COMPONENT24, gl_DEPTH_COMPONENT32,
        gl_DEPTH_TEXTURE_MODE, gl_TEXTURE_DEPTH_SIZE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_COMPONENT16 :: GLenum
gl_DEPTH_COMPONENT16 = 33189
 
gl_DEPTH_COMPONENT24 :: GLenum
gl_DEPTH_COMPONENT24 = 33190
 
gl_DEPTH_COMPONENT32 :: GLenum
gl_DEPTH_COMPONENT32 = 33191
 
gl_DEPTH_TEXTURE_MODE :: GLenum
gl_DEPTH_TEXTURE_MODE = 34891
 
gl_TEXTURE_DEPTH_SIZE :: GLenum
gl_TEXTURE_DEPTH_SIZE = 34890