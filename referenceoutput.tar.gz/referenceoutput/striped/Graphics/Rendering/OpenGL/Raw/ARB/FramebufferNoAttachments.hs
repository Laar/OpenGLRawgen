-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FramebufferNoAttachments
       (gl_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS,
        gl_FRAMEBUFFER_DEFAULT_HEIGHT, gl_FRAMEBUFFER_DEFAULT_LAYERS,
        gl_FRAMEBUFFER_DEFAULT_SAMPLES, gl_FRAMEBUFFER_DEFAULT_WIDTH,
        gl_MAX_FRAMEBUFFER_HEIGHT, gl_MAX_FRAMEBUFFER_LAYERS,
        gl_MAX_FRAMEBUFFER_SAMPLES, gl_MAX_FRAMEBUFFER_WIDTH,
        glFramebufferParameteri, glGetFramebufferParameteriv,
        glGetNamedFramebufferParameteriv, glNamedFramebufferParameteri)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_DEFAULT_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_DEFAULT_LAYERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_DEFAULT_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_DEFAULT_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_FRAMEBUFFER_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_FRAMEBUFFER_LAYERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_FRAMEBUFFER_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_FRAMEBUFFER_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glFramebufferParameteri)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glGetFramebufferParameteriv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glGetNamedFramebufferParameteriv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glNamedFramebufferParameteri)