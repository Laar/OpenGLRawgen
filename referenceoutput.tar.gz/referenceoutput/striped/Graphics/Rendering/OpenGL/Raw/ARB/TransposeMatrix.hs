{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransposeMatrix
       (gl_TRANSPOSE_COLOR_MATRIX, gl_TRANSPOSE_MODELVIEW_MATRIX,
        gl_TRANSPOSE_PROJECTION_MATRIX, gl_TRANSPOSE_TEXTURE_MATRIX,
        glLoadTransposeMatrixd, glLoadTransposeMatrixf,
        glMultTransposeMatrixd, glMultTransposeMatrixf)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TRANSPOSE_COLOR_MATRIX :: GLenum
gl_TRANSPOSE_COLOR_MATRIX = 34022
 
gl_TRANSPOSE_MODELVIEW_MATRIX :: GLenum
gl_TRANSPOSE_MODELVIEW_MATRIX = 34019
 
gl_TRANSPOSE_PROJECTION_MATRIX :: GLenum
gl_TRANSPOSE_PROJECTION_MATRIX = 34020
 
gl_TRANSPOSE_TEXTURE_MATRIX :: GLenum
gl_TRANSPOSE_TEXTURE_MATRIX = 34021
 
foreign import CALLCONV unsafe "dynamic" dyn_glLoadTransposeMatrixd
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
glLoadTransposeMatrixd :: Ptr GLdouble -> IO ()
glLoadTransposeMatrixd
  = dyn_glLoadTransposeMatrixd ptr_glLoadTransposeMatrixd
 
{-# NOINLINE ptr_glLoadTransposeMatrixd #-}
 
ptr_glLoadTransposeMatrixd :: FunPtr a
ptr_glLoadTransposeMatrixd
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glLoadTransposeMatrixdARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glLoadTransposeMatrixf
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
glLoadTransposeMatrixf :: Ptr GLfloat -> IO ()
glLoadTransposeMatrixf
  = dyn_glLoadTransposeMatrixf ptr_glLoadTransposeMatrixf
 
{-# NOINLINE ptr_glLoadTransposeMatrixf #-}
 
ptr_glLoadTransposeMatrixf :: FunPtr a
ptr_glLoadTransposeMatrixf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glLoadTransposeMatrixfARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultTransposeMatrixd
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
glMultTransposeMatrixd :: Ptr GLdouble -> IO ()
glMultTransposeMatrixd
  = dyn_glMultTransposeMatrixd ptr_glMultTransposeMatrixd
 
{-# NOINLINE ptr_glMultTransposeMatrixd #-}
 
ptr_glMultTransposeMatrixd :: FunPtr a
ptr_glMultTransposeMatrixd
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glMultTransposeMatrixdARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultTransposeMatrixf
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
glMultTransposeMatrixf :: Ptr GLfloat -> IO ()
glMultTransposeMatrixf
  = dyn_glMultTransposeMatrixf ptr_glMultTransposeMatrixf
 
{-# NOINLINE ptr_glMultTransposeMatrixf #-}
 
ptr_glMultTransposeMatrixf :: FunPtr a
ptr_glMultTransposeMatrixf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glMultTransposeMatrixfARB"