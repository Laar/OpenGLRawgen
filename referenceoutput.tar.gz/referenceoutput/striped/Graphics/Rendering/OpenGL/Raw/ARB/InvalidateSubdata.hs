-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.InvalidateSubdata
       (glInvalidateBufferData, glInvalidateBufferSubData,
        glInvalidateFramebuffer, glInvalidateSubFramebuffer,
        glInvalidateTexImage, glInvalidateTexSubImage)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateBufferData)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateBufferSubData)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateFramebuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateSubFramebuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateTexImage)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glInvalidateTexSubImage)