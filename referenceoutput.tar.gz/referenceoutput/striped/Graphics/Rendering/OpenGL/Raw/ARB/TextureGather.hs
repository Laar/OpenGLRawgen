-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureGather
       (gl_MAX_PROGRAM_TEXTURE_GATHER_COMPONENTS,
        gl_MAX_PROGRAM_TEXTURE_GATHER_OFFSET,
        gl_MIN_PROGRAM_TEXTURE_GATHER_OFFSET)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_PROGRAM_TEXTURE_GATHER_COMPONENTS :: GLenum
gl_MAX_PROGRAM_TEXTURE_GATHER_COMPONENTS = 36767
 
gl_MAX_PROGRAM_TEXTURE_GATHER_OFFSET :: GLenum
gl_MAX_PROGRAM_TEXTURE_GATHER_OFFSET = 36447
 
gl_MIN_PROGRAM_TEXTURE_GATHER_OFFSET :: GLenum
gl_MIN_PROGRAM_TEXTURE_GATHER_OFFSET = 36446