module Graphics.Rendering.OpenGL.Raw.ARB.ClEvent
       (gl_SYNC_CL_EVENT, gl_SYNC_CL_EVENT_COMPLETE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SYNC_CL_EVENT :: GLenum
gl_SYNC_CL_EVENT = 33344
 
gl_SYNC_CL_EVENT_COMPLETE :: GLenum
gl_SYNC_CL_EVENT_COMPLETE = 33345