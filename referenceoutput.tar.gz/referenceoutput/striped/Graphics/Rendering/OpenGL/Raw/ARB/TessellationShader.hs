module Graphics.Rendering.OpenGL.Raw.ARB.TessellationShader
       (gl_CCW, gl_CW, gl_EQUAL, gl_FRACTIONAL_EVEN, gl_FRACTIONAL_ODD,
        gl_ISOLINES, gl_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS,
        gl_MAX_PATCH_VERTICES, gl_MAX_TESS_CONTROL_INPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_UNIFORM_BLOCKS,
        gl_MAX_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_TESS_EVALUATION_INPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_EVALUATION_UNIFORM_BLOCKS,
        gl_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS, gl_MAX_TESS_GEN_LEVEL,
        gl_MAX_TESS_PATCH_COMPONENTS, gl_PATCHES,
        gl_PATCH_DEFAULT_INNER_LEVEL, gl_PATCH_DEFAULT_OUTER_LEVEL,
        gl_PATCH_VERTICES, gl_QUADS, gl_TESS_CONTROL_OUTPUT_VERTICES,
        gl_TESS_CONTROL_SHADER, gl_TESS_EVALUATION_SHADER,
        gl_TESS_GEN_MODE, gl_TESS_GEN_POINT_MODE, gl_TESS_GEN_SPACING,
        gl_TESS_GEN_VERTEX_ORDER, gl_TRIANGLES,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER,
        glPatchParameterfv, glPatchParameteri)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11 (gl_CCW)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11 (gl_CW)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_EQUAL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_FRACTIONAL_EVEN)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_FRACTIONAL_ODD)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ISOLINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_PATCH_VERTICES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_INPUT_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_OUTPUT_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_CONTROL_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_EVALUATION_INPUT_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_EVALUATION_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_GEN_LEVEL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TESS_PATCH_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_PATCHES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_PATCH_DEFAULT_INNER_LEVEL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_PATCH_DEFAULT_OUTER_LEVEL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_PATCH_VERTICES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_QUADS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_CONTROL_OUTPUT_VERTICES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_CONTROL_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_EVALUATION_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_GEN_MODE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_GEN_POINT_MODE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_GEN_SPACING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TESS_GEN_VERTEX_ORDER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_TRIANGLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glPatchParameterfv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glPatchParameteri)