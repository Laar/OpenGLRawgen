{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TextureRgb10A2ui
       (gl_RGB10_A2UI) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_RGB10_A2UI)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions