{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.SampleShading
       (gl_MIN_SAMPLE_SHADING_VALUE, gl_SAMPLE_SHADING,
        glMinSampleShading)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MIN_SAMPLE_SHADING_VALUE :: GLenum
gl_MIN_SAMPLE_SHADING_VALUE = 35895
 
gl_SAMPLE_SHADING :: GLenum
gl_SAMPLE_SHADING = 35894
 
foreign import CALLCONV unsafe "dynamic" dyn_glMinSampleShading ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glMinSampleShading :: GLfloat -> IO ()
glMinSampleShading = dyn_glMinSampleShading ptr_glMinSampleShading
 
{-# NOINLINE ptr_glMinSampleShading #-}
 
ptr_glMinSampleShading :: FunPtr a
ptr_glMinSampleShading
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sample_shading"
        "glMinSampleShadingARB"