module Graphics.Rendering.OpenGL.Raw.ARB.UniformBufferObject
       (gl_ACTIVE_UNIFORM_BLOCKS, gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH,
        gl_INVALID_INDEX, gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS,
        gl_MAX_FRAGMENT_UNIFORM_BLOCKS, gl_MAX_GEOMETRY_UNIFORM_BLOCKS,
        gl_MAX_UNIFORM_BLOCK_SIZE, gl_MAX_UNIFORM_BUFFER_BINDINGS,
        gl_MAX_VERTEX_UNIFORM_BLOCKS, gl_UNIFORM_ARRAY_STRIDE,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES, gl_UNIFORM_BLOCK_BINDING,
        gl_UNIFORM_BLOCK_DATA_SIZE, gl_UNIFORM_BLOCK_INDEX,
        gl_UNIFORM_BLOCK_NAME_LENGTH,
        gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER, gl_UNIFORM_BUFFER,
        gl_UNIFORM_BUFFER_BINDING, gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT,
        gl_UNIFORM_BUFFER_SIZE, gl_UNIFORM_BUFFER_START,
        gl_UNIFORM_IS_ROW_MAJOR, gl_UNIFORM_MATRIX_STRIDE,
        gl_UNIFORM_NAME_LENGTH, gl_UNIFORM_OFFSET, gl_UNIFORM_SIZE,
        gl_UNIFORM_TYPE, glGetActiveUniformBlockName,
        glGetActiveUniformBlockiv, glGetActiveUniformName,
        glGetActiveUniformsiv, glGetUniformBlockIndex, glGetUniformIndices,
        glUniformBlockBinding)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_ACTIVE_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_INVALID_INDEX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_COMBINED_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_FRAGMENT_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_UNIFORM_BLOCK_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_UNIFORM_BUFFER_BINDINGS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_MAX_VERTEX_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_ARRAY_STRIDE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_DATA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_INDEX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_NAME_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BUFFER_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_BUFFER_START)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_IS_ROW_MAJOR)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_MATRIX_STRIDE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_NAME_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetActiveUniformBlockName)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetActiveUniformBlockiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetActiveUniformName)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetActiveUniformsiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetUniformBlockIndex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glGetUniformIndices)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glUniformBlockBinding)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS :: GLenum
gl_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS = 35378
 
gl_MAX_GEOMETRY_UNIFORM_BLOCKS :: GLenum
gl_MAX_GEOMETRY_UNIFORM_BLOCKS = 35372
 
gl_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER :: GLenum
gl_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER = 35397