{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.RobustnessCompatibility
       (glGetnColorTable, glGetnConvolutionFilter, glGetnHistogram,
        glGetnMapdv, glGetnMapfv, glGetnMapiv, glGetnMinmax,
        glGetnPixelMapfv, glGetnPixelMapuiv, glGetnPixelMapusv,
        glGetnPolygonStipple, glGetnSeparableFilter)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnColorTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glGetnColorTable ::
                 GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ()
glGetnColorTable = dyn_glGetnColorTable ptr_glGetnColorTable
 
{-# NOINLINE ptr_glGetnColorTable #-}
 
ptr_glGetnColorTable :: FunPtr a
ptr_glGetnColorTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnColorTableARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnConvolutionFilter
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glGetnConvolutionFilter ::
                        GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ()
glGetnConvolutionFilter
  = dyn_glGetnConvolutionFilter ptr_glGetnConvolutionFilter
 
{-# NOINLINE ptr_glGetnConvolutionFilter #-}
 
ptr_glGetnConvolutionFilter :: FunPtr a
ptr_glGetnConvolutionFilter
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnConvolutionFilterARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnHistogram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnHistogram ::
                GLenum ->
                  GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnHistogram = dyn_glGetnHistogram ptr_glGetnHistogram
 
{-# NOINLINE ptr_glGetnHistogram #-}
 
ptr_glGetnHistogram :: FunPtr a
ptr_glGetnHistogram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnHistogramARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapdv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLdouble -> IO ())
 
glGetnMapdv :: GLenum -> GLenum -> GLsizei -> Ptr GLdouble -> IO ()
glGetnMapdv = dyn_glGetnMapdv ptr_glGetnMapdv
 
{-# NOINLINE ptr_glGetnMapdv #-}
 
ptr_glGetnMapdv :: FunPtr a
ptr_glGetnMapdv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapdvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnMapfv :: GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glGetnMapfv = dyn_glGetnMapfv ptr_glGetnMapfv
 
{-# NOINLINE ptr_glGetnMapfv #-}
 
ptr_glGetnMapfv :: FunPtr a
ptr_glGetnMapfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ())
 
glGetnMapiv :: GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ()
glGetnMapiv = dyn_glGetnMapiv ptr_glGetnMapiv
 
{-# NOINLINE ptr_glGetnMapiv #-}
 
ptr_glGetnMapiv :: FunPtr a
ptr_glGetnMapiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMinmax ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnMinmax ::
             GLenum ->
               GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnMinmax = dyn_glGetnMinmax ptr_glGetnMinmax
 
{-# NOINLINE ptr_glGetnMinmax #-}
 
ptr_glGetnMinmax :: FunPtr a
ptr_glGetnMinmax
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMinmaxARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnPixelMapfv :: GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glGetnPixelMapfv = dyn_glGetnPixelMapfv ptr_glGetnPixelMapfv
 
{-# NOINLINE ptr_glGetnPixelMapfv #-}
 
ptr_glGetnPixelMapfv :: FunPtr a
ptr_glGetnPixelMapfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLuint -> IO ())
 
glGetnPixelMapuiv :: GLenum -> GLsizei -> Ptr GLuint -> IO ()
glGetnPixelMapuiv = dyn_glGetnPixelMapuiv ptr_glGetnPixelMapuiv
 
{-# NOINLINE ptr_glGetnPixelMapuiv #-}
 
ptr_glGetnPixelMapuiv :: FunPtr a
ptr_glGetnPixelMapuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapuivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapusv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLushort -> IO ())
 
glGetnPixelMapusv :: GLenum -> GLsizei -> Ptr GLushort -> IO ()
glGetnPixelMapusv = dyn_glGetnPixelMapusv ptr_glGetnPixelMapusv
 
{-# NOINLINE ptr_glGetnPixelMapusv #-}
 
ptr_glGetnPixelMapusv :: FunPtr a
ptr_glGetnPixelMapusv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapusvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPolygonStipple ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLubyte -> IO ())
 
glGetnPolygonStipple :: GLsizei -> Ptr GLubyte -> IO ()
glGetnPolygonStipple
  = dyn_glGetnPolygonStipple ptr_glGetnPolygonStipple
 
{-# NOINLINE ptr_glGetnPolygonStipple #-}
 
ptr_glGetnPolygonStipple :: FunPtr a
ptr_glGetnPolygonStipple
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPolygonStippleARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnSeparableFilter
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLenum -> GLsizei -> Ptr f -> GLsizei -> Ptr h -> Ptr i -> IO ())
 
glGetnSeparableFilter ::
                      GLenum ->
                        GLenum ->
                          GLenum -> GLsizei -> Ptr f -> GLsizei -> Ptr h -> Ptr i -> IO ()
glGetnSeparableFilter
  = dyn_glGetnSeparableFilter ptr_glGetnSeparableFilter
 
{-# NOINLINE ptr_glGetnSeparableFilter #-}
 
ptr_glGetnSeparableFilter :: FunPtr a
ptr_glGetnSeparableFilter
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnSeparableFilterARB"