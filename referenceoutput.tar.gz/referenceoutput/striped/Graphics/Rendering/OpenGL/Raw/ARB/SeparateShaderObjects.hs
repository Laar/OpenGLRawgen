-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.SeparateShaderObjects
       (gl_ACTIVE_PROGRAM, gl_ALL_SHADER_BITS, gl_FRAGMENT_SHADER_BIT,
        gl_GEOMETRY_SHADER_BIT, gl_PROGRAM_PIPELINE_BINDING,
        gl_PROGRAM_SEPARABLE, gl_TESS_CONTROL_SHADER_BIT,
        gl_TESS_EVALUATION_SHADER_BIT, gl_VERTEX_SHADER_BIT,
        glActiveShaderProgram, glBindProgramPipeline,
        glCreateShaderProgramv, glDeleteProgramPipelines,
        glGenProgramPipelines, glGetProgramPipelineInfoLog,
        glGetProgramPipelineiv, glIsProgramPipeline, glProgramUniform1d,
        glProgramUniform1dv, glProgramUniform1f, glProgramUniform1fv,
        glProgramUniform1i, glProgramUniform1iv, glProgramUniform1ui,
        glProgramUniform1uiv, glProgramUniform2d, glProgramUniform2dv,
        glProgramUniform2f, glProgramUniform2fv, glProgramUniform2i,
        glProgramUniform2iv, glProgramUniform2ui, glProgramUniform2uiv,
        glProgramUniform3d, glProgramUniform3dv, glProgramUniform3f,
        glProgramUniform3fv, glProgramUniform3i, glProgramUniform3iv,
        glProgramUniform3ui, glProgramUniform3uiv, glProgramUniform4d,
        glProgramUniform4dv, glProgramUniform4f, glProgramUniform4fv,
        glProgramUniform4i, glProgramUniform4iv, glProgramUniform4ui,
        glProgramUniform4uiv, glProgramUniformMatrix2dv,
        glProgramUniformMatrix2fv, glProgramUniformMatrix2x3dv,
        glProgramUniformMatrix2x3fv, glProgramUniformMatrix2x4dv,
        glProgramUniformMatrix2x4fv, glProgramUniformMatrix3dv,
        glProgramUniformMatrix3fv, glProgramUniformMatrix3x2dv,
        glProgramUniformMatrix3x2fv, glProgramUniformMatrix3x4dv,
        glProgramUniformMatrix3x4fv, glProgramUniformMatrix4dv,
        glProgramUniformMatrix4fv, glProgramUniformMatrix4x2dv,
        glProgramUniformMatrix4x2fv, glProgramUniformMatrix4x3dv,
        glProgramUniformMatrix4x3fv, glUseProgramStages,
        glValidateProgramPipeline)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_ACTIVE_PROGRAM)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_ALL_SHADER_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_FRAGMENT_SHADER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_GEOMETRY_SHADER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_PROGRAM_PIPELINE_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_PROGRAM_SEPARABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_TESS_CONTROL_SHADER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_TESS_EVALUATION_SHADER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_VERTEX_SHADER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glActiveShaderProgram)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glBindProgramPipeline)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glCreateShaderProgramv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glDeleteProgramPipelines)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glGenProgramPipelines)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glGetProgramPipelineInfoLog)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glGetProgramPipelineiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glIsProgramPipeline)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1f)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform1uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2f)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3f)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4f)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniform4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2x3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2x3fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2x4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix2x4fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3x2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3x2fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3x4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix3x4fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4x2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4x2fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4x3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glProgramUniformMatrix4x3fv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glUseProgramStages)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glValidateProgramPipeline)