module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedbackInstanced
       (glDrawTransformFeedbackStreamInstanced,
        glDrawTransformFeedbackInstanced)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawTransformFeedbackStreamInstanced,
        glDrawTransformFeedbackInstanced)