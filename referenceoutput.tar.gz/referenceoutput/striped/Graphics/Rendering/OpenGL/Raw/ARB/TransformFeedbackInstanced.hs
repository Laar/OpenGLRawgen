module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedbackInstanced
       (glDrawTransformFeedbackInstanced,
        glDrawTransformFeedbackStreamInstanced)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawTransformFeedbackInstanced)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawTransformFeedbackStreamInstanced)