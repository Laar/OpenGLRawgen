{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.VertexBufferObject
       (gl_ARRAY_BUFFER, gl_ARRAY_BUFFER_BINDING, gl_BUFFER_ACCESS,
        gl_BUFFER_MAPPED, gl_BUFFER_MAP_POINTER, gl_BUFFER_SIZE,
        gl_BUFFER_USAGE, gl_COLOR_ARRAY_BUFFER_BINDING, gl_DYNAMIC_COPY,
        gl_DYNAMIC_DRAW, gl_DYNAMIC_READ,
        gl_EDGE_FLAG_ARRAY_BUFFER_BINDING, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING,
        gl_FOG_COORDINATE_ARRAY_BUFFER_BINDING,
        gl_INDEX_ARRAY_BUFFER_BINDING, gl_NORMAL_ARRAY_BUFFER_BINDING,
        gl_READ_ONLY, gl_READ_WRITE,
        gl_SECONDARY_COLOR_ARRAY_BUFFER_BINDING, gl_STATIC_COPY,
        gl_STATIC_DRAW, gl_STATIC_READ, gl_STREAM_COPY, gl_STREAM_DRAW,
        gl_STREAM_READ, gl_TEXTURE_COORD_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_WEIGHT_ARRAY_BUFFER_BINDING, gl_WRITE_ONLY, glBindBuffer,
        glBufferData, glBufferSubData, glDeleteBuffers, glGenBuffers,
        glGetBufferParameteriv, glGetBufferPointerv, glGetBufferSubData,
        glIsBuffer, glMapBuffer, glUnmapBuffer)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ARRAY_BUFFER :: GLenum
gl_ARRAY_BUFFER = 34962
 
gl_ARRAY_BUFFER_BINDING :: GLenum
gl_ARRAY_BUFFER_BINDING = 34964
 
gl_BUFFER_ACCESS :: GLenum
gl_BUFFER_ACCESS = 35003
 
gl_BUFFER_MAPPED :: GLenum
gl_BUFFER_MAPPED = 35004
 
gl_BUFFER_MAP_POINTER :: GLenum
gl_BUFFER_MAP_POINTER = 35005
 
gl_BUFFER_SIZE :: GLenum
gl_BUFFER_SIZE = 34660
 
gl_BUFFER_USAGE :: GLenum
gl_BUFFER_USAGE = 34661
 
gl_COLOR_ARRAY_BUFFER_BINDING :: GLenum
gl_COLOR_ARRAY_BUFFER_BINDING = 34968
 
gl_DYNAMIC_COPY :: GLenum
gl_DYNAMIC_COPY = 35050
 
gl_DYNAMIC_DRAW :: GLenum
gl_DYNAMIC_DRAW = 35048
 
gl_DYNAMIC_READ :: GLenum
gl_DYNAMIC_READ = 35049
 
gl_EDGE_FLAG_ARRAY_BUFFER_BINDING :: GLenum
gl_EDGE_FLAG_ARRAY_BUFFER_BINDING = 34971
 
gl_ELEMENT_ARRAY_BUFFER :: GLenum
gl_ELEMENT_ARRAY_BUFFER = 34963
 
gl_ELEMENT_ARRAY_BUFFER_BINDING :: GLenum
gl_ELEMENT_ARRAY_BUFFER_BINDING = 34965
 
gl_FOG_COORDINATE_ARRAY_BUFFER_BINDING :: GLenum
gl_FOG_COORDINATE_ARRAY_BUFFER_BINDING = 34973
 
gl_INDEX_ARRAY_BUFFER_BINDING :: GLenum
gl_INDEX_ARRAY_BUFFER_BINDING = 34969
 
gl_NORMAL_ARRAY_BUFFER_BINDING :: GLenum
gl_NORMAL_ARRAY_BUFFER_BINDING = 34967
 
gl_READ_ONLY :: GLenum
gl_READ_ONLY = 35000
 
gl_READ_WRITE :: GLenum
gl_READ_WRITE = 35002
 
gl_SECONDARY_COLOR_ARRAY_BUFFER_BINDING :: GLenum
gl_SECONDARY_COLOR_ARRAY_BUFFER_BINDING = 34972
 
gl_STATIC_COPY :: GLenum
gl_STATIC_COPY = 35046
 
gl_STATIC_DRAW :: GLenum
gl_STATIC_DRAW = 35044
 
gl_STATIC_READ :: GLenum
gl_STATIC_READ = 35045
 
gl_STREAM_COPY :: GLenum
gl_STREAM_COPY = 35042
 
gl_STREAM_DRAW :: GLenum
gl_STREAM_DRAW = 35040
 
gl_STREAM_READ :: GLenum
gl_STREAM_READ = 35041
 
gl_TEXTURE_COORD_ARRAY_BUFFER_BINDING :: GLenum
gl_TEXTURE_COORD_ARRAY_BUFFER_BINDING = 34970
 
gl_VERTEX_ARRAY_BUFFER_BINDING :: GLenum
gl_VERTEX_ARRAY_BUFFER_BINDING = 34966
 
gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING :: GLenum
gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = 34975
 
gl_WEIGHT_ARRAY_BUFFER_BINDING :: GLenum
gl_WEIGHT_ARRAY_BUFFER_BINDING = 34974
 
gl_WRITE_ONLY :: GLenum
gl_WRITE_ONLY = 35001
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindBuffer :: GLenum -> GLuint -> IO ()
glBindBuffer = dyn_glBindBuffer ptr_glBindBuffer
 
{-# NOINLINE ptr_glBindBuffer #-}
 
ptr_glBindBuffer :: FunPtr a
ptr_glBindBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glBindBufferARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizeiptr -> Ptr d -> GLenum -> IO ())
 
glBufferData :: GLenum -> GLsizeiptr -> Ptr d -> GLenum -> IO ()
glBufferData = dyn_glBufferData ptr_glBufferData
 
{-# NOINLINE ptr_glBufferData #-}
 
ptr_glBufferData :: FunPtr a
ptr_glBufferData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glBufferDataARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> Ptr e -> IO ())
 
glBufferSubData ::
                GLenum -> GLintptr -> GLsizeiptr -> Ptr e -> IO ()
glBufferSubData = dyn_glBufferSubData ptr_glBufferSubData
 
{-# NOINLINE ptr_glBufferSubData #-}
 
ptr_glBufferSubData :: FunPtr a
ptr_glBufferSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glBufferSubDataARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteBuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteBuffers :: GLsizei -> Ptr GLuint -> IO ()
glDeleteBuffers = dyn_glDeleteBuffers ptr_glDeleteBuffers
 
{-# NOINLINE ptr_glDeleteBuffers #-}
 
ptr_glDeleteBuffers :: FunPtr a
ptr_glDeleteBuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glDeleteBuffersARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenBuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenBuffers :: GLsizei -> Ptr GLuint -> IO ()
glGenBuffers = dyn_glGenBuffers ptr_glGenBuffers
 
{-# NOINLINE ptr_glGenBuffers #-}
 
ptr_glGenBuffers :: FunPtr a
ptr_glGenBuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glGenBuffersARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetBufferParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetBufferParameteriv
  = dyn_glGetBufferParameteriv ptr_glGetBufferParameteriv
 
{-# NOINLINE ptr_glGetBufferParameteriv #-}
 
ptr_glGetBufferParameteriv :: FunPtr a
ptr_glGetBufferParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glGetBufferParameterivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr (Ptr d) -> IO ())
 
glGetBufferPointerv :: GLenum -> GLenum -> Ptr (Ptr d) -> IO ()
glGetBufferPointerv
  = dyn_glGetBufferPointerv ptr_glGetBufferPointerv
 
{-# NOINLINE ptr_glGetBufferPointerv #-}
 
ptr_glGetBufferPointerv :: FunPtr a
ptr_glGetBufferPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glGetBufferPointervARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> Ptr e -> IO ())
 
glGetBufferSubData ::
                   GLenum -> GLintptr -> GLsizeiptr -> Ptr e -> IO ()
glGetBufferSubData = dyn_glGetBufferSubData ptr_glGetBufferSubData
 
{-# NOINLINE ptr_glGetBufferSubData #-}
 
ptr_glGetBufferSubData :: FunPtr a
ptr_glGetBufferSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glGetBufferSubDataARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsBuffer :: GLuint -> IO GLboolean
glIsBuffer = dyn_glIsBuffer ptr_glIsBuffer
 
{-# NOINLINE ptr_glIsBuffer #-}
 
ptr_glIsBuffer :: FunPtr a
ptr_glIsBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glIsBufferARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO (Ptr a))
 
glMapBuffer :: GLenum -> GLenum -> IO (Ptr a)
glMapBuffer = dyn_glMapBuffer ptr_glMapBuffer
 
{-# NOINLINE ptr_glMapBuffer #-}
 
ptr_glMapBuffer :: FunPtr a
ptr_glMapBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glMapBufferARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnmapBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLboolean)
 
glUnmapBuffer :: GLenum -> IO GLboolean
glUnmapBuffer = dyn_glUnmapBuffer ptr_glUnmapBuffer
 
{-# NOINLINE ptr_glUnmapBuffer #-}
 
ptr_glUnmapBuffer :: FunPtr a
ptr_glUnmapBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_buffer_object"
        "glUnmapBufferARB"