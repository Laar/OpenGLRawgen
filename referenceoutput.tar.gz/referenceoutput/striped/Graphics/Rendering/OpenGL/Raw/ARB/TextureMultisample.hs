module Graphics.Rendering.OpenGL.Raw.ARB.TextureMultisample
       (gl_INT_SAMPLER_2D_MULTISAMPLE,
        gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_MAX_COLOR_TEXTURE_SAMPLES,
        gl_MAX_DEPTH_TEXTURE_SAMPLES, gl_MAX_INTEGER_SAMPLES,
        gl_MAX_SAMPLE_MASK_WORDS, gl_PROXY_TEXTURE_2D_MULTISAMPLE,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY, gl_SAMPLER_2D_MULTISAMPLE,
        gl_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_SAMPLE_MASK,
        gl_SAMPLE_MASK_VALUE, gl_SAMPLE_POSITION,
        gl_TEXTURE_2D_MULTISAMPLE, gl_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_FIXED_SAMPLE_LOCATIONS, gl_TEXTURE_SAMPLES,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY, glGetMultisamplefv,
        glSampleMaski, glTexImage2DMultisample, glTexImage3DMultisample)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_INT_SAMPLER_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_MAX_COLOR_TEXTURE_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_MAX_DEPTH_TEXTURE_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_MAX_INTEGER_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_MAX_SAMPLE_MASK_WORDS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_PROXY_TEXTURE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SAMPLER_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SAMPLER_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SAMPLE_MASK)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SAMPLE_MASK_VALUE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SAMPLE_POSITION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_BINDING_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_FIXED_SAMPLE_LOCATIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glGetMultisamplefv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glSampleMaski)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glTexImage2DMultisample)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glTexImage3DMultisample)