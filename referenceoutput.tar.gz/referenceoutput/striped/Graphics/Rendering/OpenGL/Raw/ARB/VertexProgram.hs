-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexProgram
       (gl_COLOR_SUM, gl_CURRENT_MATRIX, gl_CURRENT_MATRIX_STACK_DEPTH,
        gl_CURRENT_VERTEX_ATTRIB, gl_MATRIX0, gl_MATRIX10, gl_MATRIX11,
        gl_MATRIX12, gl_MATRIX13, gl_MATRIX14, gl_MATRIX15, gl_MATRIX16,
        gl_MATRIX17, gl_MATRIX18, gl_MATRIX19, gl_MATRIX1, gl_MATRIX20,
        gl_MATRIX21, gl_MATRIX22, gl_MATRIX23, gl_MATRIX24, gl_MATRIX25,
        gl_MATRIX26, gl_MATRIX27, gl_MATRIX28, gl_MATRIX29, gl_MATRIX2,
        gl_MATRIX30, gl_MATRIX31, gl_MATRIX3, gl_MATRIX4, gl_MATRIX5,
        gl_MATRIX6, gl_MATRIX7, gl_MATRIX8, gl_MATRIX9,
        gl_MAX_PROGRAM_ADDRESS_REGISTERS, gl_MAX_PROGRAM_ATTRIBS,
        gl_MAX_PROGRAM_ENV_PARAMETERS, gl_MAX_PROGRAM_INSTRUCTIONS,
        gl_MAX_PROGRAM_LOCAL_PARAMETERS, gl_MAX_PROGRAM_MATRICES,
        gl_MAX_PROGRAM_MATRIX_STACK_DEPTH,
        gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS,
        gl_MAX_PROGRAM_NATIVE_ATTRIBS, gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS,
        gl_MAX_PROGRAM_NATIVE_PARAMETERS,
        gl_MAX_PROGRAM_NATIVE_TEMPORARIES, gl_MAX_PROGRAM_PARAMETERS,
        gl_MAX_PROGRAM_TEMPORARIES, gl_MAX_VERTEX_ATTRIBS,
        gl_PROGRAM_ADDRESS_REGISTERS, gl_PROGRAM_ATTRIBS,
        gl_PROGRAM_BINDING, gl_PROGRAM_ERROR_POSITION,
        gl_PROGRAM_ERROR_STRING, gl_PROGRAM_FORMAT,
        gl_PROGRAM_FORMAT_ASCII, gl_PROGRAM_INSTRUCTIONS,
        gl_PROGRAM_LENGTH, gl_PROGRAM_NATIVE_ADDRESS_REGISTERS,
        gl_PROGRAM_NATIVE_ATTRIBS, gl_PROGRAM_NATIVE_INSTRUCTIONS,
        gl_PROGRAM_NATIVE_PARAMETERS, gl_PROGRAM_NATIVE_TEMPORARIES,
        gl_PROGRAM_PARAMETERS, gl_PROGRAM_STRING, gl_PROGRAM_TEMPORARIES,
        gl_PROGRAM_UNDER_NATIVE_LIMITS, gl_TRANSPOSE_CURRENT_MATRIX,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED, gl_VERTEX_ATTRIB_ARRAY_NORMALIZED,
        gl_VERTEX_ATTRIB_ARRAY_POINTER, gl_VERTEX_ATTRIB_ARRAY_SIZE,
        gl_VERTEX_ATTRIB_ARRAY_STRIDE, gl_VERTEX_ATTRIB_ARRAY_TYPE,
        gl_VERTEX_PROGRAM, gl_VERTEX_PROGRAM_POINT_SIZE,
        gl_VERTEX_PROGRAM_TWO_SIDE, glBindProgram, glDeletePrograms,
        glDisableVertexAttribArray, glEnableVertexAttribArray,
        glGenPrograms, glGetProgramEnvParameterdv,
        glGetProgramEnvParameterfv, glGetProgramLocalParameterdv,
        glGetProgramLocalParameterfv, glGetProgramString, glGetProgramiv,
        glGetVertexAttribPointerv, glGetVertexAttribdv,
        glGetVertexAttribfv, glGetVertexAttribiv, glIsProgram,
        glProgramEnvParameter4d, glProgramEnvParameter4dv,
        glProgramEnvParameter4f, glProgramEnvParameter4fv,
        glProgramLocalParameter4d, glProgramLocalParameter4dv,
        glProgramLocalParameter4f, glProgramLocalParameter4fv,
        glProgramString, glVertexAttrib1d, glVertexAttrib1dv,
        glVertexAttrib1f, glVertexAttrib1fv, glVertexAttrib1s,
        glVertexAttrib1sv, glVertexAttrib2d, glVertexAttrib2dv,
        glVertexAttrib2f, glVertexAttrib2fv, glVertexAttrib2s,
        glVertexAttrib2sv, glVertexAttrib3d, glVertexAttrib3dv,
        glVertexAttrib3f, glVertexAttrib3fv, glVertexAttrib3s,
        glVertexAttrib3sv, glVertexAttrib4Nbv, glVertexAttrib4Niv,
        glVertexAttrib4Nsv, glVertexAttrib4Nub, glVertexAttrib4Nubv,
        glVertexAttrib4Nuiv, glVertexAttrib4Nusv, glVertexAttrib4bv,
        glVertexAttrib4d, glVertexAttrib4dv, glVertexAttrib4f,
        glVertexAttrib4fv, glVertexAttrib4iv, glVertexAttrib4s,
        glVertexAttrib4sv, glVertexAttrib4ubv, glVertexAttrib4uiv,
        glVertexAttrib4usv, glVertexAttribPointer)
       where
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_COLOR_SUM)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_MATRIX)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_MATRIX_STACK_DEPTH)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_VERTEX_ATTRIB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX0)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX10)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX11)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX12)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX13)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX14)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX15)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX16)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX17)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX18)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX19)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX1)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX20)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX21)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX22)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX23)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX24)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX25)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX26)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX27)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX28)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX29)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX2)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX30)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX31)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX3)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX4)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX5)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX6)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX7)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX8)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX9)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ADDRESS_REGISTERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ATTRIBS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ENV_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_INSTRUCTIONS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_LOCAL_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_MATRICES)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_MATRIX_STACK_DEPTH)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_ATTRIBS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_TEMPORARIES)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_TEMPORARIES)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_VERTEX_ATTRIBS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ADDRESS_REGISTERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ATTRIBS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_BINDING)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ERROR_POSITION)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ERROR_STRING)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_FORMAT)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_FORMAT_ASCII)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_INSTRUCTIONS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_LENGTH)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_ADDRESS_REGISTERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_ATTRIBS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_INSTRUCTIONS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_TEMPORARIES)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_PARAMETERS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_STRING)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_TEMPORARIES)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_UNDER_NATIVE_LIMITS)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_TRANSPOSE_CURRENT_MATRIX)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_ENABLED)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_NORMALIZED)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_POINTER)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_SIZE)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_STRIDE)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_TYPE)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM_POINT_SIZE)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM_TWO_SIDE)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glBindProgram)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glDeletePrograms)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glDisableVertexAttribArray)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glEnableVertexAttribArray)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGenPrograms)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramEnvParameterdv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramEnvParameterfv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramLocalParameterdv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramLocalParameterfv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramString)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramiv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribPointerv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribdv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribfv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribiv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glIsProgram)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramString)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1s)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1sv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2s)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2sv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3s)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3sv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nbv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Niv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nsv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nub)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nubv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nuiv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4Nusv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4bv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4d)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4dv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4f)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4fv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4iv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4s)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4sv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4ubv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4uiv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4usv)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttribPointer)