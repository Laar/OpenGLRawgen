{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.PointParameters
       (gl_POINT_DISTANCE_ATTENUATION, gl_POINT_FADE_THRESHOLD_SIZE,
        gl_POINT_SIZE_MAX, gl_POINT_SIZE_MIN, glPointParameterf,
        glPointParameterfv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_POINT_DISTANCE_ATTENUATION :: GLenum
gl_POINT_DISTANCE_ATTENUATION = 33065
 
gl_POINT_FADE_THRESHOLD_SIZE :: GLenum
gl_POINT_FADE_THRESHOLD_SIZE = 33064
 
gl_POINT_SIZE_MAX :: GLenum
gl_POINT_SIZE_MAX = 33063
 
gl_POINT_SIZE_MIN :: GLenum
gl_POINT_SIZE_MIN = 33062
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
glPointParameterf :: GLenum -> GLfloat -> IO ()
glPointParameterf = dyn_glPointParameterf ptr_glPointParameterf
 
{-# NOINLINE ptr_glPointParameterf #-}
 
ptr_glPointParameterf :: FunPtr a
ptr_glPointParameterf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_point_parameters"
        "glPointParameterfARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glPointParameterfv :: GLenum -> Ptr GLfloat -> IO ()
glPointParameterfv = dyn_glPointParameterfv ptr_glPointParameterfv
 
{-# NOINLINE ptr_glPointParameterfv #-}
 
ptr_glPointParameterfv :: FunPtr a
ptr_glPointParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_point_parameters"
        "glPointParameterfvARB"