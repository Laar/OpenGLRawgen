module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedback2
       (gl_TRANSFORM_FEEDBACK, gl_TRANSFORM_FEEDBACK_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BINDING, gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED, gl_TRANSFORM_FEEDBACK_PAUSED,
        glBindTransformFeedback, glDeleteTransformFeedbacks,
        glDrawTransformFeedback, glGenTransformFeedbacks,
        glIsTransformFeedback, glPauseTransformFeedback,
        glResumeTransformFeedback)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glBindTransformFeedback)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDeleteTransformFeedbacks)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawTransformFeedback)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGenTransformFeedbacks)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glIsTransformFeedback)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glPauseTransformFeedback)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glResumeTransformFeedback)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TRANSFORM_FEEDBACK_ACTIVE :: GLenum
gl_TRANSFORM_FEEDBACK_ACTIVE = gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE
 
gl_TRANSFORM_FEEDBACK_PAUSED :: GLenum
gl_TRANSFORM_FEEDBACK_PAUSED = gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED