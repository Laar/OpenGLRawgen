-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureStorageMultisample
       (glTexStorage2DMultisample, glTexStorage3DMultisample,
        glTextureStorage2DMultisample, glTextureStorage3DMultisample)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTexStorage2DMultisample)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTexStorage3DMultisample)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTextureStorage2DMultisample)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTextureStorage3DMultisample)