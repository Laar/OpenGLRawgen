{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ShadingLanguageInclude
       (gl_NAMED_STRING_LENGTH, gl_NAMED_STRING_TYPE, gl_SHADER_INCLUDE,
        glCompileShaderInclude, glDeleteNamedString, glGetNamedString,
        glGetNamedStringiv, glIsNamedString, glNamedString)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_NAMED_STRING_LENGTH :: GLenum
gl_NAMED_STRING_LENGTH = 36329
 
gl_NAMED_STRING_TYPE :: GLenum
gl_NAMED_STRING_TYPE = 36330
 
gl_SHADER_INCLUDE :: GLenum
gl_SHADER_INCLUDE = 36270
 
foreign import CALLCONV unsafe "dynamic" dyn_glCompileShaderInclude
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ())
 
glCompileShaderInclude ::
                       GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ()
glCompileShaderInclude
  = dyn_glCompileShaderInclude ptr_glCompileShaderInclude
 
{-# NOINLINE ptr_glCompileShaderInclude #-}
 
ptr_glCompileShaderInclude :: FunPtr a
ptr_glCompileShaderInclude
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glCompileShaderIncludeARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteNamedString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> IO ())
 
glDeleteNamedString :: GLint -> Ptr GLchar -> IO ()
glDeleteNamedString
  = dyn_glDeleteNamedString ptr_glDeleteNamedString
 
{-# NOINLINE ptr_glDeleteNamedString #-}
 
ptr_glDeleteNamedString :: FunPtr a
ptr_glDeleteNamedString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glDeleteNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetNamedString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    Ptr GLchar -> GLsizei -> Ptr GLint -> Ptr GLchar -> IO ())
 
glGetNamedString ::
                 GLint -> Ptr GLchar -> GLsizei -> Ptr GLint -> Ptr GLchar -> IO ()
glGetNamedString = dyn_glGetNamedString ptr_glGetNamedString
 
{-# NOINLINE ptr_glGetNamedString #-}
 
ptr_glGetNamedString :: FunPtr a
ptr_glGetNamedString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glGetNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetNamedStringiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedStringiv ::
                   GLint -> Ptr GLchar -> GLenum -> Ptr GLint -> IO ()
glGetNamedStringiv = dyn_glGetNamedStringiv ptr_glGetNamedStringiv
 
{-# NOINLINE ptr_glGetNamedStringiv #-}
 
ptr_glGetNamedStringiv :: FunPtr a
ptr_glGetNamedStringiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glGetNamedStringivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsNamedString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> IO GLboolean)
 
glIsNamedString :: GLint -> Ptr GLchar -> IO GLboolean
glIsNamedString = dyn_glIsNamedString ptr_glIsNamedString
 
{-# NOINLINE ptr_glIsNamedString #-}
 
ptr_glIsNamedString :: FunPtr a
ptr_glIsNamedString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glIsNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLchar -> GLint -> Ptr GLchar -> IO ())
 
glNamedString ::
              GLenum -> GLint -> Ptr GLchar -> GLint -> Ptr GLchar -> IO ()
glNamedString = dyn_glNamedString ptr_glNamedString
 
{-# NOINLINE ptr_glNamedString #-}
 
ptr_glNamedString :: FunPtr a
ptr_glNamedString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glNamedStringARB"