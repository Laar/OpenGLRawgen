module Graphics.Rendering.OpenGL.Raw.ARB.PointSprite
       (gl_POINT_SPRITE, gl_COORD_REPLACE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_POINT_SPRITE :: GLenum
gl_POINT_SPRITE = 34913
 
gl_COORD_REPLACE :: GLenum
gl_COORD_REPLACE = 34914