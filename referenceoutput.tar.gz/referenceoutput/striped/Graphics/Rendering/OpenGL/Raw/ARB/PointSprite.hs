-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.PointSprite
       (gl_COORD_REPLACE, gl_POINT_SPRITE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COORD_REPLACE :: GLenum
gl_COORD_REPLACE = 34914
 
gl_POINT_SPRITE :: GLenum
gl_POINT_SPRITE = 34913