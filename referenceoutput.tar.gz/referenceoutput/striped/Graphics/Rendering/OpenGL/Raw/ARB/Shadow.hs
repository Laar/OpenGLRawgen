-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Shadow
       (gl_COMPARE_R_TO_TEXTURE, gl_TEXTURE_COMPARE_FUNC,
        gl_TEXTURE_COMPARE_MODE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPARE_R_TO_TEXTURE :: GLenum
gl_COMPARE_R_TO_TEXTURE = 34894
 
gl_TEXTURE_COMPARE_FUNC :: GLenum
gl_TEXTURE_COMPARE_FUNC = 34893
 
gl_TEXTURE_COMPARE_MODE :: GLenum
gl_TEXTURE_COMPARE_MODE = 34892