-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.InternalformatQuery2
       (gl_AUTO_GENERATE_MIPMAP, gl_CAVEAT_SUPPORT, gl_CLEAR_BUFFER,
        gl_COLOR_COMPONENTS, gl_COLOR_ENCODING, gl_COLOR_RENDERABLE,
        gl_COMPUTE_TEXTURE, gl_DEPTH_COMPONENTS, gl_DEPTH_RENDERABLE,
        gl_FILTER, gl_FRAGMENT_TEXTURE, gl_FRAMEBUFFER_BLEND,
        gl_FRAMEBUFFER_RENDERABLE, gl_FRAMEBUFFER_RENDERABLE_LAYERED,
        gl_FULL_SUPPORT, gl_GEOMETRY_TEXTURE, gl_GET_TEXTURE_IMAGE_FORMAT,
        gl_GET_TEXTURE_IMAGE_TYPE, gl_IMAGE_CLASS_10_10_10_2,
        gl_IMAGE_CLASS_11_11_10, gl_IMAGE_CLASS_1_X_16,
        gl_IMAGE_CLASS_1_X_32, gl_IMAGE_CLASS_1_X_8, gl_IMAGE_CLASS_2_X_16,
        gl_IMAGE_CLASS_2_X_32, gl_IMAGE_CLASS_2_X_8, gl_IMAGE_CLASS_4_X_16,
        gl_IMAGE_CLASS_4_X_32, gl_IMAGE_CLASS_4_X_8,
        gl_IMAGE_COMPATIBILITY_CLASS, gl_IMAGE_FORMAT_COMPATIBILITY_TYPE,
        gl_IMAGE_PIXEL_FORMAT, gl_IMAGE_PIXEL_TYPE, gl_IMAGE_TEXEL_SIZE,
        gl_INTERNALFORMAT_ALPHA_SIZE, gl_INTERNALFORMAT_ALPHA_TYPE,
        gl_INTERNALFORMAT_BLUE_SIZE, gl_INTERNALFORMAT_BLUE_TYPE,
        gl_INTERNALFORMAT_DEPTH_SIZE, gl_INTERNALFORMAT_DEPTH_TYPE,
        gl_INTERNALFORMAT_GREEN_SIZE, gl_INTERNALFORMAT_GREEN_TYPE,
        gl_INTERNALFORMAT_PREFERRED, gl_INTERNALFORMAT_RED_SIZE,
        gl_INTERNALFORMAT_RED_TYPE, gl_INTERNALFORMAT_SHARED_SIZE,
        gl_INTERNALFORMAT_STENCIL_SIZE, gl_INTERNALFORMAT_STENCIL_TYPE,
        gl_INTERNALFORMAT_SUPPORTED, gl_MANUAL_GENERATE_MIPMAP,
        gl_MAX_COMBINED_DIMENSIONS, gl_MAX_DEPTH, gl_MAX_HEIGHT,
        gl_MAX_LAYERS, gl_MAX_WIDTH, gl_MIPMAP, gl_NUM_SAMPLE_COUNTS,
        gl_READ_PIXELS, gl_READ_PIXELS_FORMAT, gl_READ_PIXELS_TYPE,
        gl_RENDERBUFFER, gl_SAMPLES, gl_SHADER_IMAGE_ATOMIC,
        gl_SHADER_IMAGE_LOAD, gl_SHADER_IMAGE_STORE,
        gl_SIMULTANEOUS_TEXTURE_AND_DEPTH_TEST,
        gl_SIMULTANEOUS_TEXTURE_AND_DEPTH_WRITE,
        gl_SIMULTANEOUS_TEXTURE_AND_STENCIL_TEST,
        gl_SIMULTANEOUS_TEXTURE_AND_STENCIL_WRITE, gl_SRGB_DECODE,
        gl_SRGB_READ, gl_SRGB_WRITE, gl_STENCIL_COMPONENTS,
        gl_STENCIL_RENDERABLE, gl_TESS_CONTROL_TEXTURE,
        gl_TESS_EVALUATION_TEXTURE, gl_TEXTURE_1D, gl_TEXTURE_1D_ARRAY,
        gl_TEXTURE_2D, gl_TEXTURE_2D_ARRAY, gl_TEXTURE_2D_MULTISAMPLE,
        gl_TEXTURE_2D_MULTISAMPLE_ARRAY, gl_TEXTURE_3D, gl_TEXTURE_BUFFER,
        gl_TEXTURE_COMPRESSED, gl_TEXTURE_COMPRESSED_BLOCK_HEIGHT,
        gl_TEXTURE_COMPRESSED_BLOCK_SIZE,
        gl_TEXTURE_COMPRESSED_BLOCK_WIDTH, gl_TEXTURE_CUBE_MAP,
        gl_TEXTURE_CUBE_MAP_ARRAY, gl_TEXTURE_GATHER,
        gl_TEXTURE_GATHER_SHADOW, gl_TEXTURE_IMAGE_FORMAT,
        gl_TEXTURE_IMAGE_TYPE, gl_TEXTURE_RECTANGLE, gl_TEXTURE_SHADOW,
        gl_TEXTURE_VIEW, gl_VERTEX_TEXTURE, gl_VIEW_CLASS_128_BITS,
        gl_VIEW_CLASS_16_BITS, gl_VIEW_CLASS_24_BITS,
        gl_VIEW_CLASS_32_BITS, gl_VIEW_CLASS_48_BITS,
        gl_VIEW_CLASS_64_BITS, gl_VIEW_CLASS_8_BITS, gl_VIEW_CLASS_96_BITS,
        gl_VIEW_CLASS_BPTC_FLOAT, gl_VIEW_CLASS_BPTC_UNORM,
        gl_VIEW_CLASS_RGTC1_RED, gl_VIEW_CLASS_RGTC2_RG,
        gl_VIEW_CLASS_S3TC_DXT1_RGB, gl_VIEW_CLASS_S3TC_DXT1_RGBA,
        gl_VIEW_CLASS_S3TC_DXT3_RGBA, gl_VIEW_CLASS_S3TC_DXT5_RGBA,
        gl_VIEW_COMPATIBILITY_CLASS, glGetInternalformati64v)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_AUTO_GENERATE_MIPMAP)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_CAVEAT_SUPPORT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_CLEAR_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COLOR_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COLOR_ENCODING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COLOR_RENDERABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COMPUTE_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_DEPTH_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_DEPTH_RENDERABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FILTER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAGMENT_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_BLEND)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_RENDERABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FRAMEBUFFER_RENDERABLE_LAYERED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_FULL_SUPPORT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_GEOMETRY_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_GET_TEXTURE_IMAGE_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_GET_TEXTURE_IMAGE_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_10_10_10_2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_11_11_10)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_1_X_16)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_1_X_32)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_1_X_8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_2_X_16)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_2_X_32)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_2_X_8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_4_X_16)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_4_X_32)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_CLASS_4_X_8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_COMPATIBILITY_CLASS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_FORMAT_COMPATIBILITY_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_PIXEL_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_PIXEL_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_IMAGE_TEXEL_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_ALPHA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_ALPHA_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_BLUE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_BLUE_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_DEPTH_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_DEPTH_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_GREEN_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_GREEN_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_PREFERRED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_RED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_RED_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_SHARED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_STENCIL_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_STENCIL_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_INTERNALFORMAT_SUPPORTED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MANUAL_GENERATE_MIPMAP)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMBINED_DIMENSIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_DEPTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_LAYERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MIPMAP)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_NUM_SAMPLE_COUNTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_READ_PIXELS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_READ_PIXELS_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_READ_PIXELS_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core13
       (gl_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_IMAGE_ATOMIC)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_IMAGE_LOAD)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_IMAGE_STORE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SIMULTANEOUS_TEXTURE_AND_DEPTH_TEST)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SIMULTANEOUS_TEXTURE_AND_DEPTH_WRITE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SIMULTANEOUS_TEXTURE_AND_STENCIL_TEST)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SIMULTANEOUS_TEXTURE_AND_STENCIL_WRITE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SRGB_READ)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SRGB_WRITE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_STENCIL_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_STENCIL_RENDERABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TESS_CONTROL_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TESS_EVALUATION_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_TEXTURE_1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_1D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_TEXTURE_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_2D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_TEXTURE_3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_TEXTURE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core13
       (gl_TEXTURE_COMPRESSED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_COMPRESSED_BLOCK_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_COMPRESSED_BLOCK_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_COMPRESSED_BLOCK_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core13
       (gl_TEXTURE_CUBE_MAP)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_TEXTURE_CUBE_MAP_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_GATHER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_GATHER_SHADOW)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_IMAGE_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_IMAGE_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_TEXTURE_RECTANGLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_SHADOW)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_VIEW)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_TEXTURE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_128_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_16_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_24_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_32_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_48_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_64_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_8_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_96_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_BPTC_FLOAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_BPTC_UNORM)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_RGTC1_RED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_RGTC2_RG)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_S3TC_DXT1_RGB)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_S3TC_DXT1_RGBA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_S3TC_DXT3_RGBA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_CLASS_S3TC_DXT5_RGBA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VIEW_COMPATIBILITY_CLASS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glGetInternalformati64v)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SRGB_DECODE :: GLenum
gl_SRGB_DECODE = 33433