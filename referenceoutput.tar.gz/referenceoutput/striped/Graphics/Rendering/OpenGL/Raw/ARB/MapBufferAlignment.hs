{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferAlignment
       (gl_MIN_MAP_BUFFER_ALIGNMENT) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MIN_MAP_BUFFER_ALIGNMENT)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions