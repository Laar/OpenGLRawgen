-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ComputeShader
       (gl_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_COMPUTE_SHADER,
        gl_COMPUTE_LOCAL_WORK_SIZE, gl_COMPUTE_SHADER,
        gl_COMPUTE_SHADER_BIT, gl_DISPATCH_INDIRECT_BUFFER,
        gl_DISPATCH_INDIRECT_BUFFER_BINDING,
        gl_MAX_COMBINED_COMPUTE_UNIFORM_COMPONENTS,
        gl_MAX_COMPUTE_ATOMIC_COUNTERS,
        gl_MAX_COMPUTE_ATOMIC_COUNTER_BUFFERS,
        gl_MAX_COMPUTE_IMAGE_UNIFORMS, gl_MAX_COMPUTE_LOCAL_INVOCATIONS,
        gl_MAX_COMPUTE_SHARED_MEMORY_SIZE,
        gl_MAX_COMPUTE_TEXTURE_IMAGE_UNITS, gl_MAX_COMPUTE_UNIFORM_BLOCKS,
        gl_MAX_COMPUTE_UNIFORM_COMPONENTS, gl_MAX_COMPUTE_WORK_GROUP_COUNT,
        gl_MAX_COMPUTE_WORK_GROUP_SIZE,
        gl_UNIFORM_BLOCK_REFERENCED_BY_COMPUTE_SHADER, glDispatchCompute,
        glDispatchComputeIndirect)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_COMPUTE_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COMPUTE_LOCAL_WORK_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_COMPUTE_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_DISPATCH_INDIRECT_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_DISPATCH_INDIRECT_BUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMBINED_COMPUTE_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_ATOMIC_COUNTERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_ATOMIC_COUNTER_BUFFERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_LOCAL_INVOCATIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_SHARED_MEMORY_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_TEXTURE_IMAGE_UNITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_UNIFORM_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_WORK_GROUP_COUNT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_WORK_GROUP_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_UNIFORM_BLOCK_REFERENCED_BY_COMPUTE_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glDispatchCompute)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glDispatchComputeIndirect)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPUTE_SHADER_BIT :: GLbitfield
gl_COMPUTE_SHADER_BIT = 32