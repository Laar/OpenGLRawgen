module Graphics.Rendering.OpenGL.Raw.ARB.ShaderStorageBufferObject
       (gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS,
        gl_MAX_COMBINED_SHADER_OUTPUT_RESOURCES,
        gl_MAX_COMBINED_SHADER_STORAGE_BLOCKS,
        gl_MAX_COMPUTE_SHADER_STORAGE_BLOCKS,
        gl_MAX_FRAGMENT_SHADER_STORAGE_BLOCKS,
        gl_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS,
        gl_MAX_SHADER_STORAGE_BLOCK_SIZE,
        gl_MAX_SHADER_STORAGE_BUFFER_BINDINGS,
        gl_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS,
        gl_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS,
        gl_MAX_VERTEX_SHADER_STORAGE_BLOCKS, gl_SHADER_STORAGE_BARRIER_BIT,
        gl_SHADER_STORAGE_BUFFER, gl_SHADER_STORAGE_BUFFER_BINDING,
        gl_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT,
        gl_SHADER_STORAGE_BUFFER_SIZE, gl_SHADER_STORAGE_BUFFER_START,
        glShaderStorageBlockBinding)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMBINED_SHADER_OUTPUT_RESOURCES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMBINED_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_COMPUTE_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_FRAGMENT_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_SHADER_STORAGE_BLOCK_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_SHADER_STORAGE_BUFFER_BINDINGS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_VERTEX_SHADER_STORAGE_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BUFFER_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_SHADER_STORAGE_BUFFER_START)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glShaderStorageBlockBinding)