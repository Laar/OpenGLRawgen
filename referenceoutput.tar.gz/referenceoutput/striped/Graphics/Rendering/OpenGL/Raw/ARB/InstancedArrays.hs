{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.InstancedArrays
       (gl_VERTEX_ATTRIB_ARRAY_DIVISOR, glVertexAttribDivisor) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_VERTEX_ATTRIB_ARRAY_DIVISOR :: GLenum
gl_VERTEX_ATTRIB_ARRAY_DIVISOR = 35070
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribDivisor
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glVertexAttribDivisor :: GLuint -> GLuint -> IO ()
glVertexAttribDivisor
  = dyn_glVertexAttribDivisor ptr_glVertexAttribDivisor
 
{-# NOINLINE ptr_glVertexAttribDivisor #-}
 
ptr_glVertexAttribDivisor :: FunPtr a
ptr_glVertexAttribDivisor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_instanced_arrays"
        "glVertexAttribDivisorARB"