module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferRange
       (gl_MAP_FLUSH_EXPLICIT_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_READ_BIT,
        gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_WRITE_BIT,
        glFlushMappedBufferRange, glMapBufferRange)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_FLUSH_EXPLICIT_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_INVALIDATE_BUFFER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_INVALIDATE_RANGE_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_READ_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_UNSYNCHRONIZED_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_WRITE_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFlushMappedBufferRange)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glMapBufferRange)