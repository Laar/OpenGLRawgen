module Graphics.Rendering.OpenGL.Raw.ARB.TextureBorderClamp
       (gl_CLAMP_TO_BORDER) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CLAMP_TO_BORDER :: GLenum
gl_CLAMP_TO_BORDER = 33069