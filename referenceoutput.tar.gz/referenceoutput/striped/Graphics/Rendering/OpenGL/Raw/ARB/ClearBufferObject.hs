module Graphics.Rendering.OpenGL.Raw.ARB.ClearBufferObject
       (glClearNamedBufferSubData, glClearNamedBufferData,
        glClearBufferSubData, glClearBufferData)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glClearNamedBufferSubData, glClearNamedBufferData,
        glClearBufferSubData, glClearBufferData)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal