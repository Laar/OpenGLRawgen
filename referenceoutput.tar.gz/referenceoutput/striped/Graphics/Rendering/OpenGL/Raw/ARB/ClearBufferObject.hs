-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ClearBufferObject
       (glClearBufferData, glClearBufferSubData, glClearNamedBufferData,
        glClearNamedBufferSubData)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glClearBufferData)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glClearBufferSubData)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glClearNamedBufferData)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glClearNamedBufferSubData)