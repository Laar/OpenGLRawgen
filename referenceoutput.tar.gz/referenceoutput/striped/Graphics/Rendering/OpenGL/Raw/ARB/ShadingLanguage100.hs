module Graphics.Rendering.OpenGL.Raw.ARB.ShadingLanguage100
       (gl_SHADING_LANGUAGE_VERSION) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SHADING_LANGUAGE_VERSION :: GLenum
gl_SHADING_LANGUAGE_VERSION = 35724