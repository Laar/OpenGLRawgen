module Graphics.Rendering.OpenGL.Raw.ARB.VertexType2101010Rev
       (gl_INT_2_10_10_10_REV, gl_UNSIGNED_INT_2_10_10_10_REV,
        glColorP3ui, glColorP3uiv, glColorP4ui, glColorP4uiv,
        glMultiTexCoordP1ui, glMultiTexCoordP1uiv, glMultiTexCoordP2ui,
        glMultiTexCoordP2uiv, glMultiTexCoordP3ui, glMultiTexCoordP3uiv,
        glMultiTexCoordP4ui, glMultiTexCoordP4uiv, glNormalP3ui,
        glNormalP3uiv, glSecondaryColorP3ui, glSecondaryColorP3uiv,
        glTexCoordP1ui, glTexCoordP1uiv, glTexCoordP2ui, glTexCoordP2uiv,
        glTexCoordP3ui, glTexCoordP3uiv, glTexCoordP4ui, glTexCoordP4uiv,
        glVertexAttribP1ui, glVertexAttribP1uiv, glVertexAttribP2ui,
        glVertexAttribP2uiv, glVertexAttribP3ui, glVertexAttribP3uiv,
        glVertexAttribP4ui, glVertexAttribP4uiv, glVertexP2ui,
        glVertexP2uiv, glVertexP3ui, glVertexP3uiv, glVertexP4ui,
        glVertexP4uiv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_UNSIGNED_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glColorP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glColorP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glColorP4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glColorP4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP1ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP1uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glMultiTexCoordP4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glNormalP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glNormalP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSecondaryColorP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSecondaryColorP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP1ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP1uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glTexCoordP4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP1ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP1uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribP4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexP4uiv)