module Graphics.Rendering.OpenGL.Raw.ARB.TextureEnvDot3
       (gl_DOT3_RGBA, gl_DOT3_RGB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DOT3_RGBA :: GLenum
gl_DOT3_RGBA = 34479
 
gl_DOT3_RGB :: GLenum
gl_DOT3_RGB = 34478