module Graphics.Rendering.OpenGL.Raw.ARB.InternalformatQuery
       (glGetInternalformativ, gl_NUM_SAMPLE_COUNTS) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glGetInternalformativ, gl_NUM_SAMPLE_COUNTS)