{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.Robustness
       (gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT, gl_GUILTY_CONTEXT_RESET,
        gl_INNOCENT_CONTEXT_RESET, gl_LOSE_CONTEXT_ON_RESET, gl_NO_ERROR,
        gl_NO_RESET_NOTIFICATION, gl_RESET_NOTIFICATION_STRATEGY,
        gl_UNKNOWN_CONTEXT_RESET, glGetGraphicsResetStatus,
        glGetnCompressedTexImage, glGetnTexImage, glGetnUniformdv,
        glGetnUniformfv, glGetnUniformiv, glGetnUniformuiv, glReadnPixels)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_NO_ERROR)
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT :: GLbitfield
gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT = 4
 
gl_GUILTY_CONTEXT_RESET :: GLenum
gl_GUILTY_CONTEXT_RESET = 33363
 
gl_INNOCENT_CONTEXT_RESET :: GLenum
gl_INNOCENT_CONTEXT_RESET = 33364
 
gl_LOSE_CONTEXT_ON_RESET :: GLenum
gl_LOSE_CONTEXT_ON_RESET = 33362
 
gl_NO_RESET_NOTIFICATION :: GLenum
gl_NO_RESET_NOTIFICATION = 33377
 
gl_RESET_NOTIFICATION_STRATEGY :: GLenum
gl_RESET_NOTIFICATION_STRATEGY = 33366
 
gl_UNKNOWN_CONTEXT_RESET :: GLenum
gl_UNKNOWN_CONTEXT_RESET = 33365
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetGraphicsResetStatus ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (IO GLenum)
 
glGetGraphicsResetStatus :: IO GLenum
glGetGraphicsResetStatus
  = dyn_glGetGraphicsResetStatus ptr_glGetGraphicsResetStatus
 
{-# NOINLINE ptr_glGetGraphicsResetStatus #-}
 
ptr_glGetGraphicsResetStatus :: FunPtr a
ptr_glGetGraphicsResetStatus
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetGraphicsResetStatusARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetnCompressedTexImage ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> Ptr e -> IO ())
 
glGetnCompressedTexImage ::
                         GLenum -> GLint -> GLsizei -> Ptr e -> IO ()
glGetnCompressedTexImage
  = dyn_glGetnCompressedTexImage ptr_glGetnCompressedTexImage
 
{-# NOINLINE ptr_glGetnCompressedTexImage #-}
 
ptr_glGetnCompressedTexImage :: FunPtr a
ptr_glGetnCompressedTexImage
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnCompressedTexImageARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnTexImage ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnTexImage ::
               GLenum -> GLint -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnTexImage = dyn_glGetnTexImage ptr_glGetnTexImage
 
{-# NOINLINE ptr_glGetnTexImage #-}
 
ptr_glGetnTexImage :: FunPtr a
ptr_glGetnTexImage
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnTexImageARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformdv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glGetnUniformdv ::
                GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glGetnUniformdv = dyn_glGetnUniformdv ptr_glGetnUniformdv
 
{-# NOINLINE ptr_glGetnUniformdv #-}
 
ptr_glGetnUniformdv :: FunPtr a
ptr_glGetnUniformdv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformdvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnUniformfv ::
                GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glGetnUniformfv = dyn_glGetnUniformfv ptr_glGetnUniformfv
 
{-# NOINLINE ptr_glGetnUniformfv #-}
 
ptr_glGetnUniformfv :: FunPtr a
ptr_glGetnUniformfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glGetnUniformiv :: GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glGetnUniformiv = dyn_glGetnUniformiv ptr_glGetnUniformiv
 
{-# NOINLINE ptr_glGetnUniformiv #-}
 
ptr_glGetnUniformiv :: FunPtr a
ptr_glGetnUniformiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glGetnUniformuiv ::
                 GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glGetnUniformuiv = dyn_glGetnUniformuiv ptr_glGetnUniformuiv
 
{-# NOINLINE ptr_glGetnUniformuiv #-}
 
ptr_glGetnUniformuiv :: FunPtr a
ptr_glGetnUniformuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformuivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glReadnPixels ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    GLint ->
                      GLsizei ->
                        GLsizei -> GLenum -> GLenum -> GLsizei -> Ptr i -> IO ())
 
glReadnPixels ::
              GLint ->
                GLint ->
                  GLsizei -> GLsizei -> GLenum -> GLenum -> GLsizei -> Ptr i -> IO ()
glReadnPixels = dyn_glReadnPixels ptr_glReadnPixels
 
{-# NOINLINE ptr_glReadnPixels #-}
 
ptr_glReadnPixels :: FunPtr a
ptr_glReadnPixels
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glReadnPixelsARB"