module Graphics.Rendering.OpenGL.Raw.ARB.CopyImage
       (glCopyImageSubData) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glCopyImageSubData)