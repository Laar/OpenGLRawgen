{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.GeometryShader4
       (gl_FRAMEBUFFER_ATTACHMENT_LAYERED,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT,
        gl_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS, gl_GEOMETRY_INPUT_TYPE,
        gl_GEOMETRY_OUTPUT_TYPE, gl_GEOMETRY_SHADER,
        gl_GEOMETRY_VERTICES_OUT, gl_LINES_ADJACENCY,
        gl_LINE_STRIP_ADJACENCY, gl_MAX_GEOMETRY_OUTPUT_VERTICES,
        gl_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS,
        gl_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_GEOMETRY_UNIFORM_COMPONENTS,
        gl_MAX_GEOMETRY_VARYING_COMPONENTS, gl_MAX_VARYING_COMPONENTS,
        gl_MAX_VERTEX_VARYING_COMPONENTS, gl_PROGRAM_POINT_SIZE,
        gl_TRIANGLES_ADJACENCY, gl_TRIANGLE_STRIP_ADJACENCY,
        glFramebufferTexture, glFramebufferTextureFace,
        glFramebufferTextureLayer, glProgramParameteri)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAX_VARYING_COMPONENTS)
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FRAMEBUFFER_ATTACHMENT_LAYERED :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_LAYERED = 36263
 
gl_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT = 36265
 
gl_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS = 36264
 
gl_GEOMETRY_INPUT_TYPE :: GLenum
gl_GEOMETRY_INPUT_TYPE = 36315
 
gl_GEOMETRY_OUTPUT_TYPE :: GLenum
gl_GEOMETRY_OUTPUT_TYPE = 36316
 
gl_GEOMETRY_SHADER :: GLenum
gl_GEOMETRY_SHADER = 36313
 
gl_GEOMETRY_VERTICES_OUT :: GLenum
gl_GEOMETRY_VERTICES_OUT = 36314
 
gl_LINES_ADJACENCY :: GLenum
gl_LINES_ADJACENCY = 10
 
gl_LINE_STRIP_ADJACENCY :: GLenum
gl_LINE_STRIP_ADJACENCY = 11
 
gl_MAX_GEOMETRY_OUTPUT_VERTICES :: GLenum
gl_MAX_GEOMETRY_OUTPUT_VERTICES = 36320
 
gl_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS :: GLenum
gl_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS = 35881
 
gl_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS :: GLenum
gl_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS = 36321
 
gl_MAX_GEOMETRY_UNIFORM_COMPONENTS :: GLenum
gl_MAX_GEOMETRY_UNIFORM_COMPONENTS = 36319
 
gl_MAX_GEOMETRY_VARYING_COMPONENTS :: GLenum
gl_MAX_GEOMETRY_VARYING_COMPONENTS = 36317
 
gl_MAX_VERTEX_VARYING_COMPONENTS :: GLenum
gl_MAX_VERTEX_VARYING_COMPONENTS = 36318
 
gl_PROGRAM_POINT_SIZE :: GLenum
gl_PROGRAM_POINT_SIZE = 34370
 
gl_TRIANGLES_ADJACENCY :: GLenum
gl_TRIANGLES_ADJACENCY = 12
 
gl_TRIANGLE_STRIP_ADJACENCY :: GLenum
gl_TRIANGLE_STRIP_ADJACENCY = 13
 
foreign import CALLCONV unsafe "dynamic" dyn_glFramebufferTexture ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> GLint -> IO ())
 
glFramebufferTexture ::
                     GLenum -> GLenum -> GLuint -> GLint -> IO ()
glFramebufferTexture
  = dyn_glFramebufferTexture ptr_glFramebufferTexture
 
{-# NOINLINE ptr_glFramebufferTexture #-}
 
ptr_glFramebufferTexture :: FunPtr a
ptr_glFramebufferTexture
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_geometry_shader4"
        "glFramebufferTextureARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferTextureFace ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> GLint -> GLenum -> IO ())
 
glFramebufferTextureFace ::
                         GLenum -> GLenum -> GLuint -> GLint -> GLenum -> IO ()
glFramebufferTextureFace
  = dyn_glFramebufferTextureFace ptr_glFramebufferTextureFace
 
{-# NOINLINE ptr_glFramebufferTextureFace #-}
 
ptr_glFramebufferTextureFace :: FunPtr a
ptr_glFramebufferTextureFace
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_geometry_shader4"
        "glFramebufferTextureFaceARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferTextureLayer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ())
 
glFramebufferTextureLayer ::
                          GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ()
glFramebufferTextureLayer
  = dyn_glFramebufferTextureLayer ptr_glFramebufferTextureLayer
 
{-# NOINLINE ptr_glFramebufferTextureLayer #-}
 
ptr_glFramebufferTextureLayer :: FunPtr a
ptr_glFramebufferTextureLayer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_geometry_shader4"
        "glFramebufferTextureLayerARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
glProgramParameteri :: GLuint -> GLenum -> GLint -> IO ()
glProgramParameteri
  = dyn_glProgramParameteri ptr_glProgramParameteri
 
{-# NOINLINE ptr_glProgramParameteri #-}
 
ptr_glProgramParameteri :: FunPtr a
ptr_glProgramParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_geometry_shader4"
        "glProgramParameteriARB"