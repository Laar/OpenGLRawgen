-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Sync
       (gl_ALREADY_SIGNALED, gl_CONDITION_SATISFIED,
        gl_MAX_SERVER_WAIT_TIMEOUT, gl_OBJECT_TYPE, gl_SIGNALED,
        gl_SYNC_CONDITION, gl_SYNC_FENCE, gl_SYNC_FLAGS,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_STATUS, gl_TIMEOUT_EXPIRED, gl_TIMEOUT_IGNORED,
        gl_UNSIGNALED, gl_WAIT_FAILED, glClientWaitSync, glDeleteSync,
        glFenceSync, glGetInteger64v, glGetSynciv, glIsSync, glWaitSync)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_ALREADY_SIGNALED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_CONDITION_SATISFIED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_MAX_SERVER_WAIT_TIMEOUT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_OBJECT_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SIGNALED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_CONDITION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_FENCE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_FLAGS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_FLUSH_COMMANDS_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_GPU_COMMANDS_COMPLETE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_SYNC_STATUS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TIMEOUT_EXPIRED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TIMEOUT_IGNORED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_UNSIGNALED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_WAIT_FAILED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glClientWaitSync)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDeleteSync)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glFenceSync)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glGetInteger64v)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glGetSynciv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glIsSync)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glWaitSync)