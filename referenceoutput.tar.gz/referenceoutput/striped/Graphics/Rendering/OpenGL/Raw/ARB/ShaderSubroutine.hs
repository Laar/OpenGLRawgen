module Graphics.Rendering.OpenGL.Raw.ARB.ShaderSubroutine
       (gl_ACTIVE_SUBROUTINES, gl_ACTIVE_SUBROUTINE_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINE_UNIFORMS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH, gl_COMPATIBLE_SUBROUTINES,
        gl_MAX_SUBROUTINES, gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_NUM_COMPATIBLE_SUBROUTINES, gl_UNIFORM_NAME_LENGTH,
        gl_UNIFORM_SIZE, glGetActiveSubroutineName,
        glGetActiveSubroutineUniformName, glGetActiveSubroutineUniformiv,
        glGetProgramStageiv, glGetSubroutineIndex,
        glGetSubroutineUniformLocation, glGetUniformSubroutineuiv,
        glUniformSubroutinesuiv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ACTIVE_SUBROUTINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ACTIVE_SUBROUTINE_MAX_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ACTIVE_SUBROUTINE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_COMPATIBLE_SUBROUTINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_SUBROUTINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_NUM_COMPATIBLE_SUBROUTINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_NAME_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetActiveSubroutineName)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetActiveSubroutineUniformName)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetActiveSubroutineUniformiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetProgramStageiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetSubroutineIndex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetSubroutineUniformLocation)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetUniformSubroutineuiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformSubroutinesuiv)