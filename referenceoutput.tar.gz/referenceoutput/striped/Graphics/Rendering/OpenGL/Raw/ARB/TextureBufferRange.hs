module Graphics.Rendering.OpenGL.Raw.ARB.TextureBufferRange
       (gl_TEXTURE_BUFFER_OFFSET, gl_TEXTURE_BUFFER_OFFSET_ALIGNMENT,
        gl_TEXTURE_BUFFER_SIZE, glTexBufferRange, glTextureBufferRange)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_OFFSET_ALIGNMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTexBufferRange)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTextureBufferRange)