module Graphics.Rendering.OpenGL.Raw.ARB.DrawIndirect
       (glDrawElementsIndirect, glDrawArraysIndirect,
        gl_DRAW_INDIRECT_BUFFER_BINDING, gl_DRAW_INDIRECT_BUFFER)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawElementsIndirect, glDrawArraysIndirect,
        gl_DRAW_INDIRECT_BUFFER_BINDING, gl_DRAW_INDIRECT_BUFFER)