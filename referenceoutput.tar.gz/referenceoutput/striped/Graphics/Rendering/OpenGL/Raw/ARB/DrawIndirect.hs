module Graphics.Rendering.OpenGL.Raw.ARB.DrawIndirect
       (gl_DRAW_INDIRECT_BUFFER, gl_DRAW_INDIRECT_BUFFER_BINDING,
        glDrawArraysIndirect, glDrawElementsIndirect)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DRAW_INDIRECT_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DRAW_INDIRECT_BUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawArraysIndirect)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawElementsIndirect)