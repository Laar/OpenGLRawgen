-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ShadowAmbient
       (gl_TEXTURE_COMPARE_FAIL_VALUE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TEXTURE_COMPARE_FAIL_VALUE :: GLenum
gl_TEXTURE_COMPARE_FAIL_VALUE = 32959