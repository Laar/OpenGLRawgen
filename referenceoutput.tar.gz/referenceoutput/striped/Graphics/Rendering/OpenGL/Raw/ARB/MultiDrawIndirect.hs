module Graphics.Rendering.OpenGL.Raw.ARB.MultiDrawIndirect
       (glMultiDrawElementsIndirect, glMultiDrawArraysIndirect) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glMultiDrawElementsIndirect, glMultiDrawArraysIndirect)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal