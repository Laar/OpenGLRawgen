{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TextureBufferObject
       (gl_MAX_TEXTURE_BUFFER_SIZE, gl_TEXTURE_BINDING_BUFFER,
        gl_TEXTURE_BUFFER, gl_TEXTURE_BUFFER_DATA_STORE_BINDING,
        gl_TEXTURE_BUFFER_FORMAT, glTexBuffer)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MAX_TEXTURE_BUFFER_SIZE :: GLenum
gl_MAX_TEXTURE_BUFFER_SIZE = 35883
 
gl_TEXTURE_BINDING_BUFFER :: GLenum
gl_TEXTURE_BINDING_BUFFER = 35884
 
gl_TEXTURE_BUFFER :: GLenum
gl_TEXTURE_BUFFER = 35882
 
gl_TEXTURE_BUFFER_DATA_STORE_BINDING :: GLenum
gl_TEXTURE_BUFFER_DATA_STORE_BINDING = 35885
 
gl_TEXTURE_BUFFER_FORMAT :: GLenum
gl_TEXTURE_BUFFER_FORMAT = 35886
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
glTexBuffer :: GLenum -> GLenum -> GLuint -> IO ()
glTexBuffer = dyn_glTexBuffer ptr_glTexBuffer
 
{-# NOINLINE ptr_glTexBuffer #-}
 
ptr_glTexBuffer :: FunPtr a
ptr_glTexBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_buffer_object"
        "glTexBufferARB"