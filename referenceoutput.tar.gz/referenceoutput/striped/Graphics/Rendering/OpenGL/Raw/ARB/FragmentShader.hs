-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FragmentShader
       (gl_FRAGMENT_SHADER, gl_FRAGMENT_SHADER_DERIVATIVE_HINT,
        gl_MAX_FRAGMENT_UNIFORM_COMPONENTS)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FRAGMENT_SHADER :: GLenum
gl_FRAGMENT_SHADER = 35632
 
gl_FRAGMENT_SHADER_DERIVATIVE_HINT :: GLenum
gl_FRAGMENT_SHADER_DERIVATIVE_HINT = 35723
 
gl_MAX_FRAGMENT_UNIFORM_COMPONENTS :: GLenum
gl_MAX_FRAGMENT_UNIFORM_COMPONENTS = 35657