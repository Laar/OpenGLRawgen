-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.HalfFloatPixel
       (gl_HALF_FLOAT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_HALF_FLOAT :: GLenum
gl_HALF_FLOAT = 5131