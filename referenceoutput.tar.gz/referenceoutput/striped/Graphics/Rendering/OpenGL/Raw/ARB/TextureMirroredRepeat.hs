module Graphics.Rendering.OpenGL.Raw.ARB.TextureMirroredRepeat
       (gl_MIRRORED_REPEAT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MIRRORED_REPEAT :: GLenum
gl_MIRRORED_REPEAT = 33648