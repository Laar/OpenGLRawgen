-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureMirroredRepeat
       (gl_MIRRORED_REPEAT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MIRRORED_REPEAT :: GLenum
gl_MIRRORED_REPEAT = 33648