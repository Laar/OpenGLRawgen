{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ShaderObjects
       (gl_BOOL, gl_BOOL_VEC2, gl_BOOL_VEC3, gl_BOOL_VEC4, gl_FLOAT_MAT2,
        gl_FLOAT_MAT3, gl_FLOAT_MAT4, gl_FLOAT_VEC2, gl_FLOAT_VEC3,
        gl_FLOAT_VEC4, gl_INT_VEC2, gl_INT_VEC3, gl_INT_VEC4,
        gl_OBJECT_ACTIVE_UNIFORMS, gl_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH,
        gl_OBJECT_ATTACHED_OBJECTS, gl_OBJECT_COMPILE_STATUS,
        gl_OBJECT_DELETE_STATUS, gl_OBJECT_INFO_LOG_LENGTH,
        gl_OBJECT_LINK_STATUS, gl_OBJECT_SHADER_SOURCE_LENGTH,
        gl_OBJECT_SUBTYPE, gl_OBJECT_TYPE, gl_OBJECT_VALIDATE_STATUS,
        gl_PROGRAM_OBJECT, gl_SAMPLER_1D, gl_SAMPLER_1D_SHADOW,
        gl_SAMPLER_2D, gl_SAMPLER_2D_RECT, gl_SAMPLER_2D_RECT_SHADOW,
        gl_SAMPLER_2D_SHADOW, gl_SAMPLER_3D, gl_SAMPLER_CUBE,
        gl_SHADER_OBJECT, glAttachObject, glCompileShader,
        glCreateProgramObject, glCreateShaderObject, glDeleteObject,
        glDetachObject, glGetActiveUniform, glGetAttachedObjects,
        glGetHandle, glGetInfoLog, glGetObjectParameterfv,
        glGetObjectParameteriv, glGetShaderSource, glGetUniformLocation,
        glGetUniformfv, glGetUniformiv, glLinkProgram, glShaderSource,
        glUniform1f, glUniform1fv, glUniform1i, glUniform1iv, glUniform2f,
        glUniform2fv, glUniform2i, glUniform2iv, glUniform3f, glUniform3fv,
        glUniform3i, glUniform3iv, glUniform4f, glUniform4fv, glUniform4i,
        glUniform4iv, glUniformMatrix2fv, glUniformMatrix3fv,
        glUniformMatrix4fv, glUseProgramObject, glValidateProgram)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BOOL :: GLenum
gl_BOOL = 35670
 
gl_BOOL_VEC2 :: GLenum
gl_BOOL_VEC2 = 35671
 
gl_BOOL_VEC3 :: GLenum
gl_BOOL_VEC3 = 35672
 
gl_BOOL_VEC4 :: GLenum
gl_BOOL_VEC4 = 35673
 
gl_FLOAT_MAT2 :: GLenum
gl_FLOAT_MAT2 = 35674
 
gl_FLOAT_MAT3 :: GLenum
gl_FLOAT_MAT3 = 35675
 
gl_FLOAT_MAT4 :: GLenum
gl_FLOAT_MAT4 = 35676
 
gl_FLOAT_VEC2 :: GLenum
gl_FLOAT_VEC2 = 35664
 
gl_FLOAT_VEC3 :: GLenum
gl_FLOAT_VEC3 = 35665
 
gl_FLOAT_VEC4 :: GLenum
gl_FLOAT_VEC4 = 35666
 
gl_INT_VEC2 :: GLenum
gl_INT_VEC2 = 35667
 
gl_INT_VEC3 :: GLenum
gl_INT_VEC3 = 35668
 
gl_INT_VEC4 :: GLenum
gl_INT_VEC4 = 35669
 
gl_OBJECT_ACTIVE_UNIFORMS :: GLenum
gl_OBJECT_ACTIVE_UNIFORMS = 35718
 
gl_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH :: GLenum
gl_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH = 35719
 
gl_OBJECT_ATTACHED_OBJECTS :: GLenum
gl_OBJECT_ATTACHED_OBJECTS = 35717
 
gl_OBJECT_COMPILE_STATUS :: GLenum
gl_OBJECT_COMPILE_STATUS = 35713
 
gl_OBJECT_DELETE_STATUS :: GLenum
gl_OBJECT_DELETE_STATUS = 35712
 
gl_OBJECT_INFO_LOG_LENGTH :: GLenum
gl_OBJECT_INFO_LOG_LENGTH = 35716
 
gl_OBJECT_LINK_STATUS :: GLenum
gl_OBJECT_LINK_STATUS = 35714
 
gl_OBJECT_SHADER_SOURCE_LENGTH :: GLenum
gl_OBJECT_SHADER_SOURCE_LENGTH = 35720
 
gl_OBJECT_SUBTYPE :: GLenum
gl_OBJECT_SUBTYPE = 35663
 
gl_OBJECT_TYPE :: GLenum
gl_OBJECT_TYPE = 35662
 
gl_OBJECT_VALIDATE_STATUS :: GLenum
gl_OBJECT_VALIDATE_STATUS = 35715
 
gl_PROGRAM_OBJECT :: GLenum
gl_PROGRAM_OBJECT = 35648
 
gl_SAMPLER_1D :: GLenum
gl_SAMPLER_1D = 35677
 
gl_SAMPLER_1D_SHADOW :: GLenum
gl_SAMPLER_1D_SHADOW = 35681
 
gl_SAMPLER_2D :: GLenum
gl_SAMPLER_2D = 35678
 
gl_SAMPLER_2D_RECT :: GLenum
gl_SAMPLER_2D_RECT = 35683
 
gl_SAMPLER_2D_RECT_SHADOW :: GLenum
gl_SAMPLER_2D_RECT_SHADOW = 35684
 
gl_SAMPLER_2D_SHADOW :: GLenum
gl_SAMPLER_2D_SHADOW = 35682
 
gl_SAMPLER_3D :: GLenum
gl_SAMPLER_3D = 35679
 
gl_SAMPLER_CUBE :: GLenum
gl_SAMPLER_CUBE = 35680
 
gl_SHADER_OBJECT :: GLenum
gl_SHADER_OBJECT = 35656
 
foreign import CALLCONV unsafe "dynamic" dyn_glAttachObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLhandle -> IO ())
 
glAttachObject :: GLhandle -> GLhandle -> IO ()
glAttachObject = dyn_glAttachObject ptr_glAttachObject
 
{-# NOINLINE ptr_glAttachObject #-}
 
ptr_glAttachObject :: FunPtr a
ptr_glAttachObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glAttachObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCompileShader ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> IO ())
 
glCompileShader :: GLhandle -> IO ()
glCompileShader = dyn_glCompileShader ptr_glCompileShader
 
{-# NOINLINE ptr_glCompileShader #-}
 
ptr_glCompileShader :: FunPtr a
ptr_glCompileShader
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glCompileShaderARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCreateProgramObject
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (IO GLhandle)
 
glCreateProgramObject :: IO GLhandle
glCreateProgramObject
  = dyn_glCreateProgramObject ptr_glCreateProgramObject
 
{-# NOINLINE ptr_glCreateProgramObject #-}
 
ptr_glCreateProgramObject :: FunPtr a
ptr_glCreateProgramObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glCreateProgramObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCreateShaderObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLhandle)
 
glCreateShaderObject :: GLenum -> IO GLhandle
glCreateShaderObject
  = dyn_glCreateShaderObject ptr_glCreateShaderObject
 
{-# NOINLINE ptr_glCreateShaderObject #-}
 
ptr_glCreateShaderObject :: FunPtr a
ptr_glCreateShaderObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glCreateShaderObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> IO ())
 
glDeleteObject :: GLhandle -> IO ()
glDeleteObject = dyn_glDeleteObject ptr_glDeleteObject
 
{-# NOINLINE ptr_glDeleteObject #-}
 
ptr_glDeleteObject :: FunPtr a
ptr_glDeleteObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glDeleteObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDetachObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLhandle -> IO ())
 
glDetachObject :: GLhandle -> GLhandle -> IO ()
glDetachObject = dyn_glDetachObject ptr_glDetachObject
 
{-# NOINLINE ptr_glDetachObject #-}
 
ptr_glDetachObject :: FunPtr a
ptr_glDetachObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glDetachObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetActiveUniform ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle ->
                    GLuint ->
                      GLsizei ->
                        Ptr GLsizei -> Ptr GLint -> Ptr GLenum -> Ptr GLchar -> IO ())
 
glGetActiveUniform ::
                   GLhandle ->
                     GLuint ->
                       GLsizei ->
                         Ptr GLsizei -> Ptr GLint -> Ptr GLenum -> Ptr GLchar -> IO ()
glGetActiveUniform = dyn_glGetActiveUniform ptr_glGetActiveUniform
 
{-# NOINLINE ptr_glGetActiveUniform #-}
 
ptr_glGetActiveUniform :: FunPtr a
ptr_glGetActiveUniform
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetActiveUniformARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetAttachedObjects ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLhandle -> IO ())
 
glGetAttachedObjects ::
                     GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLhandle -> IO ()
glGetAttachedObjects
  = dyn_glGetAttachedObjects ptr_glGetAttachedObjects
 
{-# NOINLINE ptr_glGetAttachedObjects #-}
 
ptr_glGetAttachedObjects :: FunPtr a
ptr_glGetAttachedObjects
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetAttachedObjectsARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetHandle ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLhandle)
 
glGetHandle :: GLenum -> IO GLhandle
glGetHandle = dyn_glGetHandle ptr_glGetHandle
 
{-# NOINLINE ptr_glGetHandle #-}
 
ptr_glGetHandle :: FunPtr a
ptr_glGetHandle
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetHandleARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetInfoLog ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
glGetInfoLog ::
             GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetInfoLog = dyn_glGetInfoLog ptr_glGetInfoLog
 
{-# NOINLINE ptr_glGetInfoLog #-}
 
ptr_glGetInfoLog :: FunPtr a
ptr_glGetInfoLog
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetInfoLogARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetObjectParameterfv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLenum -> Ptr GLfloat -> IO ())
 
glGetObjectParameterfv ::
                       GLhandle -> GLenum -> Ptr GLfloat -> IO ()
glGetObjectParameterfv
  = dyn_glGetObjectParameterfv ptr_glGetObjectParameterfv
 
{-# NOINLINE ptr_glGetObjectParameterfv #-}
 
ptr_glGetObjectParameterfv :: FunPtr a
ptr_glGetObjectParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetObjectParameterfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetObjectParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLenum -> Ptr GLint -> IO ())
 
glGetObjectParameteriv :: GLhandle -> GLenum -> Ptr GLint -> IO ()
glGetObjectParameteriv
  = dyn_glGetObjectParameteriv ptr_glGetObjectParameteriv
 
{-# NOINLINE ptr_glGetObjectParameteriv #-}
 
ptr_glGetObjectParameteriv :: FunPtr a
ptr_glGetObjectParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetObjectParameterivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetShaderSource ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
glGetShaderSource ::
                  GLhandle -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetShaderSource = dyn_glGetShaderSource ptr_glGetShaderSource
 
{-# NOINLINE ptr_glGetShaderSource #-}
 
ptr_glGetShaderSource :: FunPtr a
ptr_glGetShaderSource
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetShaderSourceARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformLocation ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> Ptr GLchar -> IO GLint)
 
glGetUniformLocation :: GLhandle -> Ptr GLchar -> IO GLint
glGetUniformLocation
  = dyn_glGetUniformLocation ptr_glGetUniformLocation
 
{-# NOINLINE ptr_glGetUniformLocation #-}
 
ptr_glGetUniformLocation :: FunPtr a
ptr_glGetUniformLocation
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetUniformLocationARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLint -> Ptr GLfloat -> IO ())
 
glGetUniformfv :: GLhandle -> GLint -> Ptr GLfloat -> IO ()
glGetUniformfv = dyn_glGetUniformfv ptr_glGetUniformfv
 
{-# NOINLINE ptr_glGetUniformfv #-}
 
ptr_glGetUniformfv :: FunPtr a
ptr_glGetUniformfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetUniformfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLint -> Ptr GLint -> IO ())
 
glGetUniformiv :: GLhandle -> GLint -> Ptr GLint -> IO ()
glGetUniformiv = dyn_glGetUniformiv ptr_glGetUniformiv
 
{-# NOINLINE ptr_glGetUniformiv #-}
 
ptr_glGetUniformiv :: FunPtr a
ptr_glGetUniformiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glGetUniformivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glLinkProgram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> IO ())
 
glLinkProgram :: GLhandle -> IO ()
glLinkProgram = dyn_glLinkProgram ptr_glLinkProgram
 
{-# NOINLINE ptr_glLinkProgram #-}
 
ptr_glLinkProgram :: FunPtr a
ptr_glLinkProgram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glLinkProgramARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glShaderSource ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ())
 
glShaderSource ::
               GLhandle -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ()
glShaderSource = dyn_glShaderSource ptr_glShaderSource
 
{-# NOINLINE ptr_glShaderSource #-}
 
ptr_glShaderSource :: FunPtr a
ptr_glShaderSource
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glShaderSourceARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLfloat -> IO ())
 
glUniform1f :: GLint -> GLfloat -> IO ()
glUniform1f = dyn_glUniform1f ptr_glUniform1f
 
{-# NOINLINE ptr_glUniform1f #-}
 
ptr_glUniform1f :: FunPtr a
ptr_glUniform1f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform1fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glUniform1fv :: GLint -> GLsizei -> Ptr GLfloat -> IO ()
glUniform1fv = dyn_glUniform1fv ptr_glUniform1fv
 
{-# NOINLINE ptr_glUniform1fv #-}
 
ptr_glUniform1fv :: FunPtr a
ptr_glUniform1fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform1fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> IO ())
 
glUniform1i :: GLint -> GLint -> IO ()
glUniform1i = dyn_glUniform1i ptr_glUniform1i
 
{-# NOINLINE ptr_glUniform1i #-}
 
ptr_glUniform1i :: FunPtr a
ptr_glUniform1i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform1iARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint -> IO ())
 
glUniform1iv :: GLint -> GLsizei -> Ptr GLint -> IO ()
glUniform1iv = dyn_glUniform1iv ptr_glUniform1iv
 
{-# NOINLINE ptr_glUniform1iv #-}
 
ptr_glUniform1iv :: FunPtr a
ptr_glUniform1iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform1ivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLfloat -> GLfloat -> IO ())
 
glUniform2f :: GLint -> GLfloat -> GLfloat -> IO ()
glUniform2f = dyn_glUniform2f ptr_glUniform2f
 
{-# NOINLINE ptr_glUniform2f #-}
 
ptr_glUniform2f :: FunPtr a
ptr_glUniform2f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform2fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glUniform2fv :: GLint -> GLsizei -> Ptr GLfloat -> IO ()
glUniform2fv = dyn_glUniform2fv ptr_glUniform2fv
 
{-# NOINLINE ptr_glUniform2fv #-}
 
ptr_glUniform2fv :: FunPtr a
ptr_glUniform2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform2fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLint -> IO ())
 
glUniform2i :: GLint -> GLint -> GLint -> IO ()
glUniform2i = dyn_glUniform2i ptr_glUniform2i
 
{-# NOINLINE ptr_glUniform2i #-}
 
ptr_glUniform2i :: FunPtr a
ptr_glUniform2i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform2iARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint -> IO ())
 
glUniform2iv :: GLint -> GLsizei -> Ptr GLint -> IO ()
glUniform2iv = dyn_glUniform2iv ptr_glUniform2iv
 
{-# NOINLINE ptr_glUniform2iv #-}
 
ptr_glUniform2iv :: FunPtr a
ptr_glUniform2iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform2ivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glUniform3f :: GLint -> GLfloat -> GLfloat -> GLfloat -> IO ()
glUniform3f = dyn_glUniform3f ptr_glUniform3f
 
{-# NOINLINE ptr_glUniform3f #-}
 
ptr_glUniform3f :: FunPtr a
ptr_glUniform3f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform3fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glUniform3fv :: GLint -> GLsizei -> Ptr GLfloat -> IO ()
glUniform3fv = dyn_glUniform3fv ptr_glUniform3fv
 
{-# NOINLINE ptr_glUniform3fv #-}
 
ptr_glUniform3fv :: FunPtr a
ptr_glUniform3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform3fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLint -> GLint -> IO ())
 
glUniform3i :: GLint -> GLint -> GLint -> GLint -> IO ()
glUniform3i = dyn_glUniform3i ptr_glUniform3i
 
{-# NOINLINE ptr_glUniform3i #-}
 
ptr_glUniform3i :: FunPtr a
ptr_glUniform3i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform3iARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint -> IO ())
 
glUniform3iv :: GLint -> GLsizei -> Ptr GLint -> IO ()
glUniform3iv = dyn_glUniform3iv ptr_glUniform3iv
 
{-# NOINLINE ptr_glUniform3iv #-}
 
ptr_glUniform3iv :: FunPtr a
ptr_glUniform3iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform3ivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glUniform4f ::
            GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glUniform4f = dyn_glUniform4f ptr_glUniform4f
 
{-# NOINLINE ptr_glUniform4f #-}
 
ptr_glUniform4f :: FunPtr a
ptr_glUniform4f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform4fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glUniform4fv :: GLint -> GLsizei -> Ptr GLfloat -> IO ()
glUniform4fv = dyn_glUniform4fv ptr_glUniform4fv
 
{-# NOINLINE ptr_glUniform4fv #-}
 
ptr_glUniform4fv :: FunPtr a
ptr_glUniform4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform4fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glUniform4i :: GLint -> GLint -> GLint -> GLint -> GLint -> IO ()
glUniform4i = dyn_glUniform4i ptr_glUniform4i
 
{-# NOINLINE ptr_glUniform4i #-}
 
ptr_glUniform4i :: FunPtr a
ptr_glUniform4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform4iARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint -> IO ())
 
glUniform4iv :: GLint -> GLsizei -> Ptr GLint -> IO ()
glUniform4iv = dyn_glUniform4iv ptr_glUniform4iv
 
{-# NOINLINE ptr_glUniform4iv #-}
 
ptr_glUniform4iv :: FunPtr a
ptr_glUniform4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniform4ivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glUniformMatrix2fv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glUniformMatrix2fv = dyn_glUniformMatrix2fv ptr_glUniformMatrix2fv
 
{-# NOINLINE ptr_glUniformMatrix2fv #-}
 
ptr_glUniformMatrix2fv :: FunPtr a
ptr_glUniformMatrix2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniformMatrix2fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glUniformMatrix3fv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glUniformMatrix3fv = dyn_glUniformMatrix3fv ptr_glUniformMatrix3fv
 
{-# NOINLINE ptr_glUniformMatrix3fv #-}
 
ptr_glUniformMatrix3fv :: FunPtr a
ptr_glUniformMatrix3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniformMatrix3fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glUniformMatrix4fv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glUniformMatrix4fv = dyn_glUniformMatrix4fv ptr_glUniformMatrix4fv
 
{-# NOINLINE ptr_glUniformMatrix4fv #-}
 
ptr_glUniformMatrix4fv :: FunPtr a
ptr_glUniformMatrix4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUniformMatrix4fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUseProgramObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> IO ())
 
glUseProgramObject :: GLhandle -> IO ()
glUseProgramObject = dyn_glUseProgramObject ptr_glUseProgramObject
 
{-# NOINLINE ptr_glUseProgramObject #-}
 
ptr_glUseProgramObject :: FunPtr a
ptr_glUseProgramObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glUseProgramObjectARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glValidateProgram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> IO ())
 
glValidateProgram :: GLhandle -> IO ()
glValidateProgram = dyn_glValidateProgram ptr_glValidateProgram
 
{-# NOINLINE ptr_glValidateProgram #-}
 
ptr_glValidateProgram :: FunPtr a
ptr_glValidateProgram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_objects"
        "glValidateProgramARB"