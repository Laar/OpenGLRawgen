module Graphics.Rendering.OpenGL.Raw.ARB.BaseInstance
       (glDrawElementsInstancedBaseVertexBaseInstance,
        glDrawElementsInstancedBaseInstance,
        glDrawArraysInstancedBaseInstance)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawElementsInstancedBaseVertexBaseInstance,
        glDrawElementsInstancedBaseInstance,
        glDrawArraysInstancedBaseInstance)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal