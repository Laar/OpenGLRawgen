module Graphics.Rendering.OpenGL.Raw.ARB.BaseInstance
       (glDrawArraysInstancedBaseInstance,
        glDrawElementsInstancedBaseInstance,
        glDrawElementsInstancedBaseVertexBaseInstance)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawArraysInstancedBaseInstance)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawElementsInstancedBaseInstance)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawElementsInstancedBaseVertexBaseInstance)