module Graphics.Rendering.OpenGL.Raw.ARB.HalfFloatVertex
       (gl_HALF_FLOAT) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_HALF_FLOAT)