module Graphics.Rendering.OpenGL.Raw.ARB.DepthBufferFloat
       (gl_DEPTH32F_STENCIL8, gl_DEPTH_COMPONENT32F,
        gl_FLOAT_32_UNSIGNED_INT_24_8_REV)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH32F_STENCIL8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH_COMPONENT32F)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FLOAT_32_UNSIGNED_INT_24_8_REV)