module Graphics.Rendering.OpenGL.Raw.ARB.ImagingCompatibility
       (gl_COLOR_MATRIX, gl_COLOR_MATRIX_STACK_DEPTH, gl_COLOR_TABLE,
        gl_COLOR_TABLE_ALPHA_SIZE, gl_COLOR_TABLE_BIAS,
        gl_COLOR_TABLE_BLUE_SIZE, gl_COLOR_TABLE_FORMAT,
        gl_COLOR_TABLE_GREEN_SIZE, gl_COLOR_TABLE_INTENSITY_SIZE,
        gl_COLOR_TABLE_LUMINANCE_SIZE, gl_COLOR_TABLE_RED_SIZE,
        gl_COLOR_TABLE_SCALE, gl_COLOR_TABLE_WIDTH, gl_CONSTANT_BORDER,
        gl_CONVOLUTION_1D, gl_CONVOLUTION_2D, gl_CONVOLUTION_BORDER_COLOR,
        gl_CONVOLUTION_BORDER_MODE, gl_CONVOLUTION_FILTER_BIAS,
        gl_CONVOLUTION_FILTER_SCALE, gl_CONVOLUTION_FORMAT,
        gl_CONVOLUTION_HEIGHT, gl_CONVOLUTION_WIDTH, gl_HISTOGRAM,
        gl_HISTOGRAM_ALPHA_SIZE, gl_HISTOGRAM_BLUE_SIZE,
        gl_HISTOGRAM_FORMAT, gl_HISTOGRAM_GREEN_SIZE,
        gl_HISTOGRAM_LUMINANCE_SIZE, gl_HISTOGRAM_RED_SIZE,
        gl_HISTOGRAM_SINK, gl_HISTOGRAM_WIDTH,
        gl_MAX_COLOR_MATRIX_STACK_DEPTH, gl_MAX_CONVOLUTION_HEIGHT,
        gl_MAX_CONVOLUTION_WIDTH, gl_MINMAX, gl_MINMAX_FORMAT,
        gl_MINMAX_SINK, gl_POST_COLOR_MATRIX_ALPHA_BIAS,
        gl_POST_COLOR_MATRIX_ALPHA_SCALE, gl_POST_COLOR_MATRIX_BLUE_BIAS,
        gl_POST_COLOR_MATRIX_BLUE_SCALE, gl_POST_COLOR_MATRIX_COLOR_TABLE,
        gl_POST_COLOR_MATRIX_GREEN_BIAS, gl_POST_COLOR_MATRIX_GREEN_SCALE,
        gl_POST_COLOR_MATRIX_RED_BIAS, gl_POST_COLOR_MATRIX_RED_SCALE,
        gl_POST_CONVOLUTION_ALPHA_BIAS, gl_POST_CONVOLUTION_ALPHA_SCALE,
        gl_POST_CONVOLUTION_BLUE_BIAS, gl_POST_CONVOLUTION_BLUE_SCALE,
        gl_POST_CONVOLUTION_COLOR_TABLE, gl_POST_CONVOLUTION_GREEN_BIAS,
        gl_POST_CONVOLUTION_GREEN_SCALE, gl_POST_CONVOLUTION_RED_BIAS,
        gl_POST_CONVOLUTION_RED_SCALE, gl_PROXY_COLOR_TABLE,
        gl_PROXY_HISTOGRAM, gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE,
        gl_PROXY_POST_CONVOLUTION_COLOR_TABLE, gl_REDUCE,
        gl_REPLICATE_BORDER, gl_SEPARABLE_2D, gl_TABLE_TOO_LARGE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_MATRIX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_MATRIX_STACK_DEPTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_ALPHA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_BLUE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_GREEN_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_INTENSITY_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_LUMINANCE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_RED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_COLOR_TABLE_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONSTANT_BORDER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_BORDER_COLOR)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_BORDER_MODE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_FILTER_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_FILTER_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_CONVOLUTION_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_ALPHA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_BLUE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_GREEN_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_LUMINANCE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_RED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_SINK)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_HISTOGRAM_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MAX_COLOR_MATRIX_STACK_DEPTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MAX_CONVOLUTION_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MAX_CONVOLUTION_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MINMAX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MINMAX_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_MINMAX_SINK)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_ALPHA_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_ALPHA_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_BLUE_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_BLUE_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_GREEN_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_GREEN_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_RED_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_COLOR_MATRIX_RED_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_ALPHA_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_ALPHA_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_BLUE_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_BLUE_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_GREEN_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_GREEN_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_RED_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_POST_CONVOLUTION_RED_SCALE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_PROXY_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_PROXY_HISTOGRAM)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_PROXY_POST_CONVOLUTION_COLOR_TABLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_REDUCE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_REPLICATE_BORDER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_SEPARABLE_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_TABLE_TOO_LARGE)