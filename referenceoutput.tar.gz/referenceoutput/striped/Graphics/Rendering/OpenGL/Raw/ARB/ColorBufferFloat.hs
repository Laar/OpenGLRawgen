{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ColorBufferFloat
       (gl_CLAMP_FRAGMENT_COLOR, gl_CLAMP_READ_COLOR,
        gl_CLAMP_VERTEX_COLOR, gl_FIXED_ONLY, gl_RGBA_FLOAT_MODE,
        glClampColor)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CLAMP_FRAGMENT_COLOR :: GLenum
gl_CLAMP_FRAGMENT_COLOR = 35099
 
gl_CLAMP_READ_COLOR :: GLenum
gl_CLAMP_READ_COLOR = 35100
 
gl_CLAMP_VERTEX_COLOR :: GLenum
gl_CLAMP_VERTEX_COLOR = 35098
 
gl_FIXED_ONLY :: GLenum
gl_FIXED_ONLY = 35101
 
gl_RGBA_FLOAT_MODE :: GLenum
gl_RGBA_FLOAT_MODE = 34848
 
foreign import CALLCONV unsafe "dynamic" dyn_glClampColor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glClampColor :: GLenum -> GLenum -> IO ()
glClampColor = dyn_glClampColor ptr_glClampColor
 
{-# NOINLINE ptr_glClampColor #-}
 
ptr_glClampColor :: FunPtr a
ptr_glClampColor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_color_buffer_float"
        "glClampColorARB"