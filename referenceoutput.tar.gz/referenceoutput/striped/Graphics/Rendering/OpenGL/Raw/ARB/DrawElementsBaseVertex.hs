module Graphics.Rendering.OpenGL.Raw.ARB.DrawElementsBaseVertex
       (glDrawElementsBaseVertex, glDrawElementsInstancedBaseVertex,
        glDrawRangeElementsBaseVertex, glMultiDrawElementsBaseVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawElementsBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawElementsInstancedBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawRangeElementsBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glMultiDrawElementsBaseVertex)