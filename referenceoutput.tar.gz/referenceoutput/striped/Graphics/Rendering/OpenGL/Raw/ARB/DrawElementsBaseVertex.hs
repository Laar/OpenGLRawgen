module Graphics.Rendering.OpenGL.Raw.ARB.DrawElementsBaseVertex
       (glMultiDrawElementsBaseVertex, glDrawRangeElementsBaseVertex,
        glDrawElementsInstancedBaseVertex, glDrawElementsBaseVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glMultiDrawElementsBaseVertex, glDrawRangeElementsBaseVertex,
        glDrawElementsInstancedBaseVertex, glDrawElementsBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal