-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureMirrorClamp
       (gl_MIRROR_CLAMP, gl_MIRROR_CLAMP_TO_BORDER,
        gl_MIRROR_CLAMP_TO_EDGE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MIRROR_CLAMP :: GLenum
gl_MIRROR_CLAMP = 34626
 
gl_MIRROR_CLAMP_TO_BORDER :: GLenum
gl_MIRROR_CLAMP_TO_BORDER = 35090
 
gl_MIRROR_CLAMP_TO_EDGE :: GLenum
gl_MIRROR_CLAMP_TO_EDGE = 34627