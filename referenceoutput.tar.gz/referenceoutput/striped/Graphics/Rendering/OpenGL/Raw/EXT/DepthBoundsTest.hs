{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.DepthBoundsTest
       (gl_DEPTH_BOUNDS, gl_DEPTH_BOUNDS_TEST, glDepthBounds) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DEPTH_BOUNDS :: GLenum
gl_DEPTH_BOUNDS = 34961
 
gl_DEPTH_BOUNDS_TEST :: GLenum
gl_DEPTH_BOUNDS_TEST = 34960
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthBounds ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLclampd -> GLclampd -> IO ())
 
glDepthBounds :: GLclampd -> GLclampd -> IO ()
glDepthBounds = dyn_glDepthBounds ptr_glDepthBounds
 
{-# NOINLINE ptr_glDepthBounds #-}
 
ptr_glDepthBounds :: FunPtr a
ptr_glDepthBounds
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_depth_bounds_test"
        "glDepthBoundsEXT"