{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.IndexFunc
       (gl_INDEX_TEST, gl_INDEX_TEST_FUNC, gl_INDEX_TEST_REF, glIndexFunc)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_INDEX_TEST :: GLenum
gl_INDEX_TEST = 33205
 
gl_INDEX_TEST_FUNC :: GLenum
gl_INDEX_TEST_FUNC = 33206
 
gl_INDEX_TEST_REF :: GLenum
gl_INDEX_TEST_REF = 33207
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexFunc ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLclampf -> IO ())
 
glIndexFunc :: GLenum -> GLclampf -> IO ()
glIndexFunc = dyn_glIndexFunc ptr_glIndexFunc
 
{-# NOINLINE ptr_glIndexFunc #-}
 
ptr_glIndexFunc :: FunPtr a
ptr_glIndexFunc
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_index_func"
        "glIndexFuncEXT"