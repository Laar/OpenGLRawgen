{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.BlendMinmax
       (gl_BLEND_EQUATION, gl_FUNC_ADD, gl_MAX, gl_MIN, glBlendEquation)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BLEND_EQUATION :: GLenum
gl_BLEND_EQUATION = 32777
 
gl_FUNC_ADD :: GLenum
gl_FUNC_ADD = 32774
 
gl_MAX :: GLenum
gl_MAX = 32776
 
gl_MIN :: GLenum
gl_MIN = 32775
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendEquation ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glBlendEquation :: GLenum -> IO ()
glBlendEquation = dyn_glBlendEquation ptr_glBlendEquation
 
{-# NOINLINE ptr_glBlendEquation #-}
 
ptr_glBlendEquation :: FunPtr a
ptr_glBlendEquation
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_blend_minmax"
        "glBlendEquationEXT"