module Graphics.Rendering.OpenGL.Raw.EXT.RescaleNormal
       (gl_RESCALE_NORMAL) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RESCALE_NORMAL :: GLenum
gl_RESCALE_NORMAL = 32826