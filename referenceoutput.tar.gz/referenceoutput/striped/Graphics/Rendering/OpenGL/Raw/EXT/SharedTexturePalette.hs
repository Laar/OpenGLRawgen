module Graphics.Rendering.OpenGL.Raw.EXT.SharedTexturePalette
       (gl_SHARED_TEXTURE_PALETTE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SHARED_TEXTURE_PALETTE :: GLenum
gl_SHARED_TEXTURE_PALETTE = 33275