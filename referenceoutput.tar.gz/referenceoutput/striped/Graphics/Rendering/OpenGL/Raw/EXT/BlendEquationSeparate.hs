{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.BlendEquationSeparate
       (gl_BLEND_EQUATION_ALPHA, gl_BLEND_EQUATION_RGB,
        glBlendEquationSeparate)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BLEND_EQUATION_ALPHA :: GLenum
gl_BLEND_EQUATION_ALPHA = 34877
 
gl_BLEND_EQUATION_RGB :: GLenum
gl_BLEND_EQUATION_RGB = 32777
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendEquationSeparate
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glBlendEquationSeparate :: GLenum -> GLenum -> IO ()
glBlendEquationSeparate
  = dyn_glBlendEquationSeparate ptr_glBlendEquationSeparate
 
{-# NOINLINE ptr_glBlendEquationSeparate #-}
 
ptr_glBlendEquationSeparate :: FunPtr a
ptr_glBlendEquationSeparate
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_blend_equation_separate"
        "glBlendEquationSeparateEXT"