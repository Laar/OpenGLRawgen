module Graphics.Rendering.OpenGL.Raw.EXT.BlendSubtract
       (gl_FUNC_REVERSE_SUBTRACT, gl_FUNC_SUBTRACT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FUNC_REVERSE_SUBTRACT :: GLenum
gl_FUNC_REVERSE_SUBTRACT = 32779
 
gl_FUNC_SUBTRACT :: GLenum
gl_FUNC_SUBTRACT = 32778