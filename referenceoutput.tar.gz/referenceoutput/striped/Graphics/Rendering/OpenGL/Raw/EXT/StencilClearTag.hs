{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.StencilClearTag
       (gl_STENCIL_CLEAR_TAG_VALUE, gl_STENCIL_TAG_BITS,
        glStencilClearTag)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_STENCIL_CLEAR_TAG_VALUE :: GLenum
gl_STENCIL_CLEAR_TAG_VALUE = 35059
 
gl_STENCIL_TAG_BITS :: GLenum
gl_STENCIL_TAG_BITS = 35058
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilClearTag ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> GLuint -> IO ())
 
glStencilClearTag :: GLsizei -> GLuint -> IO ()
glStencilClearTag = dyn_glStencilClearTag ptr_glStencilClearTag
 
{-# NOINLINE ptr_glStencilClearTag #-}
 
ptr_glStencilClearTag :: FunPtr a
ptr_glStencilClearTag
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_stencil_clear_tag"
        "glStencilClearTagEXT"