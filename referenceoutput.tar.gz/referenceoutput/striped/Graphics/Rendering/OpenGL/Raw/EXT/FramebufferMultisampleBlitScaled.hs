module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferMultisampleBlitScaled
       (gl_SCALED_RESOLVE_FASTEST, gl_SCALED_RESOLVE_NICEST) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SCALED_RESOLVE_FASTEST :: GLenum
gl_SCALED_RESOLVE_FASTEST = 37050
 
gl_SCALED_RESOLVE_NICEST :: GLenum
gl_SCALED_RESOLVE_NICEST = 37051