-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureCompressionLatc
       (gl_COMPRESSED_LUMINANCE_ALPHA_LATC2,
        gl_COMPRESSED_LUMINANCE_LATC1,
        gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2,
        gl_COMPRESSED_SIGNED_LUMINANCE_LATC1)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPRESSED_LUMINANCE_ALPHA_LATC2 :: GLenum
gl_COMPRESSED_LUMINANCE_ALPHA_LATC2 = 35954
 
gl_COMPRESSED_LUMINANCE_LATC1 :: GLenum
gl_COMPRESSED_LUMINANCE_LATC1 = 35952
 
gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2 :: GLenum
gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2 = 35955
 
gl_COMPRESSED_SIGNED_LUMINANCE_LATC1 :: GLenum
gl_COMPRESSED_SIGNED_LUMINANCE_LATC1 = 35953