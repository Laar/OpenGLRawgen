{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.ColorSubtable
       (glColorSubTable, glCopyColorSubTable) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorSubTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ())
 
glColorSubTable ::
                GLenum -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ()
glColorSubTable = dyn_glColorSubTable ptr_glColorSubTable
 
{-# NOINLINE ptr_glColorSubTable #-}
 
ptr_glColorSubTable :: FunPtr a
ptr_glColorSubTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_color_subtable"
        "glColorSubTableEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyColorSubTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyColorSubTable ::
                    GLenum -> GLsizei -> GLint -> GLint -> GLsizei -> IO ()
glCopyColorSubTable
  = dyn_glCopyColorSubTable ptr_glCopyColorSubTable
 
{-# NOINLINE ptr_glCopyColorSubTable #-}
 
ptr_glCopyColorSubTable :: FunPtr a
ptr_glCopyColorSubTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_color_subtable"
        "glCopyColorSubTableEXT"