module Graphics.Rendering.OpenGL.Raw.EXT.StencilWrap
       (gl_DECR_WRAP, gl_INCR_WRAP) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DECR_WRAP :: GLenum
gl_DECR_WRAP = 34056
 
gl_INCR_WRAP :: GLenum
gl_INCR_WRAP = 34055