-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.PackedFloat
       (gl_R11F_G11F_B10F, gl_RGBA_SIGNED_COMPONENTS,
        gl_UNSIGNED_INT_10F_11F_11F_REV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_R11F_G11F_B10F :: GLenum
gl_R11F_G11F_B10F = 35898
 
gl_RGBA_SIGNED_COMPONENTS :: GLenum
gl_RGBA_SIGNED_COMPONENTS = 35900
 
gl_UNSIGNED_INT_10F_11F_11F_REV :: GLenum
gl_UNSIGNED_INT_10F_11F_11F_REV = 35899