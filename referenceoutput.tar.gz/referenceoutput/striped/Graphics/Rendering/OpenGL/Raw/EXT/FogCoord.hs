{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.FogCoord
       (gl_CURRENT_FOG_COORDINATE, gl_FOG_COORDINATE_ARRAY,
        gl_FOG_COORDINATE_ARRAY_POINTER, gl_FOG_COORDINATE_ARRAY_STRIDE,
        gl_FOG_COORDINATE_ARRAY_TYPE, gl_FOG_COORDINATE,
        gl_FOG_COORDINATE_SOURCE, gl_FRAGMENT_DEPTH, glFogCoordPointer,
        glFogCoordd, glFogCoorddv, glFogCoordf, glFogCoordfv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CURRENT_FOG_COORDINATE :: GLenum
gl_CURRENT_FOG_COORDINATE = 33875
 
gl_FOG_COORDINATE_ARRAY :: GLenum
gl_FOG_COORDINATE_ARRAY = 33879
 
gl_FOG_COORDINATE_ARRAY_POINTER :: GLenum
gl_FOG_COORDINATE_ARRAY_POINTER = 33878
 
gl_FOG_COORDINATE_ARRAY_STRIDE :: GLenum
gl_FOG_COORDINATE_ARRAY_STRIDE = 33877
 
gl_FOG_COORDINATE_ARRAY_TYPE :: GLenum
gl_FOG_COORDINATE_ARRAY_TYPE = 33876
 
gl_FOG_COORDINATE :: GLenum
gl_FOG_COORDINATE = 33873
 
gl_FOG_COORDINATE_SOURCE :: GLenum
gl_FOG_COORDINATE_SOURCE = 33872
 
gl_FRAGMENT_DEPTH :: GLenum
gl_FRAGMENT_DEPTH = 33874
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordPointer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr d -> IO ())
 
glFogCoordPointer :: GLenum -> GLsizei -> Ptr d -> IO ()
glFogCoordPointer = dyn_glFogCoordPointer ptr_glFogCoordPointer
 
{-# NOINLINE ptr_glFogCoordPointer #-}
 
ptr_glFogCoordPointer :: FunPtr a
ptr_glFogCoordPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_fog_coord"
        "glFogCoordPointerEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordd ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> IO ())
 
glFogCoordd :: GLdouble -> IO ()
glFogCoordd = dyn_glFogCoordd ptr_glFogCoordd
 
{-# NOINLINE ptr_glFogCoordd #-}
 
ptr_glFogCoordd :: FunPtr a
ptr_glFogCoordd
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_fog_coord"
        "glFogCoorddEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoorddv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
glFogCoorddv :: Ptr GLdouble -> IO ()
glFogCoorddv = dyn_glFogCoorddv ptr_glFogCoorddv
 
{-# NOINLINE ptr_glFogCoorddv #-}
 
ptr_glFogCoorddv :: FunPtr a
ptr_glFogCoorddv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_fog_coord"
        "glFogCoorddvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glFogCoordf :: GLfloat -> IO ()
glFogCoordf = dyn_glFogCoordf ptr_glFogCoordf
 
{-# NOINLINE ptr_glFogCoordf #-}
 
ptr_glFogCoordf :: FunPtr a
ptr_glFogCoordf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_fog_coord"
        "glFogCoordfEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
glFogCoordfv :: Ptr GLfloat -> IO ()
glFogCoordfv = dyn_glFogCoordfv ptr_glFogCoordfv
 
{-# NOINLINE ptr_glFogCoordfv #-}
 
ptr_glFogCoordfv :: FunPtr a
ptr_glFogCoordfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_fog_coord"
        "glFogCoordfvEXT"