module Graphics.Rendering.OpenGL.Raw.EXT.TextureSRGBDecode
       (gl_DECODE, gl_SKIP_DECODE, gl_TEXTURE_SRGB_DECODE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DECODE :: GLenum
gl_DECODE = 35401
 
gl_SKIP_DECODE :: GLenum
gl_SKIP_DECODE = 35402
 
gl_TEXTURE_SRGB_DECODE :: GLenum
gl_TEXTURE_SRGB_DECODE = 35400