{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.DrawRangeElements
       (gl_MAX_ELEMENTS_INDICES, gl_MAX_ELEMENTS_VERTICES,
        glDrawRangeElements)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MAX_ELEMENTS_INDICES :: GLenum
gl_MAX_ELEMENTS_INDICES = 33001
 
gl_MAX_ELEMENTS_VERTICES :: GLenum
gl_MAX_ELEMENTS_VERTICES = 33000
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawRangeElements ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> GLenum -> Ptr g -> IO ())
 
glDrawRangeElements ::
                    GLenum -> GLuint -> GLuint -> GLsizei -> GLenum -> Ptr g -> IO ()
glDrawRangeElements
  = dyn_glDrawRangeElements ptr_glDrawRangeElements
 
{-# NOINLINE ptr_glDrawRangeElements #-}
 
ptr_glDrawRangeElements :: FunPtr a
ptr_glDrawRangeElements
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_range_elements"
        "glDrawRangeElementsEXT"