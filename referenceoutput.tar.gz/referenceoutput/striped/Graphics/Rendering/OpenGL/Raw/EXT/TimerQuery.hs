{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TimerQuery
       (gl_TIME_ELAPSED, glGetQueryObjecti64v, glGetQueryObjectui64v)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TIME_ELAPSED :: GLenum
gl_TIME_ELAPSED = 35007
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjecti64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint64 -> IO ())
 
glGetQueryObjecti64v :: GLuint -> GLenum -> Ptr GLint64 -> IO ()
glGetQueryObjecti64v
  = dyn_glGetQueryObjecti64v ptr_glGetQueryObjecti64v
 
{-# NOINLINE ptr_glGetQueryObjecti64v #-}
 
ptr_glGetQueryObjecti64v :: FunPtr a
ptr_glGetQueryObjecti64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_timer_query"
        "glGetQueryObjecti64vEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjectui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint64 -> IO ())
 
glGetQueryObjectui64v :: GLuint -> GLenum -> Ptr GLuint64 -> IO ()
glGetQueryObjectui64v
  = dyn_glGetQueryObjectui64v ptr_glGetQueryObjectui64v
 
{-# NOINLINE ptr_glGetQueryObjectui64v #-}
 
ptr_glGetQueryObjectui64v :: FunPtr a
ptr_glGetQueryObjectui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_timer_query"
        "glGetQueryObjectui64vEXT"