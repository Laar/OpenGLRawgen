{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.IndexMaterial
       (gl_INDEX_MATERIAL, gl_INDEX_MATERIAL_FACE,
        gl_INDEX_MATERIAL_PARAMETER, glIndexMaterial)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_INDEX_MATERIAL :: GLenum
gl_INDEX_MATERIAL = 33208
 
gl_INDEX_MATERIAL_FACE :: GLenum
gl_INDEX_MATERIAL_FACE = 33210
 
gl_INDEX_MATERIAL_PARAMETER :: GLenum
gl_INDEX_MATERIAL_PARAMETER = 33209
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexMaterial ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glIndexMaterial :: GLenum -> GLenum -> IO ()
glIndexMaterial = dyn_glIndexMaterial ptr_glIndexMaterial
 
{-# NOINLINE ptr_glIndexMaterial #-}
 
ptr_glIndexMaterial :: FunPtr a
ptr_glIndexMaterial
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_index_material"
        "glIndexMaterialEXT"