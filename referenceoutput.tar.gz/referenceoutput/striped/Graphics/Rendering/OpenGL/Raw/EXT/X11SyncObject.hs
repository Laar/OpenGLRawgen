{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.X11SyncObject
       (gl_SYNC_X11_FENCE, glImportSync) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_SYNC_X11_FENCE :: GLenum
gl_SYNC_X11_FENCE = 37089
 
foreign import CALLCONV unsafe "dynamic" dyn_glImportSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLbitfield -> IO GLsync)
 
glImportSync :: GLenum -> GLintptr -> GLbitfield -> IO GLsync
glImportSync = dyn_glImportSync ptr_glImportSync
 
{-# NOINLINE ptr_glImportSync #-}
 
ptr_glImportSync :: FunPtr a
ptr_glImportSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_x11_sync_object"
        "glImportSyncEXT"