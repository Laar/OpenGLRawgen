-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.Bgra (gl_BGRA, gl_BGR)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_BGRA :: GLenum
gl_BGRA = 32993
 
gl_BGR :: GLenum
gl_BGR = 32992