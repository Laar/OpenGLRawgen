{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.CopyTexture
       (glCopyTexImage1D, glCopyTexImage2D, glCopyTexSubImage1D,
        glCopyTexSubImage2D, glCopyTexSubImage3D)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTexImage1D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ())
 
glCopyTexImage1D ::
                 GLenum ->
                   GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ()
glCopyTexImage1D = dyn_glCopyTexImage1D ptr_glCopyTexImage1D
 
{-# NOINLINE ptr_glCopyTexImage1D #-}
 
ptr_glCopyTexImage1D :: FunPtr a
ptr_glCopyTexImage1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_copy_texture"
        "glCopyTexImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTexImage2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ())
 
glCopyTexImage2D ::
                 GLenum ->
                   GLint ->
                     GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ()
glCopyTexImage2D = dyn_glCopyTexImage2D ptr_glCopyTexImage2D
 
{-# NOINLINE ptr_glCopyTexImage2D #-}
 
ptr_glCopyTexImage2D :: FunPtr a
ptr_glCopyTexImage2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_copy_texture"
        "glCopyTexImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTexSubImage1D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyTexSubImage1D ::
                    GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ()
glCopyTexSubImage1D
  = dyn_glCopyTexSubImage1D ptr_glCopyTexSubImage1D
 
{-# NOINLINE ptr_glCopyTexSubImage1D #-}
 
ptr_glCopyTexSubImage1D :: FunPtr a
ptr_glCopyTexSubImage1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_copy_texture"
        "glCopyTexSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTexSubImage2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyTexSubImage2D ::
                    GLenum ->
                      GLint ->
                        GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyTexSubImage2D
  = dyn_glCopyTexSubImage2D ptr_glCopyTexSubImage2D
 
{-# NOINLINE ptr_glCopyTexSubImage2D #-}
 
ptr_glCopyTexSubImage2D :: FunPtr a
ptr_glCopyTexSubImage2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_copy_texture"
        "glCopyTexSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTexSubImage3D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint ->
                        GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyTexSubImage3D ::
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyTexSubImage3D
  = dyn_glCopyTexSubImage3D ptr_glCopyTexSubImage3D
 
{-# NOINLINE ptr_glCopyTexSubImage3D #-}
 
ptr_glCopyTexSubImage3D :: FunPtr a
ptr_glCopyTexSubImage3D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_copy_texture"
        "glCopyTexSubImage3DEXT"