-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.Abgr (gl_ABGR) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ABGR :: GLenum
gl_ABGR = 32768