module Graphics.Rendering.OpenGL.Raw.EXT.Abgr (gl_ABGR) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ABGR :: GLenum
gl_ABGR = 32768