-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureSwizzle
       (gl_TEXTURE_SWIZZLE_A, gl_TEXTURE_SWIZZLE_B, gl_TEXTURE_SWIZZLE_G,
        gl_TEXTURE_SWIZZLE_RGBA, gl_TEXTURE_SWIZZLE_R)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TEXTURE_SWIZZLE_A :: GLenum
gl_TEXTURE_SWIZZLE_A = 36421
 
gl_TEXTURE_SWIZZLE_B :: GLenum
gl_TEXTURE_SWIZZLE_B = 36420
 
gl_TEXTURE_SWIZZLE_G :: GLenum
gl_TEXTURE_SWIZZLE_G = 36419
 
gl_TEXTURE_SWIZZLE_RGBA :: GLenum
gl_TEXTURE_SWIZZLE_RGBA = 36422
 
gl_TEXTURE_SWIZZLE_R :: GLenum
gl_TEXTURE_SWIZZLE_R = 36418