{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.TextureObject
       (gl_TEXTURE_1D_BINDING, gl_TEXTURE_2D_BINDING,
        gl_TEXTURE_3D_BINDING, gl_TEXTURE_PRIORITY, gl_TEXTURE_RESIDENT,
        glAreTexturesResident, glBindTexture, glDeleteTextures,
        glGenTextures, glIsTexture, glPrioritizeTextures)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TEXTURE_1D_BINDING :: GLenum
gl_TEXTURE_1D_BINDING = 32872
 
gl_TEXTURE_2D_BINDING :: GLenum
gl_TEXTURE_2D_BINDING = 32873
 
gl_TEXTURE_3D_BINDING :: GLenum
gl_TEXTURE_3D_BINDING = 32874
 
gl_TEXTURE_PRIORITY :: GLenum
gl_TEXTURE_PRIORITY = 32870
 
gl_TEXTURE_RESIDENT :: GLenum
gl_TEXTURE_RESIDENT = 32871
 
foreign import CALLCONV unsafe "dynamic" dyn_glAreTexturesResident
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> Ptr GLboolean -> IO GLboolean)
 
glAreTexturesResident ::
                      GLsizei -> Ptr GLuint -> Ptr GLboolean -> IO GLboolean
glAreTexturesResident
  = dyn_glAreTexturesResident ptr_glAreTexturesResident
 
{-# NOINLINE ptr_glAreTexturesResident #-}
 
ptr_glAreTexturesResident :: FunPtr a
ptr_glAreTexturesResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glAreTexturesResidentEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindTexture ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindTexture :: GLenum -> GLuint -> IO ()
glBindTexture = dyn_glBindTexture ptr_glBindTexture
 
{-# NOINLINE ptr_glBindTexture #-}
 
ptr_glBindTexture :: FunPtr a
ptr_glBindTexture
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glBindTextureEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteTextures ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteTextures :: GLsizei -> Ptr GLuint -> IO ()
glDeleteTextures = dyn_glDeleteTextures ptr_glDeleteTextures
 
{-# NOINLINE ptr_glDeleteTextures #-}
 
ptr_glDeleteTextures :: FunPtr a
ptr_glDeleteTextures
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glDeleteTexturesEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenTextures ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenTextures :: GLsizei -> Ptr GLuint -> IO ()
glGenTextures = dyn_glGenTextures ptr_glGenTextures
 
{-# NOINLINE ptr_glGenTextures #-}
 
ptr_glGenTextures :: FunPtr a
ptr_glGenTextures
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glGenTexturesEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsTexture ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsTexture :: GLuint -> IO GLboolean
glIsTexture = dyn_glIsTexture ptr_glIsTexture
 
{-# NOINLINE ptr_glIsTexture #-}
 
ptr_glIsTexture :: FunPtr a
ptr_glIsTexture
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glIsTextureEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPrioritizeTextures ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> Ptr GLclampf -> IO ())
 
glPrioritizeTextures ::
                     GLsizei -> Ptr GLuint -> Ptr GLclampf -> IO ()
glPrioritizeTextures
  = dyn_glPrioritizeTextures ptr_glPrioritizeTextures
 
{-# NOINLINE ptr_glPrioritizeTextures #-}
 
ptr_glPrioritizeTextures :: FunPtr a
ptr_glPrioritizeTextures
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_object"
        "glPrioritizeTexturesEXT"