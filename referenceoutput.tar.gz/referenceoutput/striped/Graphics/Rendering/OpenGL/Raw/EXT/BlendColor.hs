{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.BlendColor
       (gl_BLEND_COLOR, gl_CONSTANT_ALPHA, gl_CONSTANT_COLOR,
        gl_ONE_MINUS_CONSTANT_ALPHA, gl_ONE_MINUS_CONSTANT_COLOR,
        glBlendColor)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BLEND_COLOR :: GLenum
gl_BLEND_COLOR = 32773
 
gl_CONSTANT_ALPHA :: GLenum
gl_CONSTANT_ALPHA = 32771
 
gl_CONSTANT_COLOR :: GLenum
gl_CONSTANT_COLOR = 32769
 
gl_ONE_MINUS_CONSTANT_ALPHA :: GLenum
gl_ONE_MINUS_CONSTANT_ALPHA = 32772
 
gl_ONE_MINUS_CONSTANT_COLOR :: GLenum
gl_ONE_MINUS_CONSTANT_COLOR = 32770
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendColor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glBlendColor :: GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glBlendColor = dyn_glBlendColor ptr_glBlendColor
 
{-# NOINLINE ptr_glBlendColor #-}
 
ptr_glBlendColor :: FunPtr a
ptr_glBlendColor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_blend_color"
        "glBlendColorEXT"