{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.DrawBuffers2
       (glColorMaskIndexed, glDisableIndexed, glEnableIndexed,
        glGetBooleanIndexedv, glGetIntegerIndexedv, glIsEnabledIndexed)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorMaskIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
glColorMaskIndexed ::
                   GLuint -> GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glColorMaskIndexed = dyn_glColorMaskIndexed ptr_glColorMaskIndexed
 
{-# NOINLINE ptr_glColorMaskIndexed #-}
 
ptr_glColorMaskIndexed :: FunPtr a
ptr_glColorMaskIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glColorMaskIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisableIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisableIndexed :: GLenum -> GLuint -> IO ()
glDisableIndexed = dyn_glDisableIndexed ptr_glDisableIndexed
 
{-# NOINLINE ptr_glDisableIndexed #-}
 
ptr_glDisableIndexed :: FunPtr a
ptr_glDisableIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glDisableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnableIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnableIndexed :: GLenum -> GLuint -> IO ()
glEnableIndexed = dyn_glEnableIndexed ptr_glEnableIndexed
 
{-# NOINLINE ptr_glEnableIndexed #-}
 
ptr_glEnableIndexed :: FunPtr a
ptr_glEnableIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glEnableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBooleanIndexedv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLboolean -> IO ())
 
glGetBooleanIndexedv :: GLenum -> GLuint -> Ptr GLboolean -> IO ()
glGetBooleanIndexedv
  = dyn_glGetBooleanIndexedv ptr_glGetBooleanIndexedv
 
{-# NOINLINE ptr_glGetBooleanIndexedv #-}
 
ptr_glGetBooleanIndexedv :: FunPtr a
ptr_glGetBooleanIndexedv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glGetBooleanIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegerIndexedv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetIntegerIndexedv :: GLenum -> GLuint -> Ptr GLint -> IO ()
glGetIntegerIndexedv
  = dyn_glGetIntegerIndexedv ptr_glGetIntegerIndexedv
 
{-# NOINLINE ptr_glGetIntegerIndexedv #-}
 
ptr_glGetIntegerIndexedv :: FunPtr a
ptr_glGetIntegerIndexedv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glGetIntegerIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsEnabledIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsEnabledIndexed :: GLenum -> GLuint -> IO GLboolean
glIsEnabledIndexed = dyn_glIsEnabledIndexed ptr_glIsEnabledIndexed
 
{-# NOINLINE ptr_glIsEnabledIndexed #-}
 
ptr_glIsEnabledIndexed :: FunPtr a
ptr_glIsEnabledIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glIsEnabledIndexedEXT"