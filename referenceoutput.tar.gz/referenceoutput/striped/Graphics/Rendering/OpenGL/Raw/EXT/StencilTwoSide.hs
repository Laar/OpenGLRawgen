{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.StencilTwoSide
       (gl_ACTIVE_STENCIL_FACE, gl_STENCIL_TEST_TWO_SIDE,
        glActiveStencilFace)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ACTIVE_STENCIL_FACE :: GLenum
gl_ACTIVE_STENCIL_FACE = 35089
 
gl_STENCIL_TEST_TWO_SIDE :: GLenum
gl_STENCIL_TEST_TWO_SIDE = 35088
 
foreign import CALLCONV unsafe "dynamic" dyn_glActiveStencilFace ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glActiveStencilFace :: GLenum -> IO ()
glActiveStencilFace
  = dyn_glActiveStencilFace ptr_glActiveStencilFace
 
{-# NOINLINE ptr_glActiveStencilFace #-}
 
ptr_glActiveStencilFace :: FunPtr a
ptr_glActiveStencilFace
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_stencil_two_side"
        "glActiveStencilFaceEXT"