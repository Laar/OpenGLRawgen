{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.PolygonOffset
       (gl_POLYGON_OFFSET_BIAS, gl_POLYGON_OFFSET,
        gl_POLYGON_OFFSET_FACTOR, glPolygonOffset)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_POLYGON_OFFSET_BIAS :: GLenum
gl_POLYGON_OFFSET_BIAS = 32825
 
gl_POLYGON_OFFSET :: GLenum
gl_POLYGON_OFFSET = 32823
 
gl_POLYGON_OFFSET_FACTOR :: GLenum
gl_POLYGON_OFFSET_FACTOR = 32824
 
foreign import CALLCONV unsafe "dynamic" dyn_glPolygonOffset ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> IO ())
 
glPolygonOffset :: GLfloat -> GLfloat -> IO ()
glPolygonOffset = dyn_glPolygonOffset ptr_glPolygonOffset
 
{-# NOINLINE ptr_glPolygonOffset #-}
 
ptr_glPolygonOffset :: FunPtr a
ptr_glPolygonOffset
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_polygon_offset"
        "glPolygonOffsetEXT"