{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.ProvokingVertex
       (gl_FIRST_VERTEX_CONVENTION, gl_LAST_VERTEX_CONVENTION,
        gl_PROVOKING_VERTEX, gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION,
        glProvokingVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FIRST_VERTEX_CONVENTION :: GLenum
gl_FIRST_VERTEX_CONVENTION = 36429
 
gl_LAST_VERTEX_CONVENTION :: GLenum
gl_LAST_VERTEX_CONVENTION = 36430
 
gl_PROVOKING_VERTEX :: GLenum
gl_PROVOKING_VERTEX = 36431
 
gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION :: GLenum
gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION = 36428
 
foreign import CALLCONV unsafe "dynamic" dyn_glProvokingVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glProvokingVertex :: GLenum -> IO ()
glProvokingVertex = dyn_glProvokingVertex ptr_glProvokingVertex
 
{-# NOINLINE ptr_glProvokingVertex #-}
 
ptr_glProvokingVertex :: FunPtr a
ptr_glProvokingVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_provoking_vertex"
        "glProvokingVertexEXT"