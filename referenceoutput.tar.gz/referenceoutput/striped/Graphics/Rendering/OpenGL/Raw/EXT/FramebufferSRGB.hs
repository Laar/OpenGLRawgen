module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferSRGB
       (gl_FRAMEBUFFER_SRGB_CAPABLE, gl_FRAMEBUFFER_SRGB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FRAMEBUFFER_SRGB_CAPABLE :: GLenum
gl_FRAMEBUFFER_SRGB_CAPABLE = 36282
 
gl_FRAMEBUFFER_SRGB :: GLenum
gl_FRAMEBUFFER_SRGB = 36281