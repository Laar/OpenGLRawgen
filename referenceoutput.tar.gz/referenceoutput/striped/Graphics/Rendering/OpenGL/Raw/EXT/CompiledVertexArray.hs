{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.CompiledVertexArray
       (gl_ARRAY_ELEMENT_LOCK_COUNT, gl_ARRAY_ELEMENT_LOCK_FIRST,
        glLockArrays, glUnlockArrays)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ARRAY_ELEMENT_LOCK_COUNT :: GLenum
gl_ARRAY_ELEMENT_LOCK_COUNT = 33193
 
gl_ARRAY_ELEMENT_LOCK_FIRST :: GLenum
gl_ARRAY_ELEMENT_LOCK_FIRST = 33192
 
foreign import CALLCONV unsafe "dynamic" dyn_glLockArrays ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> IO ())
 
glLockArrays :: GLint -> GLsizei -> IO ()
glLockArrays = dyn_glLockArrays ptr_glLockArrays
 
{-# NOINLINE ptr_glLockArrays #-}
 
ptr_glLockArrays :: FunPtr a
ptr_glLockArrays
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_compiled_vertex_array"
        "glLockArraysEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnlockArrays ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glUnlockArrays :: IO ()
glUnlockArrays = dyn_glUnlockArrays ptr_glUnlockArrays
 
{-# NOINLINE ptr_glUnlockArrays #-}
 
ptr_glUnlockArrays :: FunPtr a
ptr_glUnlockArrays
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_compiled_vertex_array"
        "glUnlockArraysEXT"