-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureFilterAnisotropic
       (gl_MAX_TEXTURE_MAX_ANISOTROPY, gl_TEXTURE_MAX_ANISOTROPY) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_TEXTURE_MAX_ANISOTROPY :: GLenum
gl_MAX_TEXTURE_MAX_ANISOTROPY = 34047
 
gl_TEXTURE_MAX_ANISOTROPY :: GLenum
gl_TEXTURE_MAX_ANISOTROPY = 34046