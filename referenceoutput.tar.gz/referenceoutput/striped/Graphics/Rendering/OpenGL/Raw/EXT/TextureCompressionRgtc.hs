-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureCompressionRgtc
       (gl_COMPRESSED_RED_GREEN_RGTC2, gl_COMPRESSED_RED_RGTC1,
        gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPRESSED_RED_GREEN_RGTC2 :: GLenum
gl_COMPRESSED_RED_GREEN_RGTC2 = 36285
 
gl_COMPRESSED_RED_RGTC1 :: GLenum
gl_COMPRESSED_RED_RGTC1 = 36283
 
gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2 :: GLenum
gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2 = 36286
 
gl_COMPRESSED_SIGNED_RED_RGTC1 :: GLenum
gl_COMPRESSED_SIGNED_RED_RGTC1 = 36284