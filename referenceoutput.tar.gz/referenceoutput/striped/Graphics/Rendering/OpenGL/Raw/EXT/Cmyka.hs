-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.Cmyka
       (gl_CMYKA, gl_CMYK, gl_PACK_CMYK_HINT, gl_UNPACK_CMYK_HINT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CMYKA :: GLenum
gl_CMYKA = 32781
 
gl_CMYK :: GLenum
gl_CMYK = 32780
 
gl_PACK_CMYK_HINT :: GLenum
gl_PACK_CMYK_HINT = 32782
 
gl_UNPACK_CMYK_HINT :: GLenum
gl_UNPACK_CMYK_HINT = 32783