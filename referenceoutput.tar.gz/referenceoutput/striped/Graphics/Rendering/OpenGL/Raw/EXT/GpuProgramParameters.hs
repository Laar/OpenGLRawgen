{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.GpuProgramParameters
       (glProgramEnvParameters4fv, glProgramLocalParameters4fv) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameters4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramEnvParameters4fv ::
                          GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramEnvParameters4fv
  = dyn_glProgramEnvParameters4fv ptr_glProgramEnvParameters4fv
 
{-# NOINLINE ptr_glProgramEnvParameters4fv #-}
 
ptr_glProgramEnvParameters4fv :: FunPtr a
ptr_glProgramEnvParameters4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_gpu_program_parameters"
        "glProgramEnvParameters4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameters4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramLocalParameters4fv ::
                            GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramLocalParameters4fv
  = dyn_glProgramLocalParameters4fv ptr_glProgramLocalParameters4fv
 
{-# NOINLINE ptr_glProgramLocalParameters4fv #-}
 
ptr_glProgramLocalParameters4fv :: FunPtr a
ptr_glProgramLocalParameters4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_gpu_program_parameters"
        "glProgramLocalParameters4fvEXT"