module Graphics.Rendering.OpenGL.Raw.EXT.PackedDepthStencil
       (gl_DEPTH24_STENCIL8, gl_DEPTH_STENCIL, gl_TEXTURE_STENCIL_SIZE,
        gl_UNSIGNED_INT_24_8)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH24_STENCIL8 :: GLenum
gl_DEPTH24_STENCIL8 = 35056
 
gl_DEPTH_STENCIL :: GLenum
gl_DEPTH_STENCIL = 34041
 
gl_TEXTURE_STENCIL_SIZE :: GLenum
gl_TEXTURE_STENCIL_SIZE = 35057
 
gl_UNSIGNED_INT_24_8 :: GLenum
gl_UNSIGNED_INT_24_8 = 34042