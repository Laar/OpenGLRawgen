-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureEnvDot3
       (gl_DOT3_RGBA, gl_DOT3_RGB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DOT3_RGBA :: GLenum
gl_DOT3_RGBA = 34625
 
gl_DOT3_RGB :: GLenum
gl_DOT3_RGB = 34624