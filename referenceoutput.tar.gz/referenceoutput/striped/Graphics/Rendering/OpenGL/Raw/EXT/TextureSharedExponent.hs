-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureSharedExponent
       (gl_RGB9_E5, gl_TEXTURE_SHARED_SIZE, gl_UNSIGNED_INT_5_9_9_9_REV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RGB9_E5 :: GLenum
gl_RGB9_E5 = 35901
 
gl_TEXTURE_SHARED_SIZE :: GLenum
gl_TEXTURE_SHARED_SIZE = 35903
 
gl_UNSIGNED_INT_5_9_9_9_REV :: GLenum
gl_UNSIGNED_INT_5_9_9_9_REV = 35902