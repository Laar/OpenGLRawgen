-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureArray
       (gl_COMPARE_REF_DEPTH_TO_TEXTURE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_MAX_ARRAY_TEXTURE_LAYERS, gl_PROXY_TEXTURE_1D_ARRAY,
        gl_PROXY_TEXTURE_2D_ARRAY, gl_TEXTURE_1D_ARRAY,
        gl_TEXTURE_2D_ARRAY, gl_TEXTURE_BINDING_1D_ARRAY,
        gl_TEXTURE_BINDING_2D_ARRAY)
       where
import Graphics.Rendering.OpenGL.Raw.EXT.GeometryShader4
       (gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPARE_REF_DEPTH_TO_TEXTURE :: GLenum
gl_COMPARE_REF_DEPTH_TO_TEXTURE = 34894
 
gl_MAX_ARRAY_TEXTURE_LAYERS :: GLenum
gl_MAX_ARRAY_TEXTURE_LAYERS = 35071
 
gl_PROXY_TEXTURE_1D_ARRAY :: GLenum
gl_PROXY_TEXTURE_1D_ARRAY = 35865
 
gl_PROXY_TEXTURE_2D_ARRAY :: GLenum
gl_PROXY_TEXTURE_2D_ARRAY = 35867
 
gl_TEXTURE_1D_ARRAY :: GLenum
gl_TEXTURE_1D_ARRAY = 35864
 
gl_TEXTURE_2D_ARRAY :: GLenum
gl_TEXTURE_2D_ARRAY = 35866
 
gl_TEXTURE_BINDING_1D_ARRAY :: GLenum
gl_TEXTURE_BINDING_1D_ARRAY = 35868
 
gl_TEXTURE_BINDING_2D_ARRAY :: GLenum
gl_TEXTURE_BINDING_2D_ARRAY = 35869