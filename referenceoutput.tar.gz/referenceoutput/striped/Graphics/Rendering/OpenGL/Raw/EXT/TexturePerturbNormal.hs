{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TexturePerturbNormal
       (gl_PERTURB, gl_TEXTURE_NORMAL, glTextureNormal) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PERTURB :: GLenum
gl_PERTURB = 34222
 
gl_TEXTURE_NORMAL :: GLenum
gl_TEXTURE_NORMAL = 34223
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureNormal ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glTextureNormal :: GLenum -> IO ()
glTextureNormal = dyn_glTextureNormal ptr_glTextureNormal
 
{-# NOINLINE ptr_glTextureNormal #-}
 
ptr_glTextureNormal :: FunPtr a
ptr_glTextureNormal
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_perturb_normal"
        "glTextureNormalEXT"