module Graphics.Rendering.OpenGL.Raw.Core.Core10
       (module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10,
        module Graphics.Rendering.OpenGL.Raw.Types)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10
import Graphics.Rendering.OpenGL.Raw.Types