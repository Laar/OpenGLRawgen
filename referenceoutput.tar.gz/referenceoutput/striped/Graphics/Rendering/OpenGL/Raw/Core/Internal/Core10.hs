{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10
       (glBlendFunc, glClear, glClearColor, glClearDepth, glClearStencil,
        glColorMask, glCullFace, glDepthFunc, glDepthMask, glDepthRange,
        glDisable, glDrawBuffer, glEnable, glFinish, glFlush, glFrontFace,
        glGetBooleanv, glGetDoublev, glGetError, glGetFloatv,
        glGetIntegerv, glGetString, glGetTexImage,
        glGetTexLevelParameterfv, glGetTexLevelParameteriv,
        glGetTexParameterfv, glGetTexParameteriv, glHint, glIsEnabled,
        glLineWidth, glLogicOp, glPixelStoref, glPixelStorei, glPointSize,
        glPolygonMode, glReadBuffer, glReadPixels, glScissor,
        glStencilFunc, glStencilMask, glStencilOp, glTexImage1D,
        glTexImage2D, glTexParameterf, glTexParameterfv, glTexParameteri,
        glTexParameteriv, glViewport)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendFunc ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glBlendFunc :: GLenum -> GLenum -> IO ()
glBlendFunc = dyn_glBlendFunc ptr_glBlendFunc
 
{-# NOINLINE ptr_glBlendFunc #-}
 
ptr_glBlendFunc :: FunPtr a
ptr_glBlendFunc
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glBlendFunc"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClear ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
glClear :: GLbitfield -> IO ()
glClear = dyn_glClear ptr_glClear
 
{-# NOINLINE ptr_glClear #-}
 
ptr_glClear :: FunPtr a
ptr_glClear
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glClear"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearColor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glClearColor :: GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glClearColor = dyn_glClearColor ptr_glClearColor
 
{-# NOINLINE ptr_glClearColor #-}
 
ptr_glClearColor :: FunPtr a
ptr_glClearColor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glClearColor"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearDepth ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> IO ())
 
glClearDepth :: GLdouble -> IO ()
glClearDepth = dyn_glClearDepth ptr_glClearDepth
 
{-# NOINLINE ptr_glClearDepth #-}
 
ptr_glClearDepth :: FunPtr a
ptr_glClearDepth
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glClearDepth"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearStencil ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> IO ())
 
glClearStencil :: GLint -> IO ()
glClearStencil = dyn_glClearStencil ptr_glClearStencil
 
{-# NOINLINE ptr_glClearStencil #-}
 
ptr_glClearStencil :: FunPtr a
ptr_glClearStencil
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glClearStencil"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorMask ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
glColorMask ::
            GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glColorMask = dyn_glColorMask ptr_glColorMask
 
{-# NOINLINE ptr_glColorMask #-}
 
ptr_glColorMask :: FunPtr a
ptr_glColorMask
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glColorMask"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCullFace ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glCullFace :: GLenum -> IO ()
glCullFace = dyn_glCullFace ptr_glCullFace
 
{-# NOINLINE ptr_glCullFace #-}
 
ptr_glCullFace :: FunPtr a
ptr_glCullFace
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glCullFace"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthFunc ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glDepthFunc :: GLenum -> IO ()
glDepthFunc = dyn_glDepthFunc ptr_glDepthFunc
 
{-# NOINLINE ptr_glDepthFunc #-}
 
ptr_glDepthFunc :: FunPtr a
ptr_glDepthFunc
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glDepthFunc"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthMask ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLboolean -> IO ())
 
glDepthMask :: GLboolean -> IO ()
glDepthMask = dyn_glDepthMask ptr_glDepthMask
 
{-# NOINLINE ptr_glDepthMask #-}
 
ptr_glDepthMask :: FunPtr a
ptr_glDepthMask
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glDepthMask"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())
 
glDepthRange :: GLdouble -> GLdouble -> IO ()
glDepthRange = dyn_glDepthRange ptr_glDepthRange
 
{-# NOINLINE ptr_glDepthRange #-}
 
ptr_glDepthRange :: FunPtr a
ptr_glDepthRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glDepthRange"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glDisable :: GLenum -> IO ()
glDisable = dyn_glDisable ptr_glDisable
 
{-# NOINLINE ptr_glDisable #-}
 
ptr_glDisable :: FunPtr a
ptr_glDisable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glDisable"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glDrawBuffer :: GLenum -> IO ()
glDrawBuffer = dyn_glDrawBuffer ptr_glDrawBuffer
 
{-# NOINLINE ptr_glDrawBuffer #-}
 
ptr_glDrawBuffer :: FunPtr a
ptr_glDrawBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glDrawBuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glEnable :: GLenum -> IO ()
glEnable = dyn_glEnable ptr_glEnable
 
{-# NOINLINE ptr_glEnable #-}
 
ptr_glEnable :: FunPtr a
ptr_glEnable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glEnable"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinish ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glFinish :: IO ()
glFinish = dyn_glFinish ptr_glFinish
 
{-# NOINLINE ptr_glFinish #-}
 
ptr_glFinish :: FunPtr a
ptr_glFinish
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glFinish"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFlush ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glFlush :: IO ()
glFlush = dyn_glFlush ptr_glFlush
 
{-# NOINLINE ptr_glFlush #-}
 
ptr_glFlush :: FunPtr a
ptr_glFlush
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glFlush"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFrontFace ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glFrontFace :: GLenum -> IO ()
glFrontFace = dyn_glFrontFace ptr_glFrontFace
 
{-# NOINLINE ptr_glFrontFace #-}
 
ptr_glFrontFace :: FunPtr a
ptr_glFrontFace
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glFrontFace"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBooleanv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLboolean -> IO ())
 
glGetBooleanv :: GLenum -> Ptr GLboolean -> IO ()
glGetBooleanv = dyn_glGetBooleanv ptr_glGetBooleanv
 
{-# NOINLINE ptr_glGetBooleanv #-}
 
ptr_glGetBooleanv :: FunPtr a
ptr_glGetBooleanv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetBooleanv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDoublev ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glGetDoublev :: GLenum -> Ptr GLdouble -> IO ()
glGetDoublev = dyn_glGetDoublev ptr_glGetDoublev
 
{-# NOINLINE ptr_glGetDoublev #-}
 
ptr_glGetDoublev :: FunPtr a
ptr_glGetDoublev
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetDoublev"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetError ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (IO GLenum)
 
glGetError :: IO GLenum
glGetError = dyn_glGetError ptr_glGetError
 
{-# NOINLINE ptr_glGetError #-}
 
ptr_glGetError :: FunPtr a
ptr_glGetError
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetError"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFloatv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glGetFloatv :: GLenum -> Ptr GLfloat -> IO ()
glGetFloatv = dyn_glGetFloatv ptr_glGetFloatv
 
{-# NOINLINE ptr_glGetFloatv #-}
 
ptr_glGetFloatv :: FunPtr a
ptr_glGetFloatv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetFloatv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
glGetIntegerv :: GLenum -> Ptr GLint -> IO ()
glGetIntegerv = dyn_glGetIntegerv ptr_glGetIntegerv
 
{-# NOINLINE ptr_glGetIntegerv #-}
 
ptr_glGetIntegerv :: FunPtr a
ptr_glGetIntegerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetIntegerv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO (Ptr GLchar))
 
glGetString :: GLenum -> IO (Ptr GLchar)
glGetString = dyn_glGetString ptr_glGetString
 
{-# NOINLINE ptr_glGetString #-}
 
ptr_glGetString :: FunPtr a
ptr_glGetString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetString"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexImage ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> GLenum -> Ptr f -> IO ())
 
glGetTexImage ::
              GLenum -> GLint -> GLenum -> GLenum -> Ptr f -> IO ()
glGetTexImage = dyn_glGetTexImage ptr_glGetTexImage
 
{-# NOINLINE ptr_glGetTexImage #-}
 
ptr_glGetTexImage :: FunPtr a
ptr_glGetTexImage
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetTexImage"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTexLevelParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetTexLevelParameterfv ::
                         GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ()
glGetTexLevelParameterfv
  = dyn_glGetTexLevelParameterfv ptr_glGetTexLevelParameterfv
 
{-# NOINLINE ptr_glGetTexLevelParameterfv #-}
 
ptr_glGetTexLevelParameterfv :: FunPtr a
ptr_glGetTexLevelParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetTexLevelParameterfv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTexLevelParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> Ptr GLint -> IO ())
 
glGetTexLevelParameteriv ::
                         GLenum -> GLint -> GLenum -> Ptr GLint -> IO ()
glGetTexLevelParameteriv
  = dyn_glGetTexLevelParameteriv ptr_glGetTexLevelParameteriv
 
{-# NOINLINE ptr_glGetTexLevelParameteriv #-}
 
ptr_glGetTexLevelParameteriv :: FunPtr a
ptr_glGetTexLevelParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetTexLevelParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetTexParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetTexParameterfv
  = dyn_glGetTexParameterfv ptr_glGetTexParameterfv
 
{-# NOINLINE ptr_glGetTexParameterfv #-}
 
ptr_glGetTexParameterfv :: FunPtr a
ptr_glGetTexParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetTexParameterfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetTexParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetTexParameteriv
  = dyn_glGetTexParameteriv ptr_glGetTexParameteriv
 
{-# NOINLINE ptr_glGetTexParameteriv #-}
 
ptr_glGetTexParameteriv :: FunPtr a
ptr_glGetTexParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glGetTexParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glHint ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glHint :: GLenum -> GLenum -> IO ()
glHint = dyn_glHint ptr_glHint
 
{-# NOINLINE ptr_glHint #-}
 
ptr_glHint :: FunPtr a
ptr_glHint
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glHint"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsEnabled ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLboolean)
 
glIsEnabled :: GLenum -> IO GLboolean
glIsEnabled = dyn_glIsEnabled ptr_glIsEnabled
 
{-# NOINLINE ptr_glIsEnabled #-}
 
ptr_glIsEnabled :: FunPtr a
ptr_glIsEnabled
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glIsEnabled"
 
foreign import CALLCONV unsafe "dynamic" dyn_glLineWidth ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glLineWidth :: GLfloat -> IO ()
glLineWidth = dyn_glLineWidth ptr_glLineWidth
 
{-# NOINLINE ptr_glLineWidth #-}
 
ptr_glLineWidth :: FunPtr a
ptr_glLineWidth
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glLineWidth"
 
foreign import CALLCONV unsafe "dynamic" dyn_glLogicOp ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glLogicOp :: GLenum -> IO ()
glLogicOp = dyn_glLogicOp ptr_glLogicOp
 
{-# NOINLINE ptr_glLogicOp #-}
 
ptr_glLogicOp :: FunPtr a
ptr_glLogicOp
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glLogicOp"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPixelStoref ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
glPixelStoref :: GLenum -> GLfloat -> IO ()
glPixelStoref = dyn_glPixelStoref ptr_glPixelStoref
 
{-# NOINLINE ptr_glPixelStoref #-}
 
ptr_glPixelStoref :: FunPtr a
ptr_glPixelStoref
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glPixelStoref"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPixelStorei ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
glPixelStorei :: GLenum -> GLint -> IO ()
glPixelStorei = dyn_glPixelStorei ptr_glPixelStorei
 
{-# NOINLINE ptr_glPixelStorei #-}
 
ptr_glPixelStorei :: FunPtr a
ptr_glPixelStorei
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glPixelStorei"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointSize ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glPointSize :: GLfloat -> IO ()
glPointSize = dyn_glPointSize ptr_glPointSize
 
{-# NOINLINE ptr_glPointSize #-}
 
ptr_glPointSize :: FunPtr a
ptr_glPointSize
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glPointSize"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPolygonMode ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glPolygonMode :: GLenum -> GLenum -> IO ()
glPolygonMode = dyn_glPolygonMode ptr_glPolygonMode
 
{-# NOINLINE ptr_glPolygonMode #-}
 
ptr_glPolygonMode :: FunPtr a
ptr_glPolygonMode
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glPolygonMode"
 
foreign import CALLCONV unsafe "dynamic" dyn_glReadBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glReadBuffer :: GLenum -> IO ()
glReadBuffer = dyn_glReadBuffer ptr_glReadBuffer
 
{-# NOINLINE ptr_glReadBuffer #-}
 
ptr_glReadBuffer :: FunPtr a
ptr_glReadBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glReadBuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glReadPixels ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> IO ())
 
glReadPixels ::
             GLint ->
               GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> IO ()
glReadPixels = dyn_glReadPixels ptr_glReadPixels
 
{-# NOINLINE ptr_glReadPixels #-}
 
ptr_glReadPixels :: FunPtr a
ptr_glReadPixels
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glReadPixels"
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glScissor :: GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glScissor = dyn_glScissor ptr_glScissor
 
{-# NOINLINE ptr_glScissor #-}
 
ptr_glScissor :: FunPtr a
ptr_glScissor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glScissor"
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilFunc ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLuint -> IO ())
 
glStencilFunc :: GLenum -> GLint -> GLuint -> IO ()
glStencilFunc = dyn_glStencilFunc ptr_glStencilFunc
 
{-# NOINLINE ptr_glStencilFunc #-}
 
ptr_glStencilFunc :: FunPtr a
ptr_glStencilFunc
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glStencilFunc"
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilMask ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glStencilMask :: GLuint -> IO ()
glStencilMask = dyn_glStencilMask ptr_glStencilMask
 
{-# NOINLINE ptr_glStencilMask #-}
 
ptr_glStencilMask :: FunPtr a
ptr_glStencilMask
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glStencilMask"
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilOp ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> IO ())
 
glStencilOp :: GLenum -> GLenum -> GLenum -> IO ()
glStencilOp = dyn_glStencilOp ptr_glStencilOp
 
{-# NOINLINE ptr_glStencilOp #-}
 
ptr_glStencilOp :: FunPtr a
ptr_glStencilOp
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glStencilOp"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexImage1D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr i -> IO ())
 
glTexImage1D ::
             GLenum ->
               GLint ->
                 GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr i -> IO ()
glTexImage1D = dyn_glTexImage1D ptr_glTexImage1D
 
{-# NOINLINE ptr_glTexImage1D #-}
 
ptr_glTexImage1D :: FunPtr a
ptr_glTexImage1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexImage1D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexImage2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint ->
                        GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ())
 
glTexImage2D ::
             GLenum ->
               GLint ->
                 GLint ->
                   GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ()
glTexImage2D = dyn_glTexImage2D ptr_glTexImage2D
 
{-# NOINLINE ptr_glTexImage2D #-}
 
ptr_glTexImage2D :: FunPtr a
ptr_glTexImage2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexImage2D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameterf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLfloat -> IO ())
 
glTexParameterf :: GLenum -> GLenum -> GLfloat -> IO ()
glTexParameterf = dyn_glTexParameterf ptr_glTexParameterf
 
{-# NOINLINE ptr_glTexParameterf #-}
 
ptr_glTexParameterf :: FunPtr a
ptr_glTexParameterf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexParameterf"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glTexParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glTexParameterfv = dyn_glTexParameterfv ptr_glTexParameterfv
 
{-# NOINLINE ptr_glTexParameterfv #-}
 
ptr_glTexParameterfv :: FunPtr a
ptr_glTexParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexParameterfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
glTexParameteri :: GLenum -> GLenum -> GLint -> IO ()
glTexParameteri = dyn_glTexParameteri ptr_glTexParameteri
 
{-# NOINLINE ptr_glTexParameteri #-}
 
ptr_glTexParameteri :: FunPtr a
ptr_glTexParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexParameteri"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glTexParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glTexParameteriv = dyn_glTexParameteriv ptr_glTexParameteriv
 
{-# NOINLINE ptr_glTexParameteriv #-}
 
ptr_glTexParameteriv :: FunPtr a
ptr_glTexParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glTexParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewport ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glViewport :: GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glViewport = dyn_glViewport ptr_glViewport
 
{-# NOINLINE ptr_glViewport #-}
 
ptr_glViewport :: FunPtr a
ptr_glViewport
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_0"
        "glViewport"