{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
       (gl_ALIASED_POINT_SIZE_RANGE, gl_COLOR_MATRIX,
        gl_COLOR_MATRIX_STACK_DEPTH, gl_COLOR_TABLE,
        gl_COLOR_TABLE_ALPHA_SIZE, gl_COLOR_TABLE_BIAS,
        gl_COLOR_TABLE_BLUE_SIZE, gl_COLOR_TABLE_FORMAT,
        gl_COLOR_TABLE_GREEN_SIZE, gl_COLOR_TABLE_INTENSITY_SIZE,
        gl_COLOR_TABLE_LUMINANCE_SIZE, gl_COLOR_TABLE_RED_SIZE,
        gl_COLOR_TABLE_SCALE, gl_COLOR_TABLE_WIDTH, gl_CONSTANT_BORDER,
        gl_CONVOLUTION_1D, gl_CONVOLUTION_2D, gl_CONVOLUTION_BORDER_COLOR,
        gl_CONVOLUTION_BORDER_MODE, gl_CONVOLUTION_FILTER_BIAS,
        gl_CONVOLUTION_FILTER_SCALE, gl_CONVOLUTION_FORMAT,
        gl_CONVOLUTION_HEIGHT, gl_CONVOLUTION_WIDTH, gl_HISTOGRAM,
        gl_HISTOGRAM_ALPHA_SIZE, gl_HISTOGRAM_BLUE_SIZE,
        gl_HISTOGRAM_FORMAT, gl_HISTOGRAM_GREEN_SIZE,
        gl_HISTOGRAM_LUMINANCE_SIZE, gl_HISTOGRAM_RED_SIZE,
        gl_HISTOGRAM_SINK, gl_HISTOGRAM_WIDTH,
        gl_LIGHT_MODEL_COLOR_CONTROL, gl_MAX_COLOR_MATRIX_STACK_DEPTH,
        gl_MAX_CONVOLUTION_HEIGHT, gl_MAX_CONVOLUTION_WIDTH, gl_MINMAX,
        gl_MINMAX_FORMAT, gl_MINMAX_SINK, gl_POST_COLOR_MATRIX_ALPHA_BIAS,
        gl_POST_COLOR_MATRIX_ALPHA_SCALE, gl_POST_COLOR_MATRIX_BLUE_BIAS,
        gl_POST_COLOR_MATRIX_BLUE_SCALE, gl_POST_COLOR_MATRIX_COLOR_TABLE,
        gl_POST_COLOR_MATRIX_GREEN_BIAS, gl_POST_COLOR_MATRIX_GREEN_SCALE,
        gl_POST_COLOR_MATRIX_RED_BIAS, gl_POST_COLOR_MATRIX_RED_SCALE,
        gl_POST_CONVOLUTION_ALPHA_BIAS, gl_POST_CONVOLUTION_ALPHA_SCALE,
        gl_POST_CONVOLUTION_BLUE_BIAS, gl_POST_CONVOLUTION_BLUE_SCALE,
        gl_POST_CONVOLUTION_COLOR_TABLE, gl_POST_CONVOLUTION_GREEN_BIAS,
        gl_POST_CONVOLUTION_GREEN_SCALE, gl_POST_CONVOLUTION_RED_BIAS,
        gl_POST_CONVOLUTION_RED_SCALE, gl_PROXY_COLOR_TABLE,
        gl_PROXY_HISTOGRAM, gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE,
        gl_PROXY_POST_CONVOLUTION_COLOR_TABLE, gl_REDUCE,
        gl_REPLICATE_BORDER, gl_RESCALE_NORMAL, gl_SEPARABLE_2D,
        gl_SEPARATE_SPECULAR_COLOR, gl_SINGLE_COLOR, gl_TABLE_TOO_LARGE,
        glColorSubTable, glColorTable, glColorTableParameterfv,
        glColorTableParameteriv, glConvolutionFilter1D,
        glConvolutionFilter2D, glConvolutionParameterf,
        glConvolutionParameterfv, glConvolutionParameteri,
        glConvolutionParameteriv, glCopyColorSubTable, glCopyColorTable,
        glCopyConvolutionFilter1D, glCopyConvolutionFilter2D,
        glGetColorTable, glGetColorTableParameterfv,
        glGetColorTableParameteriv, glGetConvolutionFilter,
        glGetConvolutionParameterfv, glGetConvolutionParameteriv,
        glGetHistogram, glGetHistogramParameterfv,
        glGetHistogramParameteriv, glGetMinmax, glGetMinmaxParameterfv,
        glGetMinmaxParameteriv, glGetSeparableFilter, glHistogram,
        glMinmax, glResetHistogram, glResetMinmax, glSeparableFilter2D)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ALIASED_POINT_SIZE_RANGE :: GLenum
gl_ALIASED_POINT_SIZE_RANGE = 33901
 
gl_COLOR_MATRIX :: GLenum
gl_COLOR_MATRIX = 32945
 
gl_COLOR_MATRIX_STACK_DEPTH :: GLenum
gl_COLOR_MATRIX_STACK_DEPTH = 32946
 
gl_COLOR_TABLE :: GLenum
gl_COLOR_TABLE = 32976
 
gl_COLOR_TABLE_ALPHA_SIZE :: GLenum
gl_COLOR_TABLE_ALPHA_SIZE = 32989
 
gl_COLOR_TABLE_BIAS :: GLenum
gl_COLOR_TABLE_BIAS = 32983
 
gl_COLOR_TABLE_BLUE_SIZE :: GLenum
gl_COLOR_TABLE_BLUE_SIZE = 32988
 
gl_COLOR_TABLE_FORMAT :: GLenum
gl_COLOR_TABLE_FORMAT = 32984
 
gl_COLOR_TABLE_GREEN_SIZE :: GLenum
gl_COLOR_TABLE_GREEN_SIZE = 32987
 
gl_COLOR_TABLE_INTENSITY_SIZE :: GLenum
gl_COLOR_TABLE_INTENSITY_SIZE = 32991
 
gl_COLOR_TABLE_LUMINANCE_SIZE :: GLenum
gl_COLOR_TABLE_LUMINANCE_SIZE = 32990
 
gl_COLOR_TABLE_RED_SIZE :: GLenum
gl_COLOR_TABLE_RED_SIZE = 32986
 
gl_COLOR_TABLE_SCALE :: GLenum
gl_COLOR_TABLE_SCALE = 32982
 
gl_COLOR_TABLE_WIDTH :: GLenum
gl_COLOR_TABLE_WIDTH = 32985
 
gl_CONSTANT_BORDER :: GLenum
gl_CONSTANT_BORDER = 33105
 
gl_CONVOLUTION_1D :: GLenum
gl_CONVOLUTION_1D = 32784
 
gl_CONVOLUTION_2D :: GLenum
gl_CONVOLUTION_2D = 32785
 
gl_CONVOLUTION_BORDER_COLOR :: GLenum
gl_CONVOLUTION_BORDER_COLOR = 33108
 
gl_CONVOLUTION_BORDER_MODE :: GLenum
gl_CONVOLUTION_BORDER_MODE = 32787
 
gl_CONVOLUTION_FILTER_BIAS :: GLenum
gl_CONVOLUTION_FILTER_BIAS = 32789
 
gl_CONVOLUTION_FILTER_SCALE :: GLenum
gl_CONVOLUTION_FILTER_SCALE = 32788
 
gl_CONVOLUTION_FORMAT :: GLenum
gl_CONVOLUTION_FORMAT = 32791
 
gl_CONVOLUTION_HEIGHT :: GLenum
gl_CONVOLUTION_HEIGHT = 32793
 
gl_CONVOLUTION_WIDTH :: GLenum
gl_CONVOLUTION_WIDTH = 32792
 
gl_HISTOGRAM :: GLenum
gl_HISTOGRAM = 32804
 
gl_HISTOGRAM_ALPHA_SIZE :: GLenum
gl_HISTOGRAM_ALPHA_SIZE = 32811
 
gl_HISTOGRAM_BLUE_SIZE :: GLenum
gl_HISTOGRAM_BLUE_SIZE = 32810
 
gl_HISTOGRAM_FORMAT :: GLenum
gl_HISTOGRAM_FORMAT = 32807
 
gl_HISTOGRAM_GREEN_SIZE :: GLenum
gl_HISTOGRAM_GREEN_SIZE = 32809
 
gl_HISTOGRAM_LUMINANCE_SIZE :: GLenum
gl_HISTOGRAM_LUMINANCE_SIZE = 32812
 
gl_HISTOGRAM_RED_SIZE :: GLenum
gl_HISTOGRAM_RED_SIZE = 32808
 
gl_HISTOGRAM_SINK :: GLenum
gl_HISTOGRAM_SINK = 32813
 
gl_HISTOGRAM_WIDTH :: GLenum
gl_HISTOGRAM_WIDTH = 32806
 
gl_LIGHT_MODEL_COLOR_CONTROL :: GLenum
gl_LIGHT_MODEL_COLOR_CONTROL = 33272
 
gl_MAX_COLOR_MATRIX_STACK_DEPTH :: GLenum
gl_MAX_COLOR_MATRIX_STACK_DEPTH = 32947
 
gl_MAX_CONVOLUTION_HEIGHT :: GLenum
gl_MAX_CONVOLUTION_HEIGHT = 32795
 
gl_MAX_CONVOLUTION_WIDTH :: GLenum
gl_MAX_CONVOLUTION_WIDTH = 32794
 
gl_MINMAX :: GLenum
gl_MINMAX = 32814
 
gl_MINMAX_FORMAT :: GLenum
gl_MINMAX_FORMAT = 32815
 
gl_MINMAX_SINK :: GLenum
gl_MINMAX_SINK = 32816
 
gl_POST_COLOR_MATRIX_ALPHA_BIAS :: GLenum
gl_POST_COLOR_MATRIX_ALPHA_BIAS = 32955
 
gl_POST_COLOR_MATRIX_ALPHA_SCALE :: GLenum
gl_POST_COLOR_MATRIX_ALPHA_SCALE = 32951
 
gl_POST_COLOR_MATRIX_BLUE_BIAS :: GLenum
gl_POST_COLOR_MATRIX_BLUE_BIAS = 32954
 
gl_POST_COLOR_MATRIX_BLUE_SCALE :: GLenum
gl_POST_COLOR_MATRIX_BLUE_SCALE = 32950
 
gl_POST_COLOR_MATRIX_COLOR_TABLE :: GLenum
gl_POST_COLOR_MATRIX_COLOR_TABLE = 32978
 
gl_POST_COLOR_MATRIX_GREEN_BIAS :: GLenum
gl_POST_COLOR_MATRIX_GREEN_BIAS = 32953
 
gl_POST_COLOR_MATRIX_GREEN_SCALE :: GLenum
gl_POST_COLOR_MATRIX_GREEN_SCALE = 32949
 
gl_POST_COLOR_MATRIX_RED_BIAS :: GLenum
gl_POST_COLOR_MATRIX_RED_BIAS = 32952
 
gl_POST_COLOR_MATRIX_RED_SCALE :: GLenum
gl_POST_COLOR_MATRIX_RED_SCALE = 32948
 
gl_POST_CONVOLUTION_ALPHA_BIAS :: GLenum
gl_POST_CONVOLUTION_ALPHA_BIAS = 32803
 
gl_POST_CONVOLUTION_ALPHA_SCALE :: GLenum
gl_POST_CONVOLUTION_ALPHA_SCALE = 32799
 
gl_POST_CONVOLUTION_BLUE_BIAS :: GLenum
gl_POST_CONVOLUTION_BLUE_BIAS = 32802
 
gl_POST_CONVOLUTION_BLUE_SCALE :: GLenum
gl_POST_CONVOLUTION_BLUE_SCALE = 32798
 
gl_POST_CONVOLUTION_COLOR_TABLE :: GLenum
gl_POST_CONVOLUTION_COLOR_TABLE = 32977
 
gl_POST_CONVOLUTION_GREEN_BIAS :: GLenum
gl_POST_CONVOLUTION_GREEN_BIAS = 32801
 
gl_POST_CONVOLUTION_GREEN_SCALE :: GLenum
gl_POST_CONVOLUTION_GREEN_SCALE = 32797
 
gl_POST_CONVOLUTION_RED_BIAS :: GLenum
gl_POST_CONVOLUTION_RED_BIAS = 32800
 
gl_POST_CONVOLUTION_RED_SCALE :: GLenum
gl_POST_CONVOLUTION_RED_SCALE = 32796
 
gl_PROXY_COLOR_TABLE :: GLenum
gl_PROXY_COLOR_TABLE = 32979
 
gl_PROXY_HISTOGRAM :: GLenum
gl_PROXY_HISTOGRAM = 32805
 
gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE :: GLenum
gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE = 32981
 
gl_PROXY_POST_CONVOLUTION_COLOR_TABLE :: GLenum
gl_PROXY_POST_CONVOLUTION_COLOR_TABLE = 32980
 
gl_REDUCE :: GLenum
gl_REDUCE = 32790
 
gl_REPLICATE_BORDER :: GLenum
gl_REPLICATE_BORDER = 33107
 
gl_RESCALE_NORMAL :: GLenum
gl_RESCALE_NORMAL = 32826
 
gl_SEPARABLE_2D :: GLenum
gl_SEPARABLE_2D = 32786
 
gl_SEPARATE_SPECULAR_COLOR :: GLenum
gl_SEPARATE_SPECULAR_COLOR = 33274
 
gl_SINGLE_COLOR :: GLenum
gl_SINGLE_COLOR = 33273
 
gl_TABLE_TOO_LARGE :: GLenum
gl_TABLE_TOO_LARGE = 32817
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorSubTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ())
 
glColorSubTable ::
                GLenum -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ()
glColorSubTable = dyn_glColorSubTable ptr_glColorSubTable
 
{-# NOINLINE ptr_glColorSubTable #-}
 
ptr_glColorSubTable :: FunPtr a
ptr_glColorSubTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glColorSubTable"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ())
 
glColorTable ::
             GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ()
glColorTable = dyn_glColorTable ptr_glColorTable
 
{-# NOINLINE ptr_glColorTable #-}
 
ptr_glColorTable :: FunPtr a
ptr_glColorTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glColorTable"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorTableParameterfv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glColorTableParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glColorTableParameterfv
  = dyn_glColorTableParameterfv ptr_glColorTableParameterfv
 
{-# NOINLINE ptr_glColorTableParameterfv #-}
 
ptr_glColorTableParameterfv :: FunPtr a
ptr_glColorTableParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glColorTableParameterfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorTableParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glColorTableParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glColorTableParameteriv
  = dyn_glColorTableParameteriv ptr_glColorTableParameteriv
 
{-# NOINLINE ptr_glColorTableParameteriv #-}
 
ptr_glColorTableParameteriv :: FunPtr a
ptr_glColorTableParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glColorTableParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glConvolutionFilter1D
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ())
 
glConvolutionFilter1D ::
                      GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr g -> IO ()
glConvolutionFilter1D
  = dyn_glConvolutionFilter1D ptr_glConvolutionFilter1D
 
{-# NOINLINE ptr_glConvolutionFilter1D #-}
 
ptr_glConvolutionFilter1D :: FunPtr a
ptr_glConvolutionFilter1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionFilter1D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glConvolutionFilter2D
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> IO ())
 
glConvolutionFilter2D ::
                      GLenum ->
                        GLenum -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> IO ()
glConvolutionFilter2D
  = dyn_glConvolutionFilter2D ptr_glConvolutionFilter2D
 
{-# NOINLINE ptr_glConvolutionFilter2D #-}
 
ptr_glConvolutionFilter2D :: FunPtr a
ptr_glConvolutionFilter2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionFilter2D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glConvolutionParameterf
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLfloat -> IO ())
 
glConvolutionParameterf :: GLenum -> GLenum -> GLfloat -> IO ()
glConvolutionParameterf
  = dyn_glConvolutionParameterf ptr_glConvolutionParameterf
 
{-# NOINLINE ptr_glConvolutionParameterf #-}
 
ptr_glConvolutionParameterf :: FunPtr a
ptr_glConvolutionParameterf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionParameterf"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glConvolutionParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glConvolutionParameterfv ::
                         GLenum -> GLenum -> Ptr GLfloat -> IO ()
glConvolutionParameterfv
  = dyn_glConvolutionParameterfv ptr_glConvolutionParameterfv
 
{-# NOINLINE ptr_glConvolutionParameterfv #-}
 
ptr_glConvolutionParameterfv :: FunPtr a
ptr_glConvolutionParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionParameterfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glConvolutionParameteri
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
glConvolutionParameteri :: GLenum -> GLenum -> GLint -> IO ()
glConvolutionParameteri
  = dyn_glConvolutionParameteri ptr_glConvolutionParameteri
 
{-# NOINLINE ptr_glConvolutionParameteri #-}
 
ptr_glConvolutionParameteri :: FunPtr a
ptr_glConvolutionParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionParameteri"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glConvolutionParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glConvolutionParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glConvolutionParameteriv
  = dyn_glConvolutionParameteriv ptr_glConvolutionParameteriv
 
{-# NOINLINE ptr_glConvolutionParameteriv #-}
 
ptr_glConvolutionParameteriv :: FunPtr a
ptr_glConvolutionParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glConvolutionParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyColorSubTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyColorSubTable ::
                    GLenum -> GLsizei -> GLint -> GLint -> GLsizei -> IO ()
glCopyColorSubTable
  = dyn_glCopyColorSubTable ptr_glCopyColorSubTable
 
{-# NOINLINE ptr_glCopyColorSubTable #-}
 
ptr_glCopyColorSubTable :: FunPtr a
ptr_glCopyColorSubTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glCopyColorSubTable"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyColorTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyColorTable ::
                 GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ()
glCopyColorTable = dyn_glCopyColorTable ptr_glCopyColorTable
 
{-# NOINLINE ptr_glCopyColorTable #-}
 
ptr_glCopyColorTable :: FunPtr a
ptr_glCopyColorTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glCopyColorTable"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyConvolutionFilter1D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyConvolutionFilter1D ::
                          GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ()
glCopyConvolutionFilter1D
  = dyn_glCopyConvolutionFilter1D ptr_glCopyConvolutionFilter1D
 
{-# NOINLINE ptr_glCopyConvolutionFilter1D #-}
 
ptr_glCopyConvolutionFilter1D :: FunPtr a
ptr_glCopyConvolutionFilter1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glCopyConvolutionFilter1D"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyConvolutionFilter2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyConvolutionFilter2D ::
                          GLenum -> GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyConvolutionFilter2D
  = dyn_glCopyConvolutionFilter2D ptr_glCopyConvolutionFilter2D
 
{-# NOINLINE ptr_glCopyConvolutionFilter2D #-}
 
ptr_glCopyConvolutionFilter2D :: FunPtr a
ptr_glCopyConvolutionFilter2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glCopyConvolutionFilter2D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetColorTable ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr e -> IO ())
 
glGetColorTable :: GLenum -> GLenum -> GLenum -> Ptr e -> IO ()
glGetColorTable = dyn_glGetColorTable ptr_glGetColorTable
 
{-# NOINLINE ptr_glGetColorTable #-}
 
ptr_glGetColorTable :: FunPtr a
ptr_glGetColorTable
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetColorTable"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetColorTableParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetColorTableParameterfv ::
                           GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetColorTableParameterfv
  = dyn_glGetColorTableParameterfv ptr_glGetColorTableParameterfv
 
{-# NOINLINE ptr_glGetColorTableParameterfv #-}
 
ptr_glGetColorTableParameterfv :: FunPtr a
ptr_glGetColorTableParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetColorTableParameterfv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetColorTableParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetColorTableParameteriv ::
                           GLenum -> GLenum -> Ptr GLint -> IO ()
glGetColorTableParameteriv
  = dyn_glGetColorTableParameteriv ptr_glGetColorTableParameteriv
 
{-# NOINLINE ptr_glGetColorTableParameteriv #-}
 
ptr_glGetColorTableParameteriv :: FunPtr a
ptr_glGetColorTableParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetColorTableParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetConvolutionFilter
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr e -> IO ())
 
glGetConvolutionFilter ::
                       GLenum -> GLenum -> GLenum -> Ptr e -> IO ()
glGetConvolutionFilter
  = dyn_glGetConvolutionFilter ptr_glGetConvolutionFilter
 
{-# NOINLINE ptr_glGetConvolutionFilter #-}
 
ptr_glGetConvolutionFilter :: FunPtr a
ptr_glGetConvolutionFilter
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetConvolutionFilter"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetConvolutionParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetConvolutionParameterfv ::
                            GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetConvolutionParameterfv
  = dyn_glGetConvolutionParameterfv ptr_glGetConvolutionParameterfv
 
{-# NOINLINE ptr_glGetConvolutionParameterfv #-}
 
ptr_glGetConvolutionParameterfv :: FunPtr a
ptr_glGetConvolutionParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetConvolutionParameterfv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetConvolutionParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetConvolutionParameteriv ::
                            GLenum -> GLenum -> Ptr GLint -> IO ()
glGetConvolutionParameteriv
  = dyn_glGetConvolutionParameteriv ptr_glGetConvolutionParameteriv
 
{-# NOINLINE ptr_glGetConvolutionParameteriv #-}
 
ptr_glGetConvolutionParameteriv :: FunPtr a
ptr_glGetConvolutionParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetConvolutionParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetHistogram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLboolean -> GLenum -> GLenum -> Ptr f -> IO ())
 
glGetHistogram ::
               GLenum -> GLboolean -> GLenum -> GLenum -> Ptr f -> IO ()
glGetHistogram = dyn_glGetHistogram ptr_glGetHistogram
 
{-# NOINLINE ptr_glGetHistogram #-}
 
ptr_glGetHistogram :: FunPtr a
ptr_glGetHistogram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetHistogram"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetHistogramParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetHistogramParameterfv ::
                          GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetHistogramParameterfv
  = dyn_glGetHistogramParameterfv ptr_glGetHistogramParameterfv
 
{-# NOINLINE ptr_glGetHistogramParameterfv #-}
 
ptr_glGetHistogramParameterfv :: FunPtr a
ptr_glGetHistogramParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetHistogramParameterfv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetHistogramParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetHistogramParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetHistogramParameteriv
  = dyn_glGetHistogramParameteriv ptr_glGetHistogramParameteriv
 
{-# NOINLINE ptr_glGetHistogramParameteriv #-}
 
ptr_glGetHistogramParameteriv :: FunPtr a
ptr_glGetHistogramParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetHistogramParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMinmax ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLboolean -> GLenum -> GLenum -> Ptr f -> IO ())
 
glGetMinmax ::
            GLenum -> GLboolean -> GLenum -> GLenum -> Ptr f -> IO ()
glGetMinmax = dyn_glGetMinmax ptr_glGetMinmax
 
{-# NOINLINE ptr_glGetMinmax #-}
 
ptr_glGetMinmax :: FunPtr a
ptr_glGetMinmax
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetMinmax"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMinmaxParameterfv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMinmaxParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMinmaxParameterfv
  = dyn_glGetMinmaxParameterfv ptr_glGetMinmaxParameterfv
 
{-# NOINLINE ptr_glGetMinmaxParameterfv #-}
 
ptr_glGetMinmaxParameterfv :: FunPtr a
ptr_glGetMinmaxParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetMinmaxParameterfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMinmaxParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMinmaxParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMinmaxParameteriv
  = dyn_glGetMinmaxParameteriv ptr_glGetMinmaxParameteriv
 
{-# NOINLINE ptr_glGetMinmaxParameteriv #-}
 
ptr_glGetMinmaxParameteriv :: FunPtr a
ptr_glGetMinmaxParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetMinmaxParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSeparableFilter ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr e -> Ptr f -> Ptr g -> IO ())
 
glGetSeparableFilter ::
                     GLenum -> GLenum -> GLenum -> Ptr e -> Ptr f -> Ptr g -> IO ()
glGetSeparableFilter
  = dyn_glGetSeparableFilter ptr_glGetSeparableFilter
 
{-# NOINLINE ptr_glGetSeparableFilter #-}
 
ptr_glGetSeparableFilter :: FunPtr a
ptr_glGetSeparableFilter
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glGetSeparableFilter"
 
foreign import CALLCONV unsafe "dynamic" dyn_glHistogram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> GLboolean -> IO ())
 
glHistogram :: GLenum -> GLsizei -> GLenum -> GLboolean -> IO ()
glHistogram = dyn_glHistogram ptr_glHistogram
 
{-# NOINLINE ptr_glHistogram #-}
 
ptr_glHistogram :: FunPtr a
ptr_glHistogram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glHistogram"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMinmax ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLboolean -> IO ())
 
glMinmax :: GLenum -> GLenum -> GLboolean -> IO ()
glMinmax = dyn_glMinmax ptr_glMinmax
 
{-# NOINLINE ptr_glMinmax #-}
 
ptr_glMinmax :: FunPtr a
ptr_glMinmax
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glMinmax"
 
foreign import CALLCONV unsafe "dynamic" dyn_glResetHistogram ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glResetHistogram :: GLenum -> IO ()
glResetHistogram = dyn_glResetHistogram ptr_glResetHistogram
 
{-# NOINLINE ptr_glResetHistogram #-}
 
ptr_glResetHistogram :: FunPtr a
ptr_glResetHistogram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glResetHistogram"
 
foreign import CALLCONV unsafe "dynamic" dyn_glResetMinmax ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glResetMinmax :: GLenum -> IO ()
glResetMinmax = dyn_glResetMinmax ptr_glResetMinmax
 
{-# NOINLINE ptr_glResetMinmax #-}
 
ptr_glResetMinmax :: FunPtr a
ptr_glResetMinmax
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glResetMinmax"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSeparableFilter2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> Ptr i -> IO ())
 
glSeparableFilter2D ::
                    GLenum ->
                      GLenum ->
                        GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr h -> Ptr i -> IO ()
glSeparableFilter2D
  = dyn_glSeparableFilter2D ptr_glSeparableFilter2D
 
{-# NOINLINE ptr_glSeparableFilter2D #-}
 
ptr_glSeparableFilter2D :: FunPtr a
ptr_glSeparableFilter2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_2_DEPRECATED"
        "glSeparableFilter2D"