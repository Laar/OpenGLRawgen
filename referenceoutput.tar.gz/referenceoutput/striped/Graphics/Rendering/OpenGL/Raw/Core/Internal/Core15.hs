{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15
       (gl_ARRAY_BUFFER, gl_ARRAY_BUFFER_BINDING, gl_BUFFER_ACCESS,
        gl_BUFFER_MAPPED, gl_BUFFER_MAP_POINTER, gl_BUFFER_SIZE,
        gl_BUFFER_USAGE, gl_CURRENT_QUERY, gl_DYNAMIC_COPY,
        gl_DYNAMIC_DRAW, gl_DYNAMIC_READ, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING, gl_QUERY_COUNTER_BITS,
        gl_QUERY_RESULT, gl_QUERY_RESULT_AVAILABLE, gl_READ_ONLY,
        gl_READ_WRITE, gl_SAMPLES_PASSED, gl_SRC1_ALPHA, gl_STATIC_COPY,
        gl_STATIC_DRAW, gl_STATIC_READ, gl_STREAM_COPY, gl_STREAM_DRAW,
        gl_STREAM_READ, gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_WRITE_ONLY, glBeginQuery, glBindBuffer, glBufferData,
        glBufferSubData, glDeleteBuffers, glDeleteQueries, glEndQuery,
        glGenBuffers, glGenQueries, glGetBufferParameteriv,
        glGetBufferPointerv, glGetBufferSubData, glGetQueryObjectiv,
        glGetQueryObjectuiv, glGetQueryiv, glIsBuffer, glIsQuery,
        glMapBuffer, glUnmapBuffer)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ARRAY_BUFFER :: GLenum
gl_ARRAY_BUFFER = 34962
 
gl_ARRAY_BUFFER_BINDING :: GLenum
gl_ARRAY_BUFFER_BINDING = 34964
 
gl_BUFFER_ACCESS :: GLenum
gl_BUFFER_ACCESS = 35003
 
gl_BUFFER_MAPPED :: GLenum
gl_BUFFER_MAPPED = 35004
 
gl_BUFFER_MAP_POINTER :: GLenum
gl_BUFFER_MAP_POINTER = 35005
 
gl_BUFFER_SIZE :: GLenum
gl_BUFFER_SIZE = 34660
 
gl_BUFFER_USAGE :: GLenum
gl_BUFFER_USAGE = 34661
 
gl_CURRENT_QUERY :: GLenum
gl_CURRENT_QUERY = 34917
 
gl_DYNAMIC_COPY :: GLenum
gl_DYNAMIC_COPY = 35050
 
gl_DYNAMIC_DRAW :: GLenum
gl_DYNAMIC_DRAW = 35048
 
gl_DYNAMIC_READ :: GLenum
gl_DYNAMIC_READ = 35049
 
gl_ELEMENT_ARRAY_BUFFER :: GLenum
gl_ELEMENT_ARRAY_BUFFER = 34963
 
gl_ELEMENT_ARRAY_BUFFER_BINDING :: GLenum
gl_ELEMENT_ARRAY_BUFFER_BINDING = 34965
 
gl_QUERY_COUNTER_BITS :: GLenum
gl_QUERY_COUNTER_BITS = 34916
 
gl_QUERY_RESULT :: GLenum
gl_QUERY_RESULT = 34918
 
gl_QUERY_RESULT_AVAILABLE :: GLenum
gl_QUERY_RESULT_AVAILABLE = 34919
 
gl_READ_ONLY :: GLenum
gl_READ_ONLY = 35000
 
gl_READ_WRITE :: GLenum
gl_READ_WRITE = 35002
 
gl_SAMPLES_PASSED :: GLenum
gl_SAMPLES_PASSED = 35092
 
gl_SRC1_ALPHA :: GLenum
gl_SRC1_ALPHA = 34185
 
gl_STATIC_COPY :: GLenum
gl_STATIC_COPY = 35046
 
gl_STATIC_DRAW :: GLenum
gl_STATIC_DRAW = 35044
 
gl_STATIC_READ :: GLenum
gl_STATIC_READ = 35045
 
gl_STREAM_COPY :: GLenum
gl_STREAM_COPY = 35042
 
gl_STREAM_DRAW :: GLenum
gl_STREAM_DRAW = 35040
 
gl_STREAM_READ :: GLenum
gl_STREAM_READ = 35041
 
gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING :: GLenum
gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = 34975
 
gl_WRITE_ONLY :: GLenum
gl_WRITE_ONLY = 35001
 
foreign import CALLCONV unsafe "dynamic" dyn_glBeginQuery ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBeginQuery :: GLenum -> GLuint -> IO ()
glBeginQuery = dyn_glBeginQuery ptr_glBeginQuery
 
{-# NOINLINE ptr_glBeginQuery #-}
 
ptr_glBeginQuery :: FunPtr a
ptr_glBeginQuery
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glBeginQuery"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindBuffer :: GLenum -> GLuint -> IO ()
glBindBuffer = dyn_glBindBuffer ptr_glBindBuffer
 
{-# NOINLINE ptr_glBindBuffer #-}
 
ptr_glBindBuffer :: FunPtr a
ptr_glBindBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glBindBuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizeiptr -> Ptr a -> GLenum -> IO ())
 
glBufferData :: GLenum -> GLsizeiptr -> Ptr a -> GLenum -> IO ()
glBufferData = dyn_glBufferData ptr_glBufferData
 
{-# NOINLINE ptr_glBufferData #-}
 
ptr_glBufferData :: FunPtr a
ptr_glBufferData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glBufferData"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> Ptr a -> IO ())
 
glBufferSubData ::
                GLenum -> GLintptr -> GLsizeiptr -> Ptr a -> IO ()
glBufferSubData = dyn_glBufferSubData ptr_glBufferSubData
 
{-# NOINLINE ptr_glBufferSubData #-}
 
ptr_glBufferSubData :: FunPtr a
ptr_glBufferSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glBufferSubData"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteBuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteBuffers :: GLsizei -> Ptr GLuint -> IO ()
glDeleteBuffers = dyn_glDeleteBuffers ptr_glDeleteBuffers
 
{-# NOINLINE ptr_glDeleteBuffers #-}
 
ptr_glDeleteBuffers :: FunPtr a
ptr_glDeleteBuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glDeleteBuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteQueries ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteQueries :: GLsizei -> Ptr GLuint -> IO ()
glDeleteQueries = dyn_glDeleteQueries ptr_glDeleteQueries
 
{-# NOINLINE ptr_glDeleteQueries #-}
 
ptr_glDeleteQueries :: FunPtr a
ptr_glDeleteQueries
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glDeleteQueries"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndQuery ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glEndQuery :: GLenum -> IO ()
glEndQuery = dyn_glEndQuery ptr_glEndQuery
 
{-# NOINLINE ptr_glEndQuery #-}
 
ptr_glEndQuery :: FunPtr a
ptr_glEndQuery
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glEndQuery"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenBuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenBuffers :: GLsizei -> Ptr GLuint -> IO ()
glGenBuffers = dyn_glGenBuffers ptr_glGenBuffers
 
{-# NOINLINE ptr_glGenBuffers #-}
 
ptr_glGenBuffers :: FunPtr a
ptr_glGenBuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGenBuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenQueries ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenQueries :: GLsizei -> Ptr GLuint -> IO ()
glGenQueries = dyn_glGenQueries ptr_glGenQueries
 
{-# NOINLINE ptr_glGenQueries #-}
 
ptr_glGenQueries :: FunPtr a
ptr_glGenQueries
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGenQueries"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetBufferParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetBufferParameteriv
  = dyn_glGetBufferParameteriv ptr_glGetBufferParameteriv
 
{-# NOINLINE ptr_glGetBufferParameteriv #-}
 
ptr_glGetBufferParameteriv :: FunPtr a
ptr_glGetBufferParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetBufferParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr (Ptr a) -> IO ())
 
glGetBufferPointerv :: GLenum -> GLenum -> Ptr (Ptr a) -> IO ()
glGetBufferPointerv
  = dyn_glGetBufferPointerv ptr_glGetBufferPointerv
 
{-# NOINLINE ptr_glGetBufferPointerv #-}
 
ptr_glGetBufferPointerv :: FunPtr a
ptr_glGetBufferPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetBufferPointerv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBufferSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> Ptr a -> IO ())
 
glGetBufferSubData ::
                   GLenum -> GLintptr -> GLsizeiptr -> Ptr a -> IO ()
glGetBufferSubData = dyn_glGetBufferSubData ptr_glGetBufferSubData
 
{-# NOINLINE ptr_glGetBufferSubData #-}
 
ptr_glGetBufferSubData :: FunPtr a
ptr_glGetBufferSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetBufferSubData"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjectiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetQueryObjectiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetQueryObjectiv = dyn_glGetQueryObjectiv ptr_glGetQueryObjectiv
 
{-# NOINLINE ptr_glGetQueryObjectiv #-}
 
ptr_glGetQueryObjectiv :: FunPtr a
ptr_glGetQueryObjectiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetQueryObjectiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjectuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
glGetQueryObjectuiv :: GLuint -> GLenum -> Ptr GLuint -> IO ()
glGetQueryObjectuiv
  = dyn_glGetQueryObjectuiv ptr_glGetQueryObjectuiv
 
{-# NOINLINE ptr_glGetQueryObjectuiv #-}
 
ptr_glGetQueryObjectuiv :: FunPtr a
ptr_glGetQueryObjectuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetQueryObjectuiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetQueryiv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetQueryiv = dyn_glGetQueryiv ptr_glGetQueryiv
 
{-# NOINLINE ptr_glGetQueryiv #-}
 
ptr_glGetQueryiv :: FunPtr a
ptr_glGetQueryiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glGetQueryiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsBuffer :: GLuint -> IO GLboolean
glIsBuffer = dyn_glIsBuffer ptr_glIsBuffer
 
{-# NOINLINE ptr_glIsBuffer #-}
 
ptr_glIsBuffer :: FunPtr a
ptr_glIsBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glIsBuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsQuery ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsQuery :: GLuint -> IO GLboolean
glIsQuery = dyn_glIsQuery ptr_glIsQuery
 
{-# NOINLINE ptr_glIsQuery #-}
 
ptr_glIsQuery :: FunPtr a
ptr_glIsQuery
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glIsQuery"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO (Ptr a))
 
glMapBuffer :: GLenum -> GLenum -> IO (Ptr a)
glMapBuffer = dyn_glMapBuffer ptr_glMapBuffer
 
{-# NOINLINE ptr_glMapBuffer #-}
 
ptr_glMapBuffer :: FunPtr a
ptr_glMapBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glMapBuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnmapBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLboolean)
 
glUnmapBuffer :: GLenum -> IO GLboolean
glUnmapBuffer = dyn_glUnmapBuffer ptr_glUnmapBuffer
 
{-# NOINLINE ptr_glUnmapBuffer #-}
 
ptr_glUnmapBuffer :: FunPtr a
ptr_glUnmapBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_1_5"
        "glUnmapBuffer"