{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.NameGenDelete
       (gl_DATA_BUFFER, gl_PERFORMANCE_MONITOR, gl_QUERY_OBJECT,
        gl_SAMPLER_OBJECT, gl_VERTEX_ARRAY_OBJECT, glDeleteNames,
        glGenNames, glIsName)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DATA_BUFFER :: GLenum
gl_DATA_BUFFER = 37201
 
gl_PERFORMANCE_MONITOR :: GLenum
gl_PERFORMANCE_MONITOR = 37202
 
gl_QUERY_OBJECT :: GLenum
gl_QUERY_OBJECT = 37203
 
gl_SAMPLER_OBJECT :: GLenum
gl_SAMPLER_OBJECT = 37205
 
gl_VERTEX_ARRAY_OBJECT :: GLenum
gl_VERTEX_ARRAY_OBJECT = 37204
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteNames ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glDeleteNames :: GLenum -> GLuint -> Ptr GLuint -> IO ()
glDeleteNames = dyn_glDeleteNames ptr_glDeleteNames
 
{-# NOINLINE ptr_glDeleteNames #-}
 
ptr_glDeleteNames :: FunPtr a
ptr_glDeleteNames
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glDeleteNamesAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenNames ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glGenNames :: GLenum -> GLuint -> Ptr GLuint -> IO ()
glGenNames = dyn_glGenNames ptr_glGenNames
 
{-# NOINLINE ptr_glGenNames #-}
 
ptr_glGenNames :: FunPtr a
ptr_glGenNames
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glGenNamesAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsName ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsName :: GLenum -> GLuint -> IO GLboolean
glIsName = dyn_glIsName ptr_glIsName
 
{-# NOINLINE ptr_glIsName #-}
 
ptr_glIsName :: FunPtr a
ptr_glIsName
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glIsNameAMD"