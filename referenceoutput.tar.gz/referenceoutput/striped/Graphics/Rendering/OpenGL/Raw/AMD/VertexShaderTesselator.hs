{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.AMD.VertexShaderTesselator
       (gl_CONTINUOUS, gl_DISCRETE, gl_INT_SAMPLER_BUFFER,
        gl_SAMPLER_BUFFER, gl_TESSELLATION_FACTOR, gl_TESSELLATION_MODE,
        gl_UNSIGNED_INT_SAMPLER_BUFFER, glTessellationFactor,
        glTessellationMode)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CONTINUOUS :: GLenum
gl_CONTINUOUS = 36871
 
gl_DISCRETE :: GLenum
gl_DISCRETE = 36870
 
gl_INT_SAMPLER_BUFFER :: GLenum
gl_INT_SAMPLER_BUFFER = 36866
 
gl_SAMPLER_BUFFER :: GLenum
gl_SAMPLER_BUFFER = 36865
 
gl_TESSELLATION_FACTOR :: GLenum
gl_TESSELLATION_FACTOR = 36869
 
gl_TESSELLATION_MODE :: GLenum
gl_TESSELLATION_MODE = 36868
 
gl_UNSIGNED_INT_SAMPLER_BUFFER :: GLenum
gl_UNSIGNED_INT_SAMPLER_BUFFER = 36867
 
foreign import CALLCONV unsafe "dynamic" dyn_glTessellationFactor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glTessellationFactor :: GLfloat -> IO ()
glTessellationFactor
  = dyn_glTessellationFactor ptr_glTessellationFactor
 
{-# NOINLINE ptr_glTessellationFactor #-}
 
ptr_glTessellationFactor :: FunPtr a
ptr_glTessellationFactor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_vertex_shader_tesselator"
        "glTessellationFactorAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTessellationMode ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glTessellationMode :: GLenum -> IO ()
glTessellationMode = dyn_glTessellationMode ptr_glTessellationMode
 
{-# NOINLINE ptr_glTessellationMode #-}
 
ptr_glTessellationMode :: FunPtr a
ptr_glTessellationMode
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_vertex_shader_tesselator"
        "glTessellationModeAMD"