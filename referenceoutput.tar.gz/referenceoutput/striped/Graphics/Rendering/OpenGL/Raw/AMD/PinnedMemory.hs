-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.PinnedMemory
       (gl_EXTERNAL_VIRTUAL_MEMORY_BUFFER) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_EXTERNAL_VIRTUAL_MEMORY_BUFFER :: GLenum
gl_EXTERNAL_VIRTUAL_MEMORY_BUFFER = 37216