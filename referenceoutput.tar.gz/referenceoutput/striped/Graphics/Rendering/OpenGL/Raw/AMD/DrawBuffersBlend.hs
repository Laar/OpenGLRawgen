{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.AMD.DrawBuffersBlend
       (glBlendEquationIndexed, glBlendEquationSeparateIndexed,
        glBlendFuncIndexed, glBlendFuncSeparateIndexed)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendEquationIndexed
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glBlendEquationIndexed :: GLuint -> GLenum -> IO ()
glBlendEquationIndexed
  = dyn_glBlendEquationIndexed ptr_glBlendEquationIndexed
 
{-# NOINLINE ptr_glBlendEquationIndexed #-}
 
ptr_glBlendEquationIndexed :: FunPtr a
ptr_glBlendEquationIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_draw_buffers_blend"
        "glBlendEquationIndexedAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBlendEquationSeparateIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> IO ())
 
glBlendEquationSeparateIndexed ::
                               GLuint -> GLenum -> GLenum -> IO ()
glBlendEquationSeparateIndexed
  = dyn_glBlendEquationSeparateIndexed
      ptr_glBlendEquationSeparateIndexed
 
{-# NOINLINE ptr_glBlendEquationSeparateIndexed #-}
 
ptr_glBlendEquationSeparateIndexed :: FunPtr a
ptr_glBlendEquationSeparateIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_draw_buffers_blend"
        "glBlendEquationSeparateIndexedAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendFuncIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> IO ())
 
glBlendFuncIndexed :: GLuint -> GLenum -> GLenum -> IO ()
glBlendFuncIndexed = dyn_glBlendFuncIndexed ptr_glBlendFuncIndexed
 
{-# NOINLINE ptr_glBlendFuncIndexed #-}
 
ptr_glBlendFuncIndexed :: FunPtr a
ptr_glBlendFuncIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_draw_buffers_blend"
        "glBlendFuncIndexedAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBlendFuncSeparateIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLenum -> GLenum -> IO ())
 
glBlendFuncSeparateIndexed ::
                           GLuint -> GLenum -> GLenum -> GLenum -> GLenum -> IO ()
glBlendFuncSeparateIndexed
  = dyn_glBlendFuncSeparateIndexed ptr_glBlendFuncSeparateIndexed
 
{-# NOINLINE ptr_glBlendFuncSeparateIndexed #-}
 
ptr_glBlendFuncSeparateIndexed :: FunPtr a
ptr_glBlendFuncSeparateIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_draw_buffers_blend"
        "glBlendFuncSeparateIndexedAMD"