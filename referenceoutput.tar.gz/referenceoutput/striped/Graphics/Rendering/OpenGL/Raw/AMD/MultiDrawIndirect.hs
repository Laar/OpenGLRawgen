{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.MultiDrawIndirect
       (glMultiDrawArraysIndirect, glMultiDrawElementsIndirect) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawArraysIndirect ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr c -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawArraysIndirect ::
                          GLenum -> Ptr c -> GLsizei -> GLsizei -> IO ()
glMultiDrawArraysIndirect
  = dyn_glMultiDrawArraysIndirect ptr_glMultiDrawArraysIndirect
 
{-# NOINLINE ptr_glMultiDrawArraysIndirect #-}
 
ptr_glMultiDrawArraysIndirect :: FunPtr a
ptr_glMultiDrawArraysIndirect
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_multi_draw_indirect"
        "glMultiDrawArraysIndirectAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementsIndirect ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr d -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawElementsIndirect ::
                            GLenum -> GLenum -> Ptr d -> GLsizei -> GLsizei -> IO ()
glMultiDrawElementsIndirect
  = dyn_glMultiDrawElementsIndirect ptr_glMultiDrawElementsIndirect
 
{-# NOINLINE ptr_glMultiDrawElementsIndirect #-}
 
ptr_glMultiDrawElementsIndirect :: FunPtr a
ptr_glMultiDrawElementsIndirect
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_multi_draw_indirect"
        "glMultiDrawElementsIndirectAMD"