{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.AMD.PerformanceMonitor
       (gl_COUNTER_RANGE, gl_COUNTER_TYPE, gl_PERCENTAGE,
        gl_PERFMON_RESULT, gl_PERFMON_RESULT_AVAILABLE,
        gl_PERFMON_RESULT_SIZE, gl_UNSIGNED_INT64, glBeginPerfMonitor,
        glDeletePerfMonitors, glEndPerfMonitor, glGenPerfMonitors,
        glGetPerfMonitorCounterData, glGetPerfMonitorCounterInfo,
        glGetPerfMonitorCounterString, glGetPerfMonitorCounters,
        glGetPerfMonitorGroupString, glGetPerfMonitorGroups,
        glSelectPerfMonitorCounters)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_COUNTER_RANGE :: GLenum
gl_COUNTER_RANGE = 35777
 
gl_COUNTER_TYPE :: GLenum
gl_COUNTER_TYPE = 35776
 
gl_PERCENTAGE :: GLenum
gl_PERCENTAGE = 35779
 
gl_PERFMON_RESULT :: GLenum
gl_PERFMON_RESULT = 35782
 
gl_PERFMON_RESULT_AVAILABLE :: GLenum
gl_PERFMON_RESULT_AVAILABLE = 35780
 
gl_PERFMON_RESULT_SIZE :: GLenum
gl_PERFMON_RESULT_SIZE = 35781
 
gl_UNSIGNED_INT64 :: GLenum
gl_UNSIGNED_INT64 = 35778
 
foreign import CALLCONV unsafe "dynamic" dyn_glBeginPerfMonitor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBeginPerfMonitor :: GLuint -> IO ()
glBeginPerfMonitor = dyn_glBeginPerfMonitor ptr_glBeginPerfMonitor
 
{-# NOINLINE ptr_glBeginPerfMonitor #-}
 
ptr_glBeginPerfMonitor :: FunPtr a
ptr_glBeginPerfMonitor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glBeginPerfMonitorAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeletePerfMonitors ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeletePerfMonitors :: GLsizei -> Ptr GLuint -> IO ()
glDeletePerfMonitors
  = dyn_glDeletePerfMonitors ptr_glDeletePerfMonitors
 
{-# NOINLINE ptr_glDeletePerfMonitors #-}
 
ptr_glDeletePerfMonitors :: FunPtr a
ptr_glDeletePerfMonitors
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glDeletePerfMonitorsAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndPerfMonitor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glEndPerfMonitor :: GLuint -> IO ()
glEndPerfMonitor = dyn_glEndPerfMonitor ptr_glEndPerfMonitor
 
{-# NOINLINE ptr_glEndPerfMonitor #-}
 
ptr_glEndPerfMonitor :: FunPtr a
ptr_glEndPerfMonitor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glEndPerfMonitorAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenPerfMonitors ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenPerfMonitors :: GLsizei -> Ptr GLuint -> IO ()
glGenPerfMonitors = dyn_glGenPerfMonitors ptr_glGenPerfMonitors
 
{-# NOINLINE ptr_glGenPerfMonitors #-}
 
ptr_glGenPerfMonitors :: FunPtr a
ptr_glGenPerfMonitors
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGenPerfMonitorsAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfMonitorCounterData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLsizei -> Ptr GLuint -> Ptr GLint -> IO ())
 
glGetPerfMonitorCounterData ::
                            GLuint -> GLenum -> GLsizei -> Ptr GLuint -> Ptr GLint -> IO ()
glGetPerfMonitorCounterData
  = dyn_glGetPerfMonitorCounterData ptr_glGetPerfMonitorCounterData
 
{-# NOINLINE ptr_glGetPerfMonitorCounterData #-}
 
ptr_glGetPerfMonitorCounterData :: FunPtr a
ptr_glGetPerfMonitorCounterData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorCounterDataAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfMonitorCounterInfo ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> Ptr e -> IO ())
 
glGetPerfMonitorCounterInfo ::
                            GLuint -> GLuint -> GLenum -> Ptr e -> IO ()
glGetPerfMonitorCounterInfo
  = dyn_glGetPerfMonitorCounterInfo ptr_glGetPerfMonitorCounterInfo
 
{-# NOINLINE ptr_glGetPerfMonitorCounterInfo #-}
 
ptr_glGetPerfMonitorCounterInfo :: FunPtr a
ptr_glGetPerfMonitorCounterInfo
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorCounterInfoAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfMonitorCounterString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
glGetPerfMonitorCounterString ::
                              GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetPerfMonitorCounterString
  = dyn_glGetPerfMonitorCounterString
      ptr_glGetPerfMonitorCounterString
 
{-# NOINLINE ptr_glGetPerfMonitorCounterString #-}
 
ptr_glGetPerfMonitorCounterString :: FunPtr a
ptr_glGetPerfMonitorCounterString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorCounterStringAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfMonitorCounters ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    Ptr GLint -> Ptr GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glGetPerfMonitorCounters ::
                         GLuint -> Ptr GLint -> Ptr GLint -> GLsizei -> Ptr GLuint -> IO ()
glGetPerfMonitorCounters
  = dyn_glGetPerfMonitorCounters ptr_glGetPerfMonitorCounters
 
{-# NOINLINE ptr_glGetPerfMonitorCounters #-}
 
ptr_glGetPerfMonitorCounters :: FunPtr a
ptr_glGetPerfMonitorCounters
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorCountersAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfMonitorGroupString ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
glGetPerfMonitorGroupString ::
                            GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetPerfMonitorGroupString
  = dyn_glGetPerfMonitorGroupString ptr_glGetPerfMonitorGroupString
 
{-# NOINLINE ptr_glGetPerfMonitorGroupString #-}
 
ptr_glGetPerfMonitorGroupString :: FunPtr a
ptr_glGetPerfMonitorGroupString
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorGroupStringAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetPerfMonitorGroups
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glGetPerfMonitorGroups ::
                       Ptr GLint -> GLsizei -> Ptr GLuint -> IO ()
glGetPerfMonitorGroups
  = dyn_glGetPerfMonitorGroups ptr_glGetPerfMonitorGroups
 
{-# NOINLINE ptr_glGetPerfMonitorGroups #-}
 
ptr_glGetPerfMonitorGroups :: FunPtr a
ptr_glGetPerfMonitorGroups
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glGetPerfMonitorGroupsAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glSelectPerfMonitorCounters ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLboolean -> GLuint -> GLint -> Ptr GLuint -> IO ())
 
glSelectPerfMonitorCounters ::
                            GLuint -> GLboolean -> GLuint -> GLint -> Ptr GLuint -> IO ()
glSelectPerfMonitorCounters
  = dyn_glSelectPerfMonitorCounters ptr_glSelectPerfMonitorCounters
 
{-# NOINLINE ptr_glSelectPerfMonitorCounters #-}
 
ptr_glSelectPerfMonitorCounters :: FunPtr a
ptr_glSelectPerfMonitorCounters
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_performance_monitor"
        "glSelectPerfMonitorCountersAMD"