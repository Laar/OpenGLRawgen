-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.DepthClampSeparate
       (gl_DEPTH_CLAMP_FAR, gl_DEPTH_CLAMP_NEAR) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_CLAMP_FAR :: GLenum
gl_DEPTH_CLAMP_FAR = 36895
 
gl_DEPTH_CLAMP_NEAR :: GLenum
gl_DEPTH_CLAMP_NEAR = 36894