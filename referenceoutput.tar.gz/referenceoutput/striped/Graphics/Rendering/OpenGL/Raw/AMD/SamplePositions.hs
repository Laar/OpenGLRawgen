{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.AMD.SamplePositions
       (gl_SUBSAMPLE_DISTANCE, glSetMultisamplefv) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_SUBSAMPLE_DISTANCE :: GLenum
gl_SUBSAMPLE_DISTANCE = 34879
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetMultisamplefv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glSetMultisamplefv :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glSetMultisamplefv = dyn_glSetMultisamplefv ptr_glSetMultisamplefv
 
{-# NOINLINE ptr_glSetMultisamplefv #-}
 
ptr_glSetMultisamplefv :: FunPtr a
ptr_glSetMultisamplefv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_sample_positions"
        "glSetMultisamplefvAMD"