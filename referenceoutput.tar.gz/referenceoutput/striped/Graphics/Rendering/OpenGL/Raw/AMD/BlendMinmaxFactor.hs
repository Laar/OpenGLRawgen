module Graphics.Rendering.OpenGL.Raw.AMD.BlendMinmaxFactor
       (gl_FACTOR_MAX, gl_FACTOR_MIN) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FACTOR_MAX :: GLenum
gl_FACTOR_MAX = 36893
 
gl_FACTOR_MIN :: GLenum
gl_FACTOR_MIN = 36892