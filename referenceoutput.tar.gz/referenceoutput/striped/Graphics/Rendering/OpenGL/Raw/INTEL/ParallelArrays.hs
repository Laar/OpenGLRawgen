{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.INTEL.ParallelArrays
       (gl_COLOR_ARRAY_PARALLEL_POINTERS,
        gl_NORMAL_ARRAY_PARALLEL_POINTERS, gl_PARALLEL_ARRAYS,
        gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS,
        gl_VERTEX_ARRAY_PARALLEL_POINTERS, glColorPointerv,
        glNormalPointerv, glTexCoordPointerv, glVertexPointerv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_COLOR_ARRAY_PARALLEL_POINTERS :: GLenum
gl_COLOR_ARRAY_PARALLEL_POINTERS = 33783
 
gl_NORMAL_ARRAY_PARALLEL_POINTERS :: GLenum
gl_NORMAL_ARRAY_PARALLEL_POINTERS = 33782
 
gl_PARALLEL_ARRAYS :: GLenum
gl_PARALLEL_ARRAYS = 33780
 
gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS :: GLenum
gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS = 33784
 
gl_VERTEX_ARRAY_PARALLEL_POINTERS :: GLenum
gl_VERTEX_ARRAY_PARALLEL_POINTERS = 33781
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glColorPointerv :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glColorPointerv = dyn_glColorPointerv ptr_glColorPointerv
 
{-# NOINLINE ptr_glColorPointerv #-}
 
ptr_glColorPointerv :: FunPtr a
ptr_glColorPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glColorPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr (Ptr c) -> IO ())
 
glNormalPointerv :: GLenum -> Ptr (Ptr c) -> IO ()
glNormalPointerv = dyn_glNormalPointerv ptr_glNormalPointerv
 
{-# NOINLINE ptr_glNormalPointerv #-}
 
ptr_glNormalPointerv :: FunPtr a
ptr_glNormalPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glNormalPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glTexCoordPointerv :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glTexCoordPointerv = dyn_glTexCoordPointerv ptr_glTexCoordPointerv
 
{-# NOINLINE ptr_glTexCoordPointerv #-}
 
ptr_glTexCoordPointerv :: FunPtr a
ptr_glTexCoordPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glTexCoordPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexPointerv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glVertexPointerv :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glVertexPointerv = dyn_glVertexPointerv ptr_glVertexPointerv
 
{-# NOINLINE ptr_glVertexPointerv #-}
 
ptr_glVertexPointerv :: FunPtr a
ptr_glVertexPointerv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glVertexPointervINTEL"