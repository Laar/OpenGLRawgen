-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TexgenReflection
       (gl_NORMAL_MAP, gl_REFLECTION_MAP) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_NORMAL_MAP :: GLenum
gl_NORMAL_MAP = 34065
 
gl_REFLECTION_MAP :: GLenum
gl_REFLECTION_MAP = 34066