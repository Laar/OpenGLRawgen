-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.VertexProgram2Option
       (gl_MAX_PROGRAM_CALL_DEPTH, gl_MAX_PROGRAM_EXEC_INSTRUCTIONS) where
import Graphics.Rendering.OpenGL.Raw.NV.FragmentProgram2
       (gl_MAX_PROGRAM_CALL_DEPTH)
import Graphics.Rendering.OpenGL.Raw.NV.FragmentProgram2
       (gl_MAX_PROGRAM_EXEC_INSTRUCTIONS)