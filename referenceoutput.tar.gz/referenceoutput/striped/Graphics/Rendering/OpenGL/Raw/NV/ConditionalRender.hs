{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.ConditionalRender
       (gl_QUERY_BY_REGION_NO_WAIT, gl_QUERY_BY_REGION_WAIT,
        gl_QUERY_NO_WAIT, gl_QUERY_WAIT, glBeginConditionalRender,
        glEndConditionalRender)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_QUERY_BY_REGION_NO_WAIT :: GLenum
gl_QUERY_BY_REGION_NO_WAIT = 36374
 
gl_QUERY_BY_REGION_WAIT :: GLenum
gl_QUERY_BY_REGION_WAIT = 36373
 
gl_QUERY_NO_WAIT :: GLenum
gl_QUERY_NO_WAIT = 36372
 
gl_QUERY_WAIT :: GLenum
gl_QUERY_WAIT = 36371
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBeginConditionalRender ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glBeginConditionalRender :: GLuint -> GLenum -> IO ()
glBeginConditionalRender
  = dyn_glBeginConditionalRender ptr_glBeginConditionalRender
 
{-# NOINLINE ptr_glBeginConditionalRender #-}
 
ptr_glBeginConditionalRender :: FunPtr a
ptr_glBeginConditionalRender
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_conditional_render"
        "glBeginConditionalRenderNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndConditionalRender
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glEndConditionalRender :: IO ()
glEndConditionalRender
  = dyn_glEndConditionalRender ptr_glEndConditionalRender
 
{-# NOINLINE ptr_glEndConditionalRender #-}
 
ptr_glEndConditionalRender :: FunPtr a
ptr_glEndConditionalRender
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_conditional_render"
        "glEndConditionalRenderNV"