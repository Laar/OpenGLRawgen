{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.RegisterCombiners2
       (gl_PER_STAGE_CONSTANTS, glCombinerStageParameterfv,
        glGetCombinerStageParameterfv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PER_STAGE_CONSTANTS :: GLenum
gl_PER_STAGE_CONSTANTS = 34101
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCombinerStageParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glCombinerStageParameterfv ::
                           GLenum -> GLenum -> Ptr GLfloat -> IO ()
glCombinerStageParameterfv
  = dyn_glCombinerStageParameterfv ptr_glCombinerStageParameterfv
 
{-# NOINLINE ptr_glCombinerStageParameterfv #-}
 
ptr_glCombinerStageParameterfv :: FunPtr a
ptr_glCombinerStageParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_register_combiners2"
        "glCombinerStageParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetCombinerStageParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetCombinerStageParameterfv ::
                              GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetCombinerStageParameterfv
  = dyn_glGetCombinerStageParameterfv
      ptr_glGetCombinerStageParameterfv
 
{-# NOINLINE ptr_glGetCombinerStageParameterfv #-}
 
ptr_glGetCombinerStageParameterfv :: FunPtr a
ptr_glGetCombinerStageParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_register_combiners2"
        "glGetCombinerStageParameterfvNV"