{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.VertexProgram4
       (gl_VERTEX_ATTRIB_ARRAY_INTEGER, glGetVertexAttribIiv,
        glGetVertexAttribIuiv, glVertexAttribI1i, glVertexAttribI1iv,
        glVertexAttribI1ui, glVertexAttribI1uiv, glVertexAttribI2i,
        glVertexAttribI2iv, glVertexAttribI2ui, glVertexAttribI2uiv,
        glVertexAttribI3i, glVertexAttribI3iv, glVertexAttribI3ui,
        glVertexAttribI3uiv, glVertexAttribI4bv, glVertexAttribI4i,
        glVertexAttribI4iv, glVertexAttribI4sv, glVertexAttribI4ubv,
        glVertexAttribI4ui, glVertexAttribI4uiv, glVertexAttribI4usv,
        glVertexAttribIPointer)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_VERTEX_ATTRIB_ARRAY_INTEGER :: GLenum
gl_VERTEX_ATTRIB_ARRAY_INTEGER = 35069
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexAttribIiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexAttribIiv
  = dyn_glGetVertexAttribIiv ptr_glGetVertexAttribIiv
 
{-# NOINLINE ptr_glGetVertexAttribIiv #-}
 
ptr_glGetVertexAttribIiv :: FunPtr a
ptr_glGetVertexAttribIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glGetVertexAttribIivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribIuiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
glGetVertexAttribIuiv :: GLuint -> GLenum -> Ptr GLuint -> IO ()
glGetVertexAttribIuiv
  = dyn_glGetVertexAttribIuiv ptr_glGetVertexAttribIuiv
 
{-# NOINLINE ptr_glGetVertexAttribIuiv #-}
 
ptr_glGetVertexAttribIuiv :: FunPtr a
ptr_glGetVertexAttribIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glGetVertexAttribIuivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> IO ())
 
glVertexAttribI1i :: GLuint -> GLint -> IO ()
glVertexAttribI1i = dyn_glVertexAttribI1i ptr_glVertexAttribI1i
 
{-# NOINLINE ptr_glVertexAttribI1i #-}
 
ptr_glVertexAttribI1i :: FunPtr a
ptr_glVertexAttribI1i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI1iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI1iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI1iv = dyn_glVertexAttribI1iv ptr_glVertexAttribI1iv
 
{-# NOINLINE ptr_glVertexAttribI1iv #-}
 
ptr_glVertexAttribI1iv :: FunPtr a
ptr_glVertexAttribI1iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI1ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glVertexAttribI1ui :: GLuint -> GLuint -> IO ()
glVertexAttribI1ui = dyn_glVertexAttribI1ui ptr_glVertexAttribI1ui
 
{-# NOINLINE ptr_glVertexAttribI1ui #-}
 
ptr_glVertexAttribI1ui :: FunPtr a
ptr_glVertexAttribI1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI1uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI1uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI1uiv
  = dyn_glVertexAttribI1uiv ptr_glVertexAttribI1uiv
 
{-# NOINLINE ptr_glVertexAttribI1uiv #-}
 
ptr_glVertexAttribI1uiv :: FunPtr a
ptr_glVertexAttribI1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI1uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> IO ())
 
glVertexAttribI2i :: GLuint -> GLint -> GLint -> IO ()
glVertexAttribI2i = dyn_glVertexAttribI2i ptr_glVertexAttribI2i
 
{-# NOINLINE ptr_glVertexAttribI2i #-}
 
ptr_glVertexAttribI2i :: FunPtr a
ptr_glVertexAttribI2i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI2iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI2iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI2iv = dyn_glVertexAttribI2iv ptr_glVertexAttribI2iv
 
{-# NOINLINE ptr_glVertexAttribI2iv #-}
 
ptr_glVertexAttribI2iv :: FunPtr a
ptr_glVertexAttribI2iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI2ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI2ui :: GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI2ui = dyn_glVertexAttribI2ui ptr_glVertexAttribI2ui
 
{-# NOINLINE ptr_glVertexAttribI2ui #-}
 
ptr_glVertexAttribI2ui :: FunPtr a
ptr_glVertexAttribI2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI2uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI2uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI2uiv
  = dyn_glVertexAttribI2uiv ptr_glVertexAttribI2uiv
 
{-# NOINLINE ptr_glVertexAttribI2uiv #-}
 
ptr_glVertexAttribI2uiv :: FunPtr a
ptr_glVertexAttribI2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI2uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> IO ())
 
glVertexAttribI3i :: GLuint -> GLint -> GLint -> GLint -> IO ()
glVertexAttribI3i = dyn_glVertexAttribI3i ptr_glVertexAttribI3i
 
{-# NOINLINE ptr_glVertexAttribI3i #-}
 
ptr_glVertexAttribI3i :: FunPtr a
ptr_glVertexAttribI3i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI3iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI3iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI3iv = dyn_glVertexAttribI3iv ptr_glVertexAttribI3iv
 
{-# NOINLINE ptr_glVertexAttribI3iv #-}
 
ptr_glVertexAttribI3iv :: FunPtr a
ptr_glVertexAttribI3iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI3ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI3ui :: GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI3ui = dyn_glVertexAttribI3ui ptr_glVertexAttribI3ui
 
{-# NOINLINE ptr_glVertexAttribI3ui #-}
 
ptr_glVertexAttribI3ui :: FunPtr a
ptr_glVertexAttribI3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI3uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI3uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI3uiv
  = dyn_glVertexAttribI3uiv ptr_glVertexAttribI3uiv
 
{-# NOINLINE ptr_glVertexAttribI3uiv #-}
 
ptr_glVertexAttribI3uiv :: FunPtr a
ptr_glVertexAttribI3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI3uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4bv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLbyte -> IO ())
 
glVertexAttribI4bv :: GLuint -> Ptr GLbyte -> IO ()
glVertexAttribI4bv = dyn_glVertexAttribI4bv ptr_glVertexAttribI4bv
 
{-# NOINLINE ptr_glVertexAttribI4bv #-}
 
ptr_glVertexAttribI4bv :: FunPtr a
ptr_glVertexAttribI4bv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4bvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glVertexAttribI4i ::
                  GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glVertexAttribI4i = dyn_glVertexAttribI4i ptr_glVertexAttribI4i
 
{-# NOINLINE ptr_glVertexAttribI4i #-}
 
ptr_glVertexAttribI4i :: FunPtr a
ptr_glVertexAttribI4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI4iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI4iv = dyn_glVertexAttribI4iv ptr_glVertexAttribI4iv
 
{-# NOINLINE ptr_glVertexAttribI4iv #-}
 
ptr_glVertexAttribI4iv :: FunPtr a
ptr_glVertexAttribI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4sv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttribI4sv :: GLuint -> Ptr GLshort -> IO ()
glVertexAttribI4sv = dyn_glVertexAttribI4sv ptr_glVertexAttribI4sv
 
{-# NOINLINE ptr_glVertexAttribI4sv #-}
 
ptr_glVertexAttribI4sv :: FunPtr a
ptr_glVertexAttribI4sv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4svEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4ubv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLubyte -> IO ())
 
glVertexAttribI4ubv :: GLuint -> Ptr GLubyte -> IO ()
glVertexAttribI4ubv
  = dyn_glVertexAttribI4ubv ptr_glVertexAttribI4ubv
 
{-# NOINLINE ptr_glVertexAttribI4ubv #-}
 
ptr_glVertexAttribI4ubv :: FunPtr a
ptr_glVertexAttribI4ubv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4ubvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI4ui ::
                   GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI4ui = dyn_glVertexAttribI4ui ptr_glVertexAttribI4ui
 
{-# NOINLINE ptr_glVertexAttribI4ui #-}
 
ptr_glVertexAttribI4ui :: FunPtr a
ptr_glVertexAttribI4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI4uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI4uiv
  = dyn_glVertexAttribI4uiv ptr_glVertexAttribI4uiv
 
{-# NOINLINE ptr_glVertexAttribI4uiv #-}
 
ptr_glVertexAttribI4uiv :: FunPtr a
ptr_glVertexAttribI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4usv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLushort -> IO ())
 
glVertexAttribI4usv :: GLuint -> Ptr GLushort -> IO ()
glVertexAttribI4usv
  = dyn_glVertexAttribI4usv ptr_glVertexAttribI4usv
 
{-# NOINLINE ptr_glVertexAttribI4usv #-}
 
ptr_glVertexAttribI4usv :: FunPtr a
ptr_glVertexAttribI4usv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribI4usvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribIPointer
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLenum -> GLsizei -> Ptr a -> IO ())
 
glVertexAttribIPointer ::
                       GLuint -> GLint -> GLenum -> GLsizei -> Ptr a -> IO ()
glVertexAttribIPointer
  = dyn_glVertexAttribIPointer ptr_glVertexAttribIPointer
 
{-# NOINLINE ptr_glVertexAttribIPointer #-}
 
ptr_glVertexAttribIPointer :: FunPtr a
ptr_glVertexAttribIPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_program4"
        "glVertexAttribIPointerEXT"