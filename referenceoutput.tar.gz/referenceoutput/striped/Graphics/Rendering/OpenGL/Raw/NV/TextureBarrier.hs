{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TextureBarrier
       (glTextureBarrier) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureBarrier ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glTextureBarrier :: IO ()
glTextureBarrier = dyn_glTextureBarrier ptr_glTextureBarrier
 
{-# NOINLINE ptr_glTextureBarrier #-}
 
ptr_glTextureBarrier :: FunPtr a
ptr_glTextureBarrier
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_texture_barrier"
        "glTextureBarrierNV"