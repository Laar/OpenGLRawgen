{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.ParameterBufferObject
       (gl_FRAGMENT_PROGRAM_PARAMETER_BUFFER,
        gl_GEOMETRY_PROGRAM_PARAMETER_BUFFER,
        gl_MAX_PROGRAM_PARAMETER_BUFFER_BINDINGS,
        gl_MAX_PROGRAM_PARAMETER_BUFFER_SIZE,
        gl_VERTEX_PROGRAM_PARAMETER_BUFFER, glProgramBufferParametersIiv,
        glProgramBufferParametersIuiv, glProgramBufferParametersfv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FRAGMENT_PROGRAM_PARAMETER_BUFFER :: GLenum
gl_FRAGMENT_PROGRAM_PARAMETER_BUFFER = 36260
 
gl_GEOMETRY_PROGRAM_PARAMETER_BUFFER :: GLenum
gl_GEOMETRY_PROGRAM_PARAMETER_BUFFER = 36259
 
gl_MAX_PROGRAM_PARAMETER_BUFFER_BINDINGS :: GLenum
gl_MAX_PROGRAM_PARAMETER_BUFFER_BINDINGS = 36256
 
gl_MAX_PROGRAM_PARAMETER_BUFFER_SIZE :: GLenum
gl_MAX_PROGRAM_PARAMETER_BUFFER_SIZE = 36257
 
gl_VERTEX_PROGRAM_PARAMETER_BUFFER :: GLenum
gl_VERTEX_PROGRAM_PARAMETER_BUFFER = 36258
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramBufferParametersIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramBufferParametersIiv ::
                             GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLint -> IO ()
glProgramBufferParametersIiv
  = dyn_glProgramBufferParametersIiv ptr_glProgramBufferParametersIiv
 
{-# NOINLINE ptr_glProgramBufferParametersIiv #-}
 
ptr_glProgramBufferParametersIiv :: FunPtr a
ptr_glProgramBufferParametersIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_parameter_buffer_object"
        "glProgramBufferParametersIivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramBufferParametersIuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramBufferParametersIuiv ::
                              GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLuint -> IO ()
glProgramBufferParametersIuiv
  = dyn_glProgramBufferParametersIuiv
      ptr_glProgramBufferParametersIuiv
 
{-# NOINLINE ptr_glProgramBufferParametersIuiv #-}
 
ptr_glProgramBufferParametersIuiv :: FunPtr a
ptr_glProgramBufferParametersIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_parameter_buffer_object"
        "glProgramBufferParametersIuivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramBufferParametersfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramBufferParametersfv ::
                            GLenum -> GLuint -> GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramBufferParametersfv
  = dyn_glProgramBufferParametersfv ptr_glProgramBufferParametersfv
 
{-# NOINLINE ptr_glProgramBufferParametersfv #-}
 
ptr_glProgramBufferParametersfv :: FunPtr a
ptr_glProgramBufferParametersfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_parameter_buffer_object"
        "glProgramBufferParametersfvNV"