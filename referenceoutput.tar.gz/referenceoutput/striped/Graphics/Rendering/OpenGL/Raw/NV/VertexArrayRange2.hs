-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.VertexArrayRange2
       (gl_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH :: GLenum
gl_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH = 34099