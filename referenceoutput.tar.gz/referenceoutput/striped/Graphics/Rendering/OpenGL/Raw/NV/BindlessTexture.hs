{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.BindlessTexture
       (glGetImageHandle, glGetTextureHandle, glGetTextureSamplerHandle,
        glIsImageHandleResident, glIsTextureHandleResident,
        glMakeImageHandleNonResident, glMakeImageHandleResident,
        glMakeTextureHandleNonResident, glMakeTextureHandleResident,
        glProgramUniformHandleui64, glProgramUniformHandleui64v,
        glUniformHandleui64, glUniformHandleui64v)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetImageHandle ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLboolean -> GLint -> GLenum -> IO GLuint64)
 
glGetImageHandle ::
                 GLuint -> GLint -> GLboolean -> GLint -> GLenum -> IO GLuint64
glGetImageHandle = dyn_glGetImageHandle ptr_glGetImageHandle
 
{-# NOINLINE ptr_glGetImageHandle #-}
 
ptr_glGetImageHandle :: FunPtr a
ptr_glGetImageHandle
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glGetImageHandleNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTextureHandle ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLuint64)
 
glGetTextureHandle :: GLuint -> IO GLuint64
glGetTextureHandle = dyn_glGetTextureHandle ptr_glGetTextureHandle
 
{-# NOINLINE ptr_glGetTextureHandle #-}
 
ptr_glGetTextureHandle :: FunPtr a
ptr_glGetTextureHandle
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glGetTextureHandleNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureSamplerHandle ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO GLuint64)
 
glGetTextureSamplerHandle :: GLuint -> GLuint -> IO GLuint64
glGetTextureSamplerHandle
  = dyn_glGetTextureSamplerHandle ptr_glGetTextureSamplerHandle
 
{-# NOINLINE ptr_glGetTextureSamplerHandle #-}
 
ptr_glGetTextureSamplerHandle :: FunPtr a
ptr_glGetTextureSamplerHandle
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glGetTextureSamplerHandleNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsImageHandleResident
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO GLboolean)
 
glIsImageHandleResident :: GLuint64 -> IO GLboolean
glIsImageHandleResident
  = dyn_glIsImageHandleResident ptr_glIsImageHandleResident
 
{-# NOINLINE ptr_glIsImageHandleResident #-}
 
ptr_glIsImageHandleResident :: FunPtr a
ptr_glIsImageHandleResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glIsImageHandleResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glIsTextureHandleResident ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO GLboolean)
 
glIsTextureHandleResident :: GLuint64 -> IO GLboolean
glIsTextureHandleResident
  = dyn_glIsTextureHandleResident ptr_glIsTextureHandleResident
 
{-# NOINLINE ptr_glIsTextureHandleResident #-}
 
ptr_glIsTextureHandleResident :: FunPtr a
ptr_glIsTextureHandleResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glIsTextureHandleResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeImageHandleNonResident ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeImageHandleNonResident :: GLuint64 -> IO ()
glMakeImageHandleNonResident
  = dyn_glMakeImageHandleNonResident ptr_glMakeImageHandleNonResident
 
{-# NOINLINE ptr_glMakeImageHandleNonResident #-}
 
ptr_glMakeImageHandleNonResident :: FunPtr a
ptr_glMakeImageHandleNonResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glMakeImageHandleNonResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeImageHandleResident ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> GLenum -> IO ())
 
glMakeImageHandleResident :: GLuint64 -> GLenum -> IO ()
glMakeImageHandleResident
  = dyn_glMakeImageHandleResident ptr_glMakeImageHandleResident
 
{-# NOINLINE ptr_glMakeImageHandleResident #-}
 
ptr_glMakeImageHandleResident :: FunPtr a
ptr_glMakeImageHandleResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glMakeImageHandleResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeTextureHandleNonResident ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeTextureHandleNonResident :: GLuint64 -> IO ()
glMakeTextureHandleNonResident
  = dyn_glMakeTextureHandleNonResident
      ptr_glMakeTextureHandleNonResident
 
{-# NOINLINE ptr_glMakeTextureHandleNonResident #-}
 
ptr_glMakeTextureHandleNonResident :: FunPtr a
ptr_glMakeTextureHandleNonResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glMakeTextureHandleNonResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeTextureHandleResident ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeTextureHandleResident :: GLuint64 -> IO ()
glMakeTextureHandleResident
  = dyn_glMakeTextureHandleResident ptr_glMakeTextureHandleResident
 
{-# NOINLINE ptr_glMakeTextureHandleResident #-}
 
ptr_glMakeTextureHandleResident :: FunPtr a
ptr_glMakeTextureHandleResident
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glMakeTextureHandleResidentNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformHandleui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint64 -> IO ())
 
glProgramUniformHandleui64 :: GLuint -> GLint -> GLuint64 -> IO ()
glProgramUniformHandleui64
  = dyn_glProgramUniformHandleui64 ptr_glProgramUniformHandleui64
 
{-# NOINLINE ptr_glProgramUniformHandleui64 #-}
 
ptr_glProgramUniformHandleui64 :: FunPtr a
ptr_glProgramUniformHandleui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glProgramUniformHandleui64NV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformHandleui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniformHandleui64v ::
                            GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniformHandleui64v
  = dyn_glProgramUniformHandleui64v ptr_glProgramUniformHandleui64v
 
{-# NOINLINE ptr_glProgramUniformHandleui64v #-}
 
ptr_glProgramUniformHandleui64v :: FunPtr a
ptr_glProgramUniformHandleui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glProgramUniformHandleui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformHandleui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> IO ())
 
glUniformHandleui64 :: GLint -> GLuint64 -> IO ()
glUniformHandleui64
  = dyn_glUniformHandleui64 ptr_glUniformHandleui64
 
{-# NOINLINE ptr_glUniformHandleui64 #-}
 
ptr_glUniformHandleui64 :: FunPtr a
ptr_glUniformHandleui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glUniformHandleui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformHandleui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniformHandleui64v :: GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniformHandleui64v
  = dyn_glUniformHandleui64v ptr_glUniformHandleui64v
 
{-# NOINLINE ptr_glUniformHandleui64v #-}
 
ptr_glUniformHandleui64v :: FunPtr a
ptr_glUniformHandleui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_texture"
        "glUniformHandleui64vNV"