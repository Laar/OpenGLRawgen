module Graphics.Rendering.OpenGL.Raw.NV.PackedDepthStencil
       (gl_DEPTH_STENCIL, gl_UNSIGNED_INT_24_8) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_STENCIL :: GLenum
gl_DEPTH_STENCIL = 34041
 
gl_UNSIGNED_INT_24_8 :: GLenum
gl_UNSIGNED_INT_24_8 = 34042