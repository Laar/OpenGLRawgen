{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.PresentVideo
       (gl_CURRENT_TIME, gl_FIELDS, gl_FRAME, gl_NUM_FILL_STREAMS,
        gl_PRESENT_DURATION, gl_PRESENT_TIME, glGetVideoi64v, glGetVideoiv,
        glGetVideoui64v, glGetVideouiv, glPresentFrameDualFill,
        glPresentFrameKeyed)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CURRENT_TIME :: GLenum
gl_CURRENT_TIME = 36392
 
gl_FIELDS :: GLenum
gl_FIELDS = 36391
 
gl_FRAME :: GLenum
gl_FRAME = 36390
 
gl_NUM_FILL_STREAMS :: GLenum
gl_NUM_FILL_STREAMS = 36393
 
gl_PRESENT_DURATION :: GLenum
gl_PRESENT_DURATION = 36395
 
gl_PRESENT_TIME :: GLenum
gl_PRESENT_TIME = 36394
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVideoi64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint64 -> IO ())
 
glGetVideoi64v :: GLuint -> GLenum -> Ptr GLint64 -> IO ()
glGetVideoi64v = dyn_glGetVideoi64v ptr_glGetVideoi64v
 
{-# NOINLINE ptr_glGetVideoi64v #-}
 
ptr_glGetVideoi64v :: FunPtr a
ptr_glGetVideoi64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glGetVideoi64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVideoiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVideoiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVideoiv = dyn_glGetVideoiv ptr_glGetVideoiv
 
{-# NOINLINE ptr_glGetVideoiv #-}
 
ptr_glGetVideoiv :: FunPtr a
ptr_glGetVideoiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glGetVideoivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVideoui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint64 -> IO ())
 
glGetVideoui64v :: GLuint -> GLenum -> Ptr GLuint64 -> IO ()
glGetVideoui64v = dyn_glGetVideoui64v ptr_glGetVideoui64v
 
{-# NOINLINE ptr_glGetVideoui64v #-}
 
ptr_glGetVideoui64v :: FunPtr a
ptr_glGetVideoui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glGetVideoui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVideouiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
glGetVideouiv :: GLuint -> GLenum -> Ptr GLuint -> IO ()
glGetVideouiv = dyn_glGetVideouiv ptr_glGetVideouiv
 
{-# NOINLINE ptr_glGetVideouiv #-}
 
ptr_glGetVideouiv :: FunPtr a
ptr_glGetVideouiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glGetVideouivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPresentFrameDualFill
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint64 ->
                      GLuint ->
                        GLuint ->
                          GLenum ->
                            GLenum ->
                              GLuint ->
                                GLenum -> GLuint -> GLenum -> GLuint -> GLenum -> GLuint -> IO ())
 
glPresentFrameDualFill ::
                       GLuint ->
                         GLuint64 ->
                           GLuint ->
                             GLuint ->
                               GLenum ->
                                 GLenum ->
                                   GLuint ->
                                     GLenum ->
                                       GLuint -> GLenum -> GLuint -> GLenum -> GLuint -> IO ()
glPresentFrameDualFill
  = dyn_glPresentFrameDualFill ptr_glPresentFrameDualFill
 
{-# NOINLINE ptr_glPresentFrameDualFill #-}
 
ptr_glPresentFrameDualFill :: FunPtr a
ptr_glPresentFrameDualFill
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glPresentFrameDualFillNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPresentFrameKeyed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint64 ->
                      GLuint ->
                        GLuint ->
                          GLenum ->
                            GLenum -> GLuint -> GLuint -> GLenum -> GLuint -> GLuint -> IO ())
 
glPresentFrameKeyed ::
                    GLuint ->
                      GLuint64 ->
                        GLuint ->
                          GLuint ->
                            GLenum ->
                              GLenum -> GLuint -> GLuint -> GLenum -> GLuint -> GLuint -> IO ()
glPresentFrameKeyed
  = dyn_glPresentFrameKeyed ptr_glPresentFrameKeyed
 
{-# NOINLINE ptr_glPresentFrameKeyed #-}
 
ptr_glPresentFrameKeyed :: FunPtr a
ptr_glPresentFrameKeyed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_present_video"
        "glPresentFrameKeyedNV"