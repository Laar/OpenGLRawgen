-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TessellationProgram5
       (gl_MAX_PROGRAM_PATCH_ATTRIBS, gl_TESS_CONTROL_PROGRAM,
        gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER,
        gl_TESS_EVALUATION_PROGRAM,
        gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_PROGRAM_PATCH_ATTRIBS :: GLenum
gl_MAX_PROGRAM_PATCH_ATTRIBS = 34520
 
gl_TESS_CONTROL_PROGRAM :: GLenum
gl_TESS_CONTROL_PROGRAM = 35102
 
gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER :: GLenum
gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER = 35956
 
gl_TESS_EVALUATION_PROGRAM :: GLenum
gl_TESS_EVALUATION_PROGRAM = 35103
 
gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER :: GLenum
gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER = 35957