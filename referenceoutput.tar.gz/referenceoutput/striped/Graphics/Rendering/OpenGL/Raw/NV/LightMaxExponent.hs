-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.LightMaxExponent
       (gl_MAX_SHININESS, gl_MAX_SPOT_EXPONENT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_SHININESS :: GLenum
gl_MAX_SHININESS = 34052
 
gl_MAX_SPOT_EXPONENT :: GLenum
gl_MAX_SPOT_EXPONENT = 34053