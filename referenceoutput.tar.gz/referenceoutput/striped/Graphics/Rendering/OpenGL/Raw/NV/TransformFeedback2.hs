{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.TransformFeedback2
       (gl_TRANSFORM_FEEDBACK_BINDING,
        gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED, gl_TRANSFORM_FEEDBACK,
        glBindTransformFeedback, glDeleteTransformFeedbacks,
        glDrawTransformFeedback, glGenTransformFeedbacks,
        glIsTransformFeedback, glPauseTransformFeedback,
        glResumeTransformFeedback)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TRANSFORM_FEEDBACK_BINDING :: GLenum
gl_TRANSFORM_FEEDBACK_BINDING = 36389
 
gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE = 36388
 
gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED = 36387
 
gl_TRANSFORM_FEEDBACK :: GLenum
gl_TRANSFORM_FEEDBACK = 36386
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindTransformFeedback
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindTransformFeedback :: GLenum -> GLuint -> IO ()
glBindTransformFeedback
  = dyn_glBindTransformFeedback ptr_glBindTransformFeedback
 
{-# NOINLINE ptr_glBindTransformFeedback #-}
 
ptr_glBindTransformFeedback :: FunPtr a
ptr_glBindTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glBindTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDeleteTransformFeedbacks ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteTransformFeedbacks :: GLsizei -> Ptr GLuint -> IO ()
glDeleteTransformFeedbacks
  = dyn_glDeleteTransformFeedbacks ptr_glDeleteTransformFeedbacks
 
{-# NOINLINE ptr_glDeleteTransformFeedbacks #-}
 
ptr_glDeleteTransformFeedbacks :: FunPtr a
ptr_glDeleteTransformFeedbacks
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glDeleteTransformFeedbacksNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawTransformFeedback
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDrawTransformFeedback :: GLenum -> GLuint -> IO ()
glDrawTransformFeedback
  = dyn_glDrawTransformFeedback ptr_glDrawTransformFeedback
 
{-# NOINLINE ptr_glDrawTransformFeedback #-}
 
ptr_glDrawTransformFeedback :: FunPtr a
ptr_glDrawTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glDrawTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenTransformFeedbacks
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenTransformFeedbacks :: GLsizei -> Ptr GLuint -> IO ()
glGenTransformFeedbacks
  = dyn_glGenTransformFeedbacks ptr_glGenTransformFeedbacks
 
{-# NOINLINE ptr_glGenTransformFeedbacks #-}
 
ptr_glGenTransformFeedbacks :: FunPtr a
ptr_glGenTransformFeedbacks
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glGenTransformFeedbacksNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsTransformFeedback
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsTransformFeedback :: GLuint -> IO GLboolean
glIsTransformFeedback
  = dyn_glIsTransformFeedback ptr_glIsTransformFeedback
 
{-# NOINLINE ptr_glIsTransformFeedback #-}
 
ptr_glIsTransformFeedback :: FunPtr a
ptr_glIsTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glIsTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPauseTransformFeedback ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glPauseTransformFeedback :: IO ()
glPauseTransformFeedback
  = dyn_glPauseTransformFeedback ptr_glPauseTransformFeedback
 
{-# NOINLINE ptr_glPauseTransformFeedback #-}
 
ptr_glPauseTransformFeedback :: FunPtr a
ptr_glPauseTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glPauseTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glResumeTransformFeedback ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glResumeTransformFeedback :: IO ()
glResumeTransformFeedback
  = dyn_glResumeTransformFeedback ptr_glResumeTransformFeedback
 
{-# NOINLINE ptr_glResumeTransformFeedback #-}
 
ptr_glResumeTransformFeedback :: FunPtr a
ptr_glResumeTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glResumeTransformFeedbackNV"