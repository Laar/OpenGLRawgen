module Graphics.Rendering.OpenGL.Raw.NV.DepthClamp (gl_DEPTH_CLAMP)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_CLAMP :: GLenum
gl_DEPTH_CLAMP = 34383