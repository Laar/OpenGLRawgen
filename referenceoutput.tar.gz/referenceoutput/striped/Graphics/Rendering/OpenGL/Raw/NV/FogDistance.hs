-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.FogDistance
       (gl_EYE_PLANE, gl_EYE_PLANE_ABSOLUTE, gl_EYE_RADIAL,
        gl_FOG_DISTANCE_MODE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11Compatibility
       (gl_EYE_PLANE)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_EYE_PLANE_ABSOLUTE :: GLenum
gl_EYE_PLANE_ABSOLUTE = 34140
 
gl_EYE_RADIAL :: GLenum
gl_EYE_RADIAL = 34139
 
gl_FOG_DISTANCE_MODE :: GLenum
gl_FOG_DISTANCE_MODE = 34138