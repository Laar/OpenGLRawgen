{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.PointSprite
       (gl_COORD_REPLACE, gl_POINT_SPRITE, gl_POINT_SPRITE_R_MODE,
        glPointParameteri, glPointParameteriv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_COORD_REPLACE :: GLenum
gl_COORD_REPLACE = 34914
 
gl_POINT_SPRITE :: GLenum
gl_POINT_SPRITE = 34913
 
gl_POINT_SPRITE_R_MODE :: GLenum
gl_POINT_SPRITE_R_MODE = 34915
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
glPointParameteri :: GLenum -> GLint -> IO ()
glPointParameteri = dyn_glPointParameteri ptr_glPointParameteri
 
{-# NOINLINE ptr_glPointParameteri #-}
 
ptr_glPointParameteri :: FunPtr a
ptr_glPointParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_point_sprite"
        "glPointParameteriNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
glPointParameteriv :: GLenum -> Ptr GLint -> IO ()
glPointParameteriv = dyn_glPointParameteriv ptr_glPointParameteriv
 
{-# NOINLINE ptr_glPointParameteriv #-}
 
ptr_glPointParameteriv :: FunPtr a
ptr_glPointParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_point_sprite"
        "glPointParameterivNV"