-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TexgenEmboss
       (gl_EMBOSS_CONSTANT, gl_EMBOSS_LIGHT, gl_EMBOSS_MAP) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_EMBOSS_CONSTANT :: GLenum
gl_EMBOSS_CONSTANT = 34142
 
gl_EMBOSS_LIGHT :: GLenum
gl_EMBOSS_LIGHT = 34141
 
gl_EMBOSS_MAP :: GLenum
gl_EMBOSS_MAP = 34143