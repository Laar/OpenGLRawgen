{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.GpuProgram4
       (gl_MAX_PROGRAM_ATTRIB_COMPONENTS, gl_MAX_PROGRAM_GENERIC_ATTRIBS,
        gl_MAX_PROGRAM_GENERIC_RESULTS, gl_MAX_PROGRAM_RESULT_COMPONENTS,
        gl_MAX_PROGRAM_TEXEL_OFFSET, gl_MIN_PROGRAM_TEXEL_OFFSET,
        gl_PROGRAM_ATTRIB_COMPONENTS, gl_PROGRAM_RESULT_COMPONENTS,
        glGetProgramEnvParameterIiv, glGetProgramEnvParameterIuiv,
        glGetProgramLocalParameterIiv, glGetProgramLocalParameterIuiv,
        glProgramEnvParameterI4i, glProgramEnvParameterI4iv,
        glProgramEnvParameterI4ui, glProgramEnvParameterI4uiv,
        glProgramEnvParametersI4iv, glProgramEnvParametersI4uiv,
        glProgramLocalParameterI4i, glProgramLocalParameterI4iv,
        glProgramLocalParameterI4ui, glProgramLocalParameterI4uiv,
        glProgramLocalParametersI4iv, glProgramLocalParametersI4uiv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MAX_PROGRAM_ATTRIB_COMPONENTS :: GLenum
gl_MAX_PROGRAM_ATTRIB_COMPONENTS = 35080
 
gl_MAX_PROGRAM_GENERIC_ATTRIBS :: GLenum
gl_MAX_PROGRAM_GENERIC_ATTRIBS = 36261
 
gl_MAX_PROGRAM_GENERIC_RESULTS :: GLenum
gl_MAX_PROGRAM_GENERIC_RESULTS = 36262
 
gl_MAX_PROGRAM_RESULT_COMPONENTS :: GLenum
gl_MAX_PROGRAM_RESULT_COMPONENTS = 35081
 
gl_MAX_PROGRAM_TEXEL_OFFSET :: GLenum
gl_MAX_PROGRAM_TEXEL_OFFSET = 35077
 
gl_MIN_PROGRAM_TEXEL_OFFSET :: GLenum
gl_MIN_PROGRAM_TEXEL_OFFSET = 35076
 
gl_PROGRAM_ATTRIB_COMPONENTS :: GLenum
gl_PROGRAM_ATTRIB_COMPONENTS = 35078
 
gl_PROGRAM_RESULT_COMPONENTS :: GLenum
gl_PROGRAM_RESULT_COMPONENTS = 35079
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramEnvParameterIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetProgramEnvParameterIiv ::
                            GLenum -> GLuint -> Ptr GLint -> IO ()
glGetProgramEnvParameterIiv
  = dyn_glGetProgramEnvParameterIiv ptr_glGetProgramEnvParameterIiv
 
{-# NOINLINE ptr_glGetProgramEnvParameterIiv #-}
 
ptr_glGetProgramEnvParameterIiv :: FunPtr a
ptr_glGetProgramEnvParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glGetProgramEnvParameterIivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramEnvParameterIuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glGetProgramEnvParameterIuiv ::
                             GLenum -> GLuint -> Ptr GLuint -> IO ()
glGetProgramEnvParameterIuiv
  = dyn_glGetProgramEnvParameterIuiv ptr_glGetProgramEnvParameterIuiv
 
{-# NOINLINE ptr_glGetProgramEnvParameterIuiv #-}
 
ptr_glGetProgramEnvParameterIuiv :: FunPtr a
ptr_glGetProgramEnvParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glGetProgramEnvParameterIuivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramLocalParameterIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetProgramLocalParameterIiv ::
                              GLenum -> GLuint -> Ptr GLint -> IO ()
glGetProgramLocalParameterIiv
  = dyn_glGetProgramLocalParameterIiv
      ptr_glGetProgramLocalParameterIiv
 
{-# NOINLINE ptr_glGetProgramLocalParameterIiv #-}
 
ptr_glGetProgramLocalParameterIiv :: FunPtr a
ptr_glGetProgramLocalParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glGetProgramLocalParameterIivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramLocalParameterIuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glGetProgramLocalParameterIuiv ::
                               GLenum -> GLuint -> Ptr GLuint -> IO ()
glGetProgramLocalParameterIuiv
  = dyn_glGetProgramLocalParameterIuiv
      ptr_glGetProgramLocalParameterIuiv
 
{-# NOINLINE ptr_glGetProgramLocalParameterIuiv #-}
 
ptr_glGetProgramLocalParameterIuiv :: FunPtr a
ptr_glGetProgramLocalParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glGetProgramLocalParameterIuivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameterI4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramEnvParameterI4i ::
                         GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramEnvParameterI4i
  = dyn_glProgramEnvParameterI4i ptr_glProgramEnvParameterI4i
 
{-# NOINLINE ptr_glProgramEnvParameterI4i #-}
 
ptr_glProgramEnvParameterI4i :: FunPtr a
ptr_glProgramEnvParameterI4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParameterI4iNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameterI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glProgramEnvParameterI4iv :: GLenum -> GLuint -> Ptr GLint -> IO ()
glProgramEnvParameterI4iv
  = dyn_glProgramEnvParameterI4iv ptr_glProgramEnvParameterI4iv
 
{-# NOINLINE ptr_glProgramEnvParameterI4iv #-}
 
ptr_glProgramEnvParameterI4iv :: FunPtr a
ptr_glProgramEnvParameterI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParameterI4ivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameterI4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramEnvParameterI4ui ::
                          GLenum -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramEnvParameterI4ui
  = dyn_glProgramEnvParameterI4ui ptr_glProgramEnvParameterI4ui
 
{-# NOINLINE ptr_glProgramEnvParameterI4ui #-}
 
ptr_glProgramEnvParameterI4ui :: FunPtr a
ptr_glProgramEnvParameterI4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParameterI4uiNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameterI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glProgramEnvParameterI4uiv ::
                           GLenum -> GLuint -> Ptr GLuint -> IO ()
glProgramEnvParameterI4uiv
  = dyn_glProgramEnvParameterI4uiv ptr_glProgramEnvParameterI4uiv
 
{-# NOINLINE ptr_glProgramEnvParameterI4uiv #-}
 
ptr_glProgramEnvParameterI4uiv :: FunPtr a
ptr_glProgramEnvParameterI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParameterI4uivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParametersI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramEnvParametersI4iv ::
                           GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ()
glProgramEnvParametersI4iv
  = dyn_glProgramEnvParametersI4iv ptr_glProgramEnvParametersI4iv
 
{-# NOINLINE ptr_glProgramEnvParametersI4iv #-}
 
ptr_glProgramEnvParametersI4iv :: FunPtr a
ptr_glProgramEnvParametersI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParametersI4ivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParametersI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramEnvParametersI4uiv ::
                            GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ()
glProgramEnvParametersI4uiv
  = dyn_glProgramEnvParametersI4uiv ptr_glProgramEnvParametersI4uiv
 
{-# NOINLINE ptr_glProgramEnvParametersI4uiv #-}
 
ptr_glProgramEnvParametersI4uiv :: FunPtr a
ptr_glProgramEnvParametersI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramEnvParametersI4uivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameterI4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramLocalParameterI4i ::
                           GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramLocalParameterI4i
  = dyn_glProgramLocalParameterI4i ptr_glProgramLocalParameterI4i
 
{-# NOINLINE ptr_glProgramLocalParameterI4i #-}
 
ptr_glProgramLocalParameterI4i :: FunPtr a
ptr_glProgramLocalParameterI4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParameterI4iNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameterI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glProgramLocalParameterI4iv ::
                            GLenum -> GLuint -> Ptr GLint -> IO ()
glProgramLocalParameterI4iv
  = dyn_glProgramLocalParameterI4iv ptr_glProgramLocalParameterI4iv
 
{-# NOINLINE ptr_glProgramLocalParameterI4iv #-}
 
ptr_glProgramLocalParameterI4iv :: FunPtr a
ptr_glProgramLocalParameterI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParameterI4ivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameterI4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramLocalParameterI4ui ::
                            GLenum -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramLocalParameterI4ui
  = dyn_glProgramLocalParameterI4ui ptr_glProgramLocalParameterI4ui
 
{-# NOINLINE ptr_glProgramLocalParameterI4ui #-}
 
ptr_glProgramLocalParameterI4ui :: FunPtr a
ptr_glProgramLocalParameterI4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParameterI4uiNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameterI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glProgramLocalParameterI4uiv ::
                             GLenum -> GLuint -> Ptr GLuint -> IO ()
glProgramLocalParameterI4uiv
  = dyn_glProgramLocalParameterI4uiv ptr_glProgramLocalParameterI4uiv
 
{-# NOINLINE ptr_glProgramLocalParameterI4uiv #-}
 
ptr_glProgramLocalParameterI4uiv :: FunPtr a
ptr_glProgramLocalParameterI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParameterI4uivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParametersI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramLocalParametersI4iv ::
                             GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ()
glProgramLocalParametersI4iv
  = dyn_glProgramLocalParametersI4iv ptr_glProgramLocalParametersI4iv
 
{-# NOINLINE ptr_glProgramLocalParametersI4iv #-}
 
ptr_glProgramLocalParametersI4iv :: FunPtr a
ptr_glProgramLocalParametersI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParametersI4ivNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParametersI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramLocalParametersI4uiv ::
                              GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ()
glProgramLocalParametersI4uiv
  = dyn_glProgramLocalParametersI4uiv
      ptr_glProgramLocalParametersI4uiv
 
{-# NOINLINE ptr_glProgramLocalParametersI4uiv #-}
 
ptr_glProgramLocalParametersI4uiv :: FunPtr a
ptr_glProgramLocalParametersI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_program4"
        "glProgramLocalParametersI4uivNV"