{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.Fence
       (gl_ALL_COMPLETED, gl_FENCE_CONDITION, gl_FENCE_STATUS,
        glDeleteFences, glFinishFence, glGenFences, glGetFenceiv,
        glIsFence, glSetFence, glTestFence)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ALL_COMPLETED :: GLenum
gl_ALL_COMPLETED = 34034
 
gl_FENCE_CONDITION :: GLenum
gl_FENCE_CONDITION = 34036
 
gl_FENCE_STATUS :: GLenum
gl_FENCE_STATUS = 34035
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteFences ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteFences :: GLsizei -> Ptr GLuint -> IO ()
glDeleteFences = dyn_glDeleteFences ptr_glDeleteFences
 
{-# NOINLINE ptr_glDeleteFences #-}
 
ptr_glDeleteFences :: FunPtr a
ptr_glDeleteFences
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glDeleteFencesNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glFinishFence :: GLuint -> IO ()
glFinishFence = dyn_glFinishFence ptr_glFinishFence
 
{-# NOINLINE ptr_glFinishFence #-}
 
ptr_glFinishFence :: FunPtr a
ptr_glFinishFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glFinishFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenFences ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenFences :: GLsizei -> Ptr GLuint -> IO ()
glGenFences = dyn_glGenFences ptr_glGenFences
 
{-# NOINLINE ptr_glGenFences #-}
 
ptr_glGenFences :: FunPtr a
ptr_glGenFences
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glGenFencesNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFenceiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetFenceiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetFenceiv = dyn_glGetFenceiv ptr_glGetFenceiv
 
{-# NOINLINE ptr_glGetFenceiv #-}
 
ptr_glGetFenceiv :: FunPtr a
ptr_glGetFenceiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glGetFenceivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsFence :: GLuint -> IO GLboolean
glIsFence = dyn_glIsFence ptr_glIsFence
 
{-# NOINLINE ptr_glIsFence #-}
 
ptr_glIsFence :: FunPtr a
ptr_glIsFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glIsFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glSetFence :: GLuint -> GLenum -> IO ()
glSetFence = dyn_glSetFence ptr_glSetFence
 
{-# NOINLINE ptr_glSetFence #-}
 
ptr_glSetFence :: FunPtr a
ptr_glSetFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glSetFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestFence ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glTestFence :: GLuint -> IO GLboolean
glTestFence = dyn_glTestFence ptr_glTestFence
 
{-# NOINLINE ptr_glTestFence #-}
 
ptr_glTestFence :: FunPtr a
ptr_glTestFence
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glTestFenceNV"