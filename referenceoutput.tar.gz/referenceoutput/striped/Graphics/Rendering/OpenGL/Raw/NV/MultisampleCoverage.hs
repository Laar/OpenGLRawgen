-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.MultisampleCoverage
       (gl_COLOR_SAMPLES, gl_COVERAGE_SAMPLES) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_SAMPLES :: GLenum
gl_COLOR_SAMPLES = 36384
 
gl_COVERAGE_SAMPLES :: GLenum
gl_COVERAGE_SAMPLES = 32937