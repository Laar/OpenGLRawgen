module Graphics.Rendering.OpenGL.Raw.NV.MultisampleCoverage
       (gl_COLOR_SAMPLES, gl_COVERAGE_SAMPLES) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_SAMPLES :: GLenum
gl_COLOR_SAMPLES = 36384
 
gl_COVERAGE_SAMPLES :: GLenum
gl_COVERAGE_SAMPLES = 32937