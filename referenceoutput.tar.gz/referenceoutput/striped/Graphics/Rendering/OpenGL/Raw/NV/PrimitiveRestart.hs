{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.PrimitiveRestart
       (gl_PRIMITIVE_RESTART_INDEX, gl_PRIMITIVE_RESTART,
        glPrimitiveRestartIndex, glPrimitiveRestart)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PRIMITIVE_RESTART_INDEX :: GLenum
gl_PRIMITIVE_RESTART_INDEX = 34137
 
gl_PRIMITIVE_RESTART :: GLenum
gl_PRIMITIVE_RESTART = 34136
 
foreign import CALLCONV unsafe "dynamic" dyn_glPrimitiveRestartIndex
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glPrimitiveRestartIndex :: GLuint -> IO ()
glPrimitiveRestartIndex
  = dyn_glPrimitiveRestartIndex ptr_glPrimitiveRestartIndex
 
{-# NOINLINE ptr_glPrimitiveRestartIndex #-}
 
ptr_glPrimitiveRestartIndex :: FunPtr a
ptr_glPrimitiveRestartIndex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_primitive_restart"
        "glPrimitiveRestartIndexNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPrimitiveRestart ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glPrimitiveRestart :: IO ()
glPrimitiveRestart = dyn_glPrimitiveRestart ptr_glPrimitiveRestart
 
{-# NOINLINE ptr_glPrimitiveRestart #-}
 
ptr_glPrimitiveRestart :: FunPtr a
ptr_glPrimitiveRestart
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_primitive_restart"
        "glPrimitiveRestartNV"