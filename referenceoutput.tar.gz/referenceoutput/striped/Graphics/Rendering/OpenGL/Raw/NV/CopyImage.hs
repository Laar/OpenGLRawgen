{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.CopyImage
       (glCopyImageSubData) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyImageSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLuint ->
                                GLenum ->
                                  GLint ->
                                    GLint ->
                                      GLint -> GLint -> GLsizei -> GLsizei -> GLsizei -> IO ())
 
glCopyImageSubData ::
                   GLuint ->
                     GLenum ->
                       GLint ->
                         GLint ->
                           GLint ->
                             GLint ->
                               GLuint ->
                                 GLenum ->
                                   GLint ->
                                     GLint ->
                                       GLint -> GLint -> GLsizei -> GLsizei -> GLsizei -> IO ()
glCopyImageSubData = dyn_glCopyImageSubData ptr_glCopyImageSubData
 
{-# NOINLINE ptr_glCopyImageSubData #-}
 
ptr_glCopyImageSubData :: FunPtr a
ptr_glCopyImageSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_copy_image"
        "glCopyImageSubDataNV"