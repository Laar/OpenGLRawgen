-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TextureRectangle
       (gl_MAX_RECTANGLE_TEXTURE_SIZE, gl_PROXY_TEXTURE_RECTANGLE,
        gl_TEXTURE_BINDING_RECTANGLE, gl_TEXTURE_RECTANGLE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_RECTANGLE_TEXTURE_SIZE :: GLenum
gl_MAX_RECTANGLE_TEXTURE_SIZE = 34040
 
gl_PROXY_TEXTURE_RECTANGLE :: GLenum
gl_PROXY_TEXTURE_RECTANGLE = 34039
 
gl_TEXTURE_BINDING_RECTANGLE :: GLenum
gl_TEXTURE_BINDING_RECTANGLE = 34038
 
gl_TEXTURE_RECTANGLE :: GLenum
gl_TEXTURE_RECTANGLE = 34037