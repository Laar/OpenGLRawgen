{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.GpuShader5
       (gl_FLOAT16, gl_FLOAT16_VEC2, gl_FLOAT16_VEC3, gl_FLOAT16_VEC4,
        gl_INT16, gl_INT16_VEC2, gl_INT16_VEC3, gl_INT16_VEC4, gl_INT64,
        gl_INT64_VEC2, gl_INT64_VEC3, gl_INT64_VEC4, gl_INT8, gl_INT8_VEC2,
        gl_INT8_VEC3, gl_INT8_VEC4, gl_PATCHES, gl_UNSIGNED_INT16,
        gl_UNSIGNED_INT16_VEC2, gl_UNSIGNED_INT16_VEC3,
        gl_UNSIGNED_INT16_VEC4, gl_UNSIGNED_INT64, gl_UNSIGNED_INT64_VEC2,
        gl_UNSIGNED_INT64_VEC3, gl_UNSIGNED_INT64_VEC4, gl_UNSIGNED_INT8,
        gl_UNSIGNED_INT8_VEC2, gl_UNSIGNED_INT8_VEC3,
        gl_UNSIGNED_INT8_VEC4, glGetUniformi64v, glProgramUniform1i64,
        glProgramUniform1i64v, glProgramUniform1ui64,
        glProgramUniform1ui64v, glProgramUniform2i64,
        glProgramUniform2i64v, glProgramUniform2ui64,
        glProgramUniform2ui64v, glProgramUniform3i64,
        glProgramUniform3i64v, glProgramUniform3ui64,
        glProgramUniform3ui64v, glProgramUniform4i64,
        glProgramUniform4i64v, glProgramUniform4ui64,
        glProgramUniform4ui64v, glUniform1i64, glUniform1i64v,
        glUniform1ui64, glUniform1ui64v, glUniform2i64, glUniform2i64v,
        glUniform2ui64, glUniform2ui64v, glUniform3i64, glUniform3i64v,
        glUniform3ui64, glUniform3ui64v, glUniform4i64, glUniform4i64v,
        glUniform4ui64, glUniform4ui64v)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_PATCHES)
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FLOAT16 :: GLenum
gl_FLOAT16 = 36856
 
gl_FLOAT16_VEC2 :: GLenum
gl_FLOAT16_VEC2 = 36857
 
gl_FLOAT16_VEC3 :: GLenum
gl_FLOAT16_VEC3 = 36858
 
gl_FLOAT16_VEC4 :: GLenum
gl_FLOAT16_VEC4 = 36859
 
gl_INT16 :: GLenum
gl_INT16 = 36836
 
gl_INT16_VEC2 :: GLenum
gl_INT16_VEC2 = 36837
 
gl_INT16_VEC3 :: GLenum
gl_INT16_VEC3 = 36838
 
gl_INT16_VEC4 :: GLenum
gl_INT16_VEC4 = 36839
 
gl_INT64 :: GLenum
gl_INT64 = 5134
 
gl_INT64_VEC2 :: GLenum
gl_INT64_VEC2 = 36841
 
gl_INT64_VEC3 :: GLenum
gl_INT64_VEC3 = 36842
 
gl_INT64_VEC4 :: GLenum
gl_INT64_VEC4 = 36843
 
gl_INT8 :: GLenum
gl_INT8 = 36832
 
gl_INT8_VEC2 :: GLenum
gl_INT8_VEC2 = 36833
 
gl_INT8_VEC3 :: GLenum
gl_INT8_VEC3 = 36834
 
gl_INT8_VEC4 :: GLenum
gl_INT8_VEC4 = 36835
 
gl_UNSIGNED_INT16 :: GLenum
gl_UNSIGNED_INT16 = 36848
 
gl_UNSIGNED_INT16_VEC2 :: GLenum
gl_UNSIGNED_INT16_VEC2 = 36849
 
gl_UNSIGNED_INT16_VEC3 :: GLenum
gl_UNSIGNED_INT16_VEC3 = 36850
 
gl_UNSIGNED_INT16_VEC4 :: GLenum
gl_UNSIGNED_INT16_VEC4 = 36851
 
gl_UNSIGNED_INT64 :: GLenum
gl_UNSIGNED_INT64 = 5135
 
gl_UNSIGNED_INT64_VEC2 :: GLenum
gl_UNSIGNED_INT64_VEC2 = 36853
 
gl_UNSIGNED_INT64_VEC3 :: GLenum
gl_UNSIGNED_INT64_VEC3 = 36854
 
gl_UNSIGNED_INT64_VEC4 :: GLenum
gl_UNSIGNED_INT64_VEC4 = 36855
 
gl_UNSIGNED_INT8 :: GLenum
gl_UNSIGNED_INT8 = 36844
 
gl_UNSIGNED_INT8_VEC2 :: GLenum
gl_UNSIGNED_INT8_VEC2 = 36845
 
gl_UNSIGNED_INT8_VEC3 :: GLenum
gl_UNSIGNED_INT8_VEC3 = 36846
 
gl_UNSIGNED_INT8_VEC4 :: GLenum
gl_UNSIGNED_INT8_VEC4 = 36847
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformi64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> Ptr GLint64 -> IO ())
 
glGetUniformi64v :: GLuint -> GLint -> Ptr GLint64 -> IO ()
glGetUniformi64v = dyn_glGetUniformi64v ptr_glGetUniformi64v
 
{-# NOINLINE ptr_glGetUniformi64v #-}
 
ptr_glGetUniformi64v :: FunPtr a
ptr_glGetUniformi64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glGetUniformi64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint64 -> IO ())
 
glProgramUniform1i64 :: GLuint -> GLint -> GLint64 -> IO ()
glProgramUniform1i64
  = dyn_glProgramUniform1i64 ptr_glProgramUniform1i64
 
{-# NOINLINE ptr_glProgramUniform1i64 #-}
 
ptr_glProgramUniform1i64 :: FunPtr a
ptr_glProgramUniform1i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform1i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1i64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glProgramUniform1i64v ::
                      GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ()
glProgramUniform1i64v
  = dyn_glProgramUniform1i64v ptr_glProgramUniform1i64v
 
{-# NOINLINE ptr_glProgramUniform1i64v #-}
 
ptr_glProgramUniform1i64v :: FunPtr a
ptr_glProgramUniform1i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform1i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1ui64
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint64 -> IO ())
 
glProgramUniform1ui64 :: GLuint -> GLint -> GLuint64 -> IO ()
glProgramUniform1ui64
  = dyn_glProgramUniform1ui64 ptr_glProgramUniform1ui64
 
{-# NOINLINE ptr_glProgramUniform1ui64 #-}
 
ptr_glProgramUniform1ui64 :: FunPtr a
ptr_glProgramUniform1ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform1ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1ui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniform1ui64v ::
                       GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniform1ui64v
  = dyn_glProgramUniform1ui64v ptr_glProgramUniform1ui64v
 
{-# NOINLINE ptr_glProgramUniform1ui64v #-}
 
ptr_glProgramUniform1ui64v :: FunPtr a
ptr_glProgramUniform1ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform1ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint64 -> GLint64 -> IO ())
 
glProgramUniform2i64 ::
                     GLuint -> GLint -> GLint64 -> GLint64 -> IO ()
glProgramUniform2i64
  = dyn_glProgramUniform2i64 ptr_glProgramUniform2i64
 
{-# NOINLINE ptr_glProgramUniform2i64 #-}
 
ptr_glProgramUniform2i64 :: FunPtr a
ptr_glProgramUniform2i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform2i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2i64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glProgramUniform2i64v ::
                      GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ()
glProgramUniform2i64v
  = dyn_glProgramUniform2i64v ptr_glProgramUniform2i64v
 
{-# NOINLINE ptr_glProgramUniform2i64v #-}
 
ptr_glProgramUniform2i64v :: FunPtr a
ptr_glProgramUniform2i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform2i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2ui64
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint64 -> GLuint64 -> IO ())
 
glProgramUniform2ui64 ::
                      GLuint -> GLint -> GLuint64 -> GLuint64 -> IO ()
glProgramUniform2ui64
  = dyn_glProgramUniform2ui64 ptr_glProgramUniform2ui64
 
{-# NOINLINE ptr_glProgramUniform2ui64 #-}
 
ptr_glProgramUniform2ui64 :: FunPtr a
ptr_glProgramUniform2ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform2ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2ui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniform2ui64v ::
                       GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniform2ui64v
  = dyn_glProgramUniform2ui64v ptr_glProgramUniform2ui64v
 
{-# NOINLINE ptr_glProgramUniform2ui64v #-}
 
ptr_glProgramUniform2ui64v :: FunPtr a
ptr_glProgramUniform2ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform2ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint64 -> GLint64 -> GLint64 -> IO ())
 
glProgramUniform3i64 ::
                     GLuint -> GLint -> GLint64 -> GLint64 -> GLint64 -> IO ()
glProgramUniform3i64
  = dyn_glProgramUniform3i64 ptr_glProgramUniform3i64
 
{-# NOINLINE ptr_glProgramUniform3i64 #-}
 
ptr_glProgramUniform3i64 :: FunPtr a
ptr_glProgramUniform3i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform3i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3i64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glProgramUniform3i64v ::
                      GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ()
glProgramUniform3i64v
  = dyn_glProgramUniform3i64v ptr_glProgramUniform3i64v
 
{-# NOINLINE ptr_glProgramUniform3i64v #-}
 
ptr_glProgramUniform3i64v :: FunPtr a
ptr_glProgramUniform3i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform3i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3ui64
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint64 -> GLuint64 -> GLuint64 -> IO ())
 
glProgramUniform3ui64 ::
                      GLuint -> GLint -> GLuint64 -> GLuint64 -> GLuint64 -> IO ()
glProgramUniform3ui64
  = dyn_glProgramUniform3ui64 ptr_glProgramUniform3ui64
 
{-# NOINLINE ptr_glProgramUniform3ui64 #-}
 
ptr_glProgramUniform3ui64 :: FunPtr a
ptr_glProgramUniform3ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform3ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3ui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniform3ui64v ::
                       GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniform3ui64v
  = dyn_glProgramUniform3ui64v ptr_glProgramUniform3ui64v
 
{-# NOINLINE ptr_glProgramUniform3ui64v #-}
 
ptr_glProgramUniform3ui64v :: FunPtr a
ptr_glProgramUniform3ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform3ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLint64 -> GLint64 -> GLint64 -> GLint64 -> IO ())
 
glProgramUniform4i64 ::
                     GLuint ->
                       GLint -> GLint64 -> GLint64 -> GLint64 -> GLint64 -> IO ()
glProgramUniform4i64
  = dyn_glProgramUniform4i64 ptr_glProgramUniform4i64
 
{-# NOINLINE ptr_glProgramUniform4i64 #-}
 
ptr_glProgramUniform4i64 :: FunPtr a
ptr_glProgramUniform4i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform4i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4i64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glProgramUniform4i64v ::
                      GLuint -> GLint -> GLsizei -> Ptr GLint64 -> IO ()
glProgramUniform4i64v
  = dyn_glProgramUniform4i64v ptr_glProgramUniform4i64v
 
{-# NOINLINE ptr_glProgramUniform4i64v #-}
 
ptr_glProgramUniform4i64v :: FunPtr a
ptr_glProgramUniform4i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform4i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4ui64
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLuint64 -> GLuint64 -> GLuint64 -> GLuint64 -> IO ())
 
glProgramUniform4ui64 ::
                      GLuint ->
                        GLint -> GLuint64 -> GLuint64 -> GLuint64 -> GLuint64 -> IO ()
glProgramUniform4ui64
  = dyn_glProgramUniform4ui64 ptr_glProgramUniform4ui64
 
{-# NOINLINE ptr_glProgramUniform4ui64 #-}
 
ptr_glProgramUniform4ui64 :: FunPtr a
ptr_glProgramUniform4ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform4ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4ui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniform4ui64v ::
                       GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniform4ui64v
  = dyn_glProgramUniform4ui64v ptr_glProgramUniform4ui64v
 
{-# NOINLINE ptr_glProgramUniform4ui64v #-}
 
ptr_glProgramUniform4ui64v :: FunPtr a
ptr_glProgramUniform4ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glProgramUniform4ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint64 -> IO ())
 
glUniform1i64 :: GLint -> GLint64 -> IO ()
glUniform1i64 = dyn_glUniform1i64 ptr_glUniform1i64
 
{-# NOINLINE ptr_glUniform1i64 #-}
 
ptr_glUniform1i64 :: FunPtr a
ptr_glUniform1i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform1i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1i64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glUniform1i64v :: GLint -> GLsizei -> Ptr GLint64 -> IO ()
glUniform1i64v = dyn_glUniform1i64v ptr_glUniform1i64v
 
{-# NOINLINE ptr_glUniform1i64v #-}
 
ptr_glUniform1i64v :: FunPtr a
ptr_glUniform1i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform1i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1ui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> IO ())
 
glUniform1ui64 :: GLint -> GLuint64 -> IO ()
glUniform1ui64 = dyn_glUniform1ui64 ptr_glUniform1ui64
 
{-# NOINLINE ptr_glUniform1ui64 #-}
 
ptr_glUniform1ui64 :: FunPtr a
ptr_glUniform1ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform1ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1ui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniform1ui64v :: GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniform1ui64v = dyn_glUniform1ui64v ptr_glUniform1ui64v
 
{-# NOINLINE ptr_glUniform1ui64v #-}
 
ptr_glUniform1ui64v :: FunPtr a
ptr_glUniform1ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform1ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint64 -> GLint64 -> IO ())
 
glUniform2i64 :: GLint -> GLint64 -> GLint64 -> IO ()
glUniform2i64 = dyn_glUniform2i64 ptr_glUniform2i64
 
{-# NOINLINE ptr_glUniform2i64 #-}
 
ptr_glUniform2i64 :: FunPtr a
ptr_glUniform2i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform2i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2i64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glUniform2i64v :: GLint -> GLsizei -> Ptr GLint64 -> IO ()
glUniform2i64v = dyn_glUniform2i64v ptr_glUniform2i64v
 
{-# NOINLINE ptr_glUniform2i64v #-}
 
ptr_glUniform2i64v :: FunPtr a
ptr_glUniform2i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform2i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2ui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> GLuint64 -> IO ())
 
glUniform2ui64 :: GLint -> GLuint64 -> GLuint64 -> IO ()
glUniform2ui64 = dyn_glUniform2ui64 ptr_glUniform2ui64
 
{-# NOINLINE ptr_glUniform2ui64 #-}
 
ptr_glUniform2ui64 :: FunPtr a
ptr_glUniform2ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform2ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2ui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniform2ui64v :: GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniform2ui64v = dyn_glUniform2ui64v ptr_glUniform2ui64v
 
{-# NOINLINE ptr_glUniform2ui64v #-}
 
ptr_glUniform2ui64v :: FunPtr a
ptr_glUniform2ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform2ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint64 -> GLint64 -> GLint64 -> IO ())
 
glUniform3i64 :: GLint -> GLint64 -> GLint64 -> GLint64 -> IO ()
glUniform3i64 = dyn_glUniform3i64 ptr_glUniform3i64
 
{-# NOINLINE ptr_glUniform3i64 #-}
 
ptr_glUniform3i64 :: FunPtr a
ptr_glUniform3i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform3i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3i64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glUniform3i64v :: GLint -> GLsizei -> Ptr GLint64 -> IO ()
glUniform3i64v = dyn_glUniform3i64v ptr_glUniform3i64v
 
{-# NOINLINE ptr_glUniform3i64v #-}
 
ptr_glUniform3i64v :: FunPtr a
ptr_glUniform3i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform3i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3ui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> GLuint64 -> GLuint64 -> IO ())
 
glUniform3ui64 ::
               GLint -> GLuint64 -> GLuint64 -> GLuint64 -> IO ()
glUniform3ui64 = dyn_glUniform3ui64 ptr_glUniform3ui64
 
{-# NOINLINE ptr_glUniform3ui64 #-}
 
ptr_glUniform3ui64 :: FunPtr a
ptr_glUniform3ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform3ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3ui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniform3ui64v :: GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniform3ui64v = dyn_glUniform3ui64v ptr_glUniform3ui64v
 
{-# NOINLINE ptr_glUniform3ui64v #-}
 
ptr_glUniform3ui64v :: FunPtr a
ptr_glUniform3ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform3ui64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4i64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint64 -> GLint64 -> GLint64 -> GLint64 -> IO ())
 
glUniform4i64 ::
              GLint -> GLint64 -> GLint64 -> GLint64 -> GLint64 -> IO ()
glUniform4i64 = dyn_glUniform4i64 ptr_glUniform4i64
 
{-# NOINLINE ptr_glUniform4i64 #-}
 
ptr_glUniform4i64 :: FunPtr a
ptr_glUniform4i64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform4i64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4i64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLint64 -> IO ())
 
glUniform4i64v :: GLint -> GLsizei -> Ptr GLint64 -> IO ()
glUniform4i64v = dyn_glUniform4i64v ptr_glUniform4i64v
 
{-# NOINLINE ptr_glUniform4i64v #-}
 
ptr_glUniform4i64v :: FunPtr a
ptr_glUniform4i64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform4i64vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4ui64 ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> GLuint64 -> GLuint64 -> GLuint64 -> IO ())
 
glUniform4ui64 ::
               GLint -> GLuint64 -> GLuint64 -> GLuint64 -> GLuint64 -> IO ()
glUniform4ui64 = dyn_glUniform4ui64 ptr_glUniform4ui64
 
{-# NOINLINE ptr_glUniform4ui64 #-}
 
ptr_glUniform4ui64 :: FunPtr a
ptr_glUniform4ui64
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform4ui64NV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4ui64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniform4ui64v :: GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniform4ui64v = dyn_glUniform4ui64v ptr_glUniform4ui64v
 
{-# NOINLINE ptr_glUniform4ui64v #-}
 
ptr_glUniform4ui64v :: FunPtr a
ptr_glUniform4ui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_gpu_shader5"
        "glUniform4ui64vNV"