{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.VertexArrayRange
       (gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT, gl_VERTEX_ARRAY_RANGE_LENGTH,
        gl_VERTEX_ARRAY_RANGE, gl_VERTEX_ARRAY_RANGE_POINTER,
        gl_VERTEX_ARRAY_RANGE_VALID, glFlushVertexArrayRange,
        glVertexArrayRange)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT :: GLenum
gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT = 34080
 
gl_VERTEX_ARRAY_RANGE_LENGTH :: GLenum
gl_VERTEX_ARRAY_RANGE_LENGTH = 34078
 
gl_VERTEX_ARRAY_RANGE :: GLenum
gl_VERTEX_ARRAY_RANGE = 34077
 
gl_VERTEX_ARRAY_RANGE_POINTER :: GLenum
gl_VERTEX_ARRAY_RANGE_POINTER = 34081
 
gl_VERTEX_ARRAY_RANGE_VALID :: GLenum
gl_VERTEX_ARRAY_RANGE_VALID = 34079
 
foreign import CALLCONV unsafe "dynamic" dyn_glFlushVertexArrayRange
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glFlushVertexArrayRange :: IO ()
glFlushVertexArrayRange
  = dyn_glFlushVertexArrayRange ptr_glFlushVertexArrayRange
 
{-# NOINLINE ptr_glFlushVertexArrayRange #-}
 
ptr_glFlushVertexArrayRange :: FunPtr a
ptr_glFlushVertexArrayRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_array_range"
        "glFlushVertexArrayRangeNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexArrayRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr c -> IO ())
 
glVertexArrayRange :: GLsizei -> Ptr c -> IO ()
glVertexArrayRange = dyn_glVertexArrayRange ptr_glVertexArrayRange
 
{-# NOINLINE ptr_glVertexArrayRange #-}
 
ptr_glVertexArrayRange :: FunPtr a
ptr_glVertexArrayRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_array_range"
        "glVertexArrayRangeNV"