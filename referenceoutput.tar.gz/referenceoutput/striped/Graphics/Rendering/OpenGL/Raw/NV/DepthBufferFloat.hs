{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.DepthBufferFloat
       (gl_DEPTH32F_STENCIL8, gl_DEPTH_BUFFER_FLOAT_MODE,
        gl_DEPTH_COMPONENT32F, gl_FLOAT_32_UNSIGNED_INT_24_8_REV,
        glClearDepthd, glDepthBoundsd, glDepthRanged)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DEPTH32F_STENCIL8 :: GLenum
gl_DEPTH32F_STENCIL8 = 36268
 
gl_DEPTH_BUFFER_FLOAT_MODE :: GLenum
gl_DEPTH_BUFFER_FLOAT_MODE = 36271
 
gl_DEPTH_COMPONENT32F :: GLenum
gl_DEPTH_COMPONENT32F = 36267
 
gl_FLOAT_32_UNSIGNED_INT_24_8_REV :: GLenum
gl_FLOAT_32_UNSIGNED_INT_24_8_REV = 36269
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearDepthd ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> IO ())
 
glClearDepthd :: GLdouble -> IO ()
glClearDepthd = dyn_glClearDepthd ptr_glClearDepthd
 
{-# NOINLINE ptr_glClearDepthd #-}
 
ptr_glClearDepthd :: FunPtr a
ptr_glClearDepthd
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glClearDepthdNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthBoundsd ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())
 
glDepthBoundsd :: GLdouble -> GLdouble -> IO ()
glDepthBoundsd = dyn_glDepthBoundsd ptr_glDepthBoundsd
 
{-# NOINLINE ptr_glDepthBoundsd #-}
 
ptr_glDepthBoundsd :: FunPtr a
ptr_glDepthBoundsd
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glDepthBoundsdNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRanged ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())
 
glDepthRanged :: GLdouble -> GLdouble -> IO ()
glDepthRanged = dyn_glDepthRanged ptr_glDepthRanged
 
{-# NOINLINE ptr_glDepthRanged #-}
 
ptr_glDepthRanged :: FunPtr a
ptr_glDepthRanged
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glDepthRangedNV"