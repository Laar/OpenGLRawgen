{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.PixelDataRange
       (gl_READ_PIXEL_DATA_RANGE_LENGTH, gl_READ_PIXEL_DATA_RANGE,
        gl_READ_PIXEL_DATA_RANGE_POINTER, gl_WRITE_PIXEL_DATA_RANGE_LENGTH,
        gl_WRITE_PIXEL_DATA_RANGE, gl_WRITE_PIXEL_DATA_RANGE_POINTER,
        glFlushPixelDataRange, glPixelDataRange)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_READ_PIXEL_DATA_RANGE_LENGTH :: GLenum
gl_READ_PIXEL_DATA_RANGE_LENGTH = 34939
 
gl_READ_PIXEL_DATA_RANGE :: GLenum
gl_READ_PIXEL_DATA_RANGE = 34937
 
gl_READ_PIXEL_DATA_RANGE_POINTER :: GLenum
gl_READ_PIXEL_DATA_RANGE_POINTER = 34941
 
gl_WRITE_PIXEL_DATA_RANGE_LENGTH :: GLenum
gl_WRITE_PIXEL_DATA_RANGE_LENGTH = 34938
 
gl_WRITE_PIXEL_DATA_RANGE :: GLenum
gl_WRITE_PIXEL_DATA_RANGE = 34936
 
gl_WRITE_PIXEL_DATA_RANGE_POINTER :: GLenum
gl_WRITE_PIXEL_DATA_RANGE_POINTER = 34940
 
foreign import CALLCONV unsafe "dynamic" dyn_glFlushPixelDataRange
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glFlushPixelDataRange :: GLenum -> IO ()
glFlushPixelDataRange
  = dyn_glFlushPixelDataRange ptr_glFlushPixelDataRange
 
{-# NOINLINE ptr_glFlushPixelDataRange #-}
 
ptr_glFlushPixelDataRange :: FunPtr a
ptr_glFlushPixelDataRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_pixel_data_range"
        "glFlushPixelDataRangeNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPixelDataRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr a -> IO ())
 
glPixelDataRange :: GLenum -> GLsizei -> Ptr a -> IO ()
glPixelDataRange = dyn_glPixelDataRange ptr_glPixelDataRange
 
{-# NOINLINE ptr_glPixelDataRange #-}
 
ptr_glPixelDataRange :: FunPtr a
ptr_glPixelDataRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_pixel_data_range"
        "glPixelDataRangeNV"