{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.Evaluators
       (gl_EVAL_2D, gl_EVAL_FRACTIONAL_TESSELLATION,
        gl_EVAL_TRIANGULAR_2D, gl_EVAL_VERTEX_ATTRIB0,
        gl_EVAL_VERTEX_ATTRIB10, gl_EVAL_VERTEX_ATTRIB11,
        gl_EVAL_VERTEX_ATTRIB12, gl_EVAL_VERTEX_ATTRIB13,
        gl_EVAL_VERTEX_ATTRIB14, gl_EVAL_VERTEX_ATTRIB15,
        gl_EVAL_VERTEX_ATTRIB1, gl_EVAL_VERTEX_ATTRIB2,
        gl_EVAL_VERTEX_ATTRIB3, gl_EVAL_VERTEX_ATTRIB4,
        gl_EVAL_VERTEX_ATTRIB5, gl_EVAL_VERTEX_ATTRIB6,
        gl_EVAL_VERTEX_ATTRIB7, gl_EVAL_VERTEX_ATTRIB8,
        gl_EVAL_VERTEX_ATTRIB9, gl_MAP_ATTRIB_U_ORDER,
        gl_MAP_ATTRIB_V_ORDER, gl_MAP_TESSELLATION,
        gl_MAX_MAP_TESSELLATION, gl_MAX_RATIONAL_EVAL_ORDER, glEvalMaps,
        glGetMapAttribParameterfv, glGetMapAttribParameteriv,
        glGetMapControlPoints, glGetMapParameterfv, glGetMapParameteriv,
        glMapControlPoints, glMapParameterfv, glMapParameteriv)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_EVAL_2D :: GLenum
gl_EVAL_2D = 34496
 
gl_EVAL_FRACTIONAL_TESSELLATION :: GLenum
gl_EVAL_FRACTIONAL_TESSELLATION = 34501
 
gl_EVAL_TRIANGULAR_2D :: GLenum
gl_EVAL_TRIANGULAR_2D = 34497
 
gl_EVAL_VERTEX_ATTRIB0 :: GLenum
gl_EVAL_VERTEX_ATTRIB0 = 34502
 
gl_EVAL_VERTEX_ATTRIB10 :: GLenum
gl_EVAL_VERTEX_ATTRIB10 = 34512
 
gl_EVAL_VERTEX_ATTRIB11 :: GLenum
gl_EVAL_VERTEX_ATTRIB11 = 34513
 
gl_EVAL_VERTEX_ATTRIB12 :: GLenum
gl_EVAL_VERTEX_ATTRIB12 = 34514
 
gl_EVAL_VERTEX_ATTRIB13 :: GLenum
gl_EVAL_VERTEX_ATTRIB13 = 34515
 
gl_EVAL_VERTEX_ATTRIB14 :: GLenum
gl_EVAL_VERTEX_ATTRIB14 = 34516
 
gl_EVAL_VERTEX_ATTRIB15 :: GLenum
gl_EVAL_VERTEX_ATTRIB15 = 34517
 
gl_EVAL_VERTEX_ATTRIB1 :: GLenum
gl_EVAL_VERTEX_ATTRIB1 = 34503
 
gl_EVAL_VERTEX_ATTRIB2 :: GLenum
gl_EVAL_VERTEX_ATTRIB2 = 34504
 
gl_EVAL_VERTEX_ATTRIB3 :: GLenum
gl_EVAL_VERTEX_ATTRIB3 = 34505
 
gl_EVAL_VERTEX_ATTRIB4 :: GLenum
gl_EVAL_VERTEX_ATTRIB4 = 34506
 
gl_EVAL_VERTEX_ATTRIB5 :: GLenum
gl_EVAL_VERTEX_ATTRIB5 = 34507
 
gl_EVAL_VERTEX_ATTRIB6 :: GLenum
gl_EVAL_VERTEX_ATTRIB6 = 34508
 
gl_EVAL_VERTEX_ATTRIB7 :: GLenum
gl_EVAL_VERTEX_ATTRIB7 = 34509
 
gl_EVAL_VERTEX_ATTRIB8 :: GLenum
gl_EVAL_VERTEX_ATTRIB8 = 34510
 
gl_EVAL_VERTEX_ATTRIB9 :: GLenum
gl_EVAL_VERTEX_ATTRIB9 = 34511
 
gl_MAP_ATTRIB_U_ORDER :: GLenum
gl_MAP_ATTRIB_U_ORDER = 34499
 
gl_MAP_ATTRIB_V_ORDER :: GLenum
gl_MAP_ATTRIB_V_ORDER = 34500
 
gl_MAP_TESSELLATION :: GLenum
gl_MAP_TESSELLATION = 34498
 
gl_MAX_MAP_TESSELLATION :: GLenum
gl_MAX_MAP_TESSELLATION = 34518
 
gl_MAX_RATIONAL_EVAL_ORDER :: GLenum
gl_MAX_RATIONAL_EVAL_ORDER = 34519
 
foreign import CALLCONV unsafe "dynamic" dyn_glEvalMaps ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glEvalMaps :: GLenum -> GLenum -> IO ()
glEvalMaps = dyn_glEvalMaps ptr_glEvalMaps
 
{-# NOINLINE ptr_glEvalMaps #-}
 
ptr_glEvalMaps :: FunPtr a
ptr_glEvalMaps
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glEvalMapsNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMapAttribParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMapAttribParameterfv ::
                          GLenum -> GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetMapAttribParameterfv
  = dyn_glGetMapAttribParameterfv ptr_glGetMapAttribParameterfv
 
{-# NOINLINE ptr_glGetMapAttribParameterfv #-}
 
ptr_glGetMapAttribParameterfv :: FunPtr a
ptr_glGetMapAttribParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapAttribParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMapAttribParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetMapAttribParameteriv ::
                          GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetMapAttribParameteriv
  = dyn_glGetMapAttribParameteriv ptr_glGetMapAttribParameteriv
 
{-# NOINLINE ptr_glGetMapAttribParameteriv #-}
 
ptr_glGetMapAttribParameteriv :: FunPtr a
ptr_glGetMapAttribParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapAttribParameterivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapControlPoints
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint ->
                      GLenum -> GLsizei -> GLsizei -> GLboolean -> Ptr a -> IO ())
 
glGetMapControlPoints ::
                      GLenum ->
                        GLuint ->
                          GLenum -> GLsizei -> GLsizei -> GLboolean -> Ptr a -> IO ()
glGetMapControlPoints
  = dyn_glGetMapControlPoints ptr_glGetMapControlPoints
 
{-# NOINLINE ptr_glGetMapControlPoints #-}
 
ptr_glGetMapControlPoints :: FunPtr a
ptr_glGetMapControlPoints
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapControlPointsNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMapParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMapParameterfv
  = dyn_glGetMapParameterfv ptr_glGetMapParameterfv
 
{-# NOINLINE ptr_glGetMapParameterfv #-}
 
ptr_glGetMapParameterfv :: FunPtr a
ptr_glGetMapParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMapParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMapParameteriv
  = dyn_glGetMapParameteriv ptr_glGetMapParameteriv
 
{-# NOINLINE ptr_glGetMapParameteriv #-}
 
ptr_glGetMapParameteriv :: FunPtr a
ptr_glGetMapParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapParameterivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapControlPoints ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint ->
                      GLenum ->
                        GLsizei ->
                          GLsizei -> GLint -> GLint -> GLboolean -> Ptr a -> IO ())
 
glMapControlPoints ::
                   GLenum ->
                     GLuint ->
                       GLenum ->
                         GLsizei -> GLsizei -> GLint -> GLint -> GLboolean -> Ptr a -> IO ()
glMapControlPoints = dyn_glMapControlPoints ptr_glMapControlPoints
 
{-# NOINLINE ptr_glMapControlPoints #-}
 
ptr_glMapControlPoints :: FunPtr a
ptr_glMapControlPoints
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapControlPointsNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glMapParameterfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glMapParameterfv = dyn_glMapParameterfv ptr_glMapParameterfv
 
{-# NOINLINE ptr_glMapParameterfv #-}
 
ptr_glMapParameterfv :: FunPtr a
ptr_glMapParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMapParameteriv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glMapParameteriv = dyn_glMapParameteriv ptr_glMapParameteriv
 
{-# NOINLINE ptr_glMapParameteriv #-}
 
ptr_glMapParameteriv :: FunPtr a
ptr_glMapParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapParameterivNV"