module Graphics.Rendering.OpenGL.Raw.NV.TextureExpandNormal
       (gl_TEXTURE_UNSIGNED_REMAP_MODE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TEXTURE_UNSIGNED_REMAP_MODE :: GLenum
gl_TEXTURE_UNSIGNED_REMAP_MODE = 34959