module Graphics.Rendering.OpenGL.Raw.Core32
       (module Graphics.Rendering.OpenGL.Raw.Core.Core32) where
import Graphics.Rendering.OpenGL.Raw.Core.Core32