module Graphics.Rendering.OpenGL.Raw.ATI.TextureEnvCombine3
       (gl_MODULATE_ADD, gl_MODULATE_SIGNED_ADD, gl_MODULATE_SUBTRACT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MODULATE_ADD :: GLenum
gl_MODULATE_ADD = 34628
 
gl_MODULATE_SIGNED_ADD :: GLenum
gl_MODULATE_SIGNED_ADD = 34629
 
gl_MODULATE_SUBTRACT :: GLenum
gl_MODULATE_SUBTRACT = 34630