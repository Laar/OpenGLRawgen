{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ATI.VertexArrayObject
       (gl_ARRAY_OBJECT_BUFFER, gl_ARRAY_OBJECT_OFFSET, gl_DISCARD,
        gl_DYNAMIC, gl_OBJECT_BUFFER_SIZE, gl_OBJECT_BUFFER_USAGE,
        gl_PRESERVE, gl_STATIC, glArrayObject, glFreeObjectBuffer,
        glGetArrayObjectfv, glGetArrayObjectiv, glGetObjectBufferfv,
        glGetObjectBufferiv, glGetVariantArrayObjectfv,
        glGetVariantArrayObjectiv, glIsObjectBuffer, glNewObjectBuffer,
        glUpdateObjectBuffer, glVariantArrayObject)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ARRAY_OBJECT_BUFFER :: GLenum
gl_ARRAY_OBJECT_BUFFER = 34662
 
gl_ARRAY_OBJECT_OFFSET :: GLenum
gl_ARRAY_OBJECT_OFFSET = 34663
 
gl_DISCARD :: GLenum
gl_DISCARD = 34659
 
gl_DYNAMIC :: GLenum
gl_DYNAMIC = 34657
 
gl_OBJECT_BUFFER_SIZE :: GLenum
gl_OBJECT_BUFFER_SIZE = 34660
 
gl_OBJECT_BUFFER_USAGE :: GLenum
gl_OBJECT_BUFFER_USAGE = 34661
 
gl_PRESERVE :: GLenum
gl_PRESERVE = 34658
 
gl_STATIC :: GLenum
gl_STATIC = 34656
 
foreign import CALLCONV unsafe "dynamic" dyn_glArrayObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> GLsizei -> GLuint -> GLuint -> IO ())
 
glArrayObject ::
              GLenum -> GLint -> GLenum -> GLsizei -> GLuint -> GLuint -> IO ()
glArrayObject = dyn_glArrayObject ptr_glArrayObject
 
{-# NOINLINE ptr_glArrayObject #-}
 
ptr_glArrayObject :: FunPtr a
ptr_glArrayObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glArrayObjectATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFreeObjectBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glFreeObjectBuffer :: GLuint -> IO ()
glFreeObjectBuffer = dyn_glFreeObjectBuffer ptr_glFreeObjectBuffer
 
{-# NOINLINE ptr_glFreeObjectBuffer #-}
 
ptr_glFreeObjectBuffer :: FunPtr a
ptr_glFreeObjectBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glFreeObjectBufferATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetArrayObjectfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetArrayObjectfv :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetArrayObjectfv = dyn_glGetArrayObjectfv ptr_glGetArrayObjectfv
 
{-# NOINLINE ptr_glGetArrayObjectfv #-}
 
ptr_glGetArrayObjectfv :: FunPtr a
ptr_glGetArrayObjectfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetArrayObjectfvATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetArrayObjectiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetArrayObjectiv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetArrayObjectiv = dyn_glGetArrayObjectiv ptr_glGetArrayObjectiv
 
{-# NOINLINE ptr_glGetArrayObjectiv #-}
 
ptr_glGetArrayObjectiv :: FunPtr a
ptr_glGetArrayObjectiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetArrayObjectivATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetObjectBufferfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetObjectBufferfv :: GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetObjectBufferfv
  = dyn_glGetObjectBufferfv ptr_glGetObjectBufferfv
 
{-# NOINLINE ptr_glGetObjectBufferfv #-}
 
ptr_glGetObjectBufferfv :: FunPtr a
ptr_glGetObjectBufferfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetObjectBufferfvATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetObjectBufferiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetObjectBufferiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetObjectBufferiv
  = dyn_glGetObjectBufferiv ptr_glGetObjectBufferiv
 
{-# NOINLINE ptr_glGetObjectBufferiv #-}
 
ptr_glGetObjectBufferiv :: FunPtr a
ptr_glGetObjectBufferiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetObjectBufferivATI"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVariantArrayObjectfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetVariantArrayObjectfv ::
                          GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetVariantArrayObjectfv
  = dyn_glGetVariantArrayObjectfv ptr_glGetVariantArrayObjectfv
 
{-# NOINLINE ptr_glGetVariantArrayObjectfv #-}
 
ptr_glGetVariantArrayObjectfv :: FunPtr a
ptr_glGetVariantArrayObjectfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetVariantArrayObjectfvATI"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVariantArrayObjectiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVariantArrayObjectiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVariantArrayObjectiv
  = dyn_glGetVariantArrayObjectiv ptr_glGetVariantArrayObjectiv
 
{-# NOINLINE ptr_glGetVariantArrayObjectiv #-}
 
ptr_glGetVariantArrayObjectiv :: FunPtr a
ptr_glGetVariantArrayObjectiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glGetVariantArrayObjectivATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsObjectBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsObjectBuffer :: GLuint -> IO GLboolean
glIsObjectBuffer = dyn_glIsObjectBuffer ptr_glIsObjectBuffer
 
{-# NOINLINE ptr_glIsObjectBuffer #-}
 
ptr_glIsObjectBuffer :: FunPtr a
ptr_glIsObjectBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glIsObjectBufferATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNewObjectBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr c -> GLenum -> IO GLuint)
 
glNewObjectBuffer :: GLsizei -> Ptr c -> GLenum -> IO GLuint
glNewObjectBuffer = dyn_glNewObjectBuffer ptr_glNewObjectBuffer
 
{-# NOINLINE ptr_glNewObjectBuffer #-}
 
ptr_glNewObjectBuffer :: FunPtr a
ptr_glNewObjectBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glNewObjectBufferATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUpdateObjectBuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> Ptr e -> GLenum -> IO ())
 
glUpdateObjectBuffer ::
                     GLuint -> GLuint -> GLsizei -> Ptr e -> GLenum -> IO ()
glUpdateObjectBuffer
  = dyn_glUpdateObjectBuffer ptr_glUpdateObjectBuffer
 
{-# NOINLINE ptr_glUpdateObjectBuffer #-}
 
ptr_glUpdateObjectBuffer :: FunPtr a
ptr_glUpdateObjectBuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glUpdateObjectBufferATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVariantArrayObject ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLsizei -> GLuint -> GLuint -> IO ())
 
glVariantArrayObject ::
                     GLuint -> GLenum -> GLsizei -> GLuint -> GLuint -> IO ()
glVariantArrayObject
  = dyn_glVariantArrayObject ptr_glVariantArrayObject
 
{-# NOINLINE ptr_glVariantArrayObject #-}
 
ptr_glVariantArrayObject :: FunPtr a
ptr_glVariantArrayObject
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_array_object"
        "glVariantArrayObjectATI"