{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.ATI.ElementArray
       (gl_ELEMENT_ARRAY, gl_ELEMENT_ARRAY_POINTER, gl_ELEMENT_ARRAY_TYPE,
        glDrawElementArray, glDrawRangeElementArray, glElementPointer)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ELEMENT_ARRAY :: GLenum
gl_ELEMENT_ARRAY = 34664
 
gl_ELEMENT_ARRAY_POINTER :: GLenum
gl_ELEMENT_ARRAY_POINTER = 34666
 
gl_ELEMENT_ARRAY_TYPE :: GLenum
gl_ELEMENT_ARRAY_TYPE = 34665
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawElementArray ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> IO ())
 
glDrawElementArray :: GLenum -> GLsizei -> IO ()
glDrawElementArray = dyn_glDrawElementArray ptr_glDrawElementArray
 
{-# NOINLINE ptr_glDrawElementArray #-}
 
ptr_glDrawElementArray :: FunPtr a
ptr_glDrawElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glDrawElementArrayATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawRangeElementArray
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> IO ())
 
glDrawRangeElementArray ::
                        GLenum -> GLuint -> GLuint -> GLsizei -> IO ()
glDrawRangeElementArray
  = dyn_glDrawRangeElementArray ptr_glDrawRangeElementArray
 
{-# NOINLINE ptr_glDrawRangeElementArray #-}
 
ptr_glDrawRangeElementArray :: FunPtr a
ptr_glDrawRangeElementArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glDrawRangeElementArrayATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glElementPointer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> IO ())
 
glElementPointer :: GLenum -> Ptr a -> IO ()
glElementPointer = dyn_glElementPointer ptr_glElementPointer
 
{-# NOINLINE ptr_glElementPointer #-}
 
ptr_glElementPointer :: FunPtr a
ptr_glElementPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glElementPointerATI"