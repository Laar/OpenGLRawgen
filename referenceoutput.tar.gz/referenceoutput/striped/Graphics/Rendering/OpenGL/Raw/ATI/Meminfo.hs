module Graphics.Rendering.OpenGL.Raw.ATI.Meminfo
       (gl_RENDERBUFFER_FREE_MEMORY, gl_TEXTURE_FREE_MEMORY,
        gl_VBO_FREE_MEMORY)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RENDERBUFFER_FREE_MEMORY :: GLenum
gl_RENDERBUFFER_FREE_MEMORY = 34813
 
gl_TEXTURE_FREE_MEMORY :: GLenum
gl_TEXTURE_FREE_MEMORY = 34812
 
gl_VBO_FREE_MEMORY :: GLenum
gl_VBO_FREE_MEMORY = 34811