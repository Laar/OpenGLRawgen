module Graphics.Rendering.OpenGL.Raw.ATI.PixelFormatFloat
       (gl_COLOR_CLEAR_UNCLAMPED_VALUE, gl_RGBA_FLOAT_MODE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_CLEAR_UNCLAMPED_VALUE :: GLenum
gl_COLOR_CLEAR_UNCLAMPED_VALUE = 34869
 
gl_RGBA_FLOAT_MODE :: GLenum
gl_RGBA_FLOAT_MODE = 34848