module Graphics.Rendering.OpenGL.Raw.ATI.TextFragmentShader
       (gl_TEXT_FRAGMENT_SHADER) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TEXT_FRAGMENT_SHADER :: GLenum
gl_TEXT_FRAGMENT_SHADER = 33280