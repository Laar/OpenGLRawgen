-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.EnhancedLayouts
       (gl_LOCATION_COMPONENT, gl_TRANSFORM_FEEDBACK_BUFFER,
        gl_TRANSFORM_FEEDBACK_BUFFER_INDEX,
        gl_TRANSFORM_FEEDBACK_BUFFER_STRIDE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_TRANSFORM_FEEDBACK_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (gl_LOCATION_COMPONENT, gl_TRANSFORM_FEEDBACK_BUFFER_INDEX,
        gl_TRANSFORM_FEEDBACK_BUFFER_STRIDE)