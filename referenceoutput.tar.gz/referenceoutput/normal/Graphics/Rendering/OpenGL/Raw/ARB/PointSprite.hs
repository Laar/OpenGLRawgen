-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.PointSprite
       (gl_COORD_REPLACE_ARB, gl_POINT_SPRITE_ARB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COORD_REPLACE_ARB :: GLenum
gl_COORD_REPLACE_ARB = 34914
 
gl_POINT_SPRITE_ARB :: GLenum
gl_POINT_SPRITE_ARB = 34913