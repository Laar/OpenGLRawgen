-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Shadow
       (gl_COMPARE_R_TO_TEXTURE_ARB, gl_TEXTURE_COMPARE_FUNC_ARB,
        gl_TEXTURE_COMPARE_MODE_ARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPARE_R_TO_TEXTURE_ARB :: GLenum
gl_COMPARE_R_TO_TEXTURE_ARB = 34894
 
gl_TEXTURE_COMPARE_FUNC_ARB :: GLenum
gl_TEXTURE_COMPARE_FUNC_ARB = 34893
 
gl_TEXTURE_COMPARE_MODE_ARB :: GLenum
gl_TEXTURE_COMPARE_MODE_ARB = 34892