-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FramebufferObjectCompatibility
       (gl_INDEX, gl_TEXTURE_INTENSITY_TYPE, gl_TEXTURE_LUMINANCE_TYPE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_INDEX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30Compatibility
       (gl_TEXTURE_INTENSITY_TYPE, gl_TEXTURE_LUMINANCE_TYPE)