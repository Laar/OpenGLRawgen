-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferRange
       (gl_MAP_FLUSH_EXPLICIT_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_READ_BIT,
        gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_WRITE_BIT,
        glFlushMappedBufferRange, glMapBufferRange)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFlushMappedBufferRange, glMapBufferRange,
        gl_MAP_FLUSH_EXPLICIT_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_READ_BIT,
        gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_WRITE_BIT)