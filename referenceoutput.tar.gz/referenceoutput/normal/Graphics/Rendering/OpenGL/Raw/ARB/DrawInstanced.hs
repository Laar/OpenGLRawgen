{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DrawInstanced
       (glDrawArraysInstancedARB, glDrawElementsInstancedARB) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawArraysInstancedARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> GLsizei -> IO ())
 
glDrawArraysInstancedARB ::
                         GLenum -> GLint -> GLsizei -> GLsizei -> IO ()
glDrawArraysInstancedARB
  = dyn_glDrawArraysInstancedARB ptr_glDrawArraysInstancedARB
 
{-# NOINLINE ptr_glDrawArraysInstancedARB #-}
 
ptr_glDrawArraysInstancedARB :: FunPtr a
ptr_glDrawArraysInstancedARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_instanced"
        "glDrawArraysInstancedARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawElementsInstancedARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> Ptr e -> GLsizei -> IO ())
 
glDrawElementsInstancedARB ::
                           GLenum -> GLsizei -> GLenum -> Ptr e -> GLsizei -> IO ()
glDrawElementsInstancedARB
  = dyn_glDrawElementsInstancedARB ptr_glDrawElementsInstancedARB
 
{-# NOINLINE ptr_glDrawElementsInstancedARB #-}
 
ptr_glDrawElementsInstancedARB :: FunPtr a
ptr_glDrawElementsInstancedARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_instanced"
        "glDrawElementsInstancedARB"