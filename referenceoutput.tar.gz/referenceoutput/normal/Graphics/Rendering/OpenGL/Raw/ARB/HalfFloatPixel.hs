-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.HalfFloatPixel
       (gl_HALF_FLOAT_ARB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_HALF_FLOAT_ARB :: GLenum
gl_HALF_FLOAT_ARB = 5131