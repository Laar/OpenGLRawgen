-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Sync
       (gl_ALREADY_SIGNALED, gl_CONDITION_SATISFIED,
        gl_MAX_SERVER_WAIT_TIMEOUT, gl_OBJECT_TYPE, gl_SIGNALED,
        gl_SYNC_CONDITION, gl_SYNC_FENCE, gl_SYNC_FLAGS,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_STATUS, gl_TIMEOUT_EXPIRED, gl_TIMEOUT_IGNORED,
        gl_UNSIGNALED, gl_WAIT_FAILED, glClientWaitSync, glDeleteSync,
        glFenceSync, glGetInteger64v, glGetSynciv, glIsSync, glWaitSync)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glClientWaitSync, glDeleteSync, glFenceSync, glGetInteger64v,
        glGetSynciv, glIsSync, glWaitSync, gl_ALREADY_SIGNALED,
        gl_CONDITION_SATISFIED, gl_MAX_SERVER_WAIT_TIMEOUT, gl_OBJECT_TYPE,
        gl_SIGNALED, gl_SYNC_CONDITION, gl_SYNC_FENCE, gl_SYNC_FLAGS,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_STATUS, gl_TIMEOUT_EXPIRED, gl_TIMEOUT_IGNORED,
        gl_UNSIGNALED, gl_WAIT_FAILED)