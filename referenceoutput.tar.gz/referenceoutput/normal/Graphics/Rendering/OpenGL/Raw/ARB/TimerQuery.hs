-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TimerQuery
       (gl_TIMESTAMP, gl_TIME_ELAPSED, glGetQueryObjecti64v,
        glGetQueryObjectui64v, glQueryCounter)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGetQueryObjecti64v, glGetQueryObjectui64v, glQueryCounter,
        gl_TIMESTAMP, gl_TIME_ELAPSED)