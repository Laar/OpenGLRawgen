-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FragmentShader
       (gl_FRAGMENT_SHADER_ARB, gl_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB,
        gl_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FRAGMENT_SHADER_ARB :: GLenum
gl_FRAGMENT_SHADER_ARB = 35632
 
gl_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB :: GLenum
gl_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB = 35723
 
gl_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB :: GLenum
gl_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB = 35657