-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FramebufferObject
       (gl_COLOR_ATTACHMENT0, gl_COLOR_ATTACHMENT1, gl_COLOR_ATTACHMENT10,
        gl_COLOR_ATTACHMENT11, gl_COLOR_ATTACHMENT12,
        gl_COLOR_ATTACHMENT13, gl_COLOR_ATTACHMENT14,
        gl_COLOR_ATTACHMENT15, gl_COLOR_ATTACHMENT2, gl_COLOR_ATTACHMENT3,
        gl_COLOR_ATTACHMENT4, gl_COLOR_ATTACHMENT5, gl_COLOR_ATTACHMENT6,
        gl_COLOR_ATTACHMENT7, gl_COLOR_ATTACHMENT8, gl_COLOR_ATTACHMENT9,
        gl_DEPTH24_STENCIL8, gl_DEPTH_ATTACHMENT, gl_DEPTH_STENCIL,
        gl_DEPTH_STENCIL_ATTACHMENT, gl_DRAW_FRAMEBUFFER,
        gl_DRAW_FRAMEBUFFER_BINDING, gl_FRAMEBUFFER,
        gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING,
        gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL, gl_FRAMEBUFFER_BINDING,
        gl_FRAMEBUFFER_COMPLETE, gl_FRAMEBUFFER_DEFAULT,
        gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER,
        gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE,
        gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER, gl_FRAMEBUFFER_UNDEFINED,
        gl_FRAMEBUFFER_UNSUPPORTED, gl_INVALID_FRAMEBUFFER_OPERATION,
        gl_MAX_COLOR_ATTACHMENTS, gl_MAX_RENDERBUFFER_SIZE, gl_MAX_SAMPLES,
        gl_READ_FRAMEBUFFER, gl_READ_FRAMEBUFFER_BINDING, gl_RENDERBUFFER,
        gl_RENDERBUFFER_ALPHA_SIZE, gl_RENDERBUFFER_BINDING,
        gl_RENDERBUFFER_BLUE_SIZE, gl_RENDERBUFFER_DEPTH_SIZE,
        gl_RENDERBUFFER_GREEN_SIZE, gl_RENDERBUFFER_HEIGHT,
        gl_RENDERBUFFER_INTERNAL_FORMAT, gl_RENDERBUFFER_RED_SIZE,
        gl_RENDERBUFFER_SAMPLES, gl_RENDERBUFFER_STENCIL_SIZE,
        gl_RENDERBUFFER_WIDTH, gl_STENCIL_ATTACHMENT, gl_STENCIL_INDEX1,
        gl_STENCIL_INDEX16, gl_STENCIL_INDEX4, gl_STENCIL_INDEX8,
        gl_TEXTURE_ALPHA_TYPE, gl_TEXTURE_BLUE_TYPE, gl_TEXTURE_DEPTH_TYPE,
        gl_TEXTURE_GREEN_TYPE, gl_TEXTURE_RED_TYPE,
        gl_TEXTURE_STENCIL_SIZE, gl_UNSIGNED_INT_24_8,
        gl_UNSIGNED_NORMALIZED, glBindFramebuffer, glBindRenderbuffer,
        glBlitFramebuffer, glCheckFramebufferStatus, glDeleteFramebuffers,
        glDeleteRenderbuffers, glFramebufferRenderbuffer,
        glFramebufferTexture1D, glFramebufferTexture2D,
        glFramebufferTexture3D, glFramebufferTextureLayer,
        glGenFramebuffers, glGenRenderbuffers, glGenerateMipmap,
        glGetFramebufferAttachmentParameteriv,
        glGetRenderbufferParameteriv, glIsFramebuffer, glIsRenderbuffer,
        glRenderbufferStorage, glRenderbufferStorageMultisample)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT0)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT1)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT10)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT11)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT12)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT13)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT14)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT15)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT3)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT5)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT6)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT7)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_COLOR_ATTACHMENT9)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH24_STENCIL8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH_ATTACHMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH_STENCIL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DEPTH_STENCIL_ATTACHMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DRAW_FRAMEBUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_DRAW_FRAMEBUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_COMPLETE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_DEFAULT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_UNDEFINED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_UNSUPPORTED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_INVALID_FRAMEBUFFER_OPERATION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAX_COLOR_ATTACHMENTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAX_RENDERBUFFER_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAX_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_READ_FRAMEBUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_READ_FRAMEBUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_ALPHA_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_BLUE_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_DEPTH_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_GREEN_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_HEIGHT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_INTERNAL_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_RED_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_STENCIL_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RENDERBUFFER_WIDTH)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_STENCIL_ATTACHMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_STENCIL_INDEX1)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_STENCIL_INDEX16)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_STENCIL_INDEX4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_STENCIL_INDEX8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_ALPHA_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_BLUE_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_DEPTH_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_GREEN_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_RED_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_TEXTURE_STENCIL_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_UNSIGNED_INT_24_8)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_UNSIGNED_NORMALIZED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glBindFramebuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glBindRenderbuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glBlitFramebuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glCheckFramebufferStatus)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glDeleteFramebuffers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glDeleteRenderbuffers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFramebufferRenderbuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFramebufferTexture1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFramebufferTexture2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFramebufferTexture3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glFramebufferTextureLayer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glGenFramebuffers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glGenRenderbuffers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glGenerateMipmap)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glGetFramebufferAttachmentParameteriv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glGetRenderbufferParameteriv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glIsFramebuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glIsRenderbuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glRenderbufferStorage)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glRenderbufferStorageMultisample)