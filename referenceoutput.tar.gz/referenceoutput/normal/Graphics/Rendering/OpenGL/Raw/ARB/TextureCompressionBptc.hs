-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureCompressionBptc
       (gl_COMPRESSED_RGBA_BPTC_UNORM_ARB,
        gl_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_ARB,
        gl_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_ARB,
        gl_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_ARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPRESSED_RGBA_BPTC_UNORM_ARB :: GLenum
gl_COMPRESSED_RGBA_BPTC_UNORM_ARB = 36492
 
gl_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_ARB :: GLenum
gl_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_ARB = 36494
 
gl_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_ARB :: GLenum
gl_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_ARB = 36495
 
gl_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_ARB :: GLenum
gl_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_ARB = 36493