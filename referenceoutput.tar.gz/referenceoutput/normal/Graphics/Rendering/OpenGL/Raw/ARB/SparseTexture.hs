{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.SparseTexture
       (gl_MAX_SPARSE_3D_TEXTURE_SIZE_ARB,
        gl_MAX_SPARSE_ARRAY_TEXTURE_LAYERS_ARB,
        gl_MAX_SPARSE_TEXTURE_SIZE_ARB, gl_MIN_SPARSE_LEVEL_ARB,
        gl_NUM_VIRTUAL_PAGE_SIZES_ARB,
        gl_SPARSE_TEXTURE_FULL_ARRAY_CUBE_MIPMAPS_ARB,
        gl_TEXTURE_SPARSE_ARB, gl_VIRTUAL_PAGE_SIZE_INDEX_ARB,
        gl_VIRTUAL_PAGE_SIZE_X_ARB, gl_VIRTUAL_PAGE_SIZE_Y_ARB,
        gl_VIRTUAL_PAGE_SIZE_Z_ARB, glTexPageCommitmentARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_SPARSE_3D_TEXTURE_SIZE_ARB :: GLenum
gl_MAX_SPARSE_3D_TEXTURE_SIZE_ARB = 37273
 
gl_MAX_SPARSE_ARRAY_TEXTURE_LAYERS_ARB :: GLenum
gl_MAX_SPARSE_ARRAY_TEXTURE_LAYERS_ARB = 37274
 
gl_MAX_SPARSE_TEXTURE_SIZE_ARB :: GLenum
gl_MAX_SPARSE_TEXTURE_SIZE_ARB = 37272
 
gl_MIN_SPARSE_LEVEL_ARB :: GLenum
gl_MIN_SPARSE_LEVEL_ARB = 37275
 
gl_NUM_VIRTUAL_PAGE_SIZES_ARB :: GLenum
gl_NUM_VIRTUAL_PAGE_SIZES_ARB = 37288
 
gl_SPARSE_TEXTURE_FULL_ARRAY_CUBE_MIPMAPS_ARB :: GLenum
gl_SPARSE_TEXTURE_FULL_ARRAY_CUBE_MIPMAPS_ARB = 37289
 
gl_TEXTURE_SPARSE_ARB :: GLenum
gl_TEXTURE_SPARSE_ARB = 37286
 
gl_VIRTUAL_PAGE_SIZE_INDEX_ARB :: GLenum
gl_VIRTUAL_PAGE_SIZE_INDEX_ARB = 37287
 
gl_VIRTUAL_PAGE_SIZE_X_ARB :: GLenum
gl_VIRTUAL_PAGE_SIZE_X_ARB = 37269
 
gl_VIRTUAL_PAGE_SIZE_Y_ARB :: GLenum
gl_VIRTUAL_PAGE_SIZE_Y_ARB = 37270
 
gl_VIRTUAL_PAGE_SIZE_Z_ARB :: GLenum
gl_VIRTUAL_PAGE_SIZE_Z_ARB = 37271
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexPageCommitmentARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
glTexPageCommitmentARB ::
                       GLenum ->
                         GLint ->
                           GLint ->
                             GLint ->
                               GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTexPageCommitmentARB
  = dyn_glTexPageCommitmentARB ptr_glTexPageCommitmentARB
 
{-# NOINLINE ptr_glTexPageCommitmentARB #-}
 
ptr_glTexPageCommitmentARB :: FunPtr a
ptr_glTexPageCommitmentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sparse_texture"
        "glTexPageCommitmentARB"