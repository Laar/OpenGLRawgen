-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ClearTexture
       (gl_CLEAR_TEXTURE, glClearTexImage, glClearTexSubImage) where
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (glClearTexImage, glClearTexSubImage, gl_CLEAR_TEXTURE)