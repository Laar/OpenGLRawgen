-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.CullDistance
       (gl_MAX_COMBINED_CLIP_AND_CULL_DISTANCES, gl_MAX_CULL_DISTANCES)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core45
       (gl_MAX_COMBINED_CLIP_AND_CULL_DISTANCES, gl_MAX_CULL_DISTANCES)