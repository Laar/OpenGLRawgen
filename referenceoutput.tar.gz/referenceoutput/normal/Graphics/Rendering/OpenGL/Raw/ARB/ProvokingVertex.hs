-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ProvokingVertex
       (gl_FIRST_VERTEX_CONVENTION, gl_LAST_VERTEX_CONVENTION,
        gl_PROVOKING_VERTEX, gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION,
        glProvokingVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_FIRST_VERTEX_CONVENTION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_LAST_VERTEX_CONVENTION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_PROVOKING_VERTEX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glProvokingVertex)