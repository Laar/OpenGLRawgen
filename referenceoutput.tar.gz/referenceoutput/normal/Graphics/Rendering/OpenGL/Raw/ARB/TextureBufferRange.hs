-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureBufferRange
       (gl_TEXTURE_BUFFER_OFFSET, gl_TEXTURE_BUFFER_OFFSET_ALIGNMENT,
        gl_TEXTURE_BUFFER_SIZE, glTexBufferRange, glTextureBufferRangeEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_OFFSET_ALIGNMENT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_TEXTURE_BUFFER_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTexBufferRange)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glTextureBufferRangeEXT)