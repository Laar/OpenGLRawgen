-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.QueryBufferObject
       (gl_QUERY_BUFFER, gl_QUERY_BUFFER_BARRIER_BIT,
        gl_QUERY_BUFFER_BINDING, gl_QUERY_RESULT_NO_WAIT)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (gl_QUERY_BUFFER, gl_QUERY_BUFFER_BARRIER_BIT,
        gl_QUERY_BUFFER_BINDING, gl_QUERY_RESULT_NO_WAIT)