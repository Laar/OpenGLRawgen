-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ES2Compatibility
       (gl_FIXED, gl_HIGH_FLOAT, gl_HIGH_INT,
        gl_IMPLEMENTATION_COLOR_READ_FORMAT,
        gl_IMPLEMENTATION_COLOR_READ_TYPE, gl_LOW_FLOAT, gl_LOW_INT,
        gl_MAX_FRAGMENT_UNIFORM_VECTORS, gl_MAX_VARYING_VECTORS,
        gl_MAX_VERTEX_UNIFORM_VECTORS, gl_MEDIUM_FLOAT, gl_MEDIUM_INT,
        gl_NUM_SHADER_BINARY_FORMATS, gl_RGB565, gl_SHADER_BINARY_FORMATS,
        gl_SHADER_COMPILER, glClearDepthf, glDepthRangef,
        glGetShaderPrecisionFormat, glReleaseShaderCompiler,
        glShaderBinary)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glClearDepthf, glDepthRangef, glGetShaderPrecisionFormat,
        glReleaseShaderCompiler, glShaderBinary, gl_FIXED, gl_HIGH_FLOAT,
        gl_HIGH_INT, gl_IMPLEMENTATION_COLOR_READ_FORMAT,
        gl_IMPLEMENTATION_COLOR_READ_TYPE, gl_LOW_FLOAT, gl_LOW_INT,
        gl_MAX_FRAGMENT_UNIFORM_VECTORS, gl_MAX_VARYING_VECTORS,
        gl_MAX_VERTEX_UNIFORM_VECTORS, gl_MEDIUM_FLOAT, gl_MEDIUM_INT,
        gl_NUM_SHADER_BINARY_FORMATS, gl_RGB565, gl_SHADER_BINARY_FORMATS,
        gl_SHADER_COMPILER)