{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_MATRIX_ARB, gl_CURRENT_MATRIX_STACK_DEPTH_ARB,
        gl_FRAGMENT_PROGRAM_ARB, gl_MATRIX0_ARB, gl_MATRIX10_ARB,
        gl_MATRIX11_ARB, gl_MATRIX12_ARB, gl_MATRIX13_ARB, gl_MATRIX14_ARB,
        gl_MATRIX15_ARB, gl_MATRIX16_ARB, gl_MATRIX17_ARB, gl_MATRIX18_ARB,
        gl_MATRIX19_ARB, gl_MATRIX1_ARB, gl_MATRIX20_ARB, gl_MATRIX21_ARB,
        gl_MATRIX22_ARB, gl_MATRIX23_ARB, gl_MATRIX24_ARB, gl_MATRIX25_ARB,
        gl_MATRIX26_ARB, gl_MATRIX27_ARB, gl_MATRIX28_ARB, gl_MATRIX29_ARB,
        gl_MATRIX2_ARB, gl_MATRIX30_ARB, gl_MATRIX31_ARB, gl_MATRIX3_ARB,
        gl_MATRIX4_ARB, gl_MATRIX5_ARB, gl_MATRIX6_ARB, gl_MATRIX7_ARB,
        gl_MATRIX8_ARB, gl_MATRIX9_ARB,
        gl_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB, gl_MAX_PROGRAM_ATTRIBS_ARB,
        gl_MAX_PROGRAM_ENV_PARAMETERS_ARB, gl_MAX_PROGRAM_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB, gl_MAX_PROGRAM_MATRICES_ARB,
        gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB,
        gl_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB,
        gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB,
        gl_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_PARAMETERS_ARB, gl_MAX_PROGRAM_TEMPORARIES_ARB,
        gl_MAX_PROGRAM_TEX_INDIRECTIONS_ARB,
        gl_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB, gl_MAX_TEXTURE_COORDS_ARB,
        gl_MAX_TEXTURE_IMAGE_UNITS_ARB, gl_PROGRAM_ALU_INSTRUCTIONS_ARB,
        gl_PROGRAM_ATTRIBS_ARB, gl_PROGRAM_BINDING_ARB,
        gl_PROGRAM_ERROR_POSITION_ARB, gl_PROGRAM_ERROR_STRING_ARB,
        gl_PROGRAM_FORMAT_ARB, gl_PROGRAM_FORMAT_ASCII_ARB,
        gl_PROGRAM_INSTRUCTIONS_ARB, gl_PROGRAM_LENGTH_ARB,
        gl_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB,
        gl_PROGRAM_NATIVE_ATTRIBS_ARB, gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_PROGRAM_NATIVE_TEMPORARIES_ARB,
        gl_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB,
        gl_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB, gl_PROGRAM_PARAMETERS_ARB,
        gl_PROGRAM_STRING_ARB, gl_PROGRAM_TEMPORARIES_ARB,
        gl_PROGRAM_TEX_INDIRECTIONS_ARB, gl_PROGRAM_TEX_INSTRUCTIONS_ARB,
        gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB,
        gl_TRANSPOSE_CURRENT_MATRIX_ARB, glBindProgramARB,
        glDeleteProgramsARB, glGenProgramsARB,
        glGetProgramEnvParameterdvARB, glGetProgramEnvParameterfvARB,
        glGetProgramLocalParameterdvARB, glGetProgramLocalParameterfvARB,
        glGetProgramStringARB, glGetProgramivARB, glIsProgramARB,
        glProgramEnvParameter4dARB, glProgramEnvParameter4dvARB,
        glProgramEnvParameter4fARB, glProgramEnvParameter4fvARB,
        glProgramLocalParameter4dARB, glProgramLocalParameter4dvARB,
        glProgramLocalParameter4fARB, glProgramLocalParameter4fvARB,
        glProgramStringARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CURRENT_MATRIX_ARB :: GLenum
gl_CURRENT_MATRIX_ARB = 34369
 
gl_CURRENT_MATRIX_STACK_DEPTH_ARB :: GLenum
gl_CURRENT_MATRIX_STACK_DEPTH_ARB = 34368
 
gl_FRAGMENT_PROGRAM_ARB :: GLenum
gl_FRAGMENT_PROGRAM_ARB = 34820
 
gl_MATRIX0_ARB :: GLenum
gl_MATRIX0_ARB = 35008
 
gl_MATRIX10_ARB :: GLenum
gl_MATRIX10_ARB = 35018
 
gl_MATRIX11_ARB :: GLenum
gl_MATRIX11_ARB = 35019
 
gl_MATRIX12_ARB :: GLenum
gl_MATRIX12_ARB = 35020
 
gl_MATRIX13_ARB :: GLenum
gl_MATRIX13_ARB = 35021
 
gl_MATRIX14_ARB :: GLenum
gl_MATRIX14_ARB = 35022
 
gl_MATRIX15_ARB :: GLenum
gl_MATRIX15_ARB = 35023
 
gl_MATRIX16_ARB :: GLenum
gl_MATRIX16_ARB = 35024
 
gl_MATRIX17_ARB :: GLenum
gl_MATRIX17_ARB = 35025
 
gl_MATRIX18_ARB :: GLenum
gl_MATRIX18_ARB = 35026
 
gl_MATRIX19_ARB :: GLenum
gl_MATRIX19_ARB = 35027
 
gl_MATRIX1_ARB :: GLenum
gl_MATRIX1_ARB = 35009
 
gl_MATRIX20_ARB :: GLenum
gl_MATRIX20_ARB = 35028
 
gl_MATRIX21_ARB :: GLenum
gl_MATRIX21_ARB = 35029
 
gl_MATRIX22_ARB :: GLenum
gl_MATRIX22_ARB = 35030
 
gl_MATRIX23_ARB :: GLenum
gl_MATRIX23_ARB = 35031
 
gl_MATRIX24_ARB :: GLenum
gl_MATRIX24_ARB = 35032
 
gl_MATRIX25_ARB :: GLenum
gl_MATRIX25_ARB = 35033
 
gl_MATRIX26_ARB :: GLenum
gl_MATRIX26_ARB = 35034
 
gl_MATRIX27_ARB :: GLenum
gl_MATRIX27_ARB = 35035
 
gl_MATRIX28_ARB :: GLenum
gl_MATRIX28_ARB = 35036
 
gl_MATRIX29_ARB :: GLenum
gl_MATRIX29_ARB = 35037
 
gl_MATRIX2_ARB :: GLenum
gl_MATRIX2_ARB = 35010
 
gl_MATRIX30_ARB :: GLenum
gl_MATRIX30_ARB = 35038
 
gl_MATRIX31_ARB :: GLenum
gl_MATRIX31_ARB = 35039
 
gl_MATRIX3_ARB :: GLenum
gl_MATRIX3_ARB = 35011
 
gl_MATRIX4_ARB :: GLenum
gl_MATRIX4_ARB = 35012
 
gl_MATRIX5_ARB :: GLenum
gl_MATRIX5_ARB = 35013
 
gl_MATRIX6_ARB :: GLenum
gl_MATRIX6_ARB = 35014
 
gl_MATRIX7_ARB :: GLenum
gl_MATRIX7_ARB = 35015
 
gl_MATRIX8_ARB :: GLenum
gl_MATRIX8_ARB = 35016
 
gl_MATRIX9_ARB :: GLenum
gl_MATRIX9_ARB = 35017
 
gl_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB = 34827
 
gl_MAX_PROGRAM_ATTRIBS_ARB :: GLenum
gl_MAX_PROGRAM_ATTRIBS_ARB = 34989
 
gl_MAX_PROGRAM_ENV_PARAMETERS_ARB :: GLenum
gl_MAX_PROGRAM_ENV_PARAMETERS_ARB = 34997
 
gl_MAX_PROGRAM_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_INSTRUCTIONS_ARB = 34977
 
gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB :: GLenum
gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB = 34996
 
gl_MAX_PROGRAM_MATRICES_ARB :: GLenum
gl_MAX_PROGRAM_MATRICES_ARB = 34351
 
gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB :: GLenum
gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB = 34350
 
gl_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34830
 
gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB = 34991
 
gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34979
 
gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB = 34987
 
gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB = 34983
 
gl_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34832
 
gl_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34831
 
gl_MAX_PROGRAM_PARAMETERS_ARB :: GLenum
gl_MAX_PROGRAM_PARAMETERS_ARB = 34985
 
gl_MAX_PROGRAM_TEMPORARIES_ARB :: GLenum
gl_MAX_PROGRAM_TEMPORARIES_ARB = 34981
 
gl_MAX_PROGRAM_TEX_INDIRECTIONS_ARB :: GLenum
gl_MAX_PROGRAM_TEX_INDIRECTIONS_ARB = 34829
 
gl_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB :: GLenum
gl_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB = 34828
 
gl_MAX_TEXTURE_COORDS_ARB :: GLenum
gl_MAX_TEXTURE_COORDS_ARB = 34929
 
gl_MAX_TEXTURE_IMAGE_UNITS_ARB :: GLenum
gl_MAX_TEXTURE_IMAGE_UNITS_ARB = 34930
 
gl_PROGRAM_ALU_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_ALU_INSTRUCTIONS_ARB = 34821
 
gl_PROGRAM_ATTRIBS_ARB :: GLenum
gl_PROGRAM_ATTRIBS_ARB = 34988
 
gl_PROGRAM_BINDING_ARB :: GLenum
gl_PROGRAM_BINDING_ARB = 34423
 
gl_PROGRAM_ERROR_POSITION_ARB :: GLenum
gl_PROGRAM_ERROR_POSITION_ARB = 34379
 
gl_PROGRAM_ERROR_STRING_ARB :: GLenum
gl_PROGRAM_ERROR_STRING_ARB = 34932
 
gl_PROGRAM_FORMAT_ARB :: GLenum
gl_PROGRAM_FORMAT_ARB = 34934
 
gl_PROGRAM_FORMAT_ASCII_ARB :: GLenum
gl_PROGRAM_FORMAT_ASCII_ARB = 34933
 
gl_PROGRAM_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_INSTRUCTIONS_ARB = 34976
 
gl_PROGRAM_LENGTH_ARB :: GLenum
gl_PROGRAM_LENGTH_ARB = 34343
 
gl_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB = 34824
 
gl_PROGRAM_NATIVE_ATTRIBS_ARB :: GLenum
gl_PROGRAM_NATIVE_ATTRIBS_ARB = 34990
 
gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34978
 
gl_PROGRAM_NATIVE_PARAMETERS_ARB :: GLenum
gl_PROGRAM_NATIVE_PARAMETERS_ARB = 34986
 
gl_PROGRAM_NATIVE_TEMPORARIES_ARB :: GLenum
gl_PROGRAM_NATIVE_TEMPORARIES_ARB = 34982
 
gl_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB :: GLenum
gl_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB = 34826
 
gl_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB = 34825
 
gl_PROGRAM_PARAMETERS_ARB :: GLenum
gl_PROGRAM_PARAMETERS_ARB = 34984
 
gl_PROGRAM_STRING_ARB :: GLenum
gl_PROGRAM_STRING_ARB = 34344
 
gl_PROGRAM_TEMPORARIES_ARB :: GLenum
gl_PROGRAM_TEMPORARIES_ARB = 34980
 
gl_PROGRAM_TEX_INDIRECTIONS_ARB :: GLenum
gl_PROGRAM_TEX_INDIRECTIONS_ARB = 34823
 
gl_PROGRAM_TEX_INSTRUCTIONS_ARB :: GLenum
gl_PROGRAM_TEX_INSTRUCTIONS_ARB = 34822
 
gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB :: GLenum
gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB = 34998
 
gl_TRANSPOSE_CURRENT_MATRIX_ARB :: GLenum
gl_TRANSPOSE_CURRENT_MATRIX_ARB = 34999
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindProgramARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindProgramARB :: GLenum -> GLuint -> IO ()
glBindProgramARB = dyn_glBindProgramARB ptr_glBindProgramARB
 
{-# NOINLINE ptr_glBindProgramARB #-}
 
ptr_glBindProgramARB :: FunPtr a
ptr_glBindProgramARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glBindProgramARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteProgramsARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteProgramsARB :: GLsizei -> Ptr GLuint -> IO ()
glDeleteProgramsARB
  = dyn_glDeleteProgramsARB ptr_glDeleteProgramsARB
 
{-# NOINLINE ptr_glDeleteProgramsARB #-}
 
ptr_glDeleteProgramsARB :: FunPtr a
ptr_glDeleteProgramsARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glDeleteProgramsARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenProgramsARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenProgramsARB :: GLsizei -> Ptr GLuint -> IO ()
glGenProgramsARB = dyn_glGenProgramsARB ptr_glGenProgramsARB
 
{-# NOINLINE ptr_glGenProgramsARB #-}
 
ptr_glGenProgramsARB :: FunPtr a
ptr_glGenProgramsARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGenProgramsARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramEnvParameterdvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetProgramEnvParameterdvARB ::
                              GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetProgramEnvParameterdvARB
  = dyn_glGetProgramEnvParameterdvARB
      ptr_glGetProgramEnvParameterdvARB
 
{-# NOINLINE ptr_glGetProgramEnvParameterdvARB #-}
 
ptr_glGetProgramEnvParameterdvARB :: FunPtr a
ptr_glGetProgramEnvParameterdvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramEnvParameterdvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramEnvParameterfvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetProgramEnvParameterfvARB ::
                              GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetProgramEnvParameterfvARB
  = dyn_glGetProgramEnvParameterfvARB
      ptr_glGetProgramEnvParameterfvARB
 
{-# NOINLINE ptr_glGetProgramEnvParameterfvARB #-}
 
ptr_glGetProgramEnvParameterfvARB :: FunPtr a
ptr_glGetProgramEnvParameterfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramEnvParameterfvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramLocalParameterdvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetProgramLocalParameterdvARB ::
                                GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetProgramLocalParameterdvARB
  = dyn_glGetProgramLocalParameterdvARB
      ptr_glGetProgramLocalParameterdvARB
 
{-# NOINLINE ptr_glGetProgramLocalParameterdvARB #-}
 
ptr_glGetProgramLocalParameterdvARB :: FunPtr a
ptr_glGetProgramLocalParameterdvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramLocalParameterdvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramLocalParameterfvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetProgramLocalParameterfvARB ::
                                GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetProgramLocalParameterfvARB
  = dyn_glGetProgramLocalParameterfvARB
      ptr_glGetProgramLocalParameterfvARB
 
{-# NOINLINE ptr_glGetProgramLocalParameterfvARB #-}
 
ptr_glGetProgramLocalParameterfvARB :: FunPtr a
ptr_glGetProgramLocalParameterfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramLocalParameterfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramStringARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr d -> IO ())
 
glGetProgramStringARB :: GLenum -> GLenum -> Ptr d -> IO ()
glGetProgramStringARB
  = dyn_glGetProgramStringARB ptr_glGetProgramStringARB
 
{-# NOINLINE ptr_glGetProgramStringARB #-}
 
ptr_glGetProgramStringARB :: FunPtr a
ptr_glGetProgramStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetProgramivARB :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetProgramivARB = dyn_glGetProgramivARB ptr_glGetProgramivARB
 
{-# NOINLINE ptr_glGetProgramivARB #-}
 
ptr_glGetProgramivARB :: FunPtr a
ptr_glGetProgramivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glGetProgramivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsProgramARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsProgramARB :: GLuint -> IO GLboolean
glIsProgramARB = dyn_glIsProgramARB ptr_glIsProgramARB
 
{-# NOINLINE ptr_glIsProgramARB #-}
 
ptr_glIsProgramARB :: FunPtr a
ptr_glIsProgramARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glIsProgramARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameter4dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramEnvParameter4dARB ::
                           GLenum ->
                             GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramEnvParameter4dARB
  = dyn_glProgramEnvParameter4dARB ptr_glProgramEnvParameter4dARB
 
{-# NOINLINE ptr_glProgramEnvParameter4dARB #-}
 
ptr_glProgramEnvParameter4dARB :: FunPtr a
ptr_glProgramEnvParameter4dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramEnvParameter4dARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameter4dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glProgramEnvParameter4dvARB ::
                            GLenum -> GLuint -> Ptr GLdouble -> IO ()
glProgramEnvParameter4dvARB
  = dyn_glProgramEnvParameter4dvARB ptr_glProgramEnvParameter4dvARB
 
{-# NOINLINE ptr_glProgramEnvParameter4dvARB #-}
 
ptr_glProgramEnvParameter4dvARB :: FunPtr a
ptr_glProgramEnvParameter4dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramEnvParameter4dvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameter4fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramEnvParameter4fARB ::
                           GLenum ->
                             GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramEnvParameter4fARB
  = dyn_glProgramEnvParameter4fARB ptr_glProgramEnvParameter4fARB
 
{-# NOINLINE ptr_glProgramEnvParameter4fARB #-}
 
ptr_glProgramEnvParameter4fARB :: FunPtr a
ptr_glProgramEnvParameter4fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramEnvParameter4fARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramEnvParameter4fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glProgramEnvParameter4fvARB ::
                            GLenum -> GLuint -> Ptr GLfloat -> IO ()
glProgramEnvParameter4fvARB
  = dyn_glProgramEnvParameter4fvARB ptr_glProgramEnvParameter4fvARB
 
{-# NOINLINE ptr_glProgramEnvParameter4fvARB #-}
 
ptr_glProgramEnvParameter4fvARB :: FunPtr a
ptr_glProgramEnvParameter4fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramEnvParameter4fvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameter4dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramLocalParameter4dARB ::
                             GLenum ->
                               GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramLocalParameter4dARB
  = dyn_glProgramLocalParameter4dARB ptr_glProgramLocalParameter4dARB
 
{-# NOINLINE ptr_glProgramLocalParameter4dARB #-}
 
ptr_glProgramLocalParameter4dARB :: FunPtr a
ptr_glProgramLocalParameter4dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramLocalParameter4dARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameter4dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glProgramLocalParameter4dvARB ::
                              GLenum -> GLuint -> Ptr GLdouble -> IO ()
glProgramLocalParameter4dvARB
  = dyn_glProgramLocalParameter4dvARB
      ptr_glProgramLocalParameter4dvARB
 
{-# NOINLINE ptr_glProgramLocalParameter4dvARB #-}
 
ptr_glProgramLocalParameter4dvARB :: FunPtr a
ptr_glProgramLocalParameter4dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramLocalParameter4dvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameter4fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramLocalParameter4fARB ::
                             GLenum ->
                               GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramLocalParameter4fARB
  = dyn_glProgramLocalParameter4fARB ptr_glProgramLocalParameter4fARB
 
{-# NOINLINE ptr_glProgramLocalParameter4fARB #-}
 
ptr_glProgramLocalParameter4fARB :: FunPtr a
ptr_glProgramLocalParameter4fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramLocalParameter4fARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramLocalParameter4fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glProgramLocalParameter4fvARB ::
                              GLenum -> GLuint -> Ptr GLfloat -> IO ()
glProgramLocalParameter4fvARB
  = dyn_glProgramLocalParameter4fvARB
      ptr_glProgramLocalParameter4fvARB
 
{-# NOINLINE ptr_glProgramLocalParameter4fvARB #-}
 
ptr_glProgramLocalParameter4fvARB :: FunPtr a
ptr_glProgramLocalParameter4fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramLocalParameter4fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramStringARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr e -> IO ())
 
glProgramStringARB :: GLenum -> GLenum -> GLsizei -> Ptr e -> IO ()
glProgramStringARB = dyn_glProgramStringARB ptr_glProgramStringARB
 
{-# NOINLINE ptr_glProgramStringARB #-}
 
ptr_glProgramStringARB :: FunPtr a
ptr_glProgramStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_fragment_program"
        "glProgramStringARB"