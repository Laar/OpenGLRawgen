-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.CopyBuffer
       (gl_COPY_READ_BUFFER, gl_COPY_READ_BUFFER_BINDING,
        gl_COPY_WRITE_BUFFER, gl_COPY_WRITE_BUFFER_BINDING,
        glCopyBufferSubData)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (glCopyBufferSubData, gl_COPY_READ_BUFFER, gl_COPY_WRITE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COPY_READ_BUFFER_BINDING :: GLenum
gl_COPY_READ_BUFFER_BINDING = gl_COPY_READ_BUFFER
 
gl_COPY_WRITE_BUFFER_BINDING :: GLenum
gl_COPY_WRITE_BUFFER_BINDING = gl_COPY_WRITE_BUFFER