{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexShader
       (gl_CURRENT_VERTEX_ATTRIB_ARB, gl_FLOAT, gl_FLOAT_MAT2_ARB,
        gl_FLOAT_MAT3_ARB, gl_FLOAT_MAT4_ARB, gl_FLOAT_VEC2_ARB,
        gl_FLOAT_VEC3_ARB, gl_FLOAT_VEC4_ARB,
        gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB, gl_MAX_TEXTURE_COORDS_ARB,
        gl_MAX_TEXTURE_IMAGE_UNITS_ARB, gl_MAX_VARYING_FLOATS_ARB,
        gl_MAX_VERTEX_ATTRIBS_ARB, gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB,
        gl_MAX_VERTEX_UNIFORM_COMPONENTS_ARB,
        gl_OBJECT_ACTIVE_ATTRIBUTES_ARB,
        gl_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB,
        gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB, gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB,
        gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB, gl_VERTEX_PROGRAM_POINT_SIZE_ARB,
        gl_VERTEX_PROGRAM_TWO_SIDE_ARB, gl_VERTEX_SHADER_ARB,
        glBindAttribLocationARB, glDisableVertexAttribArrayARB,
        glEnableVertexAttribArrayARB, glGetActiveAttribARB,
        glGetAttribLocationARB, glGetVertexAttribPointervARB,
        glGetVertexAttribdvARB, glGetVertexAttribfvARB,
        glGetVertexAttribivARB, glVertexAttrib1dARB, glVertexAttrib1dvARB,
        glVertexAttrib1fARB, glVertexAttrib1fvARB, glVertexAttrib1sARB,
        glVertexAttrib1svARB, glVertexAttrib2dARB, glVertexAttrib2dvARB,
        glVertexAttrib2fARB, glVertexAttrib2fvARB, glVertexAttrib2sARB,
        glVertexAttrib2svARB, glVertexAttrib3dARB, glVertexAttrib3dvARB,
        glVertexAttrib3fARB, glVertexAttrib3fvARB, glVertexAttrib3sARB,
        glVertexAttrib3svARB, glVertexAttrib4NbvARB, glVertexAttrib4NivARB,
        glVertexAttrib4NsvARB, glVertexAttrib4NubARB,
        glVertexAttrib4NubvARB, glVertexAttrib4NuivARB,
        glVertexAttrib4NusvARB, glVertexAttrib4bvARB, glVertexAttrib4dARB,
        glVertexAttrib4dvARB, glVertexAttrib4fARB, glVertexAttrib4fvARB,
        glVertexAttrib4ivARB, glVertexAttrib4sARB, glVertexAttrib4svARB,
        glVertexAttrib4ubvARB, glVertexAttrib4uivARB,
        glVertexAttrib4usvARB, glVertexAttribPointerARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_TEXTURE_COORDS_ARB, gl_MAX_TEXTURE_IMAGE_UNITS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.ShaderObjects
       (gl_FLOAT_MAT2_ARB, gl_FLOAT_MAT3_ARB, gl_FLOAT_MAT4_ARB,
        gl_FLOAT_VEC2_ARB, gl_FLOAT_VEC3_ARB, gl_FLOAT_VEC4_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.VertexProgram
       (glDisableVertexAttribArrayARB, glEnableVertexAttribArrayARB,
        glGetVertexAttribPointervARB, glGetVertexAttribdvARB,
        glGetVertexAttribfvARB, glGetVertexAttribivARB,
        glVertexAttrib1dARB, glVertexAttrib1dvARB, glVertexAttrib1fARB,
        glVertexAttrib1fvARB, glVertexAttrib1sARB, glVertexAttrib1svARB,
        glVertexAttrib2dARB, glVertexAttrib2dvARB, glVertexAttrib2fARB,
        glVertexAttrib2fvARB, glVertexAttrib2sARB, glVertexAttrib2svARB,
        glVertexAttrib3dARB, glVertexAttrib3dvARB, glVertexAttrib3fARB,
        glVertexAttrib3fvARB, glVertexAttrib3sARB, glVertexAttrib3svARB,
        glVertexAttrib4NbvARB, glVertexAttrib4NivARB,
        glVertexAttrib4NsvARB, glVertexAttrib4NubARB,
        glVertexAttrib4NubvARB, glVertexAttrib4NuivARB,
        glVertexAttrib4NusvARB, glVertexAttrib4bvARB, glVertexAttrib4dARB,
        glVertexAttrib4dvARB, glVertexAttrib4fARB, glVertexAttrib4fvARB,
        glVertexAttrib4ivARB, glVertexAttrib4sARB, glVertexAttrib4svARB,
        glVertexAttrib4ubvARB, glVertexAttrib4uivARB,
        glVertexAttrib4usvARB, glVertexAttribPointerARB,
        gl_CURRENT_VERTEX_ATTRIB_ARB, gl_MAX_VERTEX_ATTRIBS_ARB,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB,
        gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB, gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB,
        gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB, gl_VERTEX_PROGRAM_POINT_SIZE_ARB,
        gl_VERTEX_PROGRAM_TWO_SIDE_ARB)
import Graphics.Rendering.OpenGL.Raw.Core.Core11 (gl_FLOAT)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB :: GLenum
gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB = 35661
 
gl_MAX_VARYING_FLOATS_ARB :: GLenum
gl_MAX_VARYING_FLOATS_ARB = 35659
 
gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB :: GLenum
gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660
 
gl_MAX_VERTEX_UNIFORM_COMPONENTS_ARB :: GLenum
gl_MAX_VERTEX_UNIFORM_COMPONENTS_ARB = 35658
 
gl_OBJECT_ACTIVE_ATTRIBUTES_ARB :: GLenum
gl_OBJECT_ACTIVE_ATTRIBUTES_ARB = 35721
 
gl_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB :: GLenum
gl_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB = 35722
 
gl_VERTEX_SHADER_ARB :: GLenum
gl_VERTEX_SHADER_ARB = 35633
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindAttribLocationARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> GLuint -> Ptr GLchar -> IO ())
 
glBindAttribLocationARB ::
                        GLhandle -> GLuint -> Ptr GLchar -> IO ()
glBindAttribLocationARB
  = dyn_glBindAttribLocationARB ptr_glBindAttribLocationARB
 
{-# NOINLINE ptr_glBindAttribLocationARB #-}
 
ptr_glBindAttribLocationARB :: FunPtr a
ptr_glBindAttribLocationARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_shader"
        "glBindAttribLocationARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetActiveAttribARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle ->
                    GLuint ->
                      GLsizei ->
                        Ptr GLsizei -> Ptr GLint -> Ptr GLenum -> Ptr GLchar -> IO ())
 
glGetActiveAttribARB ::
                     GLhandle ->
                       GLuint ->
                         GLsizei ->
                           Ptr GLsizei -> Ptr GLint -> Ptr GLenum -> Ptr GLchar -> IO ()
glGetActiveAttribARB
  = dyn_glGetActiveAttribARB ptr_glGetActiveAttribARB
 
{-# NOINLINE ptr_glGetActiveAttribARB #-}
 
ptr_glGetActiveAttribARB :: FunPtr a
ptr_glGetActiveAttribARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_shader"
        "glGetActiveAttribARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetAttribLocationARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhandle -> Ptr GLchar -> IO GLint)
 
glGetAttribLocationARB :: GLhandle -> Ptr GLchar -> IO GLint
glGetAttribLocationARB
  = dyn_glGetAttribLocationARB ptr_glGetAttribLocationARB
 
{-# NOINLINE ptr_glGetAttribLocationARB #-}
 
ptr_glGetAttribLocationARB :: FunPtr a
ptr_glGetAttribLocationARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_shader"
        "glGetAttribLocationARB"