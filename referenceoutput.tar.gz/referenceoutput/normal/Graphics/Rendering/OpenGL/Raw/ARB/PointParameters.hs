{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.PointParameters
       (gl_POINT_DISTANCE_ATTENUATION_ARB,
        gl_POINT_FADE_THRESHOLD_SIZE_ARB, gl_POINT_SIZE_MAX_ARB,
        gl_POINT_SIZE_MIN_ARB, glPointParameterfARB, glPointParameterfvARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_POINT_DISTANCE_ATTENUATION_ARB :: GLenum
gl_POINT_DISTANCE_ATTENUATION_ARB = 33065
 
gl_POINT_FADE_THRESHOLD_SIZE_ARB :: GLenum
gl_POINT_FADE_THRESHOLD_SIZE_ARB = 33064
 
gl_POINT_SIZE_MAX_ARB :: GLenum
gl_POINT_SIZE_MAX_ARB = 33063
 
gl_POINT_SIZE_MIN_ARB :: GLenum
gl_POINT_SIZE_MIN_ARB = 33062
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterfARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
glPointParameterfARB :: GLenum -> GLfloat -> IO ()
glPointParameterfARB
  = dyn_glPointParameterfARB ptr_glPointParameterfARB
 
{-# NOINLINE ptr_glPointParameterfARB #-}
 
ptr_glPointParameterfARB :: FunPtr a
ptr_glPointParameterfARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_point_parameters"
        "glPointParameterfARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterfvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glPointParameterfvARB :: GLenum -> Ptr GLfloat -> IO ()
glPointParameterfvARB
  = dyn_glPointParameterfvARB ptr_glPointParameterfvARB
 
{-# NOINLINE ptr_glPointParameterfvARB #-}
 
ptr_glPointParameterfvARB :: FunPtr a
ptr_glPointParameterfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_point_parameters"
        "glPointParameterfvARB"