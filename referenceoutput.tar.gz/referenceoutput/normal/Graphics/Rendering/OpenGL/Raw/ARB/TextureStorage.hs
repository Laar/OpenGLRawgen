-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureStorage
       (gl_TEXTURE_IMMUTABLE_FORMAT, glTexStorage1D, glTexStorage2D,
        glTexStorage3D, glTextureStorage1DEXT, glTextureStorage2DEXT,
        glTextureStorage3DEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_TEXTURE_IMMUTABLE_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTexStorage1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTexStorage2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTexStorage3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTextureStorage1DEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTextureStorage2DEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glTextureStorage3DEXT)