-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferAlignment
       (gl_MIN_MAP_BUFFER_ALIGNMENT) where
import Graphics.Rendering.OpenGL.Raw.Core.Core42
       (gl_MIN_MAP_BUFFER_ALIGNMENT)