-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexType10f11f11fRev
       (gl_UNSIGNED_INT_10F_11F_11F_REV) where
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_UNSIGNED_INT_10F_11F_11F_REV)