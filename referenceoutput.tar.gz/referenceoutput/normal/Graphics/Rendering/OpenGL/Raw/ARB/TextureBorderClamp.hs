-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureBorderClamp
       (gl_CLAMP_TO_BORDER_ARB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CLAMP_TO_BORDER_ARB :: GLenum
gl_CLAMP_TO_BORDER_ARB = 33069