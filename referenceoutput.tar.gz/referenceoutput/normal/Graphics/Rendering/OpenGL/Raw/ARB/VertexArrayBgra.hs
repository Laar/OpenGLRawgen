-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexArrayBgra (gl_BGRA)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core12 (gl_BGRA)