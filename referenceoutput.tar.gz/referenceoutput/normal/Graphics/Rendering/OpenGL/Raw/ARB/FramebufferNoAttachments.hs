-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FramebufferNoAttachments
       (gl_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS,
        gl_FRAMEBUFFER_DEFAULT_HEIGHT, gl_FRAMEBUFFER_DEFAULT_LAYERS,
        gl_FRAMEBUFFER_DEFAULT_SAMPLES, gl_FRAMEBUFFER_DEFAULT_WIDTH,
        gl_MAX_FRAMEBUFFER_HEIGHT, gl_MAX_FRAMEBUFFER_LAYERS,
        gl_MAX_FRAMEBUFFER_SAMPLES, gl_MAX_FRAMEBUFFER_WIDTH,
        glFramebufferParameteri, glGetFramebufferParameteriv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core43
       (glFramebufferParameteri, glGetFramebufferParameteriv,
        gl_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS,
        gl_FRAMEBUFFER_DEFAULT_HEIGHT, gl_FRAMEBUFFER_DEFAULT_LAYERS,
        gl_FRAMEBUFFER_DEFAULT_SAMPLES, gl_FRAMEBUFFER_DEFAULT_WIDTH,
        gl_MAX_FRAMEBUFFER_HEIGHT, gl_MAX_FRAMEBUFFER_LAYERS,
        gl_MAX_FRAMEBUFFER_SAMPLES, gl_MAX_FRAMEBUFFER_WIDTH)