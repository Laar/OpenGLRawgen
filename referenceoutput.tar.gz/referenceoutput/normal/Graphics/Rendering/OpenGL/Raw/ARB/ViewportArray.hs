-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ViewportArray
       (gl_DEPTH_RANGE, gl_FIRST_VERTEX_CONVENTION,
        gl_LAST_VERTEX_CONVENTION, gl_LAYER_PROVOKING_VERTEX,
        gl_MAX_VIEWPORTS, gl_PROVOKING_VERTEX, gl_SCISSOR_BOX,
        gl_SCISSOR_TEST, gl_UNDEFINED_VERTEX, gl_VIEWPORT,
        gl_VIEWPORT_BOUNDS_RANGE, gl_VIEWPORT_INDEX_PROVOKING_VERTEX,
        gl_VIEWPORT_SUBPIXEL_BITS, glDepthRangeArrayv, glDepthRangeIndexed,
        glGetDoublei_v, glGetFloati_v, glScissorArrayv, glScissorIndexed,
        glScissorIndexedv, glViewportArrayv, glViewportIndexedf,
        glViewportIndexedfv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_DEPTH_RANGE, gl_SCISSOR_BOX, gl_SCISSOR_TEST, gl_VIEWPORT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_FIRST_VERTEX_CONVENTION, gl_LAST_VERTEX_CONVENTION,
        gl_PROVOKING_VERTEX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glDepthRangeArrayv, glDepthRangeIndexed, glGetDoublei_v,
        glGetFloati_v, glScissorArrayv, glScissorIndexed,
        glScissorIndexedv, glViewportArrayv, glViewportIndexedf,
        glViewportIndexedfv, gl_LAYER_PROVOKING_VERTEX, gl_MAX_VIEWPORTS,
        gl_UNDEFINED_VERTEX, gl_VIEWPORT_BOUNDS_RANGE,
        gl_VIEWPORT_INDEX_PROVOKING_VERTEX, gl_VIEWPORT_SUBPIXEL_BITS)