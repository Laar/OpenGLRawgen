{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ComputeVariableGroupSize
       (gl_MAX_COMPUTE_FIXED_GROUP_INVOCATIONS_ARB,
        gl_MAX_COMPUTE_FIXED_GROUP_SIZE_ARB,
        gl_MAX_COMPUTE_VARIABLE_GROUP_INVOCATIONS_ARB,
        gl_MAX_COMPUTE_VARIABLE_GROUP_SIZE_ARB,
        glDispatchComputeGroupSizeARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_COMPUTE_FIXED_GROUP_INVOCATIONS_ARB :: GLenum
gl_MAX_COMPUTE_FIXED_GROUP_INVOCATIONS_ARB = 37099
 
gl_MAX_COMPUTE_FIXED_GROUP_SIZE_ARB :: GLenum
gl_MAX_COMPUTE_FIXED_GROUP_SIZE_ARB = 37311
 
gl_MAX_COMPUTE_VARIABLE_GROUP_INVOCATIONS_ARB :: GLenum
gl_MAX_COMPUTE_VARIABLE_GROUP_INVOCATIONS_ARB = 37700
 
gl_MAX_COMPUTE_VARIABLE_GROUP_SIZE_ARB :: GLenum
gl_MAX_COMPUTE_VARIABLE_GROUP_SIZE_ARB = 37701
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDispatchComputeGroupSizeARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glDispatchComputeGroupSizeARB ::
                              GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glDispatchComputeGroupSizeARB
  = dyn_glDispatchComputeGroupSizeARB
      ptr_glDispatchComputeGroupSizeARB
 
{-# NOINLINE ptr_glDispatchComputeGroupSizeARB #-}
 
ptr_glDispatchComputeGroupSizeARB :: FunPtr a
ptr_glDispatchComputeGroupSizeARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_compute_variable_group_size"
        "glDispatchComputeGroupSizeARB"