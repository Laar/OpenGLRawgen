{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Robustness
       (gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT_ARB,
        gl_GUILTY_CONTEXT_RESET_ARB, gl_INNOCENT_CONTEXT_RESET_ARB,
        gl_LOSE_CONTEXT_ON_RESET_ARB, gl_NO_ERROR,
        gl_NO_RESET_NOTIFICATION_ARB, gl_RESET_NOTIFICATION_STRATEGY_ARB,
        gl_UNKNOWN_CONTEXT_RESET_ARB, glGetGraphicsResetStatusARB,
        glGetnCompressedTexImageARB, glGetnTexImageARB, glGetnUniformdvARB,
        glGetnUniformfvARB, glGetnUniformivARB, glGetnUniformuivARB,
        glReadnPixelsARB)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_NO_ERROR)
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT_ARB :: GLbitfield
gl_CONTEXT_FLAG_ROBUST_ACCESS_BIT_ARB = 4
 
gl_GUILTY_CONTEXT_RESET_ARB :: GLenum
gl_GUILTY_CONTEXT_RESET_ARB = 33363
 
gl_INNOCENT_CONTEXT_RESET_ARB :: GLenum
gl_INNOCENT_CONTEXT_RESET_ARB = 33364
 
gl_LOSE_CONTEXT_ON_RESET_ARB :: GLenum
gl_LOSE_CONTEXT_ON_RESET_ARB = 33362
 
gl_NO_RESET_NOTIFICATION_ARB :: GLenum
gl_NO_RESET_NOTIFICATION_ARB = 33377
 
gl_RESET_NOTIFICATION_STRATEGY_ARB :: GLenum
gl_RESET_NOTIFICATION_STRATEGY_ARB = 33366
 
gl_UNKNOWN_CONTEXT_RESET_ARB :: GLenum
gl_UNKNOWN_CONTEXT_RESET_ARB = 33365
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetGraphicsResetStatusARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (IO GLenum)
 
glGetGraphicsResetStatusARB :: IO GLenum
glGetGraphicsResetStatusARB
  = dyn_glGetGraphicsResetStatusARB ptr_glGetGraphicsResetStatusARB
 
{-# NOINLINE ptr_glGetGraphicsResetStatusARB #-}
 
ptr_glGetGraphicsResetStatusARB :: FunPtr a
ptr_glGetGraphicsResetStatusARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetGraphicsResetStatusARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetnCompressedTexImageARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> Ptr e -> IO ())
 
glGetnCompressedTexImageARB ::
                            GLenum -> GLint -> GLsizei -> Ptr e -> IO ()
glGetnCompressedTexImageARB
  = dyn_glGetnCompressedTexImageARB ptr_glGetnCompressedTexImageARB
 
{-# NOINLINE ptr_glGetnCompressedTexImageARB #-}
 
ptr_glGetnCompressedTexImageARB :: FunPtr a
ptr_glGetnCompressedTexImageARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnCompressedTexImageARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnTexImageARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnTexImageARB ::
                  GLenum -> GLint -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnTexImageARB = dyn_glGetnTexImageARB ptr_glGetnTexImageARB
 
{-# NOINLINE ptr_glGetnTexImageARB #-}
 
ptr_glGetnTexImageARB :: FunPtr a
ptr_glGetnTexImageARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnTexImageARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformdvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glGetnUniformdvARB ::
                   GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glGetnUniformdvARB = dyn_glGetnUniformdvARB ptr_glGetnUniformdvARB
 
{-# NOINLINE ptr_glGetnUniformdvARB #-}
 
ptr_glGetnUniformdvARB :: FunPtr a
ptr_glGetnUniformdvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformdvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformfvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnUniformfvARB ::
                   GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glGetnUniformfvARB = dyn_glGetnUniformfvARB ptr_glGetnUniformfvARB
 
{-# NOINLINE ptr_glGetnUniformfvARB #-}
 
ptr_glGetnUniformfvARB :: FunPtr a
ptr_glGetnUniformfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glGetnUniformivARB ::
                   GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glGetnUniformivARB = dyn_glGetnUniformivARB ptr_glGetnUniformivARB
 
{-# NOINLINE ptr_glGetnUniformivARB #-}
 
ptr_glGetnUniformivARB :: FunPtr a
ptr_glGetnUniformivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnUniformuivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glGetnUniformuivARB ::
                    GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glGetnUniformuivARB
  = dyn_glGetnUniformuivARB ptr_glGetnUniformuivARB
 
{-# NOINLINE ptr_glGetnUniformuivARB #-}
 
ptr_glGetnUniformuivARB :: FunPtr a
ptr_glGetnUniformuivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glGetnUniformuivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glReadnPixelsARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    GLint ->
                      GLsizei ->
                        GLsizei -> GLenum -> GLenum -> GLsizei -> Ptr i -> IO ())
 
glReadnPixelsARB ::
                 GLint ->
                   GLint ->
                     GLsizei -> GLsizei -> GLenum -> GLenum -> GLsizei -> Ptr i -> IO ()
glReadnPixelsARB = dyn_glReadnPixelsARB ptr_glReadnPixelsARB
 
{-# NOINLINE ptr_glReadnPixelsARB #-}
 
ptr_glReadnPixelsARB :: FunPtr a
ptr_glReadnPixelsARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness"
        "glReadnPixelsARB"