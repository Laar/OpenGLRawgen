-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexType2101010Rev
       (gl_INT_2_10_10_10_REV, gl_UNSIGNED_INT_2_10_10_10_REV,
        glVertexAttribP1ui, glVertexAttribP1uiv, glVertexAttribP2ui,
        glVertexAttribP2uiv, glVertexAttribP3ui, glVertexAttribP3uiv,
        glVertexAttribP4ui, glVertexAttribP4uiv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core12
       (gl_UNSIGNED_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Core33
       (glVertexAttribP1ui, glVertexAttribP1uiv, glVertexAttribP2ui,
        glVertexAttribP2uiv, glVertexAttribP3ui, glVertexAttribP3uiv,
        glVertexAttribP4ui, glVertexAttribP4uiv, gl_INT_2_10_10_10_REV)