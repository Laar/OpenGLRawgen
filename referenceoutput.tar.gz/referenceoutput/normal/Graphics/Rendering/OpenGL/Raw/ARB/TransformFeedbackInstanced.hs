-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedbackInstanced
       (glDrawTransformFeedbackInstanced,
        glDrawTransformFeedbackStreamInstanced)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawTransformFeedbackInstanced)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawTransformFeedbackStreamInstanced)