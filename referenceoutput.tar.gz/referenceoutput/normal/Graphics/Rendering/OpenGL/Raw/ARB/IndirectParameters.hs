{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.IndirectParameters
       (gl_PARAMETER_BUFFER_ARB, gl_PARAMETER_BUFFER_BINDING_ARB,
        glMultiDrawArraysIndirectCountARB,
        glMultiDrawElementsIndirectCountARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PARAMETER_BUFFER_ARB :: GLenum
gl_PARAMETER_BUFFER_ARB = 33006
 
gl_PARAMETER_BUFFER_BINDING_ARB :: GLenum
gl_PARAMETER_BUFFER_BINDING_ARB = 33007
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawArraysIndirectCountARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLintptr -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawArraysIndirectCountARB ::
                                  GLenum -> GLintptr -> GLintptr -> GLsizei -> GLsizei -> IO ()
glMultiDrawArraysIndirectCountARB
  = dyn_glMultiDrawArraysIndirectCountARB
      ptr_glMultiDrawArraysIndirectCountARB
 
{-# NOINLINE ptr_glMultiDrawArraysIndirectCountARB #-}
 
ptr_glMultiDrawArraysIndirectCountARB :: FunPtr a
ptr_glMultiDrawArraysIndirectCountARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_indirect_parameters"
        "glMultiDrawArraysIndirectCountARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementsIndirectCountARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum -> GLintptr -> GLintptr -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawElementsIndirectCountARB ::
                                    GLenum ->
                                      GLenum -> GLintptr -> GLintptr -> GLsizei -> GLsizei -> IO ()
glMultiDrawElementsIndirectCountARB
  = dyn_glMultiDrawElementsIndirectCountARB
      ptr_glMultiDrawElementsIndirectCountARB
 
{-# NOINLINE ptr_glMultiDrawElementsIndirectCountARB #-}
 
ptr_glMultiDrawElementsIndirectCountARB :: FunPtr a
ptr_glMultiDrawElementsIndirectCountARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_indirect_parameters"
        "glMultiDrawElementsIndirectCountARB"