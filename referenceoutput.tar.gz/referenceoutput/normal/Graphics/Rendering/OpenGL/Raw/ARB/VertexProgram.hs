-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexProgram
       (gl_COLOR_SUM_ARB, gl_CURRENT_MATRIX_ARB,
        gl_CURRENT_MATRIX_STACK_DEPTH_ARB, gl_CURRENT_VERTEX_ATTRIB_ARB,
        gl_MATRIX0_ARB, gl_MATRIX10_ARB, gl_MATRIX11_ARB, gl_MATRIX12_ARB,
        gl_MATRIX13_ARB, gl_MATRIX14_ARB, gl_MATRIX15_ARB, gl_MATRIX16_ARB,
        gl_MATRIX17_ARB, gl_MATRIX18_ARB, gl_MATRIX19_ARB, gl_MATRIX1_ARB,
        gl_MATRIX20_ARB, gl_MATRIX21_ARB, gl_MATRIX22_ARB, gl_MATRIX23_ARB,
        gl_MATRIX24_ARB, gl_MATRIX25_ARB, gl_MATRIX26_ARB, gl_MATRIX27_ARB,
        gl_MATRIX28_ARB, gl_MATRIX29_ARB, gl_MATRIX2_ARB, gl_MATRIX30_ARB,
        gl_MATRIX31_ARB, gl_MATRIX3_ARB, gl_MATRIX4_ARB, gl_MATRIX5_ARB,
        gl_MATRIX6_ARB, gl_MATRIX7_ARB, gl_MATRIX8_ARB, gl_MATRIX9_ARB,
        gl_MAX_PROGRAM_ADDRESS_REGISTERS_ARB, gl_MAX_PROGRAM_ATTRIBS_ARB,
        gl_MAX_PROGRAM_ENV_PARAMETERS_ARB, gl_MAX_PROGRAM_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB, gl_MAX_PROGRAM_MATRICES_ARB,
        gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB,
        gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB,
        gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB,
        gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB,
        gl_MAX_PROGRAM_PARAMETERS_ARB, gl_MAX_PROGRAM_TEMPORARIES_ARB,
        gl_MAX_VERTEX_ATTRIBS_ARB, gl_PROGRAM_ADDRESS_REGISTERS_ARB,
        gl_PROGRAM_ATTRIBS_ARB, gl_PROGRAM_BINDING_ARB,
        gl_PROGRAM_ERROR_POSITION_ARB, gl_PROGRAM_ERROR_STRING_ARB,
        gl_PROGRAM_FORMAT_ARB, gl_PROGRAM_FORMAT_ASCII_ARB,
        gl_PROGRAM_INSTRUCTIONS_ARB, gl_PROGRAM_LENGTH_ARB,
        gl_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB,
        gl_PROGRAM_NATIVE_ATTRIBS_ARB, gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_PROGRAM_NATIVE_TEMPORARIES_ARB, gl_PROGRAM_PARAMETERS_ARB,
        gl_PROGRAM_STRING_ARB, gl_PROGRAM_TEMPORARIES_ARB,
        gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB,
        gl_TRANSPOSE_CURRENT_MATRIX_ARB,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB,
        gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB, gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB,
        gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB, gl_VERTEX_PROGRAM_ARB,
        gl_VERTEX_PROGRAM_POINT_SIZE_ARB, gl_VERTEX_PROGRAM_TWO_SIDE_ARB,
        glBindProgramARB, glDeleteProgramsARB,
        glDisableVertexAttribArrayARB, glEnableVertexAttribArrayARB,
        glGenProgramsARB, glGetProgramEnvParameterdvARB,
        glGetProgramEnvParameterfvARB, glGetProgramLocalParameterdvARB,
        glGetProgramLocalParameterfvARB, glGetProgramStringARB,
        glGetProgramivARB, glGetVertexAttribPointervARB,
        glGetVertexAttribdvARB, glGetVertexAttribfvARB,
        glGetVertexAttribivARB, glIsProgramARB, glProgramEnvParameter4dARB,
        glProgramEnvParameter4dvARB, glProgramEnvParameter4fARB,
        glProgramEnvParameter4fvARB, glProgramLocalParameter4dARB,
        glProgramLocalParameter4dvARB, glProgramLocalParameter4fARB,
        glProgramLocalParameter4fvARB, glProgramStringARB,
        glVertexAttrib1dARB, glVertexAttrib1dvARB, glVertexAttrib1fARB,
        glVertexAttrib1fvARB, glVertexAttrib1sARB, glVertexAttrib1svARB,
        glVertexAttrib2dARB, glVertexAttrib2dvARB, glVertexAttrib2fARB,
        glVertexAttrib2fvARB, glVertexAttrib2sARB, glVertexAttrib2svARB,
        glVertexAttrib3dARB, glVertexAttrib3dvARB, glVertexAttrib3fARB,
        glVertexAttrib3fvARB, glVertexAttrib3sARB, glVertexAttrib3svARB,
        glVertexAttrib4NbvARB, glVertexAttrib4NivARB,
        glVertexAttrib4NsvARB, glVertexAttrib4NubARB,
        glVertexAttrib4NubvARB, glVertexAttrib4NuivARB,
        glVertexAttrib4NusvARB, glVertexAttrib4bvARB, glVertexAttrib4dARB,
        glVertexAttrib4dvARB, glVertexAttrib4fARB, glVertexAttrib4fvARB,
        glVertexAttrib4ivARB, glVertexAttrib4sARB, glVertexAttrib4svARB,
        glVertexAttrib4ubvARB, glVertexAttrib4uivARB,
        glVertexAttrib4usvARB, glVertexAttribPointerARB)
       where
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_COLOR_SUM_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_MATRIX_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_MATRIX_STACK_DEPTH_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_CURRENT_VERTEX_ATTRIB_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX0_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX10_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX11_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX12_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX13_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX14_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX15_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX16_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX17_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX18_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX19_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX1_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX20_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX21_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX22_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX23_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX24_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX25_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX26_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX27_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX28_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX29_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX2_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX30_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX31_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX3_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX4_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX5_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX6_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX7_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX8_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MATRIX9_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ADDRESS_REGISTERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ATTRIBS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_ENV_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_INSTRUCTIONS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_MATRICES_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_PROGRAM_TEMPORARIES_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_MAX_VERTEX_ATTRIBS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ADDRESS_REGISTERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ATTRIBS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_BINDING_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ERROR_POSITION_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_ERROR_STRING_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_FORMAT_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_FORMAT_ASCII_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_INSTRUCTIONS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_LENGTH_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_ATTRIBS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_NATIVE_TEMPORARIES_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_PARAMETERS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_STRING_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_TEMPORARIES_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_TRANSPOSE_CURRENT_MATRIX_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM_POINT_SIZE_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (gl_VERTEX_PROGRAM_TWO_SIDE_ARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glBindProgramARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glDeleteProgramsARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glDisableVertexAttribArrayARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glEnableVertexAttribArrayARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGenProgramsARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramEnvParameterdvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramEnvParameterfvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramLocalParameterdvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramLocalParameterfvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramStringARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetProgramivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribPointervARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribdvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribfvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glGetVertexAttribivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glIsProgramARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramEnvParameter4fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramLocalParameter4fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glProgramStringARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1sARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib1svARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2sARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib2svARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3sARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib3svARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NbvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NsvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NubARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NubvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NuivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4NusvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4bvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4dARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4dvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4fARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4fvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4ivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4sARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4svARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4ubvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4uivARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttrib4usvARB)
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glVertexAttribPointerARB)