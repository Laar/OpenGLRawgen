{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexProgram
       (gl_COLOR_SUM_ARB, gl_CURRENT_MATRIX_ARB,
        gl_CURRENT_MATRIX_STACK_DEPTH_ARB, gl_CURRENT_VERTEX_ATTRIB_ARB,
        gl_MATRIX0_ARB, gl_MATRIX10_ARB, gl_MATRIX11_ARB, gl_MATRIX12_ARB,
        gl_MATRIX13_ARB, gl_MATRIX14_ARB, gl_MATRIX15_ARB, gl_MATRIX16_ARB,
        gl_MATRIX17_ARB, gl_MATRIX18_ARB, gl_MATRIX19_ARB, gl_MATRIX1_ARB,
        gl_MATRIX20_ARB, gl_MATRIX21_ARB, gl_MATRIX22_ARB, gl_MATRIX23_ARB,
        gl_MATRIX24_ARB, gl_MATRIX25_ARB, gl_MATRIX26_ARB, gl_MATRIX27_ARB,
        gl_MATRIX28_ARB, gl_MATRIX29_ARB, gl_MATRIX2_ARB, gl_MATRIX30_ARB,
        gl_MATRIX31_ARB, gl_MATRIX3_ARB, gl_MATRIX4_ARB, gl_MATRIX5_ARB,
        gl_MATRIX6_ARB, gl_MATRIX7_ARB, gl_MATRIX8_ARB, gl_MATRIX9_ARB,
        gl_MAX_PROGRAM_ADDRESS_REGISTERS_ARB, gl_MAX_PROGRAM_ATTRIBS_ARB,
        gl_MAX_PROGRAM_ENV_PARAMETERS_ARB, gl_MAX_PROGRAM_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB, gl_MAX_PROGRAM_MATRICES_ARB,
        gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB,
        gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB,
        gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB,
        gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB,
        gl_MAX_PROGRAM_PARAMETERS_ARB, gl_MAX_PROGRAM_TEMPORARIES_ARB,
        gl_MAX_VERTEX_ATTRIBS_ARB, gl_PROGRAM_ADDRESS_REGISTERS_ARB,
        gl_PROGRAM_ATTRIBS_ARB, gl_PROGRAM_BINDING_ARB,
        gl_PROGRAM_ERROR_POSITION_ARB, gl_PROGRAM_ERROR_STRING_ARB,
        gl_PROGRAM_FORMAT_ARB, gl_PROGRAM_FORMAT_ASCII_ARB,
        gl_PROGRAM_INSTRUCTIONS_ARB, gl_PROGRAM_LENGTH_ARB,
        gl_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB,
        gl_PROGRAM_NATIVE_ATTRIBS_ARB, gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_PROGRAM_NATIVE_TEMPORARIES_ARB, gl_PROGRAM_PARAMETERS_ARB,
        gl_PROGRAM_STRING_ARB, gl_PROGRAM_TEMPORARIES_ARB,
        gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB,
        gl_TRANSPOSE_CURRENT_MATRIX_ARB,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB,
        gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB,
        gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB, gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB,
        gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB, gl_VERTEX_PROGRAM_ARB,
        gl_VERTEX_PROGRAM_POINT_SIZE_ARB, gl_VERTEX_PROGRAM_TWO_SIDE_ARB,
        glBindProgramARB, glDeleteProgramsARB,
        glDisableVertexAttribArrayARB, glEnableVertexAttribArrayARB,
        glGenProgramsARB, glGetProgramEnvParameterdvARB,
        glGetProgramEnvParameterfvARB, glGetProgramLocalParameterdvARB,
        glGetProgramLocalParameterfvARB, glGetProgramStringARB,
        glGetProgramivARB, glGetVertexAttribPointervARB,
        glGetVertexAttribdvARB, glGetVertexAttribfvARB,
        glGetVertexAttribivARB, glIsProgramARB, glProgramEnvParameter4dARB,
        glProgramEnvParameter4dvARB, glProgramEnvParameter4fARB,
        glProgramEnvParameter4fvARB, glProgramLocalParameter4dARB,
        glProgramLocalParameter4dvARB, glProgramLocalParameter4fARB,
        glProgramLocalParameter4fvARB, glProgramStringARB,
        glVertexAttrib1dARB, glVertexAttrib1dvARB, glVertexAttrib1fARB,
        glVertexAttrib1fvARB, glVertexAttrib1sARB, glVertexAttrib1svARB,
        glVertexAttrib2dARB, glVertexAttrib2dvARB, glVertexAttrib2fARB,
        glVertexAttrib2fvARB, glVertexAttrib2sARB, glVertexAttrib2svARB,
        glVertexAttrib3dARB, glVertexAttrib3dvARB, glVertexAttrib3fARB,
        glVertexAttrib3fvARB, glVertexAttrib3sARB, glVertexAttrib3svARB,
        glVertexAttrib4NbvARB, glVertexAttrib4NivARB,
        glVertexAttrib4NsvARB, glVertexAttrib4NubARB,
        glVertexAttrib4NubvARB, glVertexAttrib4NuivARB,
        glVertexAttrib4NusvARB, glVertexAttrib4bvARB, glVertexAttrib4dARB,
        glVertexAttrib4dvARB, glVertexAttrib4fARB, glVertexAttrib4fvARB,
        glVertexAttrib4ivARB, glVertexAttrib4sARB, glVertexAttrib4svARB,
        glVertexAttrib4ubvARB, glVertexAttrib4uivARB,
        glVertexAttrib4usvARB, glVertexAttribPointerARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.ARB.FragmentProgram
       (glBindProgramARB, glDeleteProgramsARB, glGenProgramsARB,
        glGetProgramEnvParameterdvARB, glGetProgramEnvParameterfvARB,
        glGetProgramLocalParameterdvARB, glGetProgramLocalParameterfvARB,
        glGetProgramStringARB, glGetProgramivARB, glIsProgramARB,
        glProgramEnvParameter4dARB, glProgramEnvParameter4dvARB,
        glProgramEnvParameter4fARB, glProgramEnvParameter4fvARB,
        glProgramLocalParameter4dARB, glProgramLocalParameter4dvARB,
        glProgramLocalParameter4fARB, glProgramLocalParameter4fvARB,
        glProgramStringARB, gl_CURRENT_MATRIX_ARB,
        gl_CURRENT_MATRIX_STACK_DEPTH_ARB, gl_MATRIX0_ARB, gl_MATRIX10_ARB,
        gl_MATRIX11_ARB, gl_MATRIX12_ARB, gl_MATRIX13_ARB, gl_MATRIX14_ARB,
        gl_MATRIX15_ARB, gl_MATRIX16_ARB, gl_MATRIX17_ARB, gl_MATRIX18_ARB,
        gl_MATRIX19_ARB, gl_MATRIX1_ARB, gl_MATRIX20_ARB, gl_MATRIX21_ARB,
        gl_MATRIX22_ARB, gl_MATRIX23_ARB, gl_MATRIX24_ARB, gl_MATRIX25_ARB,
        gl_MATRIX26_ARB, gl_MATRIX27_ARB, gl_MATRIX28_ARB, gl_MATRIX29_ARB,
        gl_MATRIX2_ARB, gl_MATRIX30_ARB, gl_MATRIX31_ARB, gl_MATRIX3_ARB,
        gl_MATRIX4_ARB, gl_MATRIX5_ARB, gl_MATRIX6_ARB, gl_MATRIX7_ARB,
        gl_MATRIX8_ARB, gl_MATRIX9_ARB, gl_MAX_PROGRAM_ATTRIBS_ARB,
        gl_MAX_PROGRAM_ENV_PARAMETERS_ARB, gl_MAX_PROGRAM_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_LOCAL_PARAMETERS_ARB, gl_MAX_PROGRAM_MATRICES_ARB,
        gl_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB,
        gl_MAX_PROGRAM_NATIVE_ATTRIBS_ARB,
        gl_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_MAX_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB,
        gl_MAX_PROGRAM_PARAMETERS_ARB, gl_MAX_PROGRAM_TEMPORARIES_ARB,
        gl_PROGRAM_ATTRIBS_ARB, gl_PROGRAM_BINDING_ARB,
        gl_PROGRAM_ERROR_POSITION_ARB, gl_PROGRAM_ERROR_STRING_ARB,
        gl_PROGRAM_FORMAT_ARB, gl_PROGRAM_FORMAT_ASCII_ARB,
        gl_PROGRAM_INSTRUCTIONS_ARB, gl_PROGRAM_LENGTH_ARB,
        gl_PROGRAM_NATIVE_ATTRIBS_ARB, gl_PROGRAM_NATIVE_INSTRUCTIONS_ARB,
        gl_PROGRAM_NATIVE_PARAMETERS_ARB,
        gl_PROGRAM_NATIVE_TEMPORARIES_ARB, gl_PROGRAM_PARAMETERS_ARB,
        gl_PROGRAM_STRING_ARB, gl_PROGRAM_TEMPORARIES_ARB,
        gl_PROGRAM_UNDER_NATIVE_LIMITS_ARB,
        gl_TRANSPOSE_CURRENT_MATRIX_ARB)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_SUM_ARB :: GLenum
gl_COLOR_SUM_ARB = 33880
 
gl_CURRENT_VERTEX_ATTRIB_ARB :: GLenum
gl_CURRENT_VERTEX_ATTRIB_ARB = 34342
 
gl_MAX_PROGRAM_ADDRESS_REGISTERS_ARB :: GLenum
gl_MAX_PROGRAM_ADDRESS_REGISTERS_ARB = 34993
 
gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB :: GLenum
gl_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34995
 
gl_MAX_VERTEX_ATTRIBS_ARB :: GLenum
gl_MAX_VERTEX_ATTRIBS_ARB = 34921
 
gl_PROGRAM_ADDRESS_REGISTERS_ARB :: GLenum
gl_PROGRAM_ADDRESS_REGISTERS_ARB = 34992
 
gl_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB :: GLenum
gl_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34994
 
gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_ENABLED_ARB = 34338
 
gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB = 34922
 
gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_POINTER_ARB = 34373
 
gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_SIZE_ARB = 34339
 
gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_STRIDE_ARB = 34340
 
gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_TYPE_ARB = 34341
 
gl_VERTEX_PROGRAM_ARB :: GLenum
gl_VERTEX_PROGRAM_ARB = 34336
 
gl_VERTEX_PROGRAM_POINT_SIZE_ARB :: GLenum
gl_VERTEX_PROGRAM_POINT_SIZE_ARB = 34370
 
gl_VERTEX_PROGRAM_TWO_SIDE_ARB :: GLenum
gl_VERTEX_PROGRAM_TWO_SIDE_ARB = 34371
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDisableVertexAttribArrayARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glDisableVertexAttribArrayARB :: GLuint -> IO ()
glDisableVertexAttribArrayARB
  = dyn_glDisableVertexAttribArrayARB
      ptr_glDisableVertexAttribArrayARB
 
{-# NOINLINE ptr_glDisableVertexAttribArrayARB #-}
 
ptr_glDisableVertexAttribArrayARB :: FunPtr a
ptr_glDisableVertexAttribArrayARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glDisableVertexAttribArrayARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glEnableVertexAttribArrayARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glEnableVertexAttribArrayARB :: GLuint -> IO ()
glEnableVertexAttribArrayARB
  = dyn_glEnableVertexAttribArrayARB ptr_glEnableVertexAttribArrayARB
 
{-# NOINLINE ptr_glEnableVertexAttribArrayARB #-}
 
ptr_glEnableVertexAttribArrayARB :: FunPtr a
ptr_glEnableVertexAttribArrayARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glEnableVertexAttribArrayARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexAttribPointervARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glGetVertexAttribPointervARB ::
                             GLuint -> GLenum -> Ptr (Ptr d) -> IO ()
glGetVertexAttribPointervARB
  = dyn_glGetVertexAttribPointervARB ptr_glGetVertexAttribPointervARB
 
{-# NOINLINE ptr_glGetVertexAttribPointervARB #-}
 
ptr_glGetVertexAttribPointervARB :: FunPtr a
ptr_glGetVertexAttribPointervARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glGetVertexAttribPointervARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribdvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLdouble -> IO ())
 
glGetVertexAttribdvARB :: GLuint -> GLenum -> Ptr GLdouble -> IO ()
glGetVertexAttribdvARB
  = dyn_glGetVertexAttribdvARB ptr_glGetVertexAttribdvARB
 
{-# NOINLINE ptr_glGetVertexAttribdvARB #-}
 
ptr_glGetVertexAttribdvARB :: FunPtr a
ptr_glGetVertexAttribdvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glGetVertexAttribdvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribfvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetVertexAttribfvARB :: GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetVertexAttribfvARB
  = dyn_glGetVertexAttribfvARB ptr_glGetVertexAttribfvARB
 
{-# NOINLINE ptr_glGetVertexAttribfvARB #-}
 
ptr_glGetVertexAttribfvARB :: FunPtr a
ptr_glGetVertexAttribfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glGetVertexAttribfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribivARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexAttribivARB :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexAttribivARB
  = dyn_glGetVertexAttribivARB ptr_glGetVertexAttribivARB
 
{-# NOINLINE ptr_glGetVertexAttribivARB #-}
 
ptr_glGetVertexAttribivARB :: FunPtr a
ptr_glGetVertexAttribivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glGetVertexAttribivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> IO ())
 
glVertexAttrib1dARB :: GLuint -> GLdouble -> IO ()
glVertexAttrib1dARB
  = dyn_glVertexAttrib1dARB ptr_glVertexAttrib1dARB
 
{-# NOINLINE ptr_glVertexAttrib1dARB #-}
 
ptr_glVertexAttrib1dARB :: FunPtr a
ptr_glVertexAttrib1dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1dARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttrib1dvARB :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttrib1dvARB
  = dyn_glVertexAttrib1dvARB ptr_glVertexAttrib1dvARB
 
{-# NOINLINE ptr_glVertexAttrib1dvARB #-}
 
ptr_glVertexAttrib1dvARB :: FunPtr a
ptr_glVertexAttrib1dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1dvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> IO ())
 
glVertexAttrib1fARB :: GLuint -> GLfloat -> IO ()
glVertexAttrib1fARB
  = dyn_glVertexAttrib1fARB ptr_glVertexAttrib1fARB
 
{-# NOINLINE ptr_glVertexAttrib1fARB #-}
 
ptr_glVertexAttrib1fARB :: FunPtr a
ptr_glVertexAttrib1fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
glVertexAttrib1fvARB :: GLuint -> Ptr GLfloat -> IO ()
glVertexAttrib1fvARB
  = dyn_glVertexAttrib1fvARB ptr_glVertexAttrib1fvARB
 
{-# NOINLINE ptr_glVertexAttrib1fvARB #-}
 
ptr_glVertexAttrib1fvARB :: FunPtr a
ptr_glVertexAttrib1fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1sARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLshort -> IO ())
 
glVertexAttrib1sARB :: GLuint -> GLshort -> IO ()
glVertexAttrib1sARB
  = dyn_glVertexAttrib1sARB ptr_glVertexAttrib1sARB
 
{-# NOINLINE ptr_glVertexAttrib1sARB #-}
 
ptr_glVertexAttrib1sARB :: FunPtr a
ptr_glVertexAttrib1sARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1sARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1svARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttrib1svARB :: GLuint -> Ptr GLshort -> IO ()
glVertexAttrib1svARB
  = dyn_glVertexAttrib1svARB ptr_glVertexAttrib1svARB
 
{-# NOINLINE ptr_glVertexAttrib1svARB #-}
 
ptr_glVertexAttrib1svARB :: FunPtr a
ptr_glVertexAttrib1svARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib1svARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> IO ())
 
glVertexAttrib2dARB :: GLuint -> GLdouble -> GLdouble -> IO ()
glVertexAttrib2dARB
  = dyn_glVertexAttrib2dARB ptr_glVertexAttrib2dARB
 
{-# NOINLINE ptr_glVertexAttrib2dARB #-}
 
ptr_glVertexAttrib2dARB :: FunPtr a
ptr_glVertexAttrib2dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2dARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttrib2dvARB :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttrib2dvARB
  = dyn_glVertexAttrib2dvARB ptr_glVertexAttrib2dvARB
 
{-# NOINLINE ptr_glVertexAttrib2dvARB #-}
 
ptr_glVertexAttrib2dvARB :: FunPtr a
ptr_glVertexAttrib2dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2dvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> IO ())
 
glVertexAttrib2fARB :: GLuint -> GLfloat -> GLfloat -> IO ()
glVertexAttrib2fARB
  = dyn_glVertexAttrib2fARB ptr_glVertexAttrib2fARB
 
{-# NOINLINE ptr_glVertexAttrib2fARB #-}
 
ptr_glVertexAttrib2fARB :: FunPtr a
ptr_glVertexAttrib2fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
glVertexAttrib2fvARB :: GLuint -> Ptr GLfloat -> IO ()
glVertexAttrib2fvARB
  = dyn_glVertexAttrib2fvARB ptr_glVertexAttrib2fvARB
 
{-# NOINLINE ptr_glVertexAttrib2fvARB #-}
 
ptr_glVertexAttrib2fvARB :: FunPtr a
ptr_glVertexAttrib2fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2sARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLshort -> GLshort -> IO ())
 
glVertexAttrib2sARB :: GLuint -> GLshort -> GLshort -> IO ()
glVertexAttrib2sARB
  = dyn_glVertexAttrib2sARB ptr_glVertexAttrib2sARB
 
{-# NOINLINE ptr_glVertexAttrib2sARB #-}
 
ptr_glVertexAttrib2sARB :: FunPtr a
ptr_glVertexAttrib2sARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2sARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2svARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttrib2svARB :: GLuint -> Ptr GLshort -> IO ()
glVertexAttrib2svARB
  = dyn_glVertexAttrib2svARB ptr_glVertexAttrib2svARB
 
{-# NOINLINE ptr_glVertexAttrib2svARB #-}
 
ptr_glVertexAttrib2svARB :: FunPtr a
ptr_glVertexAttrib2svARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib2svARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glVertexAttrib3dARB ::
                    GLuint -> GLdouble -> GLdouble -> GLdouble -> IO ()
glVertexAttrib3dARB
  = dyn_glVertexAttrib3dARB ptr_glVertexAttrib3dARB
 
{-# NOINLINE ptr_glVertexAttrib3dARB #-}
 
ptr_glVertexAttrib3dARB :: FunPtr a
ptr_glVertexAttrib3dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3dARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttrib3dvARB :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttrib3dvARB
  = dyn_glVertexAttrib3dvARB ptr_glVertexAttrib3dvARB
 
{-# NOINLINE ptr_glVertexAttrib3dvARB #-}
 
ptr_glVertexAttrib3dvARB :: FunPtr a
ptr_glVertexAttrib3dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3dvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glVertexAttrib3fARB ::
                    GLuint -> GLfloat -> GLfloat -> GLfloat -> IO ()
glVertexAttrib3fARB
  = dyn_glVertexAttrib3fARB ptr_glVertexAttrib3fARB
 
{-# NOINLINE ptr_glVertexAttrib3fARB #-}
 
ptr_glVertexAttrib3fARB :: FunPtr a
ptr_glVertexAttrib3fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
glVertexAttrib3fvARB :: GLuint -> Ptr GLfloat -> IO ()
glVertexAttrib3fvARB
  = dyn_glVertexAttrib3fvARB ptr_glVertexAttrib3fvARB
 
{-# NOINLINE ptr_glVertexAttrib3fvARB #-}
 
ptr_glVertexAttrib3fvARB :: FunPtr a
ptr_glVertexAttrib3fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3sARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLshort -> GLshort -> GLshort -> IO ())
 
glVertexAttrib3sARB ::
                    GLuint -> GLshort -> GLshort -> GLshort -> IO ()
glVertexAttrib3sARB
  = dyn_glVertexAttrib3sARB ptr_glVertexAttrib3sARB
 
{-# NOINLINE ptr_glVertexAttrib3sARB #-}
 
ptr_glVertexAttrib3sARB :: FunPtr a
ptr_glVertexAttrib3sARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3sARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3svARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttrib3svARB :: GLuint -> Ptr GLshort -> IO ()
glVertexAttrib3svARB
  = dyn_glVertexAttrib3svARB ptr_glVertexAttrib3svARB
 
{-# NOINLINE ptr_glVertexAttrib3svARB #-}
 
ptr_glVertexAttrib3svARB :: FunPtr a
ptr_glVertexAttrib3svARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib3svARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NbvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLbyte -> IO ())
 
glVertexAttrib4NbvARB :: GLuint -> Ptr GLbyte -> IO ()
glVertexAttrib4NbvARB
  = dyn_glVertexAttrib4NbvARB ptr_glVertexAttrib4NbvARB
 
{-# NOINLINE ptr_glVertexAttrib4NbvARB #-}
 
ptr_glVertexAttrib4NbvARB :: FunPtr a
ptr_glVertexAttrib4NbvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NbvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NivARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttrib4NivARB :: GLuint -> Ptr GLint -> IO ()
glVertexAttrib4NivARB
  = dyn_glVertexAttrib4NivARB ptr_glVertexAttrib4NivARB
 
{-# NOINLINE ptr_glVertexAttrib4NivARB #-}
 
ptr_glVertexAttrib4NivARB :: FunPtr a
ptr_glVertexAttrib4NivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NsvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttrib4NsvARB :: GLuint -> Ptr GLshort -> IO ()
glVertexAttrib4NsvARB
  = dyn_glVertexAttrib4NsvARB ptr_glVertexAttrib4NsvARB
 
{-# NOINLINE ptr_glVertexAttrib4NsvARB #-}
 
ptr_glVertexAttrib4NsvARB :: FunPtr a
ptr_glVertexAttrib4NsvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NsvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NubARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLubyte -> GLubyte -> GLubyte -> GLubyte -> IO ())
 
glVertexAttrib4NubARB ::
                      GLuint -> GLubyte -> GLubyte -> GLubyte -> GLubyte -> IO ()
glVertexAttrib4NubARB
  = dyn_glVertexAttrib4NubARB ptr_glVertexAttrib4NubARB
 
{-# NOINLINE ptr_glVertexAttrib4NubARB #-}
 
ptr_glVertexAttrib4NubARB :: FunPtr a
ptr_glVertexAttrib4NubARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NubARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NubvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLubyte -> IO ())
 
glVertexAttrib4NubvARB :: GLuint -> Ptr GLubyte -> IO ()
glVertexAttrib4NubvARB
  = dyn_glVertexAttrib4NubvARB ptr_glVertexAttrib4NubvARB
 
{-# NOINLINE ptr_glVertexAttrib4NubvARB #-}
 
ptr_glVertexAttrib4NubvARB :: FunPtr a
ptr_glVertexAttrib4NubvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NubvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NuivARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttrib4NuivARB :: GLuint -> Ptr GLuint -> IO ()
glVertexAttrib4NuivARB
  = dyn_glVertexAttrib4NuivARB ptr_glVertexAttrib4NuivARB
 
{-# NOINLINE ptr_glVertexAttrib4NuivARB #-}
 
ptr_glVertexAttrib4NuivARB :: FunPtr a
ptr_glVertexAttrib4NuivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NuivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4NusvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLushort -> IO ())
 
glVertexAttrib4NusvARB :: GLuint -> Ptr GLushort -> IO ()
glVertexAttrib4NusvARB
  = dyn_glVertexAttrib4NusvARB ptr_glVertexAttrib4NusvARB
 
{-# NOINLINE ptr_glVertexAttrib4NusvARB #-}
 
ptr_glVertexAttrib4NusvARB :: FunPtr a
ptr_glVertexAttrib4NusvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4NusvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4bvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLbyte -> IO ())
 
glVertexAttrib4bvARB :: GLuint -> Ptr GLbyte -> IO ()
glVertexAttrib4bvARB
  = dyn_glVertexAttrib4bvARB ptr_glVertexAttrib4bvARB
 
{-# NOINLINE ptr_glVertexAttrib4bvARB #-}
 
ptr_glVertexAttrib4bvARB :: FunPtr a
ptr_glVertexAttrib4bvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4bvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4dARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glVertexAttrib4dARB ::
                    GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glVertexAttrib4dARB
  = dyn_glVertexAttrib4dARB ptr_glVertexAttrib4dARB
 
{-# NOINLINE ptr_glVertexAttrib4dARB #-}
 
ptr_glVertexAttrib4dARB :: FunPtr a
ptr_glVertexAttrib4dARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4dARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4dvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttrib4dvARB :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttrib4dvARB
  = dyn_glVertexAttrib4dvARB ptr_glVertexAttrib4dvARB
 
{-# NOINLINE ptr_glVertexAttrib4dvARB #-}
 
ptr_glVertexAttrib4dvARB :: FunPtr a
ptr_glVertexAttrib4dvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4dvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4fARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glVertexAttrib4fARB ::
                    GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glVertexAttrib4fARB
  = dyn_glVertexAttrib4fARB ptr_glVertexAttrib4fARB
 
{-# NOINLINE ptr_glVertexAttrib4fARB #-}
 
ptr_glVertexAttrib4fARB :: FunPtr a
ptr_glVertexAttrib4fARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4fARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4fvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
glVertexAttrib4fvARB :: GLuint -> Ptr GLfloat -> IO ()
glVertexAttrib4fvARB
  = dyn_glVertexAttrib4fvARB ptr_glVertexAttrib4fvARB
 
{-# NOINLINE ptr_glVertexAttrib4fvARB #-}
 
ptr_glVertexAttrib4fvARB :: FunPtr a
ptr_glVertexAttrib4fvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4fvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4ivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttrib4ivARB :: GLuint -> Ptr GLint -> IO ()
glVertexAttrib4ivARB
  = dyn_glVertexAttrib4ivARB ptr_glVertexAttrib4ivARB
 
{-# NOINLINE ptr_glVertexAttrib4ivARB #-}
 
ptr_glVertexAttrib4ivARB :: FunPtr a
ptr_glVertexAttrib4ivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4ivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4sARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLshort -> GLshort -> GLshort -> GLshort -> IO ())
 
glVertexAttrib4sARB ::
                    GLuint -> GLshort -> GLshort -> GLshort -> GLshort -> IO ()
glVertexAttrib4sARB
  = dyn_glVertexAttrib4sARB ptr_glVertexAttrib4sARB
 
{-# NOINLINE ptr_glVertexAttrib4sARB #-}
 
ptr_glVertexAttrib4sARB :: FunPtr a
ptr_glVertexAttrib4sARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4sARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4svARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttrib4svARB :: GLuint -> Ptr GLshort -> IO ()
glVertexAttrib4svARB
  = dyn_glVertexAttrib4svARB ptr_glVertexAttrib4svARB
 
{-# NOINLINE ptr_glVertexAttrib4svARB #-}
 
ptr_glVertexAttrib4svARB :: FunPtr a
ptr_glVertexAttrib4svARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4svARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4ubvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLubyte -> IO ())
 
glVertexAttrib4ubvARB :: GLuint -> Ptr GLubyte -> IO ()
glVertexAttrib4ubvARB
  = dyn_glVertexAttrib4ubvARB ptr_glVertexAttrib4ubvARB
 
{-# NOINLINE ptr_glVertexAttrib4ubvARB #-}
 
ptr_glVertexAttrib4ubvARB :: FunPtr a
ptr_glVertexAttrib4ubvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4ubvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4uivARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttrib4uivARB :: GLuint -> Ptr GLuint -> IO ()
glVertexAttrib4uivARB
  = dyn_glVertexAttrib4uivARB ptr_glVertexAttrib4uivARB
 
{-# NOINLINE ptr_glVertexAttrib4uivARB #-}
 
ptr_glVertexAttrib4uivARB :: FunPtr a
ptr_glVertexAttrib4uivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4uivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4usvARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLushort -> IO ())
 
glVertexAttrib4usvARB :: GLuint -> Ptr GLushort -> IO ()
glVertexAttrib4usvARB
  = dyn_glVertexAttrib4usvARB ptr_glVertexAttrib4usvARB
 
{-# NOINLINE ptr_glVertexAttrib4usvARB #-}
 
ptr_glVertexAttrib4usvARB :: FunPtr a
ptr_glVertexAttrib4usvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttrib4usvARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexAttribPointerARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLenum -> GLboolean -> GLsizei -> Ptr g -> IO ())
 
glVertexAttribPointerARB ::
                         GLuint -> GLint -> GLenum -> GLboolean -> GLsizei -> Ptr g -> IO ()
glVertexAttribPointerARB
  = dyn_glVertexAttribPointerARB ptr_glVertexAttribPointerARB
 
{-# NOINLINE ptr_glVertexAttribPointerARB #-}
 
ptr_glVertexAttribPointerARB :: FunPtr a
ptr_glVertexAttribPointerARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_program"
        "glVertexAttribPointerARB"