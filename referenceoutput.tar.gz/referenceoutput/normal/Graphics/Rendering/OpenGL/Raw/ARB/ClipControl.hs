-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ClipControl
       (gl_CLIP_DEPTH_MODE, gl_CLIP_ORIGIN, gl_LOWER_LEFT,
        gl_NEGATIVE_ONE_TO_ONE, gl_UPPER_LEFT, gl_ZERO_TO_ONE,
        glClipControl)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core20
       (gl_LOWER_LEFT, gl_UPPER_LEFT)
import Graphics.Rendering.OpenGL.Raw.Core.Core45
       (glClipControl, gl_CLIP_DEPTH_MODE, gl_CLIP_ORIGIN,
        gl_NEGATIVE_ONE_TO_ONE, gl_ZERO_TO_ONE)