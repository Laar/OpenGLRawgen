{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.BindlessTexture
       (gl_UNSIGNED_INT64_ARB, glGetImageHandleARB, glGetTextureHandleARB,
        glGetTextureSamplerHandleARB, glGetVertexAttribLui64vARB,
        glIsImageHandleResidentARB, glIsTextureHandleResidentARB,
        glMakeImageHandleNonResidentARB, glMakeImageHandleResidentARB,
        glMakeTextureHandleNonResidentARB, glMakeTextureHandleResidentARB,
        glProgramUniformHandleui64ARB, glProgramUniformHandleui64vARB,
        glUniformHandleui64ARB, glUniformHandleui64vARB,
        glVertexAttribL1ui64ARB, glVertexAttribL1ui64vARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_UNSIGNED_INT64_ARB :: GLenum
gl_UNSIGNED_INT64_ARB = 5135
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetImageHandleARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLboolean -> GLint -> GLenum -> IO GLuint64)
 
glGetImageHandleARB ::
                    GLuint -> GLint -> GLboolean -> GLint -> GLenum -> IO GLuint64
glGetImageHandleARB
  = dyn_glGetImageHandleARB ptr_glGetImageHandleARB
 
{-# NOINLINE ptr_glGetImageHandleARB #-}
 
ptr_glGetImageHandleARB :: FunPtr a
ptr_glGetImageHandleARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glGetImageHandleARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTextureHandleARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLuint64)
 
glGetTextureHandleARB :: GLuint -> IO GLuint64
glGetTextureHandleARB
  = dyn_glGetTextureHandleARB ptr_glGetTextureHandleARB
 
{-# NOINLINE ptr_glGetTextureHandleARB #-}
 
ptr_glGetTextureHandleARB :: FunPtr a
ptr_glGetTextureHandleARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glGetTextureHandleARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureSamplerHandleARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO GLuint64)
 
glGetTextureSamplerHandleARB :: GLuint -> GLuint -> IO GLuint64
glGetTextureSamplerHandleARB
  = dyn_glGetTextureSamplerHandleARB ptr_glGetTextureSamplerHandleARB
 
{-# NOINLINE ptr_glGetTextureSamplerHandleARB #-}
 
ptr_glGetTextureSamplerHandleARB :: FunPtr a
ptr_glGetTextureSamplerHandleARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glGetTextureSamplerHandleARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexAttribLui64vARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint64 -> IO ())
 
glGetVertexAttribLui64vARB ::
                           GLuint -> GLenum -> Ptr GLuint64 -> IO ()
glGetVertexAttribLui64vARB
  = dyn_glGetVertexAttribLui64vARB ptr_glGetVertexAttribLui64vARB
 
{-# NOINLINE ptr_glGetVertexAttribLui64vARB #-}
 
ptr_glGetVertexAttribLui64vARB :: FunPtr a
ptr_glGetVertexAttribLui64vARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glGetVertexAttribLui64vARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glIsImageHandleResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO GLboolean)
 
glIsImageHandleResidentARB :: GLuint64 -> IO GLboolean
glIsImageHandleResidentARB
  = dyn_glIsImageHandleResidentARB ptr_glIsImageHandleResidentARB
 
{-# NOINLINE ptr_glIsImageHandleResidentARB #-}
 
ptr_glIsImageHandleResidentARB :: FunPtr a
ptr_glIsImageHandleResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glIsImageHandleResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glIsTextureHandleResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO GLboolean)
 
glIsTextureHandleResidentARB :: GLuint64 -> IO GLboolean
glIsTextureHandleResidentARB
  = dyn_glIsTextureHandleResidentARB ptr_glIsTextureHandleResidentARB
 
{-# NOINLINE ptr_glIsTextureHandleResidentARB #-}
 
ptr_glIsTextureHandleResidentARB :: FunPtr a
ptr_glIsTextureHandleResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glIsTextureHandleResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeImageHandleNonResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeImageHandleNonResidentARB :: GLuint64 -> IO ()
glMakeImageHandleNonResidentARB
  = dyn_glMakeImageHandleNonResidentARB
      ptr_glMakeImageHandleNonResidentARB
 
{-# NOINLINE ptr_glMakeImageHandleNonResidentARB #-}
 
ptr_glMakeImageHandleNonResidentARB :: FunPtr a
ptr_glMakeImageHandleNonResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glMakeImageHandleNonResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeImageHandleResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> GLenum -> IO ())
 
glMakeImageHandleResidentARB :: GLuint64 -> GLenum -> IO ()
glMakeImageHandleResidentARB
  = dyn_glMakeImageHandleResidentARB ptr_glMakeImageHandleResidentARB
 
{-# NOINLINE ptr_glMakeImageHandleResidentARB #-}
 
ptr_glMakeImageHandleResidentARB :: FunPtr a
ptr_glMakeImageHandleResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glMakeImageHandleResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeTextureHandleNonResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeTextureHandleNonResidentARB :: GLuint64 -> IO ()
glMakeTextureHandleNonResidentARB
  = dyn_glMakeTextureHandleNonResidentARB
      ptr_glMakeTextureHandleNonResidentARB
 
{-# NOINLINE ptr_glMakeTextureHandleNonResidentARB #-}
 
ptr_glMakeTextureHandleNonResidentARB :: FunPtr a
ptr_glMakeTextureHandleNonResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glMakeTextureHandleNonResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMakeTextureHandleResidentARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint64 -> IO ())
 
glMakeTextureHandleResidentARB :: GLuint64 -> IO ()
glMakeTextureHandleResidentARB
  = dyn_glMakeTextureHandleResidentARB
      ptr_glMakeTextureHandleResidentARB
 
{-# NOINLINE ptr_glMakeTextureHandleResidentARB #-}
 
ptr_glMakeTextureHandleResidentARB :: FunPtr a
ptr_glMakeTextureHandleResidentARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glMakeTextureHandleResidentARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformHandleui64ARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint64 -> IO ())
 
glProgramUniformHandleui64ARB ::
                              GLuint -> GLint -> GLuint64 -> IO ()
glProgramUniformHandleui64ARB
  = dyn_glProgramUniformHandleui64ARB
      ptr_glProgramUniformHandleui64ARB
 
{-# NOINLINE ptr_glProgramUniformHandleui64ARB #-}
 
ptr_glProgramUniformHandleui64ARB :: FunPtr a
ptr_glProgramUniformHandleui64ARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glProgramUniformHandleui64ARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformHandleui64vARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glProgramUniformHandleui64vARB ::
                               GLuint -> GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glProgramUniformHandleui64vARB
  = dyn_glProgramUniformHandleui64vARB
      ptr_glProgramUniformHandleui64vARB
 
{-# NOINLINE ptr_glProgramUniformHandleui64vARB #-}
 
ptr_glProgramUniformHandleui64vARB :: FunPtr a
ptr_glProgramUniformHandleui64vARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glProgramUniformHandleui64vARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformHandleui64ARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint64 -> IO ())
 
glUniformHandleui64ARB :: GLint -> GLuint64 -> IO ()
glUniformHandleui64ARB
  = dyn_glUniformHandleui64ARB ptr_glUniformHandleui64ARB
 
{-# NOINLINE ptr_glUniformHandleui64ARB #-}
 
ptr_glUniformHandleui64ARB :: FunPtr a
ptr_glUniformHandleui64ARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glUniformHandleui64ARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformHandleui64vARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint64 -> IO ())
 
glUniformHandleui64vARB ::
                        GLint -> GLsizei -> Ptr GLuint64 -> IO ()
glUniformHandleui64vARB
  = dyn_glUniformHandleui64vARB ptr_glUniformHandleui64vARB
 
{-# NOINLINE ptr_glUniformHandleui64vARB #-}
 
ptr_glUniformHandleui64vARB :: FunPtr a
ptr_glUniformHandleui64vARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glUniformHandleui64vARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL1ui64ARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint64 -> IO ())
 
glVertexAttribL1ui64ARB :: GLuint -> GLuint64 -> IO ()
glVertexAttribL1ui64ARB
  = dyn_glVertexAttribL1ui64ARB ptr_glVertexAttribL1ui64ARB
 
{-# NOINLINE ptr_glVertexAttribL1ui64ARB #-}
 
ptr_glVertexAttribL1ui64ARB :: FunPtr a
ptr_glVertexAttribL1ui64ARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glVertexAttribL1ui64ARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexAttribL1ui64vARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint64 -> IO ())
 
glVertexAttribL1ui64vARB :: GLuint -> Ptr GLuint64 -> IO ()
glVertexAttribL1ui64vARB
  = dyn_glVertexAttribL1ui64vARB ptr_glVertexAttribL1ui64vARB
 
{-# NOINLINE ptr_glVertexAttribL1ui64vARB #-}
 
ptr_glVertexAttribL1ui64vARB :: FunPtr a
ptr_glVertexAttribL1ui64vARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_bindless_texture"
        "glVertexAttribL1ui64vARB"