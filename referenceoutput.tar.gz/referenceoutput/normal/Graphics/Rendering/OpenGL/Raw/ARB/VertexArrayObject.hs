-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexArrayObject
       (gl_VERTEX_ARRAY_BINDING, glBindVertexArray, glDeleteVertexArrays,
        glGenVertexArrays, glIsVertexArray)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (glBindVertexArray, glDeleteVertexArrays, glGenVertexArrays,
        glIsVertexArray, gl_VERTEX_ARRAY_BINDING)