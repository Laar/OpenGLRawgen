{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ShadingLanguageInclude
       (gl_NAMED_STRING_LENGTH_ARB, gl_NAMED_STRING_TYPE_ARB,
        gl_SHADER_INCLUDE_ARB, glCompileShaderIncludeARB,
        glDeleteNamedStringARB, glGetNamedStringARB, glGetNamedStringivARB,
        glIsNamedStringARB, glNamedStringARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_NAMED_STRING_LENGTH_ARB :: GLenum
gl_NAMED_STRING_LENGTH_ARB = 36329
 
gl_NAMED_STRING_TYPE_ARB :: GLenum
gl_NAMED_STRING_TYPE_ARB = 36330
 
gl_SHADER_INCLUDE_ARB :: GLenum
gl_SHADER_INCLUDE_ARB = 36270
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompileShaderIncludeARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ())
 
glCompileShaderIncludeARB ::
                          GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLint -> IO ()
glCompileShaderIncludeARB
  = dyn_glCompileShaderIncludeARB ptr_glCompileShaderIncludeARB
 
{-# NOINLINE ptr_glCompileShaderIncludeARB #-}
 
ptr_glCompileShaderIncludeARB :: FunPtr a
ptr_glCompileShaderIncludeARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glCompileShaderIncludeARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteNamedStringARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> IO ())
 
glDeleteNamedStringARB :: GLint -> Ptr GLchar -> IO ()
glDeleteNamedStringARB
  = dyn_glDeleteNamedStringARB ptr_glDeleteNamedStringARB
 
{-# NOINLINE ptr_glDeleteNamedStringARB #-}
 
ptr_glDeleteNamedStringARB :: FunPtr a
ptr_glDeleteNamedStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glDeleteNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetNamedStringARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    Ptr GLchar -> GLsizei -> Ptr GLint -> Ptr GLchar -> IO ())
 
glGetNamedStringARB ::
                    GLint -> Ptr GLchar -> GLsizei -> Ptr GLint -> Ptr GLchar -> IO ()
glGetNamedStringARB
  = dyn_glGetNamedStringARB ptr_glGetNamedStringARB
 
{-# NOINLINE ptr_glGetNamedStringARB #-}
 
ptr_glGetNamedStringARB :: FunPtr a
ptr_glGetNamedStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glGetNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetNamedStringivARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedStringivARB ::
                      GLint -> Ptr GLchar -> GLenum -> Ptr GLint -> IO ()
glGetNamedStringivARB
  = dyn_glGetNamedStringivARB ptr_glGetNamedStringivARB
 
{-# NOINLINE ptr_glGetNamedStringivARB #-}
 
ptr_glGetNamedStringivARB :: FunPtr a
ptr_glGetNamedStringivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glGetNamedStringivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsNamedStringARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr GLchar -> IO GLboolean)
 
glIsNamedStringARB :: GLint -> Ptr GLchar -> IO GLboolean
glIsNamedStringARB = dyn_glIsNamedStringARB ptr_glIsNamedStringARB
 
{-# NOINLINE ptr_glIsNamedStringARB #-}
 
ptr_glIsNamedStringARB :: FunPtr a
ptr_glIsNamedStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glIsNamedStringARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedStringARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLchar -> GLint -> Ptr GLchar -> IO ())
 
glNamedStringARB ::
                 GLenum -> GLint -> Ptr GLchar -> GLint -> Ptr GLchar -> IO ()
glNamedStringARB = dyn_glNamedStringARB ptr_glNamedStringARB
 
{-# NOINLINE ptr_glNamedStringARB #-}
 
ptr_glNamedStringARB :: FunPtr a
ptr_glNamedStringARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shading_language_include"
        "glNamedStringARB"