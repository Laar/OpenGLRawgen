{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.SampleShading
       (gl_MIN_SAMPLE_SHADING_VALUE_ARB, gl_SAMPLE_SHADING_ARB,
        glMinSampleShadingARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MIN_SAMPLE_SHADING_VALUE_ARB :: GLenum
gl_MIN_SAMPLE_SHADING_VALUE_ARB = 35895
 
gl_SAMPLE_SHADING_ARB :: GLenum
gl_SAMPLE_SHADING_ARB = 35894
 
foreign import CALLCONV unsafe "dynamic" dyn_glMinSampleShadingARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glMinSampleShadingARB :: GLfloat -> IO ()
glMinSampleShadingARB
  = dyn_glMinSampleShadingARB ptr_glMinSampleShadingARB
 
{-# NOINLINE ptr_glMinSampleShadingARB #-}
 
ptr_glMinSampleShadingARB :: FunPtr a
ptr_glMinSampleShadingARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sample_shading"
        "glMinSampleShadingARB"