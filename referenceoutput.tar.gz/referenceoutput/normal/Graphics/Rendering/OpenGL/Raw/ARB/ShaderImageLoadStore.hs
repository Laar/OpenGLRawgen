-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ShaderImageLoadStore
       (gl_ALL_BARRIER_BITS, gl_ATOMIC_COUNTER_BARRIER_BIT,
        gl_BUFFER_UPDATE_BARRIER_BIT, gl_COMMAND_BARRIER_BIT,
        gl_ELEMENT_ARRAY_BARRIER_BIT, gl_FRAMEBUFFER_BARRIER_BIT,
        gl_IMAGE_1D, gl_IMAGE_1D_ARRAY, gl_IMAGE_2D, gl_IMAGE_2D_ARRAY,
        gl_IMAGE_2D_MULTISAMPLE, gl_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_IMAGE_2D_RECT, gl_IMAGE_3D, gl_IMAGE_BINDING_ACCESS,
        gl_IMAGE_BINDING_FORMAT, gl_IMAGE_BINDING_LAYER,
        gl_IMAGE_BINDING_LAYERED, gl_IMAGE_BINDING_LEVEL,
        gl_IMAGE_BINDING_NAME, gl_IMAGE_BUFFER, gl_IMAGE_CUBE,
        gl_IMAGE_CUBE_MAP_ARRAY, gl_IMAGE_FORMAT_COMPATIBILITY_BY_CLASS,
        gl_IMAGE_FORMAT_COMPATIBILITY_BY_SIZE,
        gl_IMAGE_FORMAT_COMPATIBILITY_TYPE, gl_INT_IMAGE_1D,
        gl_INT_IMAGE_1D_ARRAY, gl_INT_IMAGE_2D, gl_INT_IMAGE_2D_ARRAY,
        gl_INT_IMAGE_2D_MULTISAMPLE, gl_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_INT_IMAGE_2D_RECT, gl_INT_IMAGE_3D, gl_INT_IMAGE_BUFFER,
        gl_INT_IMAGE_CUBE, gl_INT_IMAGE_CUBE_MAP_ARRAY,
        gl_MAX_COMBINED_IMAGE_UNIFORMS,
        gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS,
        gl_MAX_FRAGMENT_IMAGE_UNIFORMS, gl_MAX_GEOMETRY_IMAGE_UNIFORMS,
        gl_MAX_IMAGE_SAMPLES, gl_MAX_IMAGE_UNITS,
        gl_MAX_TESS_CONTROL_IMAGE_UNIFORMS,
        gl_MAX_TESS_EVALUATION_IMAGE_UNIFORMS,
        gl_MAX_VERTEX_IMAGE_UNIFORMS, gl_PIXEL_BUFFER_BARRIER_BIT,
        gl_SHADER_IMAGE_ACCESS_BARRIER_BIT, gl_TEXTURE_FETCH_BARRIER_BIT,
        gl_TEXTURE_UPDATE_BARRIER_BIT, gl_TRANSFORM_FEEDBACK_BARRIER_BIT,
        gl_UNIFORM_BARRIER_BIT, gl_UNSIGNED_INT_IMAGE_1D,
        gl_UNSIGNED_INT_IMAGE_1D_ARRAY, gl_UNSIGNED_INT_IMAGE_2D,
        gl_UNSIGNED_INT_IMAGE_2D_ARRAY,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_IMAGE_2D_RECT, gl_UNSIGNED_INT_IMAGE_3D,
        gl_UNSIGNED_INT_IMAGE_BUFFER, gl_UNSIGNED_INT_IMAGE_CUBE,
        gl_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY,
        gl_VERTEX_ATTRIB_ARRAY_BARRIER_BIT, glBindImageTexture,
        glMemoryBarrier)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_ALL_BARRIER_BITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_ATOMIC_COUNTER_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_BUFFER_UPDATE_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_COMMAND_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_ELEMENT_ARRAY_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_FRAMEBUFFER_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_1D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_2D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_2D_RECT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_ACCESS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_LAYER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_LAYERED)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_LEVEL)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BINDING_NAME)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_CUBE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_CUBE_MAP_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_FORMAT_COMPATIBILITY_BY_CLASS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_FORMAT_COMPATIBILITY_BY_SIZE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_IMAGE_FORMAT_COMPATIBILITY_TYPE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_1D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_2D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_2D_RECT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_CUBE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_INT_IMAGE_CUBE_MAP_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_COMBINED_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_FRAGMENT_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_GEOMETRY_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_IMAGE_SAMPLES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_IMAGE_UNITS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_TESS_CONTROL_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_TESS_EVALUATION_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MAX_VERTEX_IMAGE_UNIFORMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_PIXEL_BUFFER_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_SHADER_IMAGE_ACCESS_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_TEXTURE_FETCH_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_TEXTURE_UPDATE_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_TRANSFORM_FEEDBACK_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNIFORM_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_1D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_1D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_2D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_2D_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_2D_RECT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_3D)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_CUBE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_VERTEX_ATTRIB_ARRAY_BARRIER_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glBindImageTexture)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glMemoryBarrier)