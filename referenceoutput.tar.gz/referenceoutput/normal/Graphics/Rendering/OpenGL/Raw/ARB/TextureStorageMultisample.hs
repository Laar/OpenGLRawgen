-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureStorageMultisample
       (glTexStorage2DMultisample, glTexStorage3DMultisample) where
import Graphics.Rendering.OpenGL.Raw.Core.Core43
       (glTexStorage2DMultisample, glTexStorage3DMultisample)