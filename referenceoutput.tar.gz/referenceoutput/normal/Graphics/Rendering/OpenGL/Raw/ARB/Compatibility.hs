-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Compatibility
       {-# DEPRECATED "The ARB.Compatibility is combined with the profiles."
                      #-}
       (module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core13Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core14Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core20Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core21Compatibility,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30Compatibility,
        gl_QUADS, glVertexAttribI1i, glVertexAttribI1iv,
        glVertexAttribI1ui, glVertexAttribI1uiv, glVertexAttribI2i,
        glVertexAttribI2iv, glVertexAttribI2ui, glVertexAttribI2uiv,
        glVertexAttribI3i, glVertexAttribI3iv, glVertexAttribI3ui,
        glVertexAttribI3uiv, glVertexAttribI4bv, glVertexAttribI4i,
        glVertexAttribI4iv, glVertexAttribI4sv, glVertexAttribI4ubv,
        glVertexAttribI4ui, glVertexAttribI4uiv, glVertexAttribI4usv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core13Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core14Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core20Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core21Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30Compatibility
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_QUADS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI1i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI1iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI1ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI1uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI2i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI2iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI2ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI2uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI3i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI3iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI3ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI3uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4bv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4i)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4iv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4sv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4ubv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4ui)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4uiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (glVertexAttribI4usv)