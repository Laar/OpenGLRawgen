-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.BlendFuncExtended
       (gl_MAX_DUAL_SOURCE_DRAW_BUFFERS, gl_ONE_MINUS_SRC1_ALPHA,
        gl_ONE_MINUS_SRC1_COLOR, gl_SRC1_ALPHA, gl_SRC1_COLOR,
        glBindFragDataLocationIndexed, glGetFragDataIndex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core15 (gl_SRC1_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Core.Core33
       (glBindFragDataLocationIndexed, glGetFragDataIndex,
        gl_MAX_DUAL_SOURCE_DRAW_BUFFERS, gl_ONE_MINUS_SRC1_ALPHA,
        gl_ONE_MINUS_SRC1_COLOR, gl_SRC1_COLOR)