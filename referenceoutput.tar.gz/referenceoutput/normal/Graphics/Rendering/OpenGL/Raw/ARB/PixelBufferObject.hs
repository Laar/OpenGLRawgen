-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.PixelBufferObject
       (gl_PIXEL_PACK_BUFFER_ARB, gl_PIXEL_PACK_BUFFER_BINDING_ARB,
        gl_PIXEL_UNPACK_BUFFER_ARB, gl_PIXEL_UNPACK_BUFFER_BINDING_ARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PIXEL_PACK_BUFFER_ARB :: GLenum
gl_PIXEL_PACK_BUFFER_ARB = 35051
 
gl_PIXEL_PACK_BUFFER_BINDING_ARB :: GLenum
gl_PIXEL_PACK_BUFFER_BINDING_ARB = 35053
 
gl_PIXEL_UNPACK_BUFFER_ARB :: GLenum
gl_PIXEL_UNPACK_BUFFER_ARB = 35052
 
gl_PIXEL_UNPACK_BUFFER_BINDING_ARB :: GLenum
gl_PIXEL_UNPACK_BUFFER_BINDING_ARB = 35055