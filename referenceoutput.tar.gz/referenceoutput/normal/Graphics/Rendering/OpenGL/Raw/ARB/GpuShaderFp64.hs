-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.GpuShaderFp64
       (gl_DOUBLE, gl_DOUBLE_MAT2, gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2x4,
        gl_DOUBLE_MAT3, gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3x4, gl_DOUBLE_MAT4,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4x3, gl_DOUBLE_VEC2, gl_DOUBLE_VEC3,
        gl_DOUBLE_VEC4, glGetUniformdv, glUniform1d, glUniform1dv,
        glUniform2d, glUniform2dv, glUniform3d, glUniform3dv, glUniform4d,
        glUniform4dv, glUniformMatrix2dv, glUniformMatrix2x3dv,
        glUniformMatrix2x4dv, glUniformMatrix3dv, glUniformMatrix3x2dv,
        glUniformMatrix3x4dv, glUniformMatrix4dv, glUniformMatrix4x2dv,
        glUniformMatrix4x3dv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_DOUBLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT2x3)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT2x4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT3)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT3x2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT3x4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT4x2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT4x3)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_VEC2)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_VEC3)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_VEC4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetUniformdv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform1d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform1dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform2d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform3d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform4d)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniform4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix2x3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix2x4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix3dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix3x2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix3x4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix4dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix4x2dv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glUniformMatrix4x3dv)