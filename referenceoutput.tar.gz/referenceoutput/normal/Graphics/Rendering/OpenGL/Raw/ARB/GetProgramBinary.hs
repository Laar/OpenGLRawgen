-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.GetProgramBinary
       (gl_NUM_PROGRAM_BINARY_FORMATS, gl_PROGRAM_BINARY_FORMATS,
        gl_PROGRAM_BINARY_LENGTH, gl_PROGRAM_BINARY_RETRIEVABLE_HINT,
        glGetProgramBinary, glProgramBinary, glProgramParameteri)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core41
       (glGetProgramBinary, glProgramBinary, glProgramParameteri,
        gl_NUM_PROGRAM_BINARY_FORMATS, gl_PROGRAM_BINARY_FORMATS,
        gl_PROGRAM_BINARY_LENGTH, gl_PROGRAM_BINARY_RETRIEVABLE_HINT)