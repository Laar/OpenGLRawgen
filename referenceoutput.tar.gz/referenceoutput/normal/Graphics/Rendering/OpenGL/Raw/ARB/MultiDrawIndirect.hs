-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.MultiDrawIndirect
       (glMultiDrawArraysIndirect, glMultiDrawElementsIndirect) where
import Graphics.Rendering.OpenGL.Raw.Core.Core43
       (glMultiDrawArraysIndirect, glMultiDrawElementsIndirect)