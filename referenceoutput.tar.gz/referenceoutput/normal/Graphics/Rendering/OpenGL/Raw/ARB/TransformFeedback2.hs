-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedback2
       (gl_TRANSFORM_FEEDBACK, gl_TRANSFORM_FEEDBACK_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BINDING, gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED, gl_TRANSFORM_FEEDBACK_PAUSED,
        glBindTransformFeedback, glDeleteTransformFeedbacks,
        glDrawTransformFeedback, glGenTransformFeedbacks,
        glIsTransformFeedback, glPauseTransformFeedback,
        glResumeTransformFeedback)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core40
       (glBindTransformFeedback, glDeleteTransformFeedbacks,
        glDrawTransformFeedback, glGenTransformFeedbacks,
        glIsTransformFeedback, glPauseTransformFeedback,
        glResumeTransformFeedback, gl_TRANSFORM_FEEDBACK,
        gl_TRANSFORM_FEEDBACK_BINDING, gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TRANSFORM_FEEDBACK_ACTIVE :: GLenum
gl_TRANSFORM_FEEDBACK_ACTIVE = 36388
 
gl_TRANSFORM_FEEDBACK_PAUSED :: GLenum
gl_TRANSFORM_FEEDBACK_PAUSED = 36387