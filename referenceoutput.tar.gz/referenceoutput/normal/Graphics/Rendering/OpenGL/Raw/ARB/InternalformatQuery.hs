-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.InternalformatQuery
       (gl_NUM_SAMPLE_COUNTS, glGetInternalformativ) where
import Graphics.Rendering.OpenGL.Raw.Core.Core42
       (glGetInternalformativ, gl_NUM_SAMPLE_COUNTS)