-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.MultiBind
       (glBindBuffersBase, glBindBuffersRange, glBindImageTextures,
        glBindSamplers, glBindTextures, glBindVertexBuffers)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (glBindBuffersBase, glBindBuffersRange, glBindImageTextures,
        glBindSamplers, glBindTextures, glBindVertexBuffers)