-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DepthTexture
       (gl_DEPTH_COMPONENT16_ARB, gl_DEPTH_COMPONENT24_ARB,
        gl_DEPTH_COMPONENT32_ARB, gl_DEPTH_TEXTURE_MODE_ARB,
        gl_TEXTURE_DEPTH_SIZE_ARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_COMPONENT16_ARB :: GLenum
gl_DEPTH_COMPONENT16_ARB = 33189
 
gl_DEPTH_COMPONENT24_ARB :: GLenum
gl_DEPTH_COMPONENT24_ARB = 33190
 
gl_DEPTH_COMPONENT32_ARB :: GLenum
gl_DEPTH_COMPONENT32_ARB = 33191
 
gl_DEPTH_TEXTURE_MODE_ARB :: GLenum
gl_DEPTH_TEXTURE_MODE_ARB = 34891
 
gl_TEXTURE_DEPTH_SIZE_ARB :: GLenum
gl_TEXTURE_DEPTH_SIZE_ARB = 34890