-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.BufferStorage
       (gl_BUFFER_IMMUTABLE_STORAGE, gl_BUFFER_STORAGE_FLAGS,
        gl_CLIENT_MAPPED_BUFFER_BARRIER_BIT, gl_CLIENT_STORAGE_BIT,
        gl_DYNAMIC_STORAGE_BIT, gl_MAP_COHERENT_BIT, gl_MAP_PERSISTENT_BIT,
        gl_MAP_READ_BIT, gl_MAP_WRITE_BIT, glBufferStorage)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_MAP_READ_BIT, gl_MAP_WRITE_BIT)
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (glBufferStorage, gl_BUFFER_IMMUTABLE_STORAGE,
        gl_BUFFER_STORAGE_FLAGS, gl_CLIENT_MAPPED_BUFFER_BARRIER_BIT,
        gl_CLIENT_STORAGE_BIT, gl_DYNAMIC_STORAGE_BIT, gl_MAP_COHERENT_BIT,
        gl_MAP_PERSISTENT_BIT)