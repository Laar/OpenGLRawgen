-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.Imaging
       (gl_BLEND_COLOR, gl_BLEND_EQUATION, gl_CONSTANT_ALPHA,
        gl_CONSTANT_COLOR, gl_FUNC_ADD, gl_FUNC_REVERSE_SUBTRACT,
        gl_FUNC_SUBTRACT, gl_MAX, gl_MIN, gl_ONE_MINUS_CONSTANT_ALPHA,
        gl_ONE_MINUS_CONSTANT_COLOR)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_BLEND_COLOR)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_BLEND_EQUATION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_CONSTANT_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_CONSTANT_COLOR)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_FUNC_ADD)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_FUNC_REVERSE_SUBTRACT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_FUNC_SUBTRACT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12 (gl_MAX)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12 (gl_MIN)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_ONE_MINUS_CONSTANT_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_ONE_MINUS_CONSTANT_COLOR)