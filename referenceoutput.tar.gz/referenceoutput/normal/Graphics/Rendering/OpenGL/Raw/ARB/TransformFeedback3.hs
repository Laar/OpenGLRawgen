-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedback3
       (gl_MAX_TRANSFORM_FEEDBACK_BUFFERS, gl_MAX_VERTEX_STREAMS,
        glBeginQueryIndexed, glDrawTransformFeedbackStream,
        glEndQueryIndexed, glGetQueryIndexediv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_TRANSFORM_FEEDBACK_BUFFERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_VERTEX_STREAMS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glBeginQueryIndexed)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawTransformFeedbackStream)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glEndQueryIndexed)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glGetQueryIndexediv)