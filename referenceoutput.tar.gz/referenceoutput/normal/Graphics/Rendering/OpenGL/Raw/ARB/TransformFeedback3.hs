-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedback3
       (gl_MAX_TRANSFORM_FEEDBACK_BUFFERS, gl_MAX_VERTEX_STREAMS,
        glBeginQueryIndexed, glDrawTransformFeedbackStream,
        glEndQueryIndexed, glGetQueryIndexediv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core40
       (glBeginQueryIndexed, glDrawTransformFeedbackStream,
        glEndQueryIndexed, glGetQueryIndexediv,
        gl_MAX_TRANSFORM_FEEDBACK_BUFFERS, gl_MAX_VERTEX_STREAMS)