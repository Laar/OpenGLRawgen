-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureRgb10A2ui
       (gl_RGB10_A2UI) where
import Graphics.Rendering.OpenGL.Raw.Core.Core33 (gl_RGB10_A2UI)