-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexAttribBinding
       (gl_MAX_VERTEX_ATTRIB_BINDINGS,
        gl_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_ATTRIB_BINDING,
        gl_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_BINDING_DIVISOR,
        gl_VERTEX_BINDING_OFFSET, gl_VERTEX_BINDING_STRIDE,
        glBindVertexBuffer, glVertexArrayBindVertexBufferEXT,
        glVertexArrayVertexAttribBindingEXT,
        glVertexArrayVertexAttribFormatEXT,
        glVertexArrayVertexAttribIFormatEXT,
        glVertexArrayVertexAttribLFormatEXT,
        glVertexArrayVertexBindingDivisorEXT, glVertexAttribBinding,
        glVertexAttribFormat, glVertexAttribIFormat, glVertexAttribLFormat,
        glVertexBindingDivisor)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_VERTEX_ATTRIB_BINDINGS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_ATTRIB_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_ATTRIB_RELATIVE_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_BINDING_DIVISOR)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_BINDING_OFFSET)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (gl_VERTEX_BINDING_STRIDE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glBindVertexBuffer)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayBindVertexBufferEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayVertexAttribBindingEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayVertexAttribFormatEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayVertexAttribIFormatEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayVertexAttribLFormatEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexArrayVertexBindingDivisorEXT)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexAttribBinding)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexAttribFormat)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexAttribIFormat)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexAttribLFormat)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core43
       (glVertexBindingDivisor)