-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexAttribBinding
       (gl_MAX_VERTEX_ATTRIB_BINDINGS,
        gl_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_ATTRIB_BINDING,
        gl_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_BINDING_DIVISOR,
        gl_VERTEX_BINDING_OFFSET, gl_VERTEX_BINDING_STRIDE,
        glBindVertexBuffer, glVertexAttribBinding, glVertexAttribFormat,
        glVertexAttribIFormat, glVertexAttribLFormat,
        glVertexBindingDivisor)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core43
       (glBindVertexBuffer, glVertexAttribBinding, glVertexAttribFormat,
        glVertexAttribIFormat, glVertexAttribLFormat,
        glVertexBindingDivisor, gl_MAX_VERTEX_ATTRIB_BINDINGS,
        gl_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_ATTRIB_BINDING,
        gl_VERTEX_ATTRIB_RELATIVE_OFFSET, gl_VERTEX_BINDING_DIVISOR,
        gl_VERTEX_BINDING_OFFSET, gl_VERTEX_BINDING_STRIDE)