-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DrawElementsBaseVertex
       (glDrawElementsBaseVertex, glDrawElementsInstancedBaseVertex,
        glDrawRangeElementsBaseVertex, glMultiDrawElementsBaseVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core32
       (glDrawElementsBaseVertex, glDrawElementsInstancedBaseVertex,
        glDrawRangeElementsBaseVertex, glMultiDrawElementsBaseVertex)