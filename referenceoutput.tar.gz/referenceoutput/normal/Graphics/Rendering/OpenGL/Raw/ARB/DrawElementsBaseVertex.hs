-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DrawElementsBaseVertex
       (glDrawElementsBaseVertex, glDrawElementsInstancedBaseVertex,
        glDrawRangeElementsBaseVertex, glMultiDrawElementsBaseVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawElementsBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawElementsInstancedBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glDrawRangeElementsBaseVertex)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (glMultiDrawElementsBaseVertex)