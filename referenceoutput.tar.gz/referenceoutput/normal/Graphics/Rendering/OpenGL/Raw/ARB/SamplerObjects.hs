-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.SamplerObjects
       (gl_SAMPLER_BINDING, glBindSampler, glDeleteSamplers,
        glGenSamplers, glGetSamplerParameterIiv, glGetSamplerParameterIuiv,
        glGetSamplerParameterfv, glGetSamplerParameteriv, glIsSampler,
        glSamplerParameterIiv, glSamplerParameterIuiv, glSamplerParameterf,
        glSamplerParameterfv, glSamplerParameteri, glSamplerParameteriv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_SAMPLER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glBindSampler)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glDeleteSamplers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGenSamplers)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGetSamplerParameterIiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGetSamplerParameterIuiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGetSamplerParameterfv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glGetSamplerParameteriv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glIsSampler)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameterIiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameterIuiv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameterf)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameterfv)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameteri)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glSamplerParameteriv)