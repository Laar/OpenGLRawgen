-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.SamplerObjects
       (gl_SAMPLER_BINDING, glBindSampler, glDeleteSamplers,
        glGenSamplers, glGetSamplerParameterIiv, glGetSamplerParameterIuiv,
        glGetSamplerParameterfv, glGetSamplerParameteriv, glIsSampler,
        glSamplerParameterIiv, glSamplerParameterIuiv, glSamplerParameterf,
        glSamplerParameterfv, glSamplerParameteri, glSamplerParameteriv)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glBindSampler, glDeleteSamplers, glGenSamplers,
        glGetSamplerParameterIiv, glGetSamplerParameterIuiv,
        glGetSamplerParameterfv, glGetSamplerParameteriv, glIsSampler,
        glSamplerParameterIiv, glSamplerParameterIuiv, glSamplerParameterf,
        glSamplerParameterfv, glSamplerParameteri, glSamplerParameteriv,
        gl_SAMPLER_BINDING)