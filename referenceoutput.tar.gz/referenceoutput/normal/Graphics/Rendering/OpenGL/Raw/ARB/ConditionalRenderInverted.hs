-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ConditionalRenderInverted
       (gl_QUERY_BY_REGION_NO_WAIT_INVERTED,
        gl_QUERY_BY_REGION_WAIT_INVERTED, gl_QUERY_NO_WAIT_INVERTED,
        gl_QUERY_WAIT_INVERTED)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core45
       (gl_QUERY_BY_REGION_NO_WAIT_INVERTED,
        gl_QUERY_BY_REGION_WAIT_INVERTED, gl_QUERY_NO_WAIT_INVERTED,
        gl_QUERY_WAIT_INVERTED)