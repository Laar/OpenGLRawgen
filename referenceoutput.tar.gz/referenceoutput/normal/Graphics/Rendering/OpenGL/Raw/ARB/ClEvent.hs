-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ClEvent
       (gl_SYNC_CL_EVENT_ARB, gl_SYNC_CL_EVENT_COMPLETE_ARB) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SYNC_CL_EVENT_ARB :: GLenum
gl_SYNC_CL_EVENT_ARB = 33344
 
gl_SYNC_CL_EVENT_COMPLETE_ARB :: GLenum
gl_SYNC_CL_EVENT_COMPLETE_ARB = 33345