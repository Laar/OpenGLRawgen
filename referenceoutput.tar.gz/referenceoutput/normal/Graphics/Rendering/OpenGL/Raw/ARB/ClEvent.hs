{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.ClEvent
       (gl_SYNC_CL_EVENT_ARB, gl_SYNC_CL_EVENT_COMPLETE_ARB,
        glCreateSyncFromCLeventARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SYNC_CL_EVENT_ARB :: GLenum
gl_SYNC_CL_EVENT_ARB = 33344
 
gl_SYNC_CL_EVENT_COMPLETE_ARB :: GLenum
gl_SYNC_CL_EVENT_COMPLETE_ARB = 33345
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCreateSyncFromCLeventARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr CLcontext -> Ptr CLevent -> GLbitfield -> IO GLsync)
 
glCreateSyncFromCLeventARB ::
                           Ptr CLcontext -> Ptr CLevent -> GLbitfield -> IO GLsync
glCreateSyncFromCLeventARB
  = dyn_glCreateSyncFromCLeventARB ptr_glCreateSyncFromCLeventARB
 
{-# NOINLINE ptr_glCreateSyncFromCLeventARB #-}
 
ptr_glCreateSyncFromCLeventARB :: FunPtr a
ptr_glCreateSyncFromCLeventARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_cl_event"
        "glCreateSyncFromCLeventARB"