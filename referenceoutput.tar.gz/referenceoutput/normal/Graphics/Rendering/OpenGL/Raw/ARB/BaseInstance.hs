-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.BaseInstance
       (glDrawArraysInstancedBaseInstance,
        glDrawElementsInstancedBaseInstance,
        glDrawElementsInstancedBaseVertexBaseInstance)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawArraysInstancedBaseInstance)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawElementsInstancedBaseInstance)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (glDrawElementsInstancedBaseVertexBaseInstance)