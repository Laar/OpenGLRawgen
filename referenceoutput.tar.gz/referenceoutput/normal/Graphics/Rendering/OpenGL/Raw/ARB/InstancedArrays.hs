{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.InstancedArrays
       (gl_VERTEX_ATTRIB_ARRAY_DIVISOR_ARB, glVertexAttribDivisorARB)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_VERTEX_ATTRIB_ARRAY_DIVISOR_ARB :: GLenum
gl_VERTEX_ATTRIB_ARRAY_DIVISOR_ARB = 35070
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexAttribDivisorARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glVertexAttribDivisorARB :: GLuint -> GLuint -> IO ()
glVertexAttribDivisorARB
  = dyn_glVertexAttribDivisorARB ptr_glVertexAttribDivisorARB
 
{-# NOINLINE ptr_glVertexAttribDivisorARB #-}
 
ptr_glVertexAttribDivisorARB :: FunPtr a
ptr_glVertexAttribDivisorARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_instanced_arrays"
        "glVertexAttribDivisorARB"