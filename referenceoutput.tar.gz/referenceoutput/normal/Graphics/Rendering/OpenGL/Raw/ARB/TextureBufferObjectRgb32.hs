-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureBufferObjectRgb32
       (gl_RGB32F, gl_RGB32I, gl_RGB32UI) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RGB32F)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RGB32I)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RGB32UI)