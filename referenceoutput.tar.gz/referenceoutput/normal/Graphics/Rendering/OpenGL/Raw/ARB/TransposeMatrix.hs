{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TransposeMatrix
       (gl_TRANSPOSE_COLOR_MATRIX_ARB, gl_TRANSPOSE_MODELVIEW_MATRIX_ARB,
        gl_TRANSPOSE_PROJECTION_MATRIX_ARB,
        gl_TRANSPOSE_TEXTURE_MATRIX_ARB, glLoadTransposeMatrixdARB,
        glLoadTransposeMatrixfARB, glMultTransposeMatrixdARB,
        glMultTransposeMatrixfARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TRANSPOSE_COLOR_MATRIX_ARB :: GLenum
gl_TRANSPOSE_COLOR_MATRIX_ARB = 34022
 
gl_TRANSPOSE_MODELVIEW_MATRIX_ARB :: GLenum
gl_TRANSPOSE_MODELVIEW_MATRIX_ARB = 34019
 
gl_TRANSPOSE_PROJECTION_MATRIX_ARB :: GLenum
gl_TRANSPOSE_PROJECTION_MATRIX_ARB = 34020
 
gl_TRANSPOSE_TEXTURE_MATRIX_ARB :: GLenum
gl_TRANSPOSE_TEXTURE_MATRIX_ARB = 34021
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glLoadTransposeMatrixdARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
glLoadTransposeMatrixdARB :: Ptr GLdouble -> IO ()
glLoadTransposeMatrixdARB
  = dyn_glLoadTransposeMatrixdARB ptr_glLoadTransposeMatrixdARB
 
{-# NOINLINE ptr_glLoadTransposeMatrixdARB #-}
 
ptr_glLoadTransposeMatrixdARB :: FunPtr a
ptr_glLoadTransposeMatrixdARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glLoadTransposeMatrixdARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glLoadTransposeMatrixfARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
glLoadTransposeMatrixfARB :: Ptr GLfloat -> IO ()
glLoadTransposeMatrixfARB
  = dyn_glLoadTransposeMatrixfARB ptr_glLoadTransposeMatrixfARB
 
{-# NOINLINE ptr_glLoadTransposeMatrixfARB #-}
 
ptr_glLoadTransposeMatrixfARB :: FunPtr a
ptr_glLoadTransposeMatrixfARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glLoadTransposeMatrixfARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultTransposeMatrixdARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
glMultTransposeMatrixdARB :: Ptr GLdouble -> IO ()
glMultTransposeMatrixdARB
  = dyn_glMultTransposeMatrixdARB ptr_glMultTransposeMatrixdARB
 
{-# NOINLINE ptr_glMultTransposeMatrixdARB #-}
 
ptr_glMultTransposeMatrixdARB :: FunPtr a
ptr_glMultTransposeMatrixdARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glMultTransposeMatrixdARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultTransposeMatrixfARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
glMultTransposeMatrixfARB :: Ptr GLfloat -> IO ()
glMultTransposeMatrixfARB
  = dyn_glMultTransposeMatrixfARB ptr_glMultTransposeMatrixfARB
 
{-# NOINLINE ptr_glMultTransposeMatrixfARB #-}
 
ptr_glMultTransposeMatrixfARB :: FunPtr a
ptr_glMultTransposeMatrixfARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transpose_matrix"
        "glMultTransposeMatrixfARB"