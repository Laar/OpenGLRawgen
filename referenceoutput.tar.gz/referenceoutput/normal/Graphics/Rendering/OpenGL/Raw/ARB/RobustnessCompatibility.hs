{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.RobustnessCompatibility
       (glGetnColorTableARB, glGetnConvolutionFilterARB,
        glGetnHistogramARB, glGetnMapdvARB, glGetnMapfvARB, glGetnMapivARB,
        glGetnMinmaxARB, glGetnPixelMapfvARB, glGetnPixelMapuivARB,
        glGetnPixelMapusvARB, glGetnPolygonStippleARB,
        glGetnSeparableFilterARB)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnColorTableARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glGetnColorTableARB ::
                    GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ()
glGetnColorTableARB
  = dyn_glGetnColorTableARB ptr_glGetnColorTableARB
 
{-# NOINLINE ptr_glGetnColorTableARB #-}
 
ptr_glGetnColorTableARB :: FunPtr a
ptr_glGetnColorTableARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnColorTableARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetnConvolutionFilterARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glGetnConvolutionFilterARB ::
                           GLenum -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ()
glGetnConvolutionFilterARB
  = dyn_glGetnConvolutionFilterARB ptr_glGetnConvolutionFilterARB
 
{-# NOINLINE ptr_glGetnConvolutionFilterARB #-}
 
ptr_glGetnConvolutionFilterARB :: FunPtr a
ptr_glGetnConvolutionFilterARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnConvolutionFilterARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnHistogramARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnHistogramARB ::
                   GLenum ->
                     GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnHistogramARB = dyn_glGetnHistogramARB ptr_glGetnHistogramARB
 
{-# NOINLINE ptr_glGetnHistogramARB #-}
 
ptr_glGetnHistogramARB :: FunPtr a
ptr_glGetnHistogramARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnHistogramARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapdvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLdouble -> IO ())
 
glGetnMapdvARB ::
               GLenum -> GLenum -> GLsizei -> Ptr GLdouble -> IO ()
glGetnMapdvARB = dyn_glGetnMapdvARB ptr_glGetnMapdvARB
 
{-# NOINLINE ptr_glGetnMapdvARB #-}
 
ptr_glGetnMapdvARB :: FunPtr a
ptr_glGetnMapdvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapdvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapfvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnMapfvARB ::
               GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glGetnMapfvARB = dyn_glGetnMapfvARB ptr_glGetnMapfvARB
 
{-# NOINLINE ptr_glGetnMapfvARB #-}
 
ptr_glGetnMapfvARB :: FunPtr a
ptr_glGetnMapfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMapivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ())
 
glGetnMapivARB :: GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ()
glGetnMapivARB = dyn_glGetnMapivARB ptr_glGetnMapivARB
 
{-# NOINLINE ptr_glGetnMapivARB #-}
 
ptr_glGetnMapivARB :: FunPtr a
ptr_glGetnMapivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMapivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnMinmaxARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ())
 
glGetnMinmaxARB ::
                GLenum ->
                  GLboolean -> GLenum -> GLenum -> GLsizei -> Ptr g -> IO ()
glGetnMinmaxARB = dyn_glGetnMinmaxARB ptr_glGetnMinmaxARB
 
{-# NOINLINE ptr_glGetnMinmaxARB #-}
 
ptr_glGetnMinmaxARB :: FunPtr a
ptr_glGetnMinmaxARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnMinmaxARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapfvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
glGetnPixelMapfvARB :: GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glGetnPixelMapfvARB
  = dyn_glGetnPixelMapfvARB ptr_glGetnPixelMapfvARB
 
{-# NOINLINE ptr_glGetnPixelMapfvARB #-}
 
ptr_glGetnPixelMapfvARB :: FunPtr a
ptr_glGetnPixelMapfvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapfvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapuivARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLuint -> IO ())
 
glGetnPixelMapuivARB :: GLenum -> GLsizei -> Ptr GLuint -> IO ()
glGetnPixelMapuivARB
  = dyn_glGetnPixelMapuivARB ptr_glGetnPixelMapuivARB
 
{-# NOINLINE ptr_glGetnPixelMapuivARB #-}
 
ptr_glGetnPixelMapuivARB :: FunPtr a
ptr_glGetnPixelMapuivARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapuivARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPixelMapusvARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLushort -> IO ())
 
glGetnPixelMapusvARB :: GLenum -> GLsizei -> Ptr GLushort -> IO ()
glGetnPixelMapusvARB
  = dyn_glGetnPixelMapusvARB ptr_glGetnPixelMapusvARB
 
{-# NOINLINE ptr_glGetnPixelMapusvARB #-}
 
ptr_glGetnPixelMapusvARB :: FunPtr a
ptr_glGetnPixelMapusvARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPixelMapusvARB"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetnPolygonStippleARB
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLubyte -> IO ())
 
glGetnPolygonStippleARB :: GLsizei -> Ptr GLubyte -> IO ()
glGetnPolygonStippleARB
  = dyn_glGetnPolygonStippleARB ptr_glGetnPolygonStippleARB
 
{-# NOINLINE ptr_glGetnPolygonStippleARB #-}
 
ptr_glGetnPolygonStippleARB :: FunPtr a
ptr_glGetnPolygonStippleARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnPolygonStippleARB"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetnSeparableFilterARB ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLenum -> GLsizei -> Ptr f -> GLsizei -> Ptr h -> Ptr i -> IO ())
 
glGetnSeparableFilterARB ::
                         GLenum ->
                           GLenum ->
                             GLenum -> GLsizei -> Ptr f -> GLsizei -> Ptr h -> Ptr i -> IO ()
glGetnSeparableFilterARB
  = dyn_glGetnSeparableFilterARB ptr_glGetnSeparableFilterARB
 
{-# NOINLINE ptr_glGetnSeparableFilterARB #-}
 
ptr_glGetnSeparableFilterARB :: FunPtr a
ptr_glGetnSeparableFilterARB
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_robustness_DEPRECATED"
        "glGetnSeparableFilterARB"