-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.VertexAttrib64bit
       (gl_DOUBLE_MAT2, gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2x4,
        gl_DOUBLE_MAT3, gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3x4, gl_DOUBLE_MAT4,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4x3, gl_DOUBLE_VEC2, gl_DOUBLE_VEC3,
        gl_DOUBLE_VEC4, gl_RGB32I, glGetVertexAttribLdv, glVertexAttribL1d,
        glVertexAttribL1dv, glVertexAttribL2d, glVertexAttribL2dv,
        glVertexAttribL3d, glVertexAttribL3dv, glVertexAttribL4d,
        glVertexAttribL4dv, glVertexAttribLPointer)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_RGB32I)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_MAT2, gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2x4,
        gl_DOUBLE_MAT3, gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3x4, gl_DOUBLE_MAT4,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4x3, gl_DOUBLE_VEC2, gl_DOUBLE_VEC3,
        gl_DOUBLE_VEC4)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (glGetVertexAttribLdv, glVertexAttribL1d, glVertexAttribL1dv,
        glVertexAttribL2d, glVertexAttribL2dv, glVertexAttribL3d,
        glVertexAttribL3dv, glVertexAttribL4d, glVertexAttribL4dv,
        glVertexAttribLPointer)