-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureStencil8
       (gl_STENCIL_INDEX, gl_STENCIL_INDEX8) where
import Graphics.Rendering.OpenGL.Raw.Core.Core11 (gl_STENCIL_INDEX)
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_STENCIL_INDEX8)