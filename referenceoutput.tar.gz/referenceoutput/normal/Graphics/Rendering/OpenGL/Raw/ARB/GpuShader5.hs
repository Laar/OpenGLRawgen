-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.GpuShader5
       (gl_FRAGMENT_INTERPOLATION_OFFSET_BITS,
        gl_GEOMETRY_SHADER_INVOCATIONS,
        gl_MAX_FRAGMENT_INTERPOLATION_OFFSET,
        gl_MAX_GEOMETRY_SHADER_INVOCATIONS, gl_MAX_VERTEX_STREAMS,
        gl_MIN_FRAGMENT_INTERPOLATION_OFFSET)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_FRAGMENT_INTERPOLATION_OFFSET_BITS,
        gl_GEOMETRY_SHADER_INVOCATIONS,
        gl_MAX_FRAGMENT_INTERPOLATION_OFFSET,
        gl_MAX_GEOMETRY_SHADER_INVOCATIONS, gl_MAX_VERTEX_STREAMS,
        gl_MIN_FRAGMENT_INTERPOLATION_OFFSET)