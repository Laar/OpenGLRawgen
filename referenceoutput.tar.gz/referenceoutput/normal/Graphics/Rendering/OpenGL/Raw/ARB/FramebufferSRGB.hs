-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.FramebufferSRGB
       (gl_FRAMEBUFFER_SRGB) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_FRAMEBUFFER_SRGB)