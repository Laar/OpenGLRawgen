-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureView
       (gl_TEXTURE_IMMUTABLE_LEVELS, gl_TEXTURE_VIEW_MIN_LAYER,
        gl_TEXTURE_VIEW_MIN_LEVEL, gl_TEXTURE_VIEW_NUM_LAYERS,
        gl_TEXTURE_VIEW_NUM_LEVELS, glTextureView)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core43
       (glTextureView, gl_TEXTURE_IMMUTABLE_LEVELS,
        gl_TEXTURE_VIEW_MIN_LAYER, gl_TEXTURE_VIEW_MIN_LEVEL,
        gl_TEXTURE_VIEW_NUM_LAYERS, gl_TEXTURE_VIEW_NUM_LEVELS)