-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.DrawIndirect
       (gl_DRAW_INDIRECT_BUFFER, gl_DRAW_INDIRECT_BUFFER_BINDING,
        glDrawArraysIndirect, glDrawElementsIndirect)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (glDrawArraysIndirect, glDrawElementsIndirect,
        gl_DRAW_INDIRECT_BUFFER, gl_DRAW_INDIRECT_BUFFER_BINDING)