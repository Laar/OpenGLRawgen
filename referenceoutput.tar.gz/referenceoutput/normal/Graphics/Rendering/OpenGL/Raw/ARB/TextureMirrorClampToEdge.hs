-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureMirrorClampToEdge
       (gl_MIRROR_CLAMP_TO_EDGE) where
import Graphics.Rendering.OpenGL.Raw.Core.Core44
       (gl_MIRROR_CLAMP_TO_EDGE)