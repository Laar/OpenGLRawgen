-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureCompressionRgtc
       (gl_COMPRESSED_RED_RGTC1, gl_COMPRESSED_RG_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1, gl_COMPRESSED_SIGNED_RG_RGTC2)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_COMPRESSED_RED_RGTC1, gl_COMPRESSED_RG_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1, gl_COMPRESSED_SIGNED_RG_RGTC2)