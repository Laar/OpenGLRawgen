-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ARB.TextureSwizzle
       (gl_TEXTURE_SWIZZLE_A, gl_TEXTURE_SWIZZLE_B, gl_TEXTURE_SWIZZLE_G,
        gl_TEXTURE_SWIZZLE_R, gl_TEXTURE_SWIZZLE_RGBA)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_TEXTURE_SWIZZLE_A, gl_TEXTURE_SWIZZLE_B, gl_TEXTURE_SWIZZLE_G,
        gl_TEXTURE_SWIZZLE_R, gl_TEXTURE_SWIZZLE_RGBA)