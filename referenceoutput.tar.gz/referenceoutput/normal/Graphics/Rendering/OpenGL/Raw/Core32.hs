-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.Core32
       {-# DEPRECATED "The core modules are moved to Graphics.Rendering.OpenGL.Raw.Core.CoreXY"
                      #-}
       (module Graphics.Rendering.OpenGL.Raw.Core.Core32) where
import Graphics.Rendering.OpenGL.Raw.Core.Core32