-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD
       (module Graphics.Rendering.OpenGL.Raw.AMD.BlendMinmaxFactor,
        module Graphics.Rendering.OpenGL.Raw.AMD.DebugOutput,
        module Graphics.Rendering.OpenGL.Raw.AMD.DepthClampSeparate,
        module Graphics.Rendering.OpenGL.Raw.AMD.DrawBuffersBlend,
        module Graphics.Rendering.OpenGL.Raw.AMD.InterleavedElements,
        module Graphics.Rendering.OpenGL.Raw.AMD.MultiDrawIndirect,
        module Graphics.Rendering.OpenGL.Raw.AMD.NameGenDelete,
        module Graphics.Rendering.OpenGL.Raw.AMD.OcclusionQueryEvent,
        module Graphics.Rendering.OpenGL.Raw.AMD.PerformanceMonitor,
        module Graphics.Rendering.OpenGL.Raw.AMD.PinnedMemory,
        module Graphics.Rendering.OpenGL.Raw.AMD.QueryBufferObject,
        module Graphics.Rendering.OpenGL.Raw.AMD.SamplePositions,
        module Graphics.Rendering.OpenGL.Raw.AMD.SeamlessCubemapPerTexture,
        module Graphics.Rendering.OpenGL.Raw.AMD.SparseTexture,
        module Graphics.Rendering.OpenGL.Raw.AMD.StencilOperationExtended,
        module Graphics.Rendering.OpenGL.Raw.AMD.VertexShaderTessellator)
       where
import Graphics.Rendering.OpenGL.Raw.AMD.BlendMinmaxFactor
import Graphics.Rendering.OpenGL.Raw.AMD.DebugOutput
import Graphics.Rendering.OpenGL.Raw.AMD.DepthClampSeparate
import Graphics.Rendering.OpenGL.Raw.AMD.DrawBuffersBlend
import Graphics.Rendering.OpenGL.Raw.AMD.InterleavedElements
import Graphics.Rendering.OpenGL.Raw.AMD.MultiDrawIndirect
import Graphics.Rendering.OpenGL.Raw.AMD.NameGenDelete
import Graphics.Rendering.OpenGL.Raw.AMD.OcclusionQueryEvent
import Graphics.Rendering.OpenGL.Raw.AMD.PerformanceMonitor
import Graphics.Rendering.OpenGL.Raw.AMD.PinnedMemory
import Graphics.Rendering.OpenGL.Raw.AMD.QueryBufferObject
import Graphics.Rendering.OpenGL.Raw.AMD.SamplePositions
import Graphics.Rendering.OpenGL.Raw.AMD.SeamlessCubemapPerTexture
import Graphics.Rendering.OpenGL.Raw.AMD.SparseTexture
import Graphics.Rendering.OpenGL.Raw.AMD.StencilOperationExtended
import Graphics.Rendering.OpenGL.Raw.AMD.VertexShaderTessellator