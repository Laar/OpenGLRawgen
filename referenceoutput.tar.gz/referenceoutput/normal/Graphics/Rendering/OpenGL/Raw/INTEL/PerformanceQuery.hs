{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.INTEL.PerformanceQuery
       (gl_PERFQUERY_COUNTER_DATA_BOOL32_INTEL,
        gl_PERFQUERY_COUNTER_DATA_DOUBLE_INTEL,
        gl_PERFQUERY_COUNTER_DATA_FLOAT_INTEL,
        gl_PERFQUERY_COUNTER_DATA_UINT32_INTEL,
        gl_PERFQUERY_COUNTER_DATA_UINT64_INTEL,
        gl_PERFQUERY_COUNTER_DESC_LENGTH_MAX_INTEL,
        gl_PERFQUERY_COUNTER_DURATION_NORM_INTEL,
        gl_PERFQUERY_COUNTER_DURATION_RAW_INTEL,
        gl_PERFQUERY_COUNTER_EVENT_INTEL,
        gl_PERFQUERY_COUNTER_NAME_LENGTH_MAX_INTEL,
        gl_PERFQUERY_COUNTER_RAW_INTEL,
        gl_PERFQUERY_COUNTER_THROUGHPUT_INTEL,
        gl_PERFQUERY_COUNTER_TIMESTAMP_INTEL,
        gl_PERFQUERY_DONOT_FLUSH_INTEL, gl_PERFQUERY_FLUSH_INTEL,
        gl_PERFQUERY_GLOBAL_CONTEXT_INTEL,
        gl_PERFQUERY_GPA_EXTENDED_COUNTERS_INTEL,
        gl_PERFQUERY_QUERY_NAME_LENGTH_MAX_INTEL,
        gl_PERFQUERY_SINGLE_CONTEXT_INTEL, gl_PERFQUERY_WAIT_INTEL,
        glBeginPerfQueryINTEL, glCreatePerfQueryINTEL,
        glDeletePerfQueryINTEL, glEndPerfQueryINTEL,
        glGetFirstPerfQueryIdINTEL, glGetNextPerfQueryIdINTEL,
        glGetPerfCounterInfoINTEL, glGetPerfQueryDataINTEL,
        glGetPerfQueryIdByNameINTEL, glGetPerfQueryInfoINTEL)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PERFQUERY_COUNTER_DATA_BOOL32_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DATA_BOOL32_INTEL = 38140
 
gl_PERFQUERY_COUNTER_DATA_DOUBLE_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DATA_DOUBLE_INTEL = 38139
 
gl_PERFQUERY_COUNTER_DATA_FLOAT_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DATA_FLOAT_INTEL = 38138
 
gl_PERFQUERY_COUNTER_DATA_UINT32_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DATA_UINT32_INTEL = 38136
 
gl_PERFQUERY_COUNTER_DATA_UINT64_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DATA_UINT64_INTEL = 38137
 
gl_PERFQUERY_COUNTER_DESC_LENGTH_MAX_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DESC_LENGTH_MAX_INTEL = 38143
 
gl_PERFQUERY_COUNTER_DURATION_NORM_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DURATION_NORM_INTEL = 38129
 
gl_PERFQUERY_COUNTER_DURATION_RAW_INTEL :: GLenum
gl_PERFQUERY_COUNTER_DURATION_RAW_INTEL = 38130
 
gl_PERFQUERY_COUNTER_EVENT_INTEL :: GLenum
gl_PERFQUERY_COUNTER_EVENT_INTEL = 38128
 
gl_PERFQUERY_COUNTER_NAME_LENGTH_MAX_INTEL :: GLenum
gl_PERFQUERY_COUNTER_NAME_LENGTH_MAX_INTEL = 38142
 
gl_PERFQUERY_COUNTER_RAW_INTEL :: GLenum
gl_PERFQUERY_COUNTER_RAW_INTEL = 38132
 
gl_PERFQUERY_COUNTER_THROUGHPUT_INTEL :: GLenum
gl_PERFQUERY_COUNTER_THROUGHPUT_INTEL = 38131
 
gl_PERFQUERY_COUNTER_TIMESTAMP_INTEL :: GLenum
gl_PERFQUERY_COUNTER_TIMESTAMP_INTEL = 38133
 
gl_PERFQUERY_DONOT_FLUSH_INTEL :: GLenum
gl_PERFQUERY_DONOT_FLUSH_INTEL = 33785
 
gl_PERFQUERY_FLUSH_INTEL :: GLenum
gl_PERFQUERY_FLUSH_INTEL = 33786
 
gl_PERFQUERY_GLOBAL_CONTEXT_INTEL :: GLenum
gl_PERFQUERY_GLOBAL_CONTEXT_INTEL = 1
 
gl_PERFQUERY_GPA_EXTENDED_COUNTERS_INTEL :: GLenum
gl_PERFQUERY_GPA_EXTENDED_COUNTERS_INTEL = 38144
 
gl_PERFQUERY_QUERY_NAME_LENGTH_MAX_INTEL :: GLenum
gl_PERFQUERY_QUERY_NAME_LENGTH_MAX_INTEL = 38141
 
gl_PERFQUERY_SINGLE_CONTEXT_INTEL :: GLenum
gl_PERFQUERY_SINGLE_CONTEXT_INTEL = 0
 
gl_PERFQUERY_WAIT_INTEL :: GLenum
gl_PERFQUERY_WAIT_INTEL = 33787
 
foreign import CALLCONV unsafe "dynamic" dyn_glBeginPerfQueryINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBeginPerfQueryINTEL :: GLuint -> IO ()
glBeginPerfQueryINTEL
  = dyn_glBeginPerfQueryINTEL ptr_glBeginPerfQueryINTEL
 
{-# NOINLINE ptr_glBeginPerfQueryINTEL #-}
 
ptr_glBeginPerfQueryINTEL :: FunPtr a
ptr_glBeginPerfQueryINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glBeginPerfQueryINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCreatePerfQueryINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glCreatePerfQueryINTEL :: GLuint -> Ptr GLuint -> IO ()
glCreatePerfQueryINTEL
  = dyn_glCreatePerfQueryINTEL ptr_glCreatePerfQueryINTEL
 
{-# NOINLINE ptr_glCreatePerfQueryINTEL #-}
 
ptr_glCreatePerfQueryINTEL :: FunPtr a
ptr_glCreatePerfQueryINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glCreatePerfQueryINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeletePerfQueryINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glDeletePerfQueryINTEL :: GLuint -> IO ()
glDeletePerfQueryINTEL
  = dyn_glDeletePerfQueryINTEL ptr_glDeletePerfQueryINTEL
 
{-# NOINLINE ptr_glDeletePerfQueryINTEL #-}
 
ptr_glDeletePerfQueryINTEL :: FunPtr a
ptr_glDeletePerfQueryINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glDeletePerfQueryINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndPerfQueryINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glEndPerfQueryINTEL :: GLuint -> IO ()
glEndPerfQueryINTEL
  = dyn_glEndPerfQueryINTEL ptr_glEndPerfQueryINTEL
 
{-# NOINLINE ptr_glEndPerfQueryINTEL #-}
 
ptr_glEndPerfQueryINTEL :: FunPtr a
ptr_glEndPerfQueryINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glEndPerfQueryINTEL"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFirstPerfQueryIdINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> IO ())
 
glGetFirstPerfQueryIdINTEL :: Ptr GLuint -> IO ()
glGetFirstPerfQueryIdINTEL
  = dyn_glGetFirstPerfQueryIdINTEL ptr_glGetFirstPerfQueryIdINTEL
 
{-# NOINLINE ptr_glGetFirstPerfQueryIdINTEL #-}
 
ptr_glGetFirstPerfQueryIdINTEL :: FunPtr a
ptr_glGetFirstPerfQueryIdINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetFirstPerfQueryIdINTEL"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNextPerfQueryIdINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glGetNextPerfQueryIdINTEL :: GLuint -> Ptr GLuint -> IO ()
glGetNextPerfQueryIdINTEL
  = dyn_glGetNextPerfQueryIdINTEL ptr_glGetNextPerfQueryIdINTEL
 
{-# NOINLINE ptr_glGetNextPerfQueryIdINTEL #-}
 
ptr_glGetNextPerfQueryIdINTEL :: FunPtr a
ptr_glGetNextPerfQueryIdINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetNextPerfQueryIdINTEL"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfCounterInfoINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLuint ->
                        Ptr GLchar ->
                          GLuint ->
                            Ptr GLchar ->
                              Ptr GLuint ->
                                Ptr GLuint -> Ptr GLuint -> Ptr GLuint -> Ptr GLuint64 -> IO ())
 
glGetPerfCounterInfoINTEL ::
                          GLuint ->
                            GLuint ->
                              GLuint ->
                                Ptr GLchar ->
                                  GLuint ->
                                    Ptr GLchar ->
                                      Ptr GLuint ->
                                        Ptr GLuint ->
                                          Ptr GLuint -> Ptr GLuint -> Ptr GLuint64 -> IO ()
glGetPerfCounterInfoINTEL
  = dyn_glGetPerfCounterInfoINTEL ptr_glGetPerfCounterInfoINTEL
 
{-# NOINLINE ptr_glGetPerfCounterInfoINTEL #-}
 
ptr_glGetPerfCounterInfoINTEL :: FunPtr a
ptr_glGetPerfCounterInfoINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetPerfCounterInfoINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetPerfQueryDataINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> Ptr e -> Ptr GLuint -> IO ())
 
glGetPerfQueryDataINTEL ::
                        GLuint -> GLuint -> GLsizei -> Ptr e -> Ptr GLuint -> IO ()
glGetPerfQueryDataINTEL
  = dyn_glGetPerfQueryDataINTEL ptr_glGetPerfQueryDataINTEL
 
{-# NOINLINE ptr_glGetPerfQueryDataINTEL #-}
 
ptr_glGetPerfQueryDataINTEL :: FunPtr a
ptr_glGetPerfQueryDataINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetPerfQueryDataINTEL"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPerfQueryIdByNameINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLchar -> Ptr GLuint -> IO ())
 
glGetPerfQueryIdByNameINTEL :: Ptr GLchar -> Ptr GLuint -> IO ()
glGetPerfQueryIdByNameINTEL
  = dyn_glGetPerfQueryIdByNameINTEL ptr_glGetPerfQueryIdByNameINTEL
 
{-# NOINLINE ptr_glGetPerfQueryIdByNameINTEL #-}
 
ptr_glGetPerfQueryIdByNameINTEL :: FunPtr a
ptr_glGetPerfQueryIdByNameINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetPerfQueryIdByNameINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetPerfQueryInfoINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      Ptr GLchar ->
                        Ptr GLuint -> Ptr GLuint -> Ptr GLuint -> Ptr GLuint -> IO ())
 
glGetPerfQueryInfoINTEL ::
                        GLuint ->
                          GLuint ->
                            Ptr GLchar ->
                              Ptr GLuint -> Ptr GLuint -> Ptr GLuint -> Ptr GLuint -> IO ()
glGetPerfQueryInfoINTEL
  = dyn_glGetPerfQueryInfoINTEL ptr_glGetPerfQueryInfoINTEL
 
{-# NOINLINE ptr_glGetPerfQueryInfoINTEL #-}
 
ptr_glGetPerfQueryInfoINTEL :: FunPtr a
ptr_glGetPerfQueryInfoINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_performance_query"
        "glGetPerfQueryInfoINTEL"