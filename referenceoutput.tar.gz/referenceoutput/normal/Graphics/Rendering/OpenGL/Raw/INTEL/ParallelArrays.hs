{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.INTEL.ParallelArrays
       (gl_COLOR_ARRAY_PARALLEL_POINTERS_INTEL,
        gl_NORMAL_ARRAY_PARALLEL_POINTERS_INTEL, gl_PARALLEL_ARRAYS_INTEL,
        gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS_INTEL,
        gl_VERTEX_ARRAY_PARALLEL_POINTERS_INTEL, glColorPointervINTEL,
        glNormalPointervINTEL, glTexCoordPointervINTEL,
        glVertexPointervINTEL)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_COLOR_ARRAY_PARALLEL_POINTERS_INTEL :: GLenum
gl_COLOR_ARRAY_PARALLEL_POINTERS_INTEL = 33783
 
gl_NORMAL_ARRAY_PARALLEL_POINTERS_INTEL :: GLenum
gl_NORMAL_ARRAY_PARALLEL_POINTERS_INTEL = 33782
 
gl_PARALLEL_ARRAYS_INTEL :: GLenum
gl_PARALLEL_ARRAYS_INTEL = 33780
 
gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS_INTEL :: GLenum
gl_TEXTURE_COORD_ARRAY_PARALLEL_POINTERS_INTEL = 33784
 
gl_VERTEX_ARRAY_PARALLEL_POINTERS_INTEL :: GLenum
gl_VERTEX_ARRAY_PARALLEL_POINTERS_INTEL = 33781
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorPointervINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glColorPointervINTEL :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glColorPointervINTEL
  = dyn_glColorPointervINTEL ptr_glColorPointervINTEL
 
{-# NOINLINE ptr_glColorPointervINTEL #-}
 
ptr_glColorPointervINTEL :: FunPtr a
ptr_glColorPointervINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glColorPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalPointervINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr (Ptr c) -> IO ())
 
glNormalPointervINTEL :: GLenum -> Ptr (Ptr c) -> IO ()
glNormalPointervINTEL
  = dyn_glNormalPointervINTEL ptr_glNormalPointervINTEL
 
{-# NOINLINE ptr_glNormalPointervINTEL #-}
 
ptr_glNormalPointervINTEL :: FunPtr a
ptr_glNormalPointervINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glNormalPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordPointervINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glTexCoordPointervINTEL :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glTexCoordPointervINTEL
  = dyn_glTexCoordPointervINTEL ptr_glTexCoordPointervINTEL
 
{-# NOINLINE ptr_glTexCoordPointervINTEL #-}
 
ptr_glTexCoordPointervINTEL :: FunPtr a
ptr_glTexCoordPointervINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glTexCoordPointervINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexPointervINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glVertexPointervINTEL :: GLint -> GLenum -> Ptr (Ptr d) -> IO ()
glVertexPointervINTEL
  = dyn_glVertexPointervINTEL ptr_glVertexPointervINTEL
 
{-# NOINLINE ptr_glVertexPointervINTEL #-}
 
ptr_glVertexPointervINTEL :: FunPtr a
ptr_glVertexPointervINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_parallel_arrays"
        "glVertexPointervINTEL"