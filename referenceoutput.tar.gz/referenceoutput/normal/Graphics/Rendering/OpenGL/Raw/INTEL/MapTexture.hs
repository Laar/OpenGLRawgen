{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.INTEL.MapTexture
       (gl_LAYOUT_DEFAULT_INTEL, gl_LAYOUT_LINEAR_CPU_CACHED_INTEL,
        gl_LAYOUT_LINEAR_INTEL, gl_TEXTURE_MEMORY_LAYOUT_INTEL,
        glMapTexture2DINTEL, glSyncTextureINTEL, glUnmapTexture2DINTEL)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_LAYOUT_DEFAULT_INTEL :: GLenum
gl_LAYOUT_DEFAULT_INTEL = 0
 
gl_LAYOUT_LINEAR_CPU_CACHED_INTEL :: GLenum
gl_LAYOUT_LINEAR_CPU_CACHED_INTEL = 2
 
gl_LAYOUT_LINEAR_INTEL :: GLenum
gl_LAYOUT_LINEAR_INTEL = 1
 
gl_TEXTURE_MEMORY_LAYOUT_INTEL :: GLenum
gl_TEXTURE_MEMORY_LAYOUT_INTEL = 33791
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapTexture2DINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLbitfield -> Ptr GLint -> Ptr GLenum -> IO (Ptr a))
 
glMapTexture2DINTEL ::
                    GLuint ->
                      GLint -> GLbitfield -> Ptr GLint -> Ptr GLenum -> IO (Ptr a)
glMapTexture2DINTEL
  = dyn_glMapTexture2DINTEL ptr_glMapTexture2DINTEL
 
{-# NOINLINE ptr_glMapTexture2DINTEL #-}
 
ptr_glMapTexture2DINTEL :: FunPtr a
ptr_glMapTexture2DINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_map_texture"
        "glMapTexture2DINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSyncTextureINTEL ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glSyncTextureINTEL :: GLuint -> IO ()
glSyncTextureINTEL = dyn_glSyncTextureINTEL ptr_glSyncTextureINTEL
 
{-# NOINLINE ptr_glSyncTextureINTEL #-}
 
ptr_glSyncTextureINTEL :: FunPtr a
ptr_glSyncTextureINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_map_texture"
        "glSyncTextureINTEL"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnmapTexture2DINTEL
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> IO ())
 
glUnmapTexture2DINTEL :: GLuint -> GLint -> IO ()
glUnmapTexture2DINTEL
  = dyn_glUnmapTexture2DINTEL ptr_glUnmapTexture2DINTEL
 
{-# NOINLINE ptr_glUnmapTexture2DINTEL #-}
 
ptr_glUnmapTexture2DINTEL :: FunPtr a
ptr_glUnmapTexture2DINTEL
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INTEL_map_texture"
        "glUnmapTexture2DINTEL"