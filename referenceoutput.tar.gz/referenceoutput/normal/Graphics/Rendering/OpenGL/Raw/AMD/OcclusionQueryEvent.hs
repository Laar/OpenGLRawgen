{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.OcclusionQueryEvent
       (gl_OCCLUSION_QUERY_EVENT_MASK_AMD, gl_QUERY_ALL_EVENT_BITS_AMD,
        gl_QUERY_DEPTH_BOUNDS_FAIL_EVENT_BIT_AMD,
        gl_QUERY_DEPTH_FAIL_EVENT_BIT_AMD,
        gl_QUERY_DEPTH_PASS_EVENT_BIT_AMD,
        gl_QUERY_STENCIL_FAIL_EVENT_BIT_AMD, glQueryObjectParameteruiAMD)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_OCCLUSION_QUERY_EVENT_MASK_AMD :: GLenum
gl_OCCLUSION_QUERY_EVENT_MASK_AMD = 34639
 
gl_QUERY_ALL_EVENT_BITS_AMD :: GLenum
gl_QUERY_ALL_EVENT_BITS_AMD = 4294967295
 
gl_QUERY_DEPTH_BOUNDS_FAIL_EVENT_BIT_AMD :: GLenum
gl_QUERY_DEPTH_BOUNDS_FAIL_EVENT_BIT_AMD = 8
 
gl_QUERY_DEPTH_FAIL_EVENT_BIT_AMD :: GLenum
gl_QUERY_DEPTH_FAIL_EVENT_BIT_AMD = 2
 
gl_QUERY_DEPTH_PASS_EVENT_BIT_AMD :: GLenum
gl_QUERY_DEPTH_PASS_EVENT_BIT_AMD = 1
 
gl_QUERY_STENCIL_FAIL_EVENT_BIT_AMD :: GLenum
gl_QUERY_STENCIL_FAIL_EVENT_BIT_AMD = 4
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glQueryObjectParameteruiAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> GLuint -> IO ())
 
glQueryObjectParameteruiAMD ::
                            GLenum -> GLuint -> GLenum -> GLuint -> IO ()
glQueryObjectParameteruiAMD
  = dyn_glQueryObjectParameteruiAMD ptr_glQueryObjectParameteruiAMD
 
{-# NOINLINE ptr_glQueryObjectParameteruiAMD #-}
 
ptr_glQueryObjectParameteruiAMD :: FunPtr a
ptr_glQueryObjectParameteruiAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_occlusion_query_event"
        "glQueryObjectParameteruiAMD"