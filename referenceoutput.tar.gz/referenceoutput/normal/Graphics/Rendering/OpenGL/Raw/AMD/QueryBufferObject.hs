module Graphics.Rendering.OpenGL.Raw.AMD.QueryBufferObject
       (gl_QUERY_BUFFER_AMD, gl_QUERY_BUFFER_BINDING_AMD,
        gl_QUERY_RESULT_NO_WAIT_AMD)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_QUERY_BUFFER_AMD :: GLenum
gl_QUERY_BUFFER_AMD = 37266
 
gl_QUERY_BUFFER_BINDING_AMD :: GLenum
gl_QUERY_BUFFER_BINDING_AMD = 37267
 
gl_QUERY_RESULT_NO_WAIT_AMD :: GLenum
gl_QUERY_RESULT_NO_WAIT_AMD = 37268