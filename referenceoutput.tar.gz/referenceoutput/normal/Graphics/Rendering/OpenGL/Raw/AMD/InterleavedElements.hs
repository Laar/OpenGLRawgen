{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.InterleavedElements
       (gl_ALPHA, gl_BLUE, gl_GREEN, gl_RED, gl_RG16UI, gl_RG8UI,
        gl_RGBA8UI, gl_VERTEX_ELEMENT_SWIZZLE_AMD,
        gl_VERTEX_ID_SWIZZLE_AMD, glVertexAttribParameteriAMD)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Core.Core11
       (gl_ALPHA, gl_BLUE, gl_GREEN, gl_RED)
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_RG16UI, gl_RG8UI, gl_RGBA8UI)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_VERTEX_ELEMENT_SWIZZLE_AMD :: GLenum
gl_VERTEX_ELEMENT_SWIZZLE_AMD = 37284
 
gl_VERTEX_ID_SWIZZLE_AMD :: GLenum
gl_VERTEX_ID_SWIZZLE_AMD = 37285
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexAttribParameteriAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
glVertexAttribParameteriAMD :: GLuint -> GLenum -> GLint -> IO ()
glVertexAttribParameteriAMD
  = dyn_glVertexAttribParameteriAMD ptr_glVertexAttribParameteriAMD
 
{-# NOINLINE ptr_glVertexAttribParameteriAMD #-}
 
ptr_glVertexAttribParameteriAMD :: FunPtr a
ptr_glVertexAttribParameteriAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_interleaved_elements"
        "glVertexAttribParameteriAMD"