{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.NameGenDelete
       (gl_DATA_BUFFER_AMD, gl_PERFORMANCE_MONITOR_AMD,
        gl_QUERY_OBJECT_AMD, gl_SAMPLER_OBJECT_AMD,
        gl_VERTEX_ARRAY_OBJECT_AMD, glDeleteNamesAMD, glGenNamesAMD,
        glIsNameAMD)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DATA_BUFFER_AMD :: GLenum
gl_DATA_BUFFER_AMD = 37201
 
gl_PERFORMANCE_MONITOR_AMD :: GLenum
gl_PERFORMANCE_MONITOR_AMD = 37202
 
gl_QUERY_OBJECT_AMD :: GLenum
gl_QUERY_OBJECT_AMD = 37203
 
gl_SAMPLER_OBJECT_AMD :: GLenum
gl_SAMPLER_OBJECT_AMD = 37205
 
gl_VERTEX_ARRAY_OBJECT_AMD :: GLenum
gl_VERTEX_ARRAY_OBJECT_AMD = 37204
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteNamesAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glDeleteNamesAMD :: GLenum -> GLuint -> Ptr GLuint -> IO ()
glDeleteNamesAMD = dyn_glDeleteNamesAMD ptr_glDeleteNamesAMD
 
{-# NOINLINE ptr_glDeleteNamesAMD #-}
 
ptr_glDeleteNamesAMD :: FunPtr a
ptr_glDeleteNamesAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glDeleteNamesAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenNamesAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glGenNamesAMD :: GLenum -> GLuint -> Ptr GLuint -> IO ()
glGenNamesAMD = dyn_glGenNamesAMD ptr_glGenNamesAMD
 
{-# NOINLINE ptr_glGenNamesAMD #-}
 
ptr_glGenNamesAMD :: FunPtr a
ptr_glGenNamesAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glGenNamesAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsNameAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsNameAMD :: GLenum -> GLuint -> IO GLboolean
glIsNameAMD = dyn_glIsNameAMD ptr_glIsNameAMD
 
{-# NOINLINE ptr_glIsNameAMD #-}
 
ptr_glIsNameAMD :: FunPtr a
ptr_glIsNameAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_name_gen_delete"
        "glIsNameAMD"