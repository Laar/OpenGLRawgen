-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.BlendMinmaxFactor
       (gl_FACTOR_MAX_AMD, gl_FACTOR_MIN_AMD) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FACTOR_MAX_AMD :: GLenum
gl_FACTOR_MAX_AMD = 36893
 
gl_FACTOR_MIN_AMD :: GLenum
gl_FACTOR_MIN_AMD = 36892