module Graphics.Rendering.OpenGL.Raw.AMD.BlendMinmaxFactor
       (gl_FACTOR_MIN_AMD, gl_FACTOR_MAX_AMD) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FACTOR_MIN_AMD :: GLenum
gl_FACTOR_MIN_AMD = 36892
 
gl_FACTOR_MAX_AMD :: GLenum
gl_FACTOR_MAX_AMD = 36893