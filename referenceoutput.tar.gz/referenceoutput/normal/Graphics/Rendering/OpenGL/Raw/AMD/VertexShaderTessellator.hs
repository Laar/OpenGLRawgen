{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.VertexShaderTessellator
       (gl_CONTINUOUS_AMD, gl_DISCRETE_AMD, gl_INT_SAMPLER_BUFFER_AMD,
        gl_SAMPLER_BUFFER_AMD, gl_TESSELLATION_FACTOR_AMD,
        gl_TESSELLATION_MODE_AMD, gl_UNSIGNED_INT_SAMPLER_BUFFER_AMD,
        glTessellationFactorAMD, glTessellationModeAMD)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CONTINUOUS_AMD :: GLenum
gl_CONTINUOUS_AMD = 36871
 
gl_DISCRETE_AMD :: GLenum
gl_DISCRETE_AMD = 36870
 
gl_INT_SAMPLER_BUFFER_AMD :: GLenum
gl_INT_SAMPLER_BUFFER_AMD = 36866
 
gl_SAMPLER_BUFFER_AMD :: GLenum
gl_SAMPLER_BUFFER_AMD = 36865
 
gl_TESSELLATION_FACTOR_AMD :: GLenum
gl_TESSELLATION_FACTOR_AMD = 36869
 
gl_TESSELLATION_MODE_AMD :: GLenum
gl_TESSELLATION_MODE_AMD = 36868
 
gl_UNSIGNED_INT_SAMPLER_BUFFER_AMD :: GLenum
gl_UNSIGNED_INT_SAMPLER_BUFFER_AMD = 36867
 
foreign import CALLCONV unsafe "dynamic" dyn_glTessellationFactorAMD
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glTessellationFactorAMD :: GLfloat -> IO ()
glTessellationFactorAMD
  = dyn_glTessellationFactorAMD ptr_glTessellationFactorAMD
 
{-# NOINLINE ptr_glTessellationFactorAMD #-}
 
ptr_glTessellationFactorAMD :: FunPtr a
ptr_glTessellationFactorAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_vertex_shader_tessellator"
        "glTessellationFactorAMD"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTessellationModeAMD
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glTessellationModeAMD :: GLenum -> IO ()
glTessellationModeAMD
  = dyn_glTessellationModeAMD ptr_glTessellationModeAMD
 
{-# NOINLINE ptr_glTessellationModeAMD #-}
 
ptr_glTessellationModeAMD :: FunPtr a
ptr_glTessellationModeAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_vertex_shader_tessellator"
        "glTessellationModeAMD"