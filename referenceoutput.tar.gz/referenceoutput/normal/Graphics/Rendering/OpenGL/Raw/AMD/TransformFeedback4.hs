-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.TransformFeedback4
       (gl_STREAM_RASTERIZATION_AMD) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_STREAM_RASTERIZATION_AMD :: GLenum
gl_STREAM_RASTERIZATION_AMD = 37280