{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.SamplePositions
       (gl_SUBSAMPLE_DISTANCE_AMD, glSetMultisamplefvAMD) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SUBSAMPLE_DISTANCE_AMD :: GLenum
gl_SUBSAMPLE_DISTANCE_AMD = 34879
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetMultisamplefvAMD
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glSetMultisamplefvAMD :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glSetMultisamplefvAMD
  = dyn_glSetMultisamplefvAMD ptr_glSetMultisamplefvAMD
 
{-# NOINLINE ptr_glSetMultisamplefvAMD #-}
 
ptr_glSetMultisamplefvAMD :: FunPtr a
ptr_glSetMultisamplefvAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_sample_positions"
        "glSetMultisamplefvAMD"