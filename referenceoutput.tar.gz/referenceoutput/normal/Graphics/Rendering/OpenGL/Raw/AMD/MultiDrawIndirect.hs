{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.AMD.MultiDrawIndirect
       (glMultiDrawArraysIndirectAMD, glMultiDrawElementsIndirectAMD)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawArraysIndirectAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawArraysIndirectAMD ::
                             GLenum -> Ptr a -> GLsizei -> GLsizei -> IO ()
glMultiDrawArraysIndirectAMD
  = dyn_glMultiDrawArraysIndirectAMD ptr_glMultiDrawArraysIndirectAMD
 
{-# NOINLINE ptr_glMultiDrawArraysIndirectAMD #-}
 
ptr_glMultiDrawArraysIndirectAMD :: FunPtr a
ptr_glMultiDrawArraysIndirectAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_multi_draw_indirect"
        "glMultiDrawArraysIndirectAMD"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementsIndirectAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr a -> GLsizei -> GLsizei -> IO ())
 
glMultiDrawElementsIndirectAMD ::
                               GLenum -> GLenum -> Ptr a -> GLsizei -> GLsizei -> IO ()
glMultiDrawElementsIndirectAMD
  = dyn_glMultiDrawElementsIndirectAMD
      ptr_glMultiDrawElementsIndirectAMD
 
{-# NOINLINE ptr_glMultiDrawElementsIndirectAMD #-}
 
ptr_glMultiDrawElementsIndirectAMD :: FunPtr a
ptr_glMultiDrawElementsIndirectAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_multi_draw_indirect"
        "glMultiDrawElementsIndirectAMD"