{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.StencilOperationExtended
       (gl_REPLACE_VALUE_AMD, gl_SET_AMD, gl_STENCIL_BACK_OP_VALUE_AMD,
        gl_STENCIL_OP_VALUE_AMD, glStencilOpValueAMD)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_REPLACE_VALUE_AMD :: GLenum
gl_REPLACE_VALUE_AMD = 34635
 
gl_SET_AMD :: GLenum
gl_SET_AMD = 34634
 
gl_STENCIL_BACK_OP_VALUE_AMD :: GLenum
gl_STENCIL_BACK_OP_VALUE_AMD = 34637
 
gl_STENCIL_OP_VALUE_AMD :: GLenum
gl_STENCIL_OP_VALUE_AMD = 34636
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilOpValueAMD ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glStencilOpValueAMD :: GLenum -> GLuint -> IO ()
glStencilOpValueAMD
  = dyn_glStencilOpValueAMD ptr_glStencilOpValueAMD
 
{-# NOINLINE ptr_glStencilOpValueAMD #-}
 
ptr_glStencilOpValueAMD :: FunPtr a
ptr_glStencilOpValueAMD
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_AMD_stencil_operation_extended"
        "glStencilOpValueAMD"