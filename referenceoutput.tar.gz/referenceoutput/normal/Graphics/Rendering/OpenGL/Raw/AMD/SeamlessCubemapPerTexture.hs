-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.AMD.SeamlessCubemapPerTexture
       (gl_TEXTURE_CUBE_MAP_SEAMLESS) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_TEXTURE_CUBE_MAP_SEAMLESS)