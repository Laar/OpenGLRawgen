{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.TimerQuery
       (gl_TIME_ELAPSED_EXT, glGetQueryObjecti64vEXT,
        glGetQueryObjectui64vEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TIME_ELAPSED_EXT :: GLenum
gl_TIME_ELAPSED_EXT = 35007
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjecti64vEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint64 -> IO ())
 
glGetQueryObjecti64vEXT :: GLuint -> GLenum -> Ptr GLint64 -> IO ()
glGetQueryObjecti64vEXT
  = dyn_glGetQueryObjecti64vEXT ptr_glGetQueryObjecti64vEXT
 
{-# NOINLINE ptr_glGetQueryObjecti64vEXT #-}
 
ptr_glGetQueryObjecti64vEXT :: FunPtr a
ptr_glGetQueryObjecti64vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_timer_query"
        "glGetQueryObjecti64vEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetQueryObjectui64vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint64 -> IO ())
 
glGetQueryObjectui64vEXT ::
                         GLuint -> GLenum -> Ptr GLuint64 -> IO ()
glGetQueryObjectui64vEXT
  = dyn_glGetQueryObjectui64vEXT ptr_glGetQueryObjectui64vEXT
 
{-# NOINLINE ptr_glGetQueryObjectui64vEXT #-}
 
ptr_glGetQueryObjectui64vEXT :: FunPtr a
ptr_glGetQueryObjectui64vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_timer_query"
        "glGetQueryObjectui64vEXT"