{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.SeparateShaderObjects
       (gl_ACTIVE_PROGRAM_EXT, glActiveProgramEXT,
        glCreateShaderProgramEXT, glUseShaderProgramEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ACTIVE_PROGRAM_EXT :: GLenum
gl_ACTIVE_PROGRAM_EXT = 33369
 
foreign import CALLCONV unsafe "dynamic" dyn_glActiveProgramEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glActiveProgramEXT :: GLuint -> IO ()
glActiveProgramEXT = dyn_glActiveProgramEXT ptr_glActiveProgramEXT
 
{-# NOINLINE ptr_glActiveProgramEXT #-}
 
ptr_glActiveProgramEXT :: FunPtr a
ptr_glActiveProgramEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_separate_shader_objects"
        "glActiveProgramEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCreateShaderProgramEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLchar -> IO GLuint)
 
glCreateShaderProgramEXT :: GLenum -> Ptr GLchar -> IO GLuint
glCreateShaderProgramEXT
  = dyn_glCreateShaderProgramEXT ptr_glCreateShaderProgramEXT
 
{-# NOINLINE ptr_glCreateShaderProgramEXT #-}
 
ptr_glCreateShaderProgramEXT :: FunPtr a
ptr_glCreateShaderProgramEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_separate_shader_objects"
        "glCreateShaderProgramEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUseShaderProgramEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glUseShaderProgramEXT :: GLenum -> GLuint -> IO ()
glUseShaderProgramEXT
  = dyn_glUseShaderProgramEXT ptr_glUseShaderProgramEXT
 
{-# NOINLINE ptr_glUseShaderProgramEXT #-}
 
ptr_glUseShaderProgramEXT :: FunPtr a
ptr_glUseShaderProgramEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_separate_shader_objects"
        "glUseShaderProgramEXT"