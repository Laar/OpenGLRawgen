{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferBlit
       (gl_DRAW_FRAMEBUFFER_BINDING_EXT, gl_DRAW_FRAMEBUFFER_EXT,
        gl_READ_FRAMEBUFFER_BINDING_EXT, gl_READ_FRAMEBUFFER_EXT,
        glBlitFramebufferEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DRAW_FRAMEBUFFER_BINDING_EXT :: GLenum
gl_DRAW_FRAMEBUFFER_BINDING_EXT = 36006
 
gl_DRAW_FRAMEBUFFER_EXT :: GLenum
gl_DRAW_FRAMEBUFFER_EXT = 36009
 
gl_READ_FRAMEBUFFER_BINDING_EXT :: GLenum
gl_READ_FRAMEBUFFER_BINDING_EXT = 36010
 
gl_READ_FRAMEBUFFER_EXT :: GLenum
gl_READ_FRAMEBUFFER_EXT = 36008
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlitFramebufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLbitfield -> GLenum -> IO ())
 
glBlitFramebufferEXT ::
                     GLint ->
                       GLint ->
                         GLint ->
                           GLint ->
                             GLint -> GLint -> GLint -> GLint -> GLbitfield -> GLenum -> IO ()
glBlitFramebufferEXT
  = dyn_glBlitFramebufferEXT ptr_glBlitFramebufferEXT
 
{-# NOINLINE ptr_glBlitFramebufferEXT #-}
 
ptr_glBlitFramebufferEXT :: FunPtr a
ptr_glBlitFramebufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_framebuffer_blit"
        "glBlitFramebufferEXT"