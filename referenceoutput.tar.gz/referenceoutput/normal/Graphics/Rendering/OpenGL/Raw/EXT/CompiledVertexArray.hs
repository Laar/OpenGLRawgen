{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.CompiledVertexArray
       (gl_ARRAY_ELEMENT_LOCK_COUNT_EXT, gl_ARRAY_ELEMENT_LOCK_FIRST_EXT,
        glLockArraysEXT, glUnlockArraysEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ARRAY_ELEMENT_LOCK_COUNT_EXT :: GLenum
gl_ARRAY_ELEMENT_LOCK_COUNT_EXT = 33193
 
gl_ARRAY_ELEMENT_LOCK_FIRST_EXT :: GLenum
gl_ARRAY_ELEMENT_LOCK_FIRST_EXT = 33192
 
foreign import CALLCONV unsafe "dynamic" dyn_glLockArraysEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> IO ())
 
glLockArraysEXT :: GLint -> GLsizei -> IO ()
glLockArraysEXT = dyn_glLockArraysEXT ptr_glLockArraysEXT
 
{-# NOINLINE ptr_glLockArraysEXT #-}
 
ptr_glLockArraysEXT :: FunPtr a
ptr_glLockArraysEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_compiled_vertex_array"
        "glLockArraysEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnlockArraysEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glUnlockArraysEXT :: IO ()
glUnlockArraysEXT = dyn_glUnlockArraysEXT ptr_glUnlockArraysEXT
 
{-# NOINLINE ptr_glUnlockArraysEXT #-}
 
ptr_glUnlockArraysEXT :: FunPtr a
ptr_glUnlockArraysEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_compiled_vertex_array"
        "glUnlockArraysEXT"