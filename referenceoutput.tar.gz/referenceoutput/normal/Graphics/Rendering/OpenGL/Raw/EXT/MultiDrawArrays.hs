{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.MultiDrawArrays
       (glMultiDrawArraysEXT, glMultiDrawElementsEXT) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiDrawArraysEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ())
 
glMultiDrawArraysEXT ::
                     GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ()
glMultiDrawArraysEXT
  = dyn_glMultiDrawArraysEXT ptr_glMultiDrawArraysEXT
 
{-# NOINLINE ptr_glMultiDrawArraysEXT #-}
 
ptr_glMultiDrawArraysEXT :: FunPtr a
ptr_glMultiDrawArraysEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_multi_draw_arrays"
        "glMultiDrawArraysEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiDrawElementsEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    Ptr GLsizei -> GLenum -> Ptr (Ptr e) -> GLsizei -> IO ())
 
glMultiDrawElementsEXT ::
                       GLenum -> Ptr GLsizei -> GLenum -> Ptr (Ptr e) -> GLsizei -> IO ()
glMultiDrawElementsEXT
  = dyn_glMultiDrawElementsEXT ptr_glMultiDrawElementsEXT
 
{-# NOINLINE ptr_glMultiDrawElementsEXT #-}
 
ptr_glMultiDrawElementsEXT :: FunPtr a
ptr_glMultiDrawElementsEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_multi_draw_arrays"
        "glMultiDrawElementsEXT"