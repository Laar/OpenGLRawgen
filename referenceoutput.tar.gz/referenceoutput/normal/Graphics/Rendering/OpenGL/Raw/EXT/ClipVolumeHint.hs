-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.ClipVolumeHint
       (gl_CLIP_VOLUME_CLIPPING_HINT_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CLIP_VOLUME_CLIPPING_HINT_EXT :: GLenum
gl_CLIP_VOLUME_CLIPPING_HINT_EXT = 33008