{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.IndexFunc
       (gl_INDEX_TEST_EXT, gl_INDEX_TEST_FUNC_EXT, gl_INDEX_TEST_REF_EXT,
        glIndexFuncEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_INDEX_TEST_EXT :: GLenum
gl_INDEX_TEST_EXT = 33205
 
gl_INDEX_TEST_FUNC_EXT :: GLenum
gl_INDEX_TEST_FUNC_EXT = 33206
 
gl_INDEX_TEST_REF_EXT :: GLenum
gl_INDEX_TEST_REF_EXT = 33207
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexFuncEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLclampf -> IO ())
 
glIndexFuncEXT :: GLenum -> GLclampf -> IO ()
glIndexFuncEXT = dyn_glIndexFuncEXT ptr_glIndexFuncEXT
 
{-# NOINLINE ptr_glIndexFuncEXT #-}
 
ptr_glIndexFuncEXT :: FunPtr a
ptr_glIndexFuncEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_index_func"
        "glIndexFuncEXT"