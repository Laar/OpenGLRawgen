{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.PolygonOffset
       (gl_POLYGON_OFFSET_BIAS_EXT, gl_POLYGON_OFFSET_EXT,
        gl_POLYGON_OFFSET_FACTOR_EXT, glPolygonOffsetEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_POLYGON_OFFSET_BIAS_EXT :: GLenum
gl_POLYGON_OFFSET_BIAS_EXT = 32825
 
gl_POLYGON_OFFSET_EXT :: GLenum
gl_POLYGON_OFFSET_EXT = 32823
 
gl_POLYGON_OFFSET_FACTOR_EXT :: GLenum
gl_POLYGON_OFFSET_FACTOR_EXT = 32824
 
foreign import CALLCONV unsafe "dynamic" dyn_glPolygonOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> IO ())
 
glPolygonOffsetEXT :: GLfloat -> GLfloat -> IO ()
glPolygonOffsetEXT = dyn_glPolygonOffsetEXT ptr_glPolygonOffsetEXT
 
{-# NOINLINE ptr_glPolygonOffsetEXT #-}
 
ptr_glPolygonOffsetEXT :: FunPtr a
ptr_glPolygonOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_polygon_offset"
        "glPolygonOffsetEXT"