module Graphics.Rendering.OpenGL.Raw.EXT.TextureEnvDot3
       (gl_DOT3_RGBA_EXT, gl_DOT3_RGB_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DOT3_RGBA_EXT :: GLenum
gl_DOT3_RGBA_EXT = 34625
 
gl_DOT3_RGB_EXT :: GLenum
gl_DOT3_RGB_EXT = 34624