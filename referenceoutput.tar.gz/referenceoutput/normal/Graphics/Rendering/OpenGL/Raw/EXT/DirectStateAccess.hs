{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.DirectStateAccess
       (gl_PROGRAM_MATRIX_EXT, gl_PROGRAM_MATRIX_STACK_DEPTH_EXT,
        gl_TRANSPOSE_PROGRAM_MATRIX_EXT, glBindMultiTextureEXT,
        glCheckNamedFramebufferStatusEXT, glClearNamedBufferDataEXT,
        glClearNamedBufferSubDataEXT, glClientAttribDefaultEXT,
        glCompressedMultiTexImage1DEXT, glCompressedMultiTexImage2DEXT,
        glCompressedMultiTexImage3DEXT, glCompressedMultiTexSubImage1DEXT,
        glCompressedMultiTexSubImage2DEXT,
        glCompressedMultiTexSubImage3DEXT, glCompressedTextureImage1DEXT,
        glCompressedTextureImage2DEXT, glCompressedTextureImage3DEXT,
        glCompressedTextureSubImage1DEXT, glCompressedTextureSubImage2DEXT,
        glCompressedTextureSubImage3DEXT, glCopyMultiTexImage1DEXT,
        glCopyMultiTexImage2DEXT, glCopyMultiTexSubImage1DEXT,
        glCopyMultiTexSubImage2DEXT, glCopyMultiTexSubImage3DEXT,
        glCopyTextureImage1DEXT, glCopyTextureImage2DEXT,
        glCopyTextureSubImage1DEXT, glCopyTextureSubImage2DEXT,
        glCopyTextureSubImage3DEXT, glDisableClientStateIndexedEXT,
        glDisableClientStateiEXT, glDisableIndexedEXT,
        glDisableVertexArrayAttribEXT, glDisableVertexArrayEXT,
        glEnableClientStateIndexedEXT, glEnableClientStateiEXT,
        glEnableIndexedEXT, glEnableVertexArrayAttribEXT,
        glEnableVertexArrayEXT, glFlushMappedNamedBufferRangeEXT,
        glFramebufferDrawBufferEXT, glFramebufferDrawBuffersEXT,
        glFramebufferReadBufferEXT, glGenerateMultiTexMipmapEXT,
        glGenerateTextureMipmapEXT, glGetBooleanIndexedvEXT,
        glGetCompressedMultiTexImageEXT, glGetCompressedTextureImageEXT,
        glGetDoubleIndexedvEXT, glGetDoublei_vEXT, glGetFloatIndexedvEXT,
        glGetFloati_vEXT, glGetFramebufferParameterivEXT,
        glGetIntegerIndexedvEXT, glGetMultiTexEnvfvEXT,
        glGetMultiTexEnvivEXT, glGetMultiTexGendvEXT,
        glGetMultiTexGenfvEXT, glGetMultiTexGenivEXT,
        glGetMultiTexImageEXT, glGetMultiTexLevelParameterfvEXT,
        glGetMultiTexLevelParameterivEXT, glGetMultiTexParameterIivEXT,
        glGetMultiTexParameterIuivEXT, glGetMultiTexParameterfvEXT,
        glGetMultiTexParameterivEXT, glGetNamedBufferParameterivEXT,
        glGetNamedBufferPointervEXT, glGetNamedBufferSubDataEXT,
        glGetNamedFramebufferAttachmentParameterivEXT,
        glGetNamedFramebufferParameterivEXT,
        glGetNamedProgramLocalParameterIivEXT,
        glGetNamedProgramLocalParameterIuivEXT,
        glGetNamedProgramLocalParameterdvEXT,
        glGetNamedProgramLocalParameterfvEXT, glGetNamedProgramStringEXT,
        glGetNamedProgramivEXT, glGetNamedRenderbufferParameterivEXT,
        glGetPointerIndexedvEXT, glGetPointeri_vEXT, glGetTextureImageEXT,
        glGetTextureLevelParameterfvEXT, glGetTextureLevelParameterivEXT,
        glGetTextureParameterIivEXT, glGetTextureParameterIuivEXT,
        glGetTextureParameterfvEXT, glGetTextureParameterivEXT,
        glGetVertexArrayIntegeri_vEXT, glGetVertexArrayIntegervEXT,
        glGetVertexArrayPointeri_vEXT, glGetVertexArrayPointervEXT,
        glIsEnabledIndexedEXT, glMapNamedBufferEXT,
        glMapNamedBufferRangeEXT, glMatrixFrustumEXT,
        glMatrixLoadIdentityEXT, glMatrixLoadTransposedEXT,
        glMatrixLoadTransposefEXT, glMatrixLoaddEXT, glMatrixLoadfEXT,
        glMatrixMultTransposedEXT, glMatrixMultTransposefEXT,
        glMatrixMultdEXT, glMatrixMultfEXT, glMatrixOrthoEXT,
        glMatrixPopEXT, glMatrixPushEXT, glMatrixRotatedEXT,
        glMatrixRotatefEXT, glMatrixScaledEXT, glMatrixScalefEXT,
        glMatrixTranslatedEXT, glMatrixTranslatefEXT, glMultiTexBufferEXT,
        glMultiTexCoordPointerEXT, glMultiTexEnvfEXT, glMultiTexEnvfvEXT,
        glMultiTexEnviEXT, glMultiTexEnvivEXT, glMultiTexGendEXT,
        glMultiTexGendvEXT, glMultiTexGenfEXT, glMultiTexGenfvEXT,
        glMultiTexGeniEXT, glMultiTexGenivEXT, glMultiTexImage1DEXT,
        glMultiTexImage2DEXT, glMultiTexImage3DEXT,
        glMultiTexParameterIivEXT, glMultiTexParameterIuivEXT,
        glMultiTexParameterfEXT, glMultiTexParameterfvEXT,
        glMultiTexParameteriEXT, glMultiTexParameterivEXT,
        glMultiTexRenderbufferEXT, glMultiTexSubImage1DEXT,
        glMultiTexSubImage2DEXT, glMultiTexSubImage3DEXT,
        glNamedBufferDataEXT, glNamedBufferStorageEXT,
        glNamedBufferSubDataEXT, glNamedCopyBufferSubDataEXT,
        glNamedFramebufferParameteriEXT, glNamedFramebufferRenderbufferEXT,
        glNamedFramebufferTexture1DEXT, glNamedFramebufferTexture2DEXT,
        glNamedFramebufferTexture3DEXT, glNamedFramebufferTextureEXT,
        glNamedFramebufferTextureFaceEXT,
        glNamedFramebufferTextureLayerEXT,
        glNamedProgramLocalParameter4dEXT,
        glNamedProgramLocalParameter4dvEXT,
        glNamedProgramLocalParameter4fEXT,
        glNamedProgramLocalParameter4fvEXT,
        glNamedProgramLocalParameterI4iEXT,
        glNamedProgramLocalParameterI4ivEXT,
        glNamedProgramLocalParameterI4uiEXT,
        glNamedProgramLocalParameterI4uivEXT,
        glNamedProgramLocalParameters4fvEXT,
        glNamedProgramLocalParametersI4ivEXT,
        glNamedProgramLocalParametersI4uivEXT, glNamedProgramStringEXT,
        glNamedRenderbufferStorageEXT,
        glNamedRenderbufferStorageMultisampleCoverageEXT,
        glNamedRenderbufferStorageMultisampleEXT, glProgramUniform1dEXT,
        glProgramUniform1dvEXT, glProgramUniform1fEXT,
        glProgramUniform1fvEXT, glProgramUniform1iEXT,
        glProgramUniform1ivEXT, glProgramUniform1uiEXT,
        glProgramUniform1uivEXT, glProgramUniform2dEXT,
        glProgramUniform2dvEXT, glProgramUniform2fEXT,
        glProgramUniform2fvEXT, glProgramUniform2iEXT,
        glProgramUniform2ivEXT, glProgramUniform2uiEXT,
        glProgramUniform2uivEXT, glProgramUniform3dEXT,
        glProgramUniform3dvEXT, glProgramUniform3fEXT,
        glProgramUniform3fvEXT, glProgramUniform3iEXT,
        glProgramUniform3ivEXT, glProgramUniform3uiEXT,
        glProgramUniform3uivEXT, glProgramUniform4dEXT,
        glProgramUniform4dvEXT, glProgramUniform4fEXT,
        glProgramUniform4fvEXT, glProgramUniform4iEXT,
        glProgramUniform4ivEXT, glProgramUniform4uiEXT,
        glProgramUniform4uivEXT, glProgramUniformMatrix2dvEXT,
        glProgramUniformMatrix2fvEXT, glProgramUniformMatrix2x3dvEXT,
        glProgramUniformMatrix2x3fvEXT, glProgramUniformMatrix2x4dvEXT,
        glProgramUniformMatrix2x4fvEXT, glProgramUniformMatrix3dvEXT,
        glProgramUniformMatrix3fvEXT, glProgramUniformMatrix3x2dvEXT,
        glProgramUniformMatrix3x2fvEXT, glProgramUniformMatrix3x4dvEXT,
        glProgramUniformMatrix3x4fvEXT, glProgramUniformMatrix4dvEXT,
        glProgramUniformMatrix4fvEXT, glProgramUniformMatrix4x2dvEXT,
        glProgramUniformMatrix4x2fvEXT, glProgramUniformMatrix4x3dvEXT,
        glProgramUniformMatrix4x3fvEXT, glPushClientAttribDefaultEXT,
        glTextureBufferEXT, glTextureBufferRangeEXT, glTextureImage1DEXT,
        glTextureImage2DEXT, glTextureImage3DEXT,
        glTexturePageCommitmentEXT, glTextureParameterIivEXT,
        glTextureParameterIuivEXT, glTextureParameterfEXT,
        glTextureParameterfvEXT, glTextureParameteriEXT,
        glTextureParameterivEXT, glTextureRenderbufferEXT,
        glTextureStorage1DEXT, glTextureStorage2DEXT,
        glTextureStorage2DMultisampleEXT, glTextureStorage3DEXT,
        glTextureStorage3DMultisampleEXT, glTextureSubImage1DEXT,
        glTextureSubImage2DEXT, glTextureSubImage3DEXT,
        glUnmapNamedBufferEXT, glVertexArrayBindVertexBufferEXT,
        glVertexArrayColorOffsetEXT, glVertexArrayEdgeFlagOffsetEXT,
        glVertexArrayFogCoordOffsetEXT, glVertexArrayIndexOffsetEXT,
        glVertexArrayMultiTexCoordOffsetEXT, glVertexArrayNormalOffsetEXT,
        glVertexArraySecondaryColorOffsetEXT,
        glVertexArrayTexCoordOffsetEXT,
        glVertexArrayVertexAttribBindingEXT,
        glVertexArrayVertexAttribDivisorEXT,
        glVertexArrayVertexAttribFormatEXT,
        glVertexArrayVertexAttribIFormatEXT,
        glVertexArrayVertexAttribIOffsetEXT,
        glVertexArrayVertexAttribLFormatEXT,
        glVertexArrayVertexAttribLOffsetEXT,
        glVertexArrayVertexAttribOffsetEXT,
        glVertexArrayVertexBindingDivisorEXT, glVertexArrayVertexOffsetEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PROGRAM_MATRIX_EXT :: GLenum
gl_PROGRAM_MATRIX_EXT = 36397
 
gl_PROGRAM_MATRIX_STACK_DEPTH_EXT :: GLenum
gl_PROGRAM_MATRIX_STACK_DEPTH_EXT = 36399
 
gl_TRANSPOSE_PROGRAM_MATRIX_EXT :: GLenum
gl_TRANSPOSE_PROGRAM_MATRIX_EXT = 36398
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindMultiTextureEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
glBindMultiTextureEXT :: GLenum -> GLenum -> GLuint -> IO ()
glBindMultiTextureEXT
  = dyn_glBindMultiTextureEXT ptr_glBindMultiTextureEXT
 
{-# NOINLINE ptr_glBindMultiTextureEXT #-}
 
ptr_glBindMultiTextureEXT :: FunPtr a
ptr_glBindMultiTextureEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glBindMultiTextureEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCheckNamedFramebufferStatusEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO GLenum)
 
glCheckNamedFramebufferStatusEXT :: GLuint -> GLenum -> IO GLenum
glCheckNamedFramebufferStatusEXT
  = dyn_glCheckNamedFramebufferStatusEXT
      ptr_glCheckNamedFramebufferStatusEXT
 
{-# NOINLINE ptr_glCheckNamedFramebufferStatusEXT #-}
 
ptr_glCheckNamedFramebufferStatusEXT :: FunPtr a
ptr_glCheckNamedFramebufferStatusEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCheckNamedFramebufferStatusEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glClearNamedBufferDataEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLenum -> Ptr f -> IO ())
 
glClearNamedBufferDataEXT ::
                          GLuint -> GLenum -> GLenum -> GLenum -> Ptr f -> IO ()
glClearNamedBufferDataEXT
  = dyn_glClearNamedBufferDataEXT ptr_glClearNamedBufferDataEXT
 
{-# NOINLINE ptr_glClearNamedBufferDataEXT #-}
 
ptr_glClearNamedBufferDataEXT :: FunPtr a
ptr_glClearNamedBufferDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glClearNamedBufferDataEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glClearNamedBufferSubDataEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLenum -> GLenum -> GLsizeiptr -> GLsizeiptr -> Ptr h -> IO ())
 
glClearNamedBufferSubDataEXT ::
                             GLuint ->
                               GLenum ->
                                 GLenum -> GLenum -> GLsizeiptr -> GLsizeiptr -> Ptr h -> IO ()
glClearNamedBufferSubDataEXT
  = dyn_glClearNamedBufferSubDataEXT ptr_glClearNamedBufferSubDataEXT
 
{-# NOINLINE ptr_glClearNamedBufferSubDataEXT #-}
 
ptr_glClearNamedBufferSubDataEXT :: FunPtr a
ptr_glClearNamedBufferSubDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glClearNamedBufferSubDataEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glClientAttribDefaultEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
glClientAttribDefaultEXT :: GLbitfield -> IO ()
glClientAttribDefaultEXT
  = dyn_glClientAttribDefaultEXT ptr_glClientAttribDefaultEXT
 
{-# NOINLINE ptr_glClientAttribDefaultEXT #-}
 
ptr_glClientAttribDefaultEXT :: FunPtr a
ptr_glClientAttribDefaultEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glClientAttribDefaultEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint -> GLenum -> GLsizei -> GLint -> GLsizei -> Ptr i -> IO ())
 
glCompressedMultiTexImage1DEXT ::
                               GLenum ->
                                 GLenum ->
                                   GLint -> GLenum -> GLsizei -> GLint -> GLsizei -> Ptr i -> IO ()
glCompressedMultiTexImage1DEXT
  = dyn_glCompressedMultiTexImage1DEXT
      ptr_glCompressedMultiTexImage1DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexImage1DEXT #-}
 
ptr_glCompressedMultiTexImage1DEXT :: FunPtr a
ptr_glCompressedMultiTexImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLenum -> GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr j -> IO ())
 
glCompressedMultiTexImage2DEXT ::
                               GLenum ->
                                 GLenum ->
                                   GLint ->
                                     GLenum ->
                                       GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr j -> IO ()
glCompressedMultiTexImage2DEXT
  = dyn_glCompressedMultiTexImage2DEXT
      ptr_glCompressedMultiTexImage2DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexImage2DEXT #-}
 
ptr_glCompressedMultiTexImage2DEXT :: FunPtr a
ptr_glCompressedMultiTexImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLenum ->
                          GLsizei ->
                            GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr k -> IO ())
 
glCompressedMultiTexImage3DEXT ::
                               GLenum ->
                                 GLenum ->
                                   GLint ->
                                     GLenum ->
                                       GLsizei ->
                                         GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr k -> IO ()
glCompressedMultiTexImage3DEXT
  = dyn_glCompressedMultiTexImage3DEXT
      ptr_glCompressedMultiTexImage3DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexImage3DEXT #-}
 
ptr_glCompressedMultiTexImage3DEXT :: FunPtr a
ptr_glCompressedMultiTexImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexSubImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint -> GLint -> GLsizei -> GLenum -> GLsizei -> Ptr i -> IO ())
 
glCompressedMultiTexSubImage1DEXT ::
                                  GLenum ->
                                    GLenum ->
                                      GLint ->
                                        GLint -> GLsizei -> GLenum -> GLsizei -> Ptr i -> IO ()
glCompressedMultiTexSubImage1DEXT
  = dyn_glCompressedMultiTexSubImage1DEXT
      ptr_glCompressedMultiTexSubImage1DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexSubImage1DEXT #-}
 
ptr_glCompressedMultiTexSubImage1DEXT :: FunPtr a
ptr_glCompressedMultiTexSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexSubImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLenum -> GLsizei -> Ptr k -> IO ())
 
glCompressedMultiTexSubImage2DEXT ::
                                  GLenum ->
                                    GLenum ->
                                      GLint ->
                                        GLint ->
                                          GLint ->
                                            GLsizei ->
                                              GLsizei -> GLenum -> GLsizei -> Ptr k -> IO ()
glCompressedMultiTexSubImage2DEXT
  = dyn_glCompressedMultiTexSubImage2DEXT
      ptr_glCompressedMultiTexSubImage2DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexSubImage2DEXT #-}
 
ptr_glCompressedMultiTexSubImage2DEXT :: FunPtr a
ptr_glCompressedMultiTexSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedMultiTexSubImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLsizei ->
                                GLsizei -> GLsizei -> GLenum -> GLsizei -> Ptr m -> IO ())
 
glCompressedMultiTexSubImage3DEXT ::
                                  GLenum ->
                                    GLenum ->
                                      GLint ->
                                        GLint ->
                                          GLint ->
                                            GLint ->
                                              GLsizei ->
                                                GLsizei ->
                                                  GLsizei -> GLenum -> GLsizei -> Ptr m -> IO ()
glCompressedMultiTexSubImage3DEXT
  = dyn_glCompressedMultiTexSubImage3DEXT
      ptr_glCompressedMultiTexSubImage3DEXT
 
{-# NOINLINE ptr_glCompressedMultiTexSubImage3DEXT #-}
 
ptr_glCompressedMultiTexSubImage3DEXT :: FunPtr a
ptr_glCompressedMultiTexSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedMultiTexSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint -> GLenum -> GLsizei -> GLint -> GLsizei -> Ptr i -> IO ())
 
glCompressedTextureImage1DEXT ::
                              GLuint ->
                                GLenum ->
                                  GLint -> GLenum -> GLsizei -> GLint -> GLsizei -> Ptr i -> IO ()
glCompressedTextureImage1DEXT
  = dyn_glCompressedTextureImage1DEXT
      ptr_glCompressedTextureImage1DEXT
 
{-# NOINLINE ptr_glCompressedTextureImage1DEXT #-}
 
ptr_glCompressedTextureImage1DEXT :: FunPtr a
ptr_glCompressedTextureImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLenum -> GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr j -> IO ())
 
glCompressedTextureImage2DEXT ::
                              GLuint ->
                                GLenum ->
                                  GLint ->
                                    GLenum ->
                                      GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr j -> IO ()
glCompressedTextureImage2DEXT
  = dyn_glCompressedTextureImage2DEXT
      ptr_glCompressedTextureImage2DEXT
 
{-# NOINLINE ptr_glCompressedTextureImage2DEXT #-}
 
ptr_glCompressedTextureImage2DEXT :: FunPtr a
ptr_glCompressedTextureImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLenum ->
                          GLsizei ->
                            GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr k -> IO ())
 
glCompressedTextureImage3DEXT ::
                              GLuint ->
                                GLenum ->
                                  GLint ->
                                    GLenum ->
                                      GLsizei ->
                                        GLsizei -> GLsizei -> GLint -> GLsizei -> Ptr k -> IO ()
glCompressedTextureImage3DEXT
  = dyn_glCompressedTextureImage3DEXT
      ptr_glCompressedTextureImage3DEXT
 
{-# NOINLINE ptr_glCompressedTextureImage3DEXT #-}
 
ptr_glCompressedTextureImage3DEXT :: FunPtr a
ptr_glCompressedTextureImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureSubImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint -> GLint -> GLsizei -> GLenum -> GLsizei -> Ptr i -> IO ())
 
glCompressedTextureSubImage1DEXT ::
                                 GLuint ->
                                   GLenum ->
                                     GLint ->
                                       GLint -> GLsizei -> GLenum -> GLsizei -> Ptr i -> IO ()
glCompressedTextureSubImage1DEXT
  = dyn_glCompressedTextureSubImage1DEXT
      ptr_glCompressedTextureSubImage1DEXT
 
{-# NOINLINE ptr_glCompressedTextureSubImage1DEXT #-}
 
ptr_glCompressedTextureSubImage1DEXT :: FunPtr a
ptr_glCompressedTextureSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureSubImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLenum -> GLsizei -> Ptr k -> IO ())
 
glCompressedTextureSubImage2DEXT ::
                                 GLuint ->
                                   GLenum ->
                                     GLint ->
                                       GLint ->
                                         GLint ->
                                           GLsizei -> GLsizei -> GLenum -> GLsizei -> Ptr k -> IO ()
glCompressedTextureSubImage2DEXT
  = dyn_glCompressedTextureSubImage2DEXT
      ptr_glCompressedTextureSubImage2DEXT
 
{-# NOINLINE ptr_glCompressedTextureSubImage2DEXT #-}
 
ptr_glCompressedTextureSubImage2DEXT :: FunPtr a
ptr_glCompressedTextureSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCompressedTextureSubImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLsizei ->
                                GLsizei -> GLsizei -> GLenum -> GLsizei -> Ptr m -> IO ())
 
glCompressedTextureSubImage3DEXT ::
                                 GLuint ->
                                   GLenum ->
                                     GLint ->
                                       GLint ->
                                         GLint ->
                                           GLint ->
                                             GLsizei ->
                                               GLsizei ->
                                                 GLsizei -> GLenum -> GLsizei -> Ptr m -> IO ()
glCompressedTextureSubImage3DEXT
  = dyn_glCompressedTextureSubImage3DEXT
      ptr_glCompressedTextureSubImage3DEXT
 
{-# NOINLINE ptr_glCompressedTextureSubImage3DEXT #-}
 
ptr_glCompressedTextureSubImage3DEXT :: FunPtr a
ptr_glCompressedTextureSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCompressedTextureSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyMultiTexImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ())
 
glCopyMultiTexImage1DEXT ::
                         GLenum ->
                           GLenum ->
                             GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ()
glCopyMultiTexImage1DEXT
  = dyn_glCopyMultiTexImage1DEXT ptr_glCopyMultiTexImage1DEXT
 
{-# NOINLINE ptr_glCopyMultiTexImage1DEXT #-}
 
ptr_glCopyMultiTexImage1DEXT :: FunPtr a
ptr_glCopyMultiTexImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyMultiTexImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyMultiTexImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ())
 
glCopyMultiTexImage2DEXT ::
                         GLenum ->
                           GLenum ->
                             GLint ->
                               GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ()
glCopyMultiTexImage2DEXT
  = dyn_glCopyMultiTexImage2DEXT ptr_glCopyMultiTexImage2DEXT
 
{-# NOINLINE ptr_glCopyMultiTexImage2DEXT #-}
 
ptr_glCopyMultiTexImage2DEXT :: FunPtr a
ptr_glCopyMultiTexImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyMultiTexImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyMultiTexSubImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyMultiTexSubImage1DEXT ::
                            GLenum ->
                              GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ()
glCopyMultiTexSubImage1DEXT
  = dyn_glCopyMultiTexSubImage1DEXT ptr_glCopyMultiTexSubImage1DEXT
 
{-# NOINLINE ptr_glCopyMultiTexSubImage1DEXT #-}
 
ptr_glCopyMultiTexSubImage1DEXT :: FunPtr a
ptr_glCopyMultiTexSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyMultiTexSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyMultiTexSubImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyMultiTexSubImage2DEXT ::
                            GLenum ->
                              GLenum ->
                                GLint ->
                                  GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyMultiTexSubImage2DEXT
  = dyn_glCopyMultiTexSubImage2DEXT ptr_glCopyMultiTexSubImage2DEXT
 
{-# NOINLINE ptr_glCopyMultiTexSubImage2DEXT #-}
 
ptr_glCopyMultiTexSubImage2DEXT :: FunPtr a
ptr_glCopyMultiTexSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyMultiTexSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyMultiTexSubImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyMultiTexSubImage3DEXT ::
                            GLenum ->
                              GLenum ->
                                GLint ->
                                  GLint ->
                                    GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyMultiTexSubImage3DEXT
  = dyn_glCopyMultiTexSubImage3DEXT ptr_glCopyMultiTexSubImage3DEXT
 
{-# NOINLINE ptr_glCopyMultiTexSubImage3DEXT #-}
 
ptr_glCopyMultiTexSubImage3DEXT :: FunPtr a
ptr_glCopyMultiTexSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyMultiTexSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTextureImage1DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ())
 
glCopyTextureImage1DEXT ::
                        GLuint ->
                          GLenum ->
                            GLint -> GLenum -> GLint -> GLint -> GLsizei -> GLint -> IO ()
glCopyTextureImage1DEXT
  = dyn_glCopyTextureImage1DEXT ptr_glCopyTextureImage1DEXT
 
{-# NOINLINE ptr_glCopyTextureImage1DEXT #-}
 
ptr_glCopyTextureImage1DEXT :: FunPtr a
ptr_glCopyTextureImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyTextureImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyTextureImage2DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ())
 
glCopyTextureImage2DEXT ::
                        GLuint ->
                          GLenum ->
                            GLint ->
                              GLenum -> GLint -> GLint -> GLsizei -> GLsizei -> GLint -> IO ()
glCopyTextureImage2DEXT
  = dyn_glCopyTextureImage2DEXT ptr_glCopyTextureImage2DEXT
 
{-# NOINLINE ptr_glCopyTextureImage2DEXT #-}
 
ptr_glCopyTextureImage2DEXT :: FunPtr a
ptr_glCopyTextureImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyTextureImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyTextureSubImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ())
 
glCopyTextureSubImage1DEXT ::
                           GLuint ->
                             GLenum -> GLint -> GLint -> GLint -> GLint -> GLsizei -> IO ()
glCopyTextureSubImage1DEXT
  = dyn_glCopyTextureSubImage1DEXT ptr_glCopyTextureSubImage1DEXT
 
{-# NOINLINE ptr_glCopyTextureSubImage1DEXT #-}
 
ptr_glCopyTextureSubImage1DEXT :: FunPtr a
ptr_glCopyTextureSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyTextureSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyTextureSubImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyTextureSubImage2DEXT ::
                           GLuint ->
                             GLenum ->
                               GLint ->
                                 GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyTextureSubImage2DEXT
  = dyn_glCopyTextureSubImage2DEXT ptr_glCopyTextureSubImage2DEXT
 
{-# NOINLINE ptr_glCopyTextureSubImage2DEXT #-}
 
ptr_glCopyTextureSubImage2DEXT :: FunPtr a
ptr_glCopyTextureSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyTextureSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCopyTextureSubImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glCopyTextureSubImage3DEXT ::
                           GLuint ->
                             GLenum ->
                               GLint ->
                                 GLint ->
                                   GLint -> GLint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glCopyTextureSubImage3DEXT
  = dyn_glCopyTextureSubImage3DEXT ptr_glCopyTextureSubImage3DEXT
 
{-# NOINLINE ptr_glCopyTextureSubImage3DEXT #-}
 
ptr_glCopyTextureSubImage3DEXT :: FunPtr a
ptr_glCopyTextureSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glCopyTextureSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDisableClientStateIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisableClientStateIndexedEXT :: GLenum -> GLuint -> IO ()
glDisableClientStateIndexedEXT
  = dyn_glDisableClientStateIndexedEXT
      ptr_glDisableClientStateIndexedEXT
 
{-# NOINLINE ptr_glDisableClientStateIndexedEXT #-}
 
ptr_glDisableClientStateIndexedEXT :: FunPtr a
ptr_glDisableClientStateIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glDisableClientStateIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDisableClientStateiEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisableClientStateiEXT :: GLenum -> GLuint -> IO ()
glDisableClientStateiEXT
  = dyn_glDisableClientStateiEXT ptr_glDisableClientStateiEXT
 
{-# NOINLINE ptr_glDisableClientStateiEXT #-}
 
ptr_glDisableClientStateiEXT :: FunPtr a
ptr_glDisableClientStateiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glDisableClientStateiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisableIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisableIndexedEXT :: GLenum -> GLuint -> IO ()
glDisableIndexedEXT
  = dyn_glDisableIndexedEXT ptr_glDisableIndexedEXT
 
{-# NOINLINE ptr_glDisableIndexedEXT #-}
 
ptr_glDisableIndexedEXT :: FunPtr a
ptr_glDisableIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glDisableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDisableVertexArrayAttribEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glDisableVertexArrayAttribEXT :: GLuint -> GLuint -> IO ()
glDisableVertexArrayAttribEXT
  = dyn_glDisableVertexArrayAttribEXT
      ptr_glDisableVertexArrayAttribEXT
 
{-# NOINLINE ptr_glDisableVertexArrayAttribEXT #-}
 
ptr_glDisableVertexArrayAttribEXT :: FunPtr a
ptr_glDisableVertexArrayAttribEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glDisableVertexArrayAttribEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisableVertexArrayEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glDisableVertexArrayEXT :: GLuint -> GLenum -> IO ()
glDisableVertexArrayEXT
  = dyn_glDisableVertexArrayEXT ptr_glDisableVertexArrayEXT
 
{-# NOINLINE ptr_glDisableVertexArrayEXT #-}
 
ptr_glDisableVertexArrayEXT :: FunPtr a
ptr_glDisableVertexArrayEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glDisableVertexArrayEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glEnableClientStateIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnableClientStateIndexedEXT :: GLenum -> GLuint -> IO ()
glEnableClientStateIndexedEXT
  = dyn_glEnableClientStateIndexedEXT
      ptr_glEnableClientStateIndexedEXT
 
{-# NOINLINE ptr_glEnableClientStateIndexedEXT #-}
 
ptr_glEnableClientStateIndexedEXT :: FunPtr a
ptr_glEnableClientStateIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glEnableClientStateIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnableClientStateiEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnableClientStateiEXT :: GLenum -> GLuint -> IO ()
glEnableClientStateiEXT
  = dyn_glEnableClientStateiEXT ptr_glEnableClientStateiEXT
 
{-# NOINLINE ptr_glEnableClientStateiEXT #-}
 
ptr_glEnableClientStateiEXT :: FunPtr a
ptr_glEnableClientStateiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glEnableClientStateiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnableIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnableIndexedEXT :: GLenum -> GLuint -> IO ()
glEnableIndexedEXT = dyn_glEnableIndexedEXT ptr_glEnableIndexedEXT
 
{-# NOINLINE ptr_glEnableIndexedEXT #-}
 
ptr_glEnableIndexedEXT :: FunPtr a
ptr_glEnableIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glEnableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glEnableVertexArrayAttribEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glEnableVertexArrayAttribEXT :: GLuint -> GLuint -> IO ()
glEnableVertexArrayAttribEXT
  = dyn_glEnableVertexArrayAttribEXT ptr_glEnableVertexArrayAttribEXT
 
{-# NOINLINE ptr_glEnableVertexArrayAttribEXT #-}
 
ptr_glEnableVertexArrayAttribEXT :: FunPtr a
ptr_glEnableVertexArrayAttribEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glEnableVertexArrayAttribEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnableVertexArrayEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glEnableVertexArrayEXT :: GLuint -> GLenum -> IO ()
glEnableVertexArrayEXT
  = dyn_glEnableVertexArrayEXT ptr_glEnableVertexArrayEXT
 
{-# NOINLINE ptr_glEnableVertexArrayEXT #-}
 
ptr_glEnableVertexArrayEXT :: FunPtr a
ptr_glEnableVertexArrayEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glEnableVertexArrayEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFlushMappedNamedBufferRangeEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLintptr -> GLsizeiptr -> IO ())
 
glFlushMappedNamedBufferRangeEXT ::
                                 GLuint -> GLintptr -> GLsizeiptr -> IO ()
glFlushMappedNamedBufferRangeEXT
  = dyn_glFlushMappedNamedBufferRangeEXT
      ptr_glFlushMappedNamedBufferRangeEXT
 
{-# NOINLINE ptr_glFlushMappedNamedBufferRangeEXT #-}
 
ptr_glFlushMappedNamedBufferRangeEXT :: FunPtr a
ptr_glFlushMappedNamedBufferRangeEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glFlushMappedNamedBufferRangeEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferDrawBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glFramebufferDrawBufferEXT :: GLuint -> GLenum -> IO ()
glFramebufferDrawBufferEXT
  = dyn_glFramebufferDrawBufferEXT ptr_glFramebufferDrawBufferEXT
 
{-# NOINLINE ptr_glFramebufferDrawBufferEXT #-}
 
ptr_glFramebufferDrawBufferEXT :: FunPtr a
ptr_glFramebufferDrawBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glFramebufferDrawBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferDrawBuffersEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLenum -> IO ())
 
glFramebufferDrawBuffersEXT ::
                            GLuint -> GLsizei -> Ptr GLenum -> IO ()
glFramebufferDrawBuffersEXT
  = dyn_glFramebufferDrawBuffersEXT ptr_glFramebufferDrawBuffersEXT
 
{-# NOINLINE ptr_glFramebufferDrawBuffersEXT #-}
 
ptr_glFramebufferDrawBuffersEXT :: FunPtr a
ptr_glFramebufferDrawBuffersEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glFramebufferDrawBuffersEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferReadBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glFramebufferReadBufferEXT :: GLuint -> GLenum -> IO ()
glFramebufferReadBufferEXT
  = dyn_glFramebufferReadBufferEXT ptr_glFramebufferReadBufferEXT
 
{-# NOINLINE ptr_glFramebufferReadBufferEXT #-}
 
ptr_glFramebufferReadBufferEXT :: FunPtr a
ptr_glFramebufferReadBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glFramebufferReadBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGenerateMultiTexMipmapEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glGenerateMultiTexMipmapEXT :: GLenum -> GLenum -> IO ()
glGenerateMultiTexMipmapEXT
  = dyn_glGenerateMultiTexMipmapEXT ptr_glGenerateMultiTexMipmapEXT
 
{-# NOINLINE ptr_glGenerateMultiTexMipmapEXT #-}
 
ptr_glGenerateMultiTexMipmapEXT :: FunPtr a
ptr_glGenerateMultiTexMipmapEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGenerateMultiTexMipmapEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGenerateTextureMipmapEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glGenerateTextureMipmapEXT :: GLuint -> GLenum -> IO ()
glGenerateTextureMipmapEXT
  = dyn_glGenerateTextureMipmapEXT ptr_glGenerateTextureMipmapEXT
 
{-# NOINLINE ptr_glGenerateTextureMipmapEXT #-}
 
ptr_glGenerateTextureMipmapEXT :: FunPtr a
ptr_glGenerateTextureMipmapEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGenerateTextureMipmapEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBooleanIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLboolean -> IO ())
 
glGetBooleanIndexedvEXT ::
                        GLenum -> GLuint -> Ptr GLboolean -> IO ()
glGetBooleanIndexedvEXT
  = dyn_glGetBooleanIndexedvEXT ptr_glGetBooleanIndexedvEXT
 
{-# NOINLINE ptr_glGetBooleanIndexedvEXT #-}
 
ptr_glGetBooleanIndexedvEXT :: FunPtr a
ptr_glGetBooleanIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetBooleanIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetCompressedMultiTexImageEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> Ptr e -> IO ())
 
glGetCompressedMultiTexImageEXT ::
                                GLenum -> GLenum -> GLint -> Ptr e -> IO ()
glGetCompressedMultiTexImageEXT
  = dyn_glGetCompressedMultiTexImageEXT
      ptr_glGetCompressedMultiTexImageEXT
 
{-# NOINLINE ptr_glGetCompressedMultiTexImageEXT #-}
 
ptr_glGetCompressedMultiTexImageEXT :: FunPtr a
ptr_glGetCompressedMultiTexImageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetCompressedMultiTexImageEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetCompressedTextureImageEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> Ptr e -> IO ())
 
glGetCompressedTextureImageEXT ::
                               GLuint -> GLenum -> GLint -> Ptr e -> IO ()
glGetCompressedTextureImageEXT
  = dyn_glGetCompressedTextureImageEXT
      ptr_glGetCompressedTextureImageEXT
 
{-# NOINLINE ptr_glGetCompressedTextureImageEXT #-}
 
ptr_glGetCompressedTextureImageEXT :: FunPtr a
ptr_glGetCompressedTextureImageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetCompressedTextureImageEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDoubleIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetDoubleIndexedvEXT :: GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetDoubleIndexedvEXT
  = dyn_glGetDoubleIndexedvEXT ptr_glGetDoubleIndexedvEXT
 
{-# NOINLINE ptr_glGetDoubleIndexedvEXT #-}
 
ptr_glGetDoubleIndexedvEXT :: FunPtr a
ptr_glGetDoubleIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetDoubleIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDoublei_vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetDoublei_vEXT :: GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetDoublei_vEXT = dyn_glGetDoublei_vEXT ptr_glGetDoublei_vEXT
 
{-# NOINLINE ptr_glGetDoublei_vEXT #-}
 
ptr_glGetDoublei_vEXT :: FunPtr a
ptr_glGetDoublei_vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetDoublei_vEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFloatIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetFloatIndexedvEXT :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetFloatIndexedvEXT
  = dyn_glGetFloatIndexedvEXT ptr_glGetFloatIndexedvEXT
 
{-# NOINLINE ptr_glGetFloatIndexedvEXT #-}
 
ptr_glGetFloatIndexedvEXT :: FunPtr a
ptr_glGetFloatIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetFloatIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFloati_vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetFloati_vEXT :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetFloati_vEXT = dyn_glGetFloati_vEXT ptr_glGetFloati_vEXT
 
{-# NOINLINE ptr_glGetFloati_vEXT #-}
 
ptr_glGetFloati_vEXT :: FunPtr a
ptr_glGetFloati_vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetFloati_vEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFramebufferParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetFramebufferParameterivEXT ::
                               GLuint -> GLenum -> Ptr GLint -> IO ()
glGetFramebufferParameterivEXT
  = dyn_glGetFramebufferParameterivEXT
      ptr_glGetFramebufferParameterivEXT
 
{-# NOINLINE ptr_glGetFramebufferParameterivEXT #-}
 
ptr_glGetFramebufferParameterivEXT :: FunPtr a
ptr_glGetFramebufferParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetFramebufferParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegerIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetIntegerIndexedvEXT :: GLenum -> GLuint -> Ptr GLint -> IO ()
glGetIntegerIndexedvEXT
  = dyn_glGetIntegerIndexedvEXT ptr_glGetIntegerIndexedvEXT
 
{-# NOINLINE ptr_glGetIntegerIndexedvEXT #-}
 
ptr_glGetIntegerIndexedvEXT :: FunPtr a
ptr_glGetIntegerIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetIntegerIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexEnvfvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMultiTexEnvfvEXT ::
                      GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMultiTexEnvfvEXT
  = dyn_glGetMultiTexEnvfvEXT ptr_glGetMultiTexEnvfvEXT
 
{-# NOINLINE ptr_glGetMultiTexEnvfvEXT #-}
 
ptr_glGetMultiTexEnvfvEXT :: FunPtr a
ptr_glGetMultiTexEnvfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexEnvfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexEnvivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMultiTexEnvivEXT ::
                      GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMultiTexEnvivEXT
  = dyn_glGetMultiTexEnvivEXT ptr_glGetMultiTexEnvivEXT
 
{-# NOINLINE ptr_glGetMultiTexEnvivEXT #-}
 
ptr_glGetMultiTexEnvivEXT :: FunPtr a
ptr_glGetMultiTexEnvivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexEnvivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexGendvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLdouble -> IO ())
 
glGetMultiTexGendvEXT ::
                      GLenum -> GLenum -> GLenum -> Ptr GLdouble -> IO ()
glGetMultiTexGendvEXT
  = dyn_glGetMultiTexGendvEXT ptr_glGetMultiTexGendvEXT
 
{-# NOINLINE ptr_glGetMultiTexGendvEXT #-}
 
ptr_glGetMultiTexGendvEXT :: FunPtr a
ptr_glGetMultiTexGendvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexGendvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexGenfvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMultiTexGenfvEXT ::
                      GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMultiTexGenfvEXT
  = dyn_glGetMultiTexGenfvEXT ptr_glGetMultiTexGenfvEXT
 
{-# NOINLINE ptr_glGetMultiTexGenfvEXT #-}
 
ptr_glGetMultiTexGenfvEXT :: FunPtr a
ptr_glGetMultiTexGenfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexGenfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexGenivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMultiTexGenivEXT ::
                      GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMultiTexGenivEXT
  = dyn_glGetMultiTexGenivEXT ptr_glGetMultiTexGenivEXT
 
{-# NOINLINE ptr_glGetMultiTexGenivEXT #-}
 
ptr_glGetMultiTexGenivEXT :: FunPtr a
ptr_glGetMultiTexGenivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexGenivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultiTexImageEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLenum -> GLenum -> Ptr g -> IO ())
 
glGetMultiTexImageEXT ::
                      GLenum -> GLenum -> GLint -> GLenum -> GLenum -> Ptr g -> IO ()
glGetMultiTexImageEXT
  = dyn_glGetMultiTexImageEXT ptr_glGetMultiTexImageEXT
 
{-# NOINLINE ptr_glGetMultiTexImageEXT #-}
 
ptr_glGetMultiTexImageEXT :: FunPtr a
ptr_glGetMultiTexImageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexImageEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexLevelParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMultiTexLevelParameterfvEXT ::
                                 GLenum -> GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ()
glGetMultiTexLevelParameterfvEXT
  = dyn_glGetMultiTexLevelParameterfvEXT
      ptr_glGetMultiTexLevelParameterfvEXT
 
{-# NOINLINE ptr_glGetMultiTexLevelParameterfvEXT #-}
 
ptr_glGetMultiTexLevelParameterfvEXT :: FunPtr a
ptr_glGetMultiTexLevelParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexLevelParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexLevelParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLenum -> Ptr GLint -> IO ())
 
glGetMultiTexLevelParameterivEXT ::
                                 GLenum -> GLenum -> GLint -> GLenum -> Ptr GLint -> IO ()
glGetMultiTexLevelParameterivEXT
  = dyn_glGetMultiTexLevelParameterivEXT
      ptr_glGetMultiTexLevelParameterivEXT
 
{-# NOINLINE ptr_glGetMultiTexLevelParameterivEXT #-}
 
ptr_glGetMultiTexLevelParameterivEXT :: FunPtr a
ptr_glGetMultiTexLevelParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexLevelParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexParameterIivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMultiTexParameterIivEXT ::
                             GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMultiTexParameterIivEXT
  = dyn_glGetMultiTexParameterIivEXT ptr_glGetMultiTexParameterIivEXT
 
{-# NOINLINE ptr_glGetMultiTexParameterIivEXT #-}
 
ptr_glGetMultiTexParameterIivEXT :: FunPtr a
ptr_glGetMultiTexParameterIivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexParameterIivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexParameterIuivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glGetMultiTexParameterIuivEXT ::
                              GLenum -> GLenum -> GLenum -> Ptr GLuint -> IO ()
glGetMultiTexParameterIuivEXT
  = dyn_glGetMultiTexParameterIuivEXT
      ptr_glGetMultiTexParameterIuivEXT
 
{-# NOINLINE ptr_glGetMultiTexParameterIuivEXT #-}
 
ptr_glGetMultiTexParameterIuivEXT :: FunPtr a
ptr_glGetMultiTexParameterIuivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexParameterIuivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMultiTexParameterfvEXT ::
                            GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMultiTexParameterfvEXT
  = dyn_glGetMultiTexParameterfvEXT ptr_glGetMultiTexParameterfvEXT
 
{-# NOINLINE ptr_glGetMultiTexParameterfvEXT #-}
 
ptr_glGetMultiTexParameterfvEXT :: FunPtr a
ptr_glGetMultiTexParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMultiTexParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMultiTexParameterivEXT ::
                            GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMultiTexParameterivEXT
  = dyn_glGetMultiTexParameterivEXT ptr_glGetMultiTexParameterivEXT
 
{-# NOINLINE ptr_glGetMultiTexParameterivEXT #-}
 
ptr_glGetMultiTexParameterivEXT :: FunPtr a
ptr_glGetMultiTexParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetMultiTexParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedBufferParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedBufferParameterivEXT ::
                               GLuint -> GLenum -> Ptr GLint -> IO ()
glGetNamedBufferParameterivEXT
  = dyn_glGetNamedBufferParameterivEXT
      ptr_glGetNamedBufferParameterivEXT
 
{-# NOINLINE ptr_glGetNamedBufferParameterivEXT #-}
 
ptr_glGetNamedBufferParameterivEXT :: FunPtr a
ptr_glGetNamedBufferParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedBufferParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedBufferPointervEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glGetNamedBufferPointervEXT ::
                            GLuint -> GLenum -> Ptr (Ptr d) -> IO ()
glGetNamedBufferPointervEXT
  = dyn_glGetNamedBufferPointervEXT ptr_glGetNamedBufferPointervEXT
 
{-# NOINLINE ptr_glGetNamedBufferPointervEXT #-}
 
ptr_glGetNamedBufferPointervEXT :: FunPtr a
ptr_glGetNamedBufferPointervEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedBufferPointervEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedBufferSubDataEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLintptr -> GLsizeiptr -> Ptr e -> IO ())
 
glGetNamedBufferSubDataEXT ::
                           GLuint -> GLintptr -> GLsizeiptr -> Ptr e -> IO ()
glGetNamedBufferSubDataEXT
  = dyn_glGetNamedBufferSubDataEXT ptr_glGetNamedBufferSubDataEXT
 
{-# NOINLINE ptr_glGetNamedBufferSubDataEXT #-}
 
ptr_glGetNamedBufferSubDataEXT :: FunPtr a
ptr_glGetNamedBufferSubDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedBufferSubDataEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedFramebufferAttachmentParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedFramebufferAttachmentParameterivEXT ::
                                              GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetNamedFramebufferAttachmentParameterivEXT
  = dyn_glGetNamedFramebufferAttachmentParameterivEXT
      ptr_glGetNamedFramebufferAttachmentParameterivEXT
 
{-# NOINLINE ptr_glGetNamedFramebufferAttachmentParameterivEXT #-}
 
ptr_glGetNamedFramebufferAttachmentParameterivEXT :: FunPtr a
ptr_glGetNamedFramebufferAttachmentParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedFramebufferAttachmentParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedFramebufferParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedFramebufferParameterivEXT ::
                                    GLuint -> GLenum -> Ptr GLint -> IO ()
glGetNamedFramebufferParameterivEXT
  = dyn_glGetNamedFramebufferParameterivEXT
      ptr_glGetNamedFramebufferParameterivEXT
 
{-# NOINLINE ptr_glGetNamedFramebufferParameterivEXT #-}
 
ptr_glGetNamedFramebufferParameterivEXT :: FunPtr a
ptr_glGetNamedFramebufferParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedFramebufferParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedProgramLocalParameterIivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetNamedProgramLocalParameterIivEXT ::
                                      GLuint -> GLenum -> GLuint -> Ptr GLint -> IO ()
glGetNamedProgramLocalParameterIivEXT
  = dyn_glGetNamedProgramLocalParameterIivEXT
      ptr_glGetNamedProgramLocalParameterIivEXT
 
{-# NOINLINE ptr_glGetNamedProgramLocalParameterIivEXT #-}
 
ptr_glGetNamedProgramLocalParameterIivEXT :: FunPtr a
ptr_glGetNamedProgramLocalParameterIivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramLocalParameterIivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedProgramLocalParameterIuivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glGetNamedProgramLocalParameterIuivEXT ::
                                       GLuint -> GLenum -> GLuint -> Ptr GLuint -> IO ()
glGetNamedProgramLocalParameterIuivEXT
  = dyn_glGetNamedProgramLocalParameterIuivEXT
      ptr_glGetNamedProgramLocalParameterIuivEXT
 
{-# NOINLINE ptr_glGetNamedProgramLocalParameterIuivEXT #-}
 
ptr_glGetNamedProgramLocalParameterIuivEXT :: FunPtr a
ptr_glGetNamedProgramLocalParameterIuivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramLocalParameterIuivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedProgramLocalParameterdvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetNamedProgramLocalParameterdvEXT ::
                                     GLuint -> GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetNamedProgramLocalParameterdvEXT
  = dyn_glGetNamedProgramLocalParameterdvEXT
      ptr_glGetNamedProgramLocalParameterdvEXT
 
{-# NOINLINE ptr_glGetNamedProgramLocalParameterdvEXT #-}
 
ptr_glGetNamedProgramLocalParameterdvEXT :: FunPtr a
ptr_glGetNamedProgramLocalParameterdvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramLocalParameterdvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedProgramLocalParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetNamedProgramLocalParameterfvEXT ::
                                     GLuint -> GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetNamedProgramLocalParameterfvEXT
  = dyn_glGetNamedProgramLocalParameterfvEXT
      ptr_glGetNamedProgramLocalParameterfvEXT
 
{-# NOINLINE ptr_glGetNamedProgramLocalParameterfvEXT #-}
 
ptr_glGetNamedProgramLocalParameterfvEXT :: FunPtr a
ptr_glGetNamedProgramLocalParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramLocalParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedProgramStringEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr e -> IO ())
 
glGetNamedProgramStringEXT ::
                           GLuint -> GLenum -> GLenum -> Ptr e -> IO ()
glGetNamedProgramStringEXT
  = dyn_glGetNamedProgramStringEXT ptr_glGetNamedProgramStringEXT
 
{-# NOINLINE ptr_glGetNamedProgramStringEXT #-}
 
ptr_glGetNamedProgramStringEXT :: FunPtr a
ptr_glGetNamedProgramStringEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramStringEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetNamedProgramivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedProgramivEXT ::
                       GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetNamedProgramivEXT
  = dyn_glGetNamedProgramivEXT ptr_glGetNamedProgramivEXT
 
{-# NOINLINE ptr_glGetNamedProgramivEXT #-}
 
ptr_glGetNamedProgramivEXT :: FunPtr a
ptr_glGetNamedProgramivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedProgramivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetNamedRenderbufferParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetNamedRenderbufferParameterivEXT ::
                                     GLuint -> GLenum -> Ptr GLint -> IO ()
glGetNamedRenderbufferParameterivEXT
  = dyn_glGetNamedRenderbufferParameterivEXT
      ptr_glGetNamedRenderbufferParameterivEXT
 
{-# NOINLINE ptr_glGetNamedRenderbufferParameterivEXT #-}
 
ptr_glGetNamedRenderbufferParameterivEXT :: FunPtr a
ptr_glGetNamedRenderbufferParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetNamedRenderbufferParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetPointerIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr (Ptr d) -> IO ())
 
glGetPointerIndexedvEXT :: GLenum -> GLuint -> Ptr (Ptr d) -> IO ()
glGetPointerIndexedvEXT
  = dyn_glGetPointerIndexedvEXT ptr_glGetPointerIndexedvEXT
 
{-# NOINLINE ptr_glGetPointerIndexedvEXT #-}
 
ptr_glGetPointerIndexedvEXT :: FunPtr a
ptr_glGetPointerIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetPointerIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetPointeri_vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr (Ptr d) -> IO ())
 
glGetPointeri_vEXT :: GLenum -> GLuint -> Ptr (Ptr d) -> IO ()
glGetPointeri_vEXT = dyn_glGetPointeri_vEXT ptr_glGetPointeri_vEXT
 
{-# NOINLINE ptr_glGetPointeri_vEXT #-}
 
ptr_glGetPointeri_vEXT :: FunPtr a
ptr_glGetPointeri_vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetPointeri_vEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTextureImageEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> GLenum -> GLenum -> Ptr g -> IO ())
 
glGetTextureImageEXT ::
                     GLuint -> GLenum -> GLint -> GLenum -> GLenum -> Ptr g -> IO ()
glGetTextureImageEXT
  = dyn_glGetTextureImageEXT ptr_glGetTextureImageEXT
 
{-# NOINLINE ptr_glGetTextureImageEXT #-}
 
ptr_glGetTextureImageEXT :: FunPtr a
ptr_glGetTextureImageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureImageEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureLevelParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetTextureLevelParameterfvEXT ::
                                GLuint -> GLenum -> GLint -> GLenum -> Ptr GLfloat -> IO ()
glGetTextureLevelParameterfvEXT
  = dyn_glGetTextureLevelParameterfvEXT
      ptr_glGetTextureLevelParameterfvEXT
 
{-# NOINLINE ptr_glGetTextureLevelParameterfvEXT #-}
 
ptr_glGetTextureLevelParameterfvEXT :: FunPtr a
ptr_glGetTextureLevelParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureLevelParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureLevelParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> GLenum -> Ptr GLint -> IO ())
 
glGetTextureLevelParameterivEXT ::
                                GLuint -> GLenum -> GLint -> GLenum -> Ptr GLint -> IO ()
glGetTextureLevelParameterivEXT
  = dyn_glGetTextureLevelParameterivEXT
      ptr_glGetTextureLevelParameterivEXT
 
{-# NOINLINE ptr_glGetTextureLevelParameterivEXT #-}
 
ptr_glGetTextureLevelParameterivEXT :: FunPtr a
ptr_glGetTextureLevelParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureLevelParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureParameterIivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetTextureParameterIivEXT ::
                            GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetTextureParameterIivEXT
  = dyn_glGetTextureParameterIivEXT ptr_glGetTextureParameterIivEXT
 
{-# NOINLINE ptr_glGetTextureParameterIivEXT #-}
 
ptr_glGetTextureParameterIivEXT :: FunPtr a
ptr_glGetTextureParameterIivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureParameterIivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureParameterIuivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glGetTextureParameterIuivEXT ::
                             GLuint -> GLenum -> GLenum -> Ptr GLuint -> IO ()
glGetTextureParameterIuivEXT
  = dyn_glGetTextureParameterIuivEXT ptr_glGetTextureParameterIuivEXT
 
{-# NOINLINE ptr_glGetTextureParameterIuivEXT #-}
 
ptr_glGetTextureParameterIuivEXT :: FunPtr a
ptr_glGetTextureParameterIuivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureParameterIuivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetTextureParameterfvEXT ::
                           GLuint -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetTextureParameterfvEXT
  = dyn_glGetTextureParameterfvEXT ptr_glGetTextureParameterfvEXT
 
{-# NOINLINE ptr_glGetTextureParameterfvEXT #-}
 
ptr_glGetTextureParameterfvEXT :: FunPtr a
ptr_glGetTextureParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTextureParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetTextureParameterivEXT ::
                           GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetTextureParameterivEXT
  = dyn_glGetTextureParameterivEXT ptr_glGetTextureParameterivEXT
 
{-# NOINLINE ptr_glGetTextureParameterivEXT #-}
 
ptr_glGetTextureParameterivEXT :: FunPtr a
ptr_glGetTextureParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetTextureParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexArrayIntegeri_vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexArrayIntegeri_vEXT ::
                              GLuint -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexArrayIntegeri_vEXT
  = dyn_glGetVertexArrayIntegeri_vEXT
      ptr_glGetVertexArrayIntegeri_vEXT
 
{-# NOINLINE ptr_glGetVertexArrayIntegeri_vEXT #-}
 
ptr_glGetVertexArrayIntegeri_vEXT :: FunPtr a
ptr_glGetVertexArrayIntegeri_vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetVertexArrayIntegeri_vEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexArrayIntegervEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexArrayIntegervEXT ::
                            GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexArrayIntegervEXT
  = dyn_glGetVertexArrayIntegervEXT ptr_glGetVertexArrayIntegervEXT
 
{-# NOINLINE ptr_glGetVertexArrayIntegervEXT #-}
 
ptr_glGetVertexArrayIntegervEXT :: FunPtr a
ptr_glGetVertexArrayIntegervEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetVertexArrayIntegervEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexArrayPointeri_vEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> Ptr (Ptr e) -> IO ())
 
glGetVertexArrayPointeri_vEXT ::
                              GLuint -> GLuint -> GLenum -> Ptr (Ptr e) -> IO ()
glGetVertexArrayPointeri_vEXT
  = dyn_glGetVertexArrayPointeri_vEXT
      ptr_glGetVertexArrayPointeri_vEXT
 
{-# NOINLINE ptr_glGetVertexArrayPointeri_vEXT #-}
 
ptr_glGetVertexArrayPointeri_vEXT :: FunPtr a
ptr_glGetVertexArrayPointeri_vEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetVertexArrayPointeri_vEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexArrayPointervEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr (Ptr d) -> IO ())
 
glGetVertexArrayPointervEXT ::
                            GLuint -> GLenum -> Ptr (Ptr d) -> IO ()
glGetVertexArrayPointervEXT
  = dyn_glGetVertexArrayPointervEXT ptr_glGetVertexArrayPointervEXT
 
{-# NOINLINE ptr_glGetVertexArrayPointervEXT #-}
 
ptr_glGetVertexArrayPointervEXT :: FunPtr a
ptr_glGetVertexArrayPointervEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glGetVertexArrayPointervEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsEnabledIndexedEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsEnabledIndexedEXT :: GLenum -> GLuint -> IO GLboolean
glIsEnabledIndexedEXT
  = dyn_glIsEnabledIndexedEXT ptr_glIsEnabledIndexedEXT
 
{-# NOINLINE ptr_glIsEnabledIndexedEXT #-}
 
ptr_glIsEnabledIndexedEXT :: FunPtr a
ptr_glIsEnabledIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glIsEnabledIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapNamedBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO (Ptr a))
 
glMapNamedBufferEXT :: GLuint -> GLenum -> IO (Ptr a)
glMapNamedBufferEXT
  = dyn_glMapNamedBufferEXT ptr_glMapNamedBufferEXT
 
{-# NOINLINE ptr_glMapNamedBufferEXT #-}
 
ptr_glMapNamedBufferEXT :: FunPtr a
ptr_glMapNamedBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMapNamedBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMapNamedBufferRangeEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a))
 
glMapNamedBufferRangeEXT ::
                         GLuint -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a)
glMapNamedBufferRangeEXT
  = dyn_glMapNamedBufferRangeEXT ptr_glMapNamedBufferRangeEXT
 
{-# NOINLINE ptr_glMapNamedBufferRangeEXT #-}
 
ptr_glMapNamedBufferRangeEXT :: FunPtr a
ptr_glMapNamedBufferRangeEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMapNamedBufferRangeEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixFrustumEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLdouble ->
                      GLdouble -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glMatrixFrustumEXT ::
                   GLenum ->
                     GLdouble ->
                       GLdouble -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glMatrixFrustumEXT = dyn_glMatrixFrustumEXT ptr_glMatrixFrustumEXT
 
{-# NOINLINE ptr_glMatrixFrustumEXT #-}
 
ptr_glMatrixFrustumEXT :: FunPtr a
ptr_glMatrixFrustumEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixFrustumEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixLoadIdentityEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glMatrixLoadIdentityEXT :: GLenum -> IO ()
glMatrixLoadIdentityEXT
  = dyn_glMatrixLoadIdentityEXT ptr_glMatrixLoadIdentityEXT
 
{-# NOINLINE ptr_glMatrixLoadIdentityEXT #-}
 
ptr_glMatrixLoadIdentityEXT :: FunPtr a
ptr_glMatrixLoadIdentityEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixLoadIdentityEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMatrixLoadTransposedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glMatrixLoadTransposedEXT :: GLenum -> Ptr GLdouble -> IO ()
glMatrixLoadTransposedEXT
  = dyn_glMatrixLoadTransposedEXT ptr_glMatrixLoadTransposedEXT
 
{-# NOINLINE ptr_glMatrixLoadTransposedEXT #-}
 
ptr_glMatrixLoadTransposedEXT :: FunPtr a
ptr_glMatrixLoadTransposedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixLoadTransposedEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMatrixLoadTransposefEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glMatrixLoadTransposefEXT :: GLenum -> Ptr GLfloat -> IO ()
glMatrixLoadTransposefEXT
  = dyn_glMatrixLoadTransposefEXT ptr_glMatrixLoadTransposefEXT
 
{-# NOINLINE ptr_glMatrixLoadTransposefEXT #-}
 
ptr_glMatrixLoadTransposefEXT :: FunPtr a
ptr_glMatrixLoadTransposefEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixLoadTransposefEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixLoaddEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glMatrixLoaddEXT :: GLenum -> Ptr GLdouble -> IO ()
glMatrixLoaddEXT = dyn_glMatrixLoaddEXT ptr_glMatrixLoaddEXT
 
{-# NOINLINE ptr_glMatrixLoaddEXT #-}
 
ptr_glMatrixLoaddEXT :: FunPtr a
ptr_glMatrixLoaddEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixLoaddEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixLoadfEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glMatrixLoadfEXT :: GLenum -> Ptr GLfloat -> IO ()
glMatrixLoadfEXT = dyn_glMatrixLoadfEXT ptr_glMatrixLoadfEXT
 
{-# NOINLINE ptr_glMatrixLoadfEXT #-}
 
ptr_glMatrixLoadfEXT :: FunPtr a
ptr_glMatrixLoadfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixLoadfEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMatrixMultTransposedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glMatrixMultTransposedEXT :: GLenum -> Ptr GLdouble -> IO ()
glMatrixMultTransposedEXT
  = dyn_glMatrixMultTransposedEXT ptr_glMatrixMultTransposedEXT
 
{-# NOINLINE ptr_glMatrixMultTransposedEXT #-}
 
ptr_glMatrixMultTransposedEXT :: FunPtr a
ptr_glMatrixMultTransposedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixMultTransposedEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMatrixMultTransposefEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glMatrixMultTransposefEXT :: GLenum -> Ptr GLfloat -> IO ()
glMatrixMultTransposefEXT
  = dyn_glMatrixMultTransposefEXT ptr_glMatrixMultTransposefEXT
 
{-# NOINLINE ptr_glMatrixMultTransposefEXT #-}
 
ptr_glMatrixMultTransposefEXT :: FunPtr a
ptr_glMatrixMultTransposefEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixMultTransposefEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixMultdEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glMatrixMultdEXT :: GLenum -> Ptr GLdouble -> IO ()
glMatrixMultdEXT = dyn_glMatrixMultdEXT ptr_glMatrixMultdEXT
 
{-# NOINLINE ptr_glMatrixMultdEXT #-}
 
ptr_glMatrixMultdEXT :: FunPtr a
ptr_glMatrixMultdEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixMultdEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixMultfEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glMatrixMultfEXT :: GLenum -> Ptr GLfloat -> IO ()
glMatrixMultfEXT = dyn_glMatrixMultfEXT ptr_glMatrixMultfEXT
 
{-# NOINLINE ptr_glMatrixMultfEXT #-}
 
ptr_glMatrixMultfEXT :: FunPtr a
ptr_glMatrixMultfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixMultfEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixOrthoEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLdouble ->
                      GLdouble -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glMatrixOrthoEXT ::
                 GLenum ->
                   GLdouble ->
                     GLdouble -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glMatrixOrthoEXT = dyn_glMatrixOrthoEXT ptr_glMatrixOrthoEXT
 
{-# NOINLINE ptr_glMatrixOrthoEXT #-}
 
ptr_glMatrixOrthoEXT :: FunPtr a
ptr_glMatrixOrthoEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixOrthoEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixPopEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glMatrixPopEXT :: GLenum -> IO ()
glMatrixPopEXT = dyn_glMatrixPopEXT ptr_glMatrixPopEXT
 
{-# NOINLINE ptr_glMatrixPopEXT #-}
 
ptr_glMatrixPopEXT :: FunPtr a
ptr_glMatrixPopEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixPopEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixPushEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glMatrixPushEXT :: GLenum -> IO ()
glMatrixPushEXT = dyn_glMatrixPushEXT ptr_glMatrixPushEXT
 
{-# NOINLINE ptr_glMatrixPushEXT #-}
 
ptr_glMatrixPushEXT :: FunPtr a
ptr_glMatrixPushEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixPushEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixRotatedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glMatrixRotatedEXT ::
                   GLenum -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glMatrixRotatedEXT = dyn_glMatrixRotatedEXT ptr_glMatrixRotatedEXT
 
{-# NOINLINE ptr_glMatrixRotatedEXT #-}
 
ptr_glMatrixRotatedEXT :: FunPtr a
ptr_glMatrixRotatedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixRotatedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixRotatefEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glMatrixRotatefEXT ::
                   GLenum -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glMatrixRotatefEXT = dyn_glMatrixRotatefEXT ptr_glMatrixRotatefEXT
 
{-# NOINLINE ptr_glMatrixRotatefEXT #-}
 
ptr_glMatrixRotatefEXT :: FunPtr a
ptr_glMatrixRotatefEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixRotatefEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixScaledEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glMatrixScaledEXT ::
                  GLenum -> GLdouble -> GLdouble -> GLdouble -> IO ()
glMatrixScaledEXT = dyn_glMatrixScaledEXT ptr_glMatrixScaledEXT
 
{-# NOINLINE ptr_glMatrixScaledEXT #-}
 
ptr_glMatrixScaledEXT :: FunPtr a
ptr_glMatrixScaledEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixScaledEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixScalefEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glMatrixScalefEXT ::
                  GLenum -> GLfloat -> GLfloat -> GLfloat -> IO ()
glMatrixScalefEXT = dyn_glMatrixScalefEXT ptr_glMatrixScalefEXT
 
{-# NOINLINE ptr_glMatrixScalefEXT #-}
 
ptr_glMatrixScalefEXT :: FunPtr a
ptr_glMatrixScalefEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixScalefEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixTranslatedEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glMatrixTranslatedEXT ::
                      GLenum -> GLdouble -> GLdouble -> GLdouble -> IO ()
glMatrixTranslatedEXT
  = dyn_glMatrixTranslatedEXT ptr_glMatrixTranslatedEXT
 
{-# NOINLINE ptr_glMatrixTranslatedEXT #-}
 
ptr_glMatrixTranslatedEXT :: FunPtr a
ptr_glMatrixTranslatedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixTranslatedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMatrixTranslatefEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glMatrixTranslatefEXT ::
                      GLenum -> GLfloat -> GLfloat -> GLfloat -> IO ()
glMatrixTranslatefEXT
  = dyn_glMatrixTranslatefEXT ptr_glMatrixTranslatefEXT
 
{-# NOINLINE ptr_glMatrixTranslatefEXT #-}
 
ptr_glMatrixTranslatefEXT :: FunPtr a
ptr_glMatrixTranslatefEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMatrixTranslatefEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLuint -> IO ())
 
glMultiTexBufferEXT ::
                    GLenum -> GLenum -> GLenum -> GLuint -> IO ()
glMultiTexBufferEXT
  = dyn_glMultiTexBufferEXT ptr_glMultiTexBufferEXT
 
{-# NOINLINE ptr_glMultiTexBufferEXT #-}
 
ptr_glMultiTexBufferEXT :: FunPtr a
ptr_glMultiTexBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexCoordPointerEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glMultiTexCoordPointerEXT ::
                          GLenum -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ()
glMultiTexCoordPointerEXT
  = dyn_glMultiTexCoordPointerEXT ptr_glMultiTexCoordPointerEXT
 
{-# NOINLINE ptr_glMultiTexCoordPointerEXT #-}
 
ptr_glMultiTexCoordPointerEXT :: FunPtr a
ptr_glMultiTexCoordPointerEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexCoordPointerEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexEnvfEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLfloat -> IO ())
 
glMultiTexEnvfEXT :: GLenum -> GLenum -> GLenum -> GLfloat -> IO ()
glMultiTexEnvfEXT = dyn_glMultiTexEnvfEXT ptr_glMultiTexEnvfEXT
 
{-# NOINLINE ptr_glMultiTexEnvfEXT #-}
 
ptr_glMultiTexEnvfEXT :: FunPtr a
ptr_glMultiTexEnvfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexEnvfEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexEnvfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glMultiTexEnvfvEXT ::
                   GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glMultiTexEnvfvEXT = dyn_glMultiTexEnvfvEXT ptr_glMultiTexEnvfvEXT
 
{-# NOINLINE ptr_glMultiTexEnvfvEXT #-}
 
ptr_glMultiTexEnvfvEXT :: FunPtr a
ptr_glMultiTexEnvfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexEnvfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexEnviEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLint -> IO ())
 
glMultiTexEnviEXT :: GLenum -> GLenum -> GLenum -> GLint -> IO ()
glMultiTexEnviEXT = dyn_glMultiTexEnviEXT ptr_glMultiTexEnviEXT
 
{-# NOINLINE ptr_glMultiTexEnviEXT #-}
 
ptr_glMultiTexEnviEXT :: FunPtr a
ptr_glMultiTexEnviEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexEnviEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexEnvivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMultiTexEnvivEXT ::
                   GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glMultiTexEnvivEXT = dyn_glMultiTexEnvivEXT ptr_glMultiTexEnvivEXT
 
{-# NOINLINE ptr_glMultiTexEnvivEXT #-}
 
ptr_glMultiTexEnvivEXT :: FunPtr a
ptr_glMultiTexEnvivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexEnvivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGendEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLdouble -> IO ())
 
glMultiTexGendEXT ::
                  GLenum -> GLenum -> GLenum -> GLdouble -> IO ()
glMultiTexGendEXT = dyn_glMultiTexGendEXT ptr_glMultiTexGendEXT
 
{-# NOINLINE ptr_glMultiTexGendEXT #-}
 
ptr_glMultiTexGendEXT :: FunPtr a
ptr_glMultiTexGendEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGendEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGendvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLdouble -> IO ())
 
glMultiTexGendvEXT ::
                   GLenum -> GLenum -> GLenum -> Ptr GLdouble -> IO ()
glMultiTexGendvEXT = dyn_glMultiTexGendvEXT ptr_glMultiTexGendvEXT
 
{-# NOINLINE ptr_glMultiTexGendvEXT #-}
 
ptr_glMultiTexGendvEXT :: FunPtr a
ptr_glMultiTexGendvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGendvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGenfEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLfloat -> IO ())
 
glMultiTexGenfEXT :: GLenum -> GLenum -> GLenum -> GLfloat -> IO ()
glMultiTexGenfEXT = dyn_glMultiTexGenfEXT ptr_glMultiTexGenfEXT
 
{-# NOINLINE ptr_glMultiTexGenfEXT #-}
 
ptr_glMultiTexGenfEXT :: FunPtr a
ptr_glMultiTexGenfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGenfEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGenfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glMultiTexGenfvEXT ::
                   GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glMultiTexGenfvEXT = dyn_glMultiTexGenfvEXT ptr_glMultiTexGenfvEXT
 
{-# NOINLINE ptr_glMultiTexGenfvEXT #-}
 
ptr_glMultiTexGenfvEXT :: FunPtr a
ptr_glMultiTexGenfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGenfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGeniEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLint -> IO ())
 
glMultiTexGeniEXT :: GLenum -> GLenum -> GLenum -> GLint -> IO ()
glMultiTexGeniEXT = dyn_glMultiTexGeniEXT ptr_glMultiTexGeniEXT
 
{-# NOINLINE ptr_glMultiTexGeniEXT #-}
 
ptr_glMultiTexGeniEXT :: FunPtr a
ptr_glMultiTexGeniEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGeniEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexGenivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMultiTexGenivEXT ::
                   GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glMultiTexGenivEXT = dyn_glMultiTexGenivEXT ptr_glMultiTexGenivEXT
 
{-# NOINLINE ptr_glMultiTexGenivEXT #-}
 
ptr_glMultiTexGenivEXT :: FunPtr a
ptr_glMultiTexGenivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexGenivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ())
 
glMultiTexImage1DEXT ::
                     GLenum ->
                       GLenum ->
                         GLint ->
                           GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ()
glMultiTexImage1DEXT
  = dyn_glMultiTexImage1DEXT ptr_glMultiTexImage1DEXT
 
{-# NOINLINE ptr_glMultiTexImage1DEXT #-}
 
ptr_glMultiTexImage1DEXT :: FunPtr a
ptr_glMultiTexImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr k -> IO ())
 
glMultiTexImage2DEXT ::
                     GLenum ->
                       GLenum ->
                         GLint ->
                           GLint ->
                             GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr k -> IO ()
glMultiTexImage2DEXT
  = dyn_glMultiTexImage2DEXT ptr_glMultiTexImage2DEXT
 
{-# NOINLINE ptr_glMultiTexImage2DEXT #-}
 
ptr_glMultiTexImage2DEXT :: FunPtr a
ptr_glMultiTexImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLsizei ->
                            GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr l -> IO ())
 
glMultiTexImage3DEXT ::
                     GLenum ->
                       GLenum ->
                         GLint ->
                           GLint ->
                             GLsizei ->
                               GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr l -> IO ()
glMultiTexImage3DEXT
  = dyn_glMultiTexImage3DEXT ptr_glMultiTexImage3DEXT
 
{-# NOINLINE ptr_glMultiTexImage3DEXT #-}
 
ptr_glMultiTexImage3DEXT :: FunPtr a
ptr_glMultiTexImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexParameterIivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMultiTexParameterIivEXT ::
                          GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glMultiTexParameterIivEXT
  = dyn_glMultiTexParameterIivEXT ptr_glMultiTexParameterIivEXT
 
{-# NOINLINE ptr_glMultiTexParameterIivEXT #-}
 
ptr_glMultiTexParameterIivEXT :: FunPtr a
ptr_glMultiTexParameterIivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameterIivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexParameterIuivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glMultiTexParameterIuivEXT ::
                           GLenum -> GLenum -> GLenum -> Ptr GLuint -> IO ()
glMultiTexParameterIuivEXT
  = dyn_glMultiTexParameterIuivEXT ptr_glMultiTexParameterIuivEXT
 
{-# NOINLINE ptr_glMultiTexParameterIuivEXT #-}
 
ptr_glMultiTexParameterIuivEXT :: FunPtr a
ptr_glMultiTexParameterIuivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameterIuivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexParameterfEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLfloat -> IO ())
 
glMultiTexParameterfEXT ::
                        GLenum -> GLenum -> GLenum -> GLfloat -> IO ()
glMultiTexParameterfEXT
  = dyn_glMultiTexParameterfEXT ptr_glMultiTexParameterfEXT
 
{-# NOINLINE ptr_glMultiTexParameterfEXT #-}
 
ptr_glMultiTexParameterfEXT :: FunPtr a
ptr_glMultiTexParameterfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameterfEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glMultiTexParameterfvEXT ::
                         GLenum -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glMultiTexParameterfvEXT
  = dyn_glMultiTexParameterfvEXT ptr_glMultiTexParameterfvEXT
 
{-# NOINLINE ptr_glMultiTexParameterfvEXT #-}
 
ptr_glMultiTexParameterfvEXT :: FunPtr a
ptr_glMultiTexParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexParameteriEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLint -> IO ())
 
glMultiTexParameteriEXT ::
                        GLenum -> GLenum -> GLenum -> GLint -> IO ()
glMultiTexParameteriEXT
  = dyn_glMultiTexParameteriEXT ptr_glMultiTexParameteriEXT
 
{-# NOINLINE ptr_glMultiTexParameteriEXT #-}
 
ptr_glMultiTexParameteriEXT :: FunPtr a
ptr_glMultiTexParameteriEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameteriEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexParameterivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMultiTexParameterivEXT ::
                         GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glMultiTexParameterivEXT
  = dyn_glMultiTexParameterivEXT ptr_glMultiTexParameterivEXT
 
{-# NOINLINE ptr_glMultiTexParameterivEXT #-}
 
ptr_glMultiTexParameterivEXT :: FunPtr a
ptr_glMultiTexParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiTexRenderbufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
glMultiTexRenderbufferEXT :: GLenum -> GLenum -> GLuint -> IO ()
glMultiTexRenderbufferEXT
  = dyn_glMultiTexRenderbufferEXT ptr_glMultiTexRenderbufferEXT
 
{-# NOINLINE ptr_glMultiTexRenderbufferEXT #-}
 
ptr_glMultiTexRenderbufferEXT :: FunPtr a
ptr_glMultiTexRenderbufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexRenderbufferEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexSubImage1DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint -> GLint -> GLsizei -> GLenum -> GLenum -> Ptr i -> IO ())
 
glMultiTexSubImage1DEXT ::
                        GLenum ->
                          GLenum ->
                            GLint -> GLint -> GLsizei -> GLenum -> GLenum -> Ptr i -> IO ()
glMultiTexSubImage1DEXT
  = dyn_glMultiTexSubImage1DEXT ptr_glMultiTexSubImage1DEXT
 
{-# NOINLINE ptr_glMultiTexSubImage1DEXT #-}
 
ptr_glMultiTexSubImage1DEXT :: FunPtr a
ptr_glMultiTexSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexSubImage2DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr k -> IO ())
 
glMultiTexSubImage2DEXT ::
                        GLenum ->
                          GLenum ->
                            GLint ->
                              GLint ->
                                GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr k -> IO ()
glMultiTexSubImage2DEXT
  = dyn_glMultiTexSubImage2DEXT ptr_glMultiTexSubImage2DEXT
 
{-# NOINLINE ptr_glMultiTexSubImage2DEXT #-}
 
ptr_glMultiTexSubImage2DEXT :: FunPtr a
ptr_glMultiTexSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexSubImage3DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLsizei ->
                                GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr m -> IO ())
 
glMultiTexSubImage3DEXT ::
                        GLenum ->
                          GLenum ->
                            GLint ->
                              GLint ->
                                GLint ->
                                  GLint ->
                                    GLsizei ->
                                      GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr m -> IO ()
glMultiTexSubImage3DEXT
  = dyn_glMultiTexSubImage3DEXT ptr_glMultiTexSubImage3DEXT
 
{-# NOINLINE ptr_glMultiTexSubImage3DEXT #-}
 
ptr_glMultiTexSubImage3DEXT :: FunPtr a
ptr_glMultiTexSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glMultiTexSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedBufferDataEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizeiptr -> Ptr d -> GLenum -> IO ())
 
glNamedBufferDataEXT ::
                     GLuint -> GLsizeiptr -> Ptr d -> GLenum -> IO ()
glNamedBufferDataEXT
  = dyn_glNamedBufferDataEXT ptr_glNamedBufferDataEXT
 
{-# NOINLINE ptr_glNamedBufferDataEXT #-}
 
ptr_glNamedBufferDataEXT :: FunPtr a
ptr_glNamedBufferDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedBufferDataEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedBufferStorageEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizeiptr -> Ptr d -> GLbitfield -> IO ())
 
glNamedBufferStorageEXT ::
                        GLuint -> GLsizeiptr -> Ptr d -> GLbitfield -> IO ()
glNamedBufferStorageEXT
  = dyn_glNamedBufferStorageEXT ptr_glNamedBufferStorageEXT
 
{-# NOINLINE ptr_glNamedBufferStorageEXT #-}
 
ptr_glNamedBufferStorageEXT :: FunPtr a
ptr_glNamedBufferStorageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedBufferStorageEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedBufferSubDataEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLintptr -> GLsizeiptr -> Ptr e -> IO ())
 
glNamedBufferSubDataEXT ::
                        GLuint -> GLintptr -> GLsizeiptr -> Ptr e -> IO ()
glNamedBufferSubDataEXT
  = dyn_glNamedBufferSubDataEXT ptr_glNamedBufferSubDataEXT
 
{-# NOINLINE ptr_glNamedBufferSubDataEXT #-}
 
ptr_glNamedBufferSubDataEXT :: FunPtr a
ptr_glNamedBufferSubDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedBufferSubDataEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedCopyBufferSubDataEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLintptr -> GLintptr -> GLsizeiptr -> IO ())
 
glNamedCopyBufferSubDataEXT ::
                            GLuint -> GLuint -> GLintptr -> GLintptr -> GLsizeiptr -> IO ()
glNamedCopyBufferSubDataEXT
  = dyn_glNamedCopyBufferSubDataEXT ptr_glNamedCopyBufferSubDataEXT
 
{-# NOINLINE ptr_glNamedCopyBufferSubDataEXT #-}
 
ptr_glNamedCopyBufferSubDataEXT :: FunPtr a
ptr_glNamedCopyBufferSubDataEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedCopyBufferSubDataEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferParameteriEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
glNamedFramebufferParameteriEXT ::
                                GLuint -> GLenum -> GLint -> IO ()
glNamedFramebufferParameteriEXT
  = dyn_glNamedFramebufferParameteriEXT
      ptr_glNamedFramebufferParameteriEXT
 
{-# NOINLINE ptr_glNamedFramebufferParameteriEXT #-}
 
ptr_glNamedFramebufferParameteriEXT :: FunPtr a
ptr_glNamedFramebufferParameteriEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferParameteriEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferRenderbufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLuint -> IO ())
 
glNamedFramebufferRenderbufferEXT ::
                                  GLuint -> GLenum -> GLenum -> GLuint -> IO ()
glNamedFramebufferRenderbufferEXT
  = dyn_glNamedFramebufferRenderbufferEXT
      ptr_glNamedFramebufferRenderbufferEXT
 
{-# NOINLINE ptr_glNamedFramebufferRenderbufferEXT #-}
 
ptr_glNamedFramebufferRenderbufferEXT :: FunPtr a
ptr_glNamedFramebufferRenderbufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferRenderbufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTexture1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLuint -> GLint -> IO ())
 
glNamedFramebufferTexture1DEXT ::
                               GLuint -> GLenum -> GLenum -> GLuint -> GLint -> IO ()
glNamedFramebufferTexture1DEXT
  = dyn_glNamedFramebufferTexture1DEXT
      ptr_glNamedFramebufferTexture1DEXT
 
{-# NOINLINE ptr_glNamedFramebufferTexture1DEXT #-}
 
ptr_glNamedFramebufferTexture1DEXT :: FunPtr a
ptr_glNamedFramebufferTexture1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTexture1DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTexture2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLuint -> GLint -> IO ())
 
glNamedFramebufferTexture2DEXT ::
                               GLuint -> GLenum -> GLenum -> GLuint -> GLint -> IO ()
glNamedFramebufferTexture2DEXT
  = dyn_glNamedFramebufferTexture2DEXT
      ptr_glNamedFramebufferTexture2DEXT
 
{-# NOINLINE ptr_glNamedFramebufferTexture2DEXT #-}
 
ptr_glNamedFramebufferTexture2DEXT :: FunPtr a
ptr_glNamedFramebufferTexture2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTexture2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTexture3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ())
 
glNamedFramebufferTexture3DEXT ::
                               GLuint -> GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ()
glNamedFramebufferTexture3DEXT
  = dyn_glNamedFramebufferTexture3DEXT
      ptr_glNamedFramebufferTexture3DEXT
 
{-# NOINLINE ptr_glNamedFramebufferTexture3DEXT #-}
 
ptr_glNamedFramebufferTexture3DEXT :: FunPtr a
ptr_glNamedFramebufferTexture3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTexture3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTextureEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLint -> IO ())
 
glNamedFramebufferTextureEXT ::
                             GLuint -> GLenum -> GLuint -> GLint -> IO ()
glNamedFramebufferTextureEXT
  = dyn_glNamedFramebufferTextureEXT ptr_glNamedFramebufferTextureEXT
 
{-# NOINLINE ptr_glNamedFramebufferTextureEXT #-}
 
ptr_glNamedFramebufferTextureEXT :: FunPtr a
ptr_glNamedFramebufferTextureEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTextureEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTextureFaceEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLint -> GLenum -> IO ())
 
glNamedFramebufferTextureFaceEXT ::
                                 GLuint -> GLenum -> GLuint -> GLint -> GLenum -> IO ()
glNamedFramebufferTextureFaceEXT
  = dyn_glNamedFramebufferTextureFaceEXT
      ptr_glNamedFramebufferTextureFaceEXT
 
{-# NOINLINE ptr_glNamedFramebufferTextureFaceEXT #-}
 
ptr_glNamedFramebufferTextureFaceEXT :: FunPtr a
ptr_glNamedFramebufferTextureFaceEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTextureFaceEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedFramebufferTextureLayerEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLint -> GLint -> IO ())
 
glNamedFramebufferTextureLayerEXT ::
                                  GLuint -> GLenum -> GLuint -> GLint -> GLint -> IO ()
glNamedFramebufferTextureLayerEXT
  = dyn_glNamedFramebufferTextureLayerEXT
      ptr_glNamedFramebufferTextureLayerEXT
 
{-# NOINLINE ptr_glNamedFramebufferTextureLayerEXT #-}
 
ptr_glNamedFramebufferTextureLayerEXT :: FunPtr a
ptr_glNamedFramebufferTextureLayerEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedFramebufferTextureLayerEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameter4dEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glNamedProgramLocalParameter4dEXT ::
                                  GLuint ->
                                    GLenum ->
                                      GLuint ->
                                        GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glNamedProgramLocalParameter4dEXT
  = dyn_glNamedProgramLocalParameter4dEXT
      ptr_glNamedProgramLocalParameter4dEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameter4dEXT #-}
 
ptr_glNamedProgramLocalParameter4dEXT :: FunPtr a
ptr_glNamedProgramLocalParameter4dEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameter4dEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameter4dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glNamedProgramLocalParameter4dvEXT ::
                                   GLuint -> GLenum -> GLuint -> Ptr GLdouble -> IO ()
glNamedProgramLocalParameter4dvEXT
  = dyn_glNamedProgramLocalParameter4dvEXT
      ptr_glNamedProgramLocalParameter4dvEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameter4dvEXT #-}
 
ptr_glNamedProgramLocalParameter4dvEXT :: FunPtr a
ptr_glNamedProgramLocalParameter4dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameter4dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameter4fEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glNamedProgramLocalParameter4fEXT ::
                                  GLuint ->
                                    GLenum ->
                                      GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glNamedProgramLocalParameter4fEXT
  = dyn_glNamedProgramLocalParameter4fEXT
      ptr_glNamedProgramLocalParameter4fEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameter4fEXT #-}
 
ptr_glNamedProgramLocalParameter4fEXT :: FunPtr a
ptr_glNamedProgramLocalParameter4fEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameter4fEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameter4fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glNamedProgramLocalParameter4fvEXT ::
                                   GLuint -> GLenum -> GLuint -> Ptr GLfloat -> IO ()
glNamedProgramLocalParameter4fvEXT
  = dyn_glNamedProgramLocalParameter4fvEXT
      ptr_glNamedProgramLocalParameter4fvEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameter4fvEXT #-}
 
ptr_glNamedProgramLocalParameter4fvEXT :: FunPtr a
ptr_glNamedProgramLocalParameter4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameter4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameterI4iEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glNamedProgramLocalParameterI4iEXT ::
                                   GLuint ->
                                     GLenum -> GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glNamedProgramLocalParameterI4iEXT
  = dyn_glNamedProgramLocalParameterI4iEXT
      ptr_glNamedProgramLocalParameterI4iEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameterI4iEXT #-}
 
ptr_glNamedProgramLocalParameterI4iEXT :: FunPtr a
ptr_glNamedProgramLocalParameterI4iEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameterI4iEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameterI4ivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLint -> IO ())
 
glNamedProgramLocalParameterI4ivEXT ::
                                    GLuint -> GLenum -> GLuint -> Ptr GLint -> IO ()
glNamedProgramLocalParameterI4ivEXT
  = dyn_glNamedProgramLocalParameterI4ivEXT
      ptr_glNamedProgramLocalParameterI4ivEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameterI4ivEXT #-}
 
ptr_glNamedProgramLocalParameterI4ivEXT :: FunPtr a
ptr_glNamedProgramLocalParameterI4ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameterI4ivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameterI4uiEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glNamedProgramLocalParameterI4uiEXT ::
                                    GLuint ->
                                      GLenum ->
                                        GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glNamedProgramLocalParameterI4uiEXT
  = dyn_glNamedProgramLocalParameterI4uiEXT
      ptr_glNamedProgramLocalParameterI4uiEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameterI4uiEXT #-}
 
ptr_glNamedProgramLocalParameterI4uiEXT :: FunPtr a
ptr_glNamedProgramLocalParameterI4uiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameterI4uiEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameterI4uivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> Ptr GLuint -> IO ())
 
glNamedProgramLocalParameterI4uivEXT ::
                                     GLuint -> GLenum -> GLuint -> Ptr GLuint -> IO ()
glNamedProgramLocalParameterI4uivEXT
  = dyn_glNamedProgramLocalParameterI4uivEXT
      ptr_glNamedProgramLocalParameterI4uivEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameterI4uivEXT #-}
 
ptr_glNamedProgramLocalParameterI4uivEXT :: FunPtr a
ptr_glNamedProgramLocalParameterI4uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameterI4uivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParameters4fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
glNamedProgramLocalParameters4fvEXT ::
                                    GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glNamedProgramLocalParameters4fvEXT
  = dyn_glNamedProgramLocalParameters4fvEXT
      ptr_glNamedProgramLocalParameters4fvEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParameters4fvEXT #-}
 
ptr_glNamedProgramLocalParameters4fvEXT :: FunPtr a
ptr_glNamedProgramLocalParameters4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParameters4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParametersI4ivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ())
 
glNamedProgramLocalParametersI4ivEXT ::
                                     GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLint -> IO ()
glNamedProgramLocalParametersI4ivEXT
  = dyn_glNamedProgramLocalParametersI4ivEXT
      ptr_glNamedProgramLocalParametersI4ivEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParametersI4ivEXT #-}
 
ptr_glNamedProgramLocalParametersI4ivEXT :: FunPtr a
ptr_glNamedProgramLocalParametersI4ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParametersI4ivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedProgramLocalParametersI4uivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ())
 
glNamedProgramLocalParametersI4uivEXT ::
                                      GLuint -> GLenum -> GLuint -> GLsizei -> Ptr GLuint -> IO ()
glNamedProgramLocalParametersI4uivEXT
  = dyn_glNamedProgramLocalParametersI4uivEXT
      ptr_glNamedProgramLocalParametersI4uivEXT
 
{-# NOINLINE ptr_glNamedProgramLocalParametersI4uivEXT #-}
 
ptr_glNamedProgramLocalParametersI4uivEXT :: FunPtr a
ptr_glNamedProgramLocalParametersI4uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramLocalParametersI4uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNamedProgramStringEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glNamedProgramStringEXT ::
                        GLuint -> GLenum -> GLenum -> GLsizei -> Ptr f -> IO ()
glNamedProgramStringEXT
  = dyn_glNamedProgramStringEXT ptr_glNamedProgramStringEXT
 
{-# NOINLINE ptr_glNamedProgramStringEXT #-}
 
ptr_glNamedProgramStringEXT :: FunPtr a
ptr_glNamedProgramStringEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedProgramStringEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedRenderbufferStorageEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glNamedRenderbufferStorageEXT ::
                              GLuint -> GLenum -> GLsizei -> GLsizei -> IO ()
glNamedRenderbufferStorageEXT
  = dyn_glNamedRenderbufferStorageEXT
      ptr_glNamedRenderbufferStorageEXT
 
{-# NOINLINE ptr_glNamedRenderbufferStorageEXT #-}
 
ptr_glNamedRenderbufferStorageEXT :: FunPtr a
ptr_glNamedRenderbufferStorageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedRenderbufferStorageEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedRenderbufferStorageMultisampleCoverageEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLsizei -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glNamedRenderbufferStorageMultisampleCoverageEXT ::
                                                 GLuint ->
                                                   GLsizei ->
                                                     GLsizei ->
                                                       GLenum -> GLsizei -> GLsizei -> IO ()
glNamedRenderbufferStorageMultisampleCoverageEXT
  = dyn_glNamedRenderbufferStorageMultisampleCoverageEXT
      ptr_glNamedRenderbufferStorageMultisampleCoverageEXT
 
{-# NOINLINE ptr_glNamedRenderbufferStorageMultisampleCoverageEXT
             #-}
 
ptr_glNamedRenderbufferStorageMultisampleCoverageEXT :: FunPtr a
ptr_glNamedRenderbufferStorageMultisampleCoverageEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedRenderbufferStorageMultisampleCoverageEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glNamedRenderbufferStorageMultisampleEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glNamedRenderbufferStorageMultisampleEXT ::
                                         GLuint -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glNamedRenderbufferStorageMultisampleEXT
  = dyn_glNamedRenderbufferStorageMultisampleEXT
      ptr_glNamedRenderbufferStorageMultisampleEXT
 
{-# NOINLINE ptr_glNamedRenderbufferStorageMultisampleEXT #-}
 
ptr_glNamedRenderbufferStorageMultisampleEXT :: FunPtr a
ptr_glNamedRenderbufferStorageMultisampleEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glNamedRenderbufferStorageMultisampleEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1dEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> IO ())
 
glProgramUniform1dEXT :: GLuint -> GLint -> GLdouble -> IO ()
glProgramUniform1dEXT
  = dyn_glProgramUniform1dEXT ptr_glProgramUniform1dEXT
 
{-# NOINLINE ptr_glProgramUniform1dEXT #-}
 
ptr_glProgramUniform1dEXT :: FunPtr a
ptr_glProgramUniform1dEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1dEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1dvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform1dvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform1dvEXT
  = dyn_glProgramUniform1dvEXT ptr_glProgramUniform1dvEXT
 
{-# NOINLINE ptr_glProgramUniform1dvEXT #-}
 
ptr_glProgramUniform1dvEXT :: FunPtr a
ptr_glProgramUniform1dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1dvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1fEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> IO ())
 
glProgramUniform1fEXT :: GLuint -> GLint -> GLfloat -> IO ()
glProgramUniform1fEXT
  = dyn_glProgramUniform1fEXT ptr_glProgramUniform1fEXT
 
{-# NOINLINE ptr_glProgramUniform1fEXT #-}
 
ptr_glProgramUniform1fEXT :: FunPtr a
ptr_glProgramUniform1fEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1fEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1fvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform1fvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform1fvEXT
  = dyn_glProgramUniform1fvEXT ptr_glProgramUniform1fvEXT
 
{-# NOINLINE ptr_glProgramUniform1fvEXT #-}
 
ptr_glProgramUniform1fvEXT :: FunPtr a
ptr_glProgramUniform1fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1fvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1iEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> IO ())
 
glProgramUniform1iEXT :: GLuint -> GLint -> GLint -> IO ()
glProgramUniform1iEXT
  = dyn_glProgramUniform1iEXT ptr_glProgramUniform1iEXT
 
{-# NOINLINE ptr_glProgramUniform1iEXT #-}
 
ptr_glProgramUniform1iEXT :: FunPtr a
ptr_glProgramUniform1iEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1ivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform1ivEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform1ivEXT
  = dyn_glProgramUniform1ivEXT ptr_glProgramUniform1ivEXT
 
{-# NOINLINE ptr_glProgramUniform1ivEXT #-}
 
ptr_glProgramUniform1ivEXT :: FunPtr a
ptr_glProgramUniform1ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1uiEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> IO ())
 
glProgramUniform1uiEXT :: GLuint -> GLint -> GLuint -> IO ()
glProgramUniform1uiEXT
  = dyn_glProgramUniform1uiEXT ptr_glProgramUniform1uiEXT
 
{-# NOINLINE ptr_glProgramUniform1uiEXT #-}
 
ptr_glProgramUniform1uiEXT :: FunPtr a
ptr_glProgramUniform1uiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1uivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform1uivEXT ::
                        GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform1uivEXT
  = dyn_glProgramUniform1uivEXT ptr_glProgramUniform1uivEXT
 
{-# NOINLINE ptr_glProgramUniform1uivEXT #-}
 
ptr_glProgramUniform1uivEXT :: FunPtr a
ptr_glProgramUniform1uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform1uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2dEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform2dEXT ::
                      GLuint -> GLint -> GLdouble -> GLdouble -> IO ()
glProgramUniform2dEXT
  = dyn_glProgramUniform2dEXT ptr_glProgramUniform2dEXT
 
{-# NOINLINE ptr_glProgramUniform2dEXT #-}
 
ptr_glProgramUniform2dEXT :: FunPtr a
ptr_glProgramUniform2dEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2dEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2dvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform2dvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform2dvEXT
  = dyn_glProgramUniform2dvEXT ptr_glProgramUniform2dvEXT
 
{-# NOINLINE ptr_glProgramUniform2dvEXT #-}
 
ptr_glProgramUniform2dvEXT :: FunPtr a
ptr_glProgramUniform2dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2dvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2fEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform2fEXT ::
                      GLuint -> GLint -> GLfloat -> GLfloat -> IO ()
glProgramUniform2fEXT
  = dyn_glProgramUniform2fEXT ptr_glProgramUniform2fEXT
 
{-# NOINLINE ptr_glProgramUniform2fEXT #-}
 
ptr_glProgramUniform2fEXT :: FunPtr a
ptr_glProgramUniform2fEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2fEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2fvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform2fvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform2fvEXT
  = dyn_glProgramUniform2fvEXT ptr_glProgramUniform2fvEXT
 
{-# NOINLINE ptr_glProgramUniform2fvEXT #-}
 
ptr_glProgramUniform2fvEXT :: FunPtr a
ptr_glProgramUniform2fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2fvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2iEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform2iEXT :: GLuint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform2iEXT
  = dyn_glProgramUniform2iEXT ptr_glProgramUniform2iEXT
 
{-# NOINLINE ptr_glProgramUniform2iEXT #-}
 
ptr_glProgramUniform2iEXT :: FunPtr a
ptr_glProgramUniform2iEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2ivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform2ivEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform2ivEXT
  = dyn_glProgramUniform2ivEXT ptr_glProgramUniform2ivEXT
 
{-# NOINLINE ptr_glProgramUniform2ivEXT #-}
 
ptr_glProgramUniform2ivEXT :: FunPtr a
ptr_glProgramUniform2ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2uiEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> IO ())
 
glProgramUniform2uiEXT ::
                       GLuint -> GLint -> GLuint -> GLuint -> IO ()
glProgramUniform2uiEXT
  = dyn_glProgramUniform2uiEXT ptr_glProgramUniform2uiEXT
 
{-# NOINLINE ptr_glProgramUniform2uiEXT #-}
 
ptr_glProgramUniform2uiEXT :: FunPtr a
ptr_glProgramUniform2uiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2uivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform2uivEXT ::
                        GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform2uivEXT
  = dyn_glProgramUniform2uivEXT ptr_glProgramUniform2uivEXT
 
{-# NOINLINE ptr_glProgramUniform2uivEXT #-}
 
ptr_glProgramUniform2uivEXT :: FunPtr a
ptr_glProgramUniform2uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform2uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3dEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform3dEXT ::
                      GLuint -> GLint -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramUniform3dEXT
  = dyn_glProgramUniform3dEXT ptr_glProgramUniform3dEXT
 
{-# NOINLINE ptr_glProgramUniform3dEXT #-}
 
ptr_glProgramUniform3dEXT :: FunPtr a
ptr_glProgramUniform3dEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3dEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3dvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform3dvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform3dvEXT
  = dyn_glProgramUniform3dvEXT ptr_glProgramUniform3dvEXT
 
{-# NOINLINE ptr_glProgramUniform3dvEXT #-}
 
ptr_glProgramUniform3dvEXT :: FunPtr a
ptr_glProgramUniform3dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3dvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3fEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform3fEXT ::
                      GLuint -> GLint -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramUniform3fEXT
  = dyn_glProgramUniform3fEXT ptr_glProgramUniform3fEXT
 
{-# NOINLINE ptr_glProgramUniform3fEXT #-}
 
ptr_glProgramUniform3fEXT :: FunPtr a
ptr_glProgramUniform3fEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3fEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3fvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform3fvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform3fvEXT
  = dyn_glProgramUniform3fvEXT ptr_glProgramUniform3fvEXT
 
{-# NOINLINE ptr_glProgramUniform3fvEXT #-}
 
ptr_glProgramUniform3fvEXT :: FunPtr a
ptr_glProgramUniform3fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3fvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3iEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform3iEXT ::
                      GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform3iEXT
  = dyn_glProgramUniform3iEXT ptr_glProgramUniform3iEXT
 
{-# NOINLINE ptr_glProgramUniform3iEXT #-}
 
ptr_glProgramUniform3iEXT :: FunPtr a
ptr_glProgramUniform3iEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3ivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform3ivEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform3ivEXT
  = dyn_glProgramUniform3ivEXT ptr_glProgramUniform3ivEXT
 
{-# NOINLINE ptr_glProgramUniform3ivEXT #-}
 
ptr_glProgramUniform3ivEXT :: FunPtr a
ptr_glProgramUniform3ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3uiEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramUniform3uiEXT ::
                       GLuint -> GLint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramUniform3uiEXT
  = dyn_glProgramUniform3uiEXT ptr_glProgramUniform3uiEXT
 
{-# NOINLINE ptr_glProgramUniform3uiEXT #-}
 
ptr_glProgramUniform3uiEXT :: FunPtr a
ptr_glProgramUniform3uiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3uivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform3uivEXT ::
                        GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform3uivEXT
  = dyn_glProgramUniform3uivEXT ptr_glProgramUniform3uivEXT
 
{-# NOINLINE ptr_glProgramUniform3uivEXT #-}
 
ptr_glProgramUniform3uivEXT :: FunPtr a
ptr_glProgramUniform3uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform3uivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4dEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform4dEXT ::
                      GLuint ->
                        GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramUniform4dEXT
  = dyn_glProgramUniform4dEXT ptr_glProgramUniform4dEXT
 
{-# NOINLINE ptr_glProgramUniform4dEXT #-}
 
ptr_glProgramUniform4dEXT :: FunPtr a
ptr_glProgramUniform4dEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4dEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4dvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform4dvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform4dvEXT
  = dyn_glProgramUniform4dvEXT ptr_glProgramUniform4dvEXT
 
{-# NOINLINE ptr_glProgramUniform4dvEXT #-}
 
ptr_glProgramUniform4dvEXT :: FunPtr a
ptr_glProgramUniform4dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4dvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4fEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform4fEXT ::
                      GLuint ->
                        GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramUniform4fEXT
  = dyn_glProgramUniform4fEXT ptr_glProgramUniform4fEXT
 
{-# NOINLINE ptr_glProgramUniform4fEXT #-}
 
ptr_glProgramUniform4fEXT :: FunPtr a
ptr_glProgramUniform4fEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4fEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4fvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform4fvEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform4fvEXT
  = dyn_glProgramUniform4fvEXT ptr_glProgramUniform4fvEXT
 
{-# NOINLINE ptr_glProgramUniform4fvEXT #-}
 
ptr_glProgramUniform4fvEXT :: FunPtr a
ptr_glProgramUniform4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4fvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4iEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform4iEXT ::
                      GLuint -> GLint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform4iEXT
  = dyn_glProgramUniform4iEXT ptr_glProgramUniform4iEXT
 
{-# NOINLINE ptr_glProgramUniform4iEXT #-}
 
ptr_glProgramUniform4iEXT :: FunPtr a
ptr_glProgramUniform4iEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4iEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4ivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform4ivEXT ::
                       GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform4ivEXT
  = dyn_glProgramUniform4ivEXT ptr_glProgramUniform4ivEXT
 
{-# NOINLINE ptr_glProgramUniform4ivEXT #-}
 
ptr_glProgramUniform4ivEXT :: FunPtr a
ptr_glProgramUniform4ivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4ivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4uiEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramUniform4uiEXT ::
                       GLuint -> GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramUniform4uiEXT
  = dyn_glProgramUniform4uiEXT ptr_glProgramUniform4uiEXT
 
{-# NOINLINE ptr_glProgramUniform4uiEXT #-}
 
ptr_glProgramUniform4uiEXT :: FunPtr a
ptr_glProgramUniform4uiEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4uiEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4uivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform4uivEXT ::
                        GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform4uivEXT
  = dyn_glProgramUniform4uivEXT ptr_glProgramUniform4uivEXT
 
{-# NOINLINE ptr_glProgramUniform4uivEXT #-}
 
ptr_glProgramUniform4uivEXT :: FunPtr a
ptr_glProgramUniform4uivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniform4uivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2dvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2dvEXT
  = dyn_glProgramUniformMatrix2dvEXT ptr_glProgramUniformMatrix2dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2dvEXT #-}
 
ptr_glProgramUniformMatrix2dvEXT :: FunPtr a
ptr_glProgramUniformMatrix2dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2fvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2fvEXT
  = dyn_glProgramUniformMatrix2fvEXT ptr_glProgramUniformMatrix2fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2fvEXT #-}
 
ptr_glProgramUniformMatrix2fvEXT :: FunPtr a
ptr_glProgramUniformMatrix2fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x3dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2x3dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2x3dvEXT
  = dyn_glProgramUniformMatrix2x3dvEXT
      ptr_glProgramUniformMatrix2x3dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2x3dvEXT #-}
 
ptr_glProgramUniformMatrix2x3dvEXT :: FunPtr a
ptr_glProgramUniformMatrix2x3dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2x3dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x3fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2x3fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2x3fvEXT
  = dyn_glProgramUniformMatrix2x3fvEXT
      ptr_glProgramUniformMatrix2x3fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2x3fvEXT #-}
 
ptr_glProgramUniformMatrix2x3fvEXT :: FunPtr a
ptr_glProgramUniformMatrix2x3fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2x3fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x4dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2x4dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2x4dvEXT
  = dyn_glProgramUniformMatrix2x4dvEXT
      ptr_glProgramUniformMatrix2x4dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2x4dvEXT #-}
 
ptr_glProgramUniformMatrix2x4dvEXT :: FunPtr a
ptr_glProgramUniformMatrix2x4dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2x4dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x4fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2x4fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2x4fvEXT
  = dyn_glProgramUniformMatrix2x4fvEXT
      ptr_glProgramUniformMatrix2x4fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix2x4fvEXT #-}
 
ptr_glProgramUniformMatrix2x4fvEXT :: FunPtr a
ptr_glProgramUniformMatrix2x4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix2x4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3dvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3dvEXT
  = dyn_glProgramUniformMatrix3dvEXT ptr_glProgramUniformMatrix3dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3dvEXT #-}
 
ptr_glProgramUniformMatrix3dvEXT :: FunPtr a
ptr_glProgramUniformMatrix3dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3fvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3fvEXT
  = dyn_glProgramUniformMatrix3fvEXT ptr_glProgramUniformMatrix3fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3fvEXT #-}
 
ptr_glProgramUniformMatrix3fvEXT :: FunPtr a
ptr_glProgramUniformMatrix3fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x2dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3x2dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3x2dvEXT
  = dyn_glProgramUniformMatrix3x2dvEXT
      ptr_glProgramUniformMatrix3x2dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3x2dvEXT #-}
 
ptr_glProgramUniformMatrix3x2dvEXT :: FunPtr a
ptr_glProgramUniformMatrix3x2dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3x2dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x2fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3x2fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3x2fvEXT
  = dyn_glProgramUniformMatrix3x2fvEXT
      ptr_glProgramUniformMatrix3x2fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3x2fvEXT #-}
 
ptr_glProgramUniformMatrix3x2fvEXT :: FunPtr a
ptr_glProgramUniformMatrix3x2fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3x2fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x4dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3x4dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3x4dvEXT
  = dyn_glProgramUniformMatrix3x4dvEXT
      ptr_glProgramUniformMatrix3x4dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3x4dvEXT #-}
 
ptr_glProgramUniformMatrix3x4dvEXT :: FunPtr a
ptr_glProgramUniformMatrix3x4dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3x4dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x4fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3x4fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3x4fvEXT
  = dyn_glProgramUniformMatrix3x4fvEXT
      ptr_glProgramUniformMatrix3x4fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix3x4fvEXT #-}
 
ptr_glProgramUniformMatrix3x4fvEXT :: FunPtr a
ptr_glProgramUniformMatrix3x4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix3x4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4dvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4dvEXT
  = dyn_glProgramUniformMatrix4dvEXT ptr_glProgramUniformMatrix4dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4dvEXT #-}
 
ptr_glProgramUniformMatrix4dvEXT :: FunPtr a
ptr_glProgramUniformMatrix4dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4fvEXT ::
                             GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4fvEXT
  = dyn_glProgramUniformMatrix4fvEXT ptr_glProgramUniformMatrix4fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4fvEXT #-}
 
ptr_glProgramUniformMatrix4fvEXT :: FunPtr a
ptr_glProgramUniformMatrix4fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x2dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4x2dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4x2dvEXT
  = dyn_glProgramUniformMatrix4x2dvEXT
      ptr_glProgramUniformMatrix4x2dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4x2dvEXT #-}
 
ptr_glProgramUniformMatrix4x2dvEXT :: FunPtr a
ptr_glProgramUniformMatrix4x2dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4x2dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x2fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4x2fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4x2fvEXT
  = dyn_glProgramUniformMatrix4x2fvEXT
      ptr_glProgramUniformMatrix4x2fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4x2fvEXT #-}
 
ptr_glProgramUniformMatrix4x2fvEXT :: FunPtr a
ptr_glProgramUniformMatrix4x2fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4x2fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x3dvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4x3dvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4x3dvEXT
  = dyn_glProgramUniformMatrix4x3dvEXT
      ptr_glProgramUniformMatrix4x3dvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4x3dvEXT #-}
 
ptr_glProgramUniformMatrix4x3dvEXT :: FunPtr a
ptr_glProgramUniformMatrix4x3dvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4x3dvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x3fvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4x3fvEXT ::
                               GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4x3fvEXT
  = dyn_glProgramUniformMatrix4x3fvEXT
      ptr_glProgramUniformMatrix4x3fvEXT
 
{-# NOINLINE ptr_glProgramUniformMatrix4x3fvEXT #-}
 
ptr_glProgramUniformMatrix4x3fvEXT :: FunPtr a
ptr_glProgramUniformMatrix4x3fvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glProgramUniformMatrix4x3fvEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPushClientAttribDefaultEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
glPushClientAttribDefaultEXT :: GLbitfield -> IO ()
glPushClientAttribDefaultEXT
  = dyn_glPushClientAttribDefaultEXT ptr_glPushClientAttribDefaultEXT
 
{-# NOINLINE ptr_glPushClientAttribDefaultEXT #-}
 
ptr_glPushClientAttribDefaultEXT :: FunPtr a
ptr_glPushClientAttribDefaultEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glPushClientAttribDefaultEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLuint -> IO ())
 
glTextureBufferEXT :: GLuint -> GLenum -> GLenum -> GLuint -> IO ()
glTextureBufferEXT = dyn_glTextureBufferEXT ptr_glTextureBufferEXT
 
{-# NOINLINE ptr_glTextureBufferEXT #-}
 
ptr_glTextureBufferEXT :: FunPtr a
ptr_glTextureBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureBufferEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureBufferRangeEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLenum -> GLuint -> GLintptr -> GLsizeiptr -> IO ())
 
glTextureBufferRangeEXT ::
                        GLuint ->
                          GLenum -> GLenum -> GLuint -> GLintptr -> GLsizeiptr -> IO ()
glTextureBufferRangeEXT
  = dyn_glTextureBufferRangeEXT ptr_glTextureBufferRangeEXT
 
{-# NOINLINE ptr_glTextureBufferRangeEXT #-}
 
ptr_glTextureBufferRangeEXT :: FunPtr a
ptr_glTextureBufferRangeEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureBufferRangeEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureImage1DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ())
 
glTextureImage1DEXT ::
                    GLuint ->
                      GLenum ->
                        GLint ->
                          GLint -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr j -> IO ()
glTextureImage1DEXT
  = dyn_glTextureImage1DEXT ptr_glTextureImage1DEXT
 
{-# NOINLINE ptr_glTextureImage1DEXT #-}
 
ptr_glTextureImage1DEXT :: FunPtr a
ptr_glTextureImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureImage2DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr k -> IO ())
 
glTextureImage2DEXT ::
                    GLuint ->
                      GLenum ->
                        GLint ->
                          GLint ->
                            GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr k -> IO ()
glTextureImage2DEXT
  = dyn_glTextureImage2DEXT ptr_glTextureImage2DEXT
 
{-# NOINLINE ptr_glTextureImage2DEXT #-}
 
ptr_glTextureImage2DEXT :: FunPtr a
ptr_glTextureImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureImage3DEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLsizei ->
                            GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr l -> IO ())
 
glTextureImage3DEXT ::
                    GLuint ->
                      GLenum ->
                        GLint ->
                          GLint ->
                            GLsizei ->
                              GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr l -> IO ()
glTextureImage3DEXT
  = dyn_glTextureImage3DEXT ptr_glTextureImage3DEXT
 
{-# NOINLINE ptr_glTextureImage3DEXT #-}
 
ptr_glTextureImage3DEXT :: FunPtr a
ptr_glTextureImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexturePageCommitmentEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
glTexturePageCommitmentEXT ::
                           GLuint ->
                             GLint ->
                               GLint ->
                                 GLint ->
                                   GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTexturePageCommitmentEXT
  = dyn_glTexturePageCommitmentEXT ptr_glTexturePageCommitmentEXT
 
{-# NOINLINE ptr_glTexturePageCommitmentEXT #-}
 
ptr_glTexturePageCommitmentEXT :: FunPtr a
ptr_glTexturePageCommitmentEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTexturePageCommitmentEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTextureParameterIivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glTextureParameterIivEXT ::
                         GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glTextureParameterIivEXT
  = dyn_glTextureParameterIivEXT ptr_glTextureParameterIivEXT
 
{-# NOINLINE ptr_glTextureParameterIivEXT #-}
 
ptr_glTextureParameterIivEXT :: FunPtr a
ptr_glTextureParameterIivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameterIivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTextureParameterIuivEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glTextureParameterIuivEXT ::
                          GLuint -> GLenum -> GLenum -> Ptr GLuint -> IO ()
glTextureParameterIuivEXT
  = dyn_glTextureParameterIuivEXT ptr_glTextureParameterIuivEXT
 
{-# NOINLINE ptr_glTextureParameterIuivEXT #-}
 
ptr_glTextureParameterIuivEXT :: FunPtr a
ptr_glTextureParameterIuivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameterIuivEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureParameterfEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLfloat -> IO ())
 
glTextureParameterfEXT ::
                       GLuint -> GLenum -> GLenum -> GLfloat -> IO ()
glTextureParameterfEXT
  = dyn_glTextureParameterfEXT ptr_glTextureParameterfEXT
 
{-# NOINLINE ptr_glTextureParameterfEXT #-}
 
ptr_glTextureParameterfEXT :: FunPtr a
ptr_glTextureParameterfEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameterfEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureParameterfvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glTextureParameterfvEXT ::
                        GLuint -> GLenum -> GLenum -> Ptr GLfloat -> IO ()
glTextureParameterfvEXT
  = dyn_glTextureParameterfvEXT ptr_glTextureParameterfvEXT
 
{-# NOINLINE ptr_glTextureParameterfvEXT #-}
 
ptr_glTextureParameterfvEXT :: FunPtr a
ptr_glTextureParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameterfvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureParameteriEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> GLint -> IO ())
 
glTextureParameteriEXT ::
                       GLuint -> GLenum -> GLenum -> GLint -> IO ()
glTextureParameteriEXT
  = dyn_glTextureParameteriEXT ptr_glTextureParameteriEXT
 
{-# NOINLINE ptr_glTextureParameteriEXT #-}
 
ptr_glTextureParameteriEXT :: FunPtr a
ptr_glTextureParameteriEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameteriEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureParameterivEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glTextureParameterivEXT ::
                        GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glTextureParameterivEXT
  = dyn_glTextureParameterivEXT ptr_glTextureParameterivEXT
 
{-# NOINLINE ptr_glTextureParameterivEXT #-}
 
ptr_glTextureParameterivEXT :: FunPtr a
ptr_glTextureParameterivEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureParameterivEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTextureRenderbufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> IO ())
 
glTextureRenderbufferEXT :: GLuint -> GLenum -> GLuint -> IO ()
glTextureRenderbufferEXT
  = dyn_glTextureRenderbufferEXT ptr_glTextureRenderbufferEXT
 
{-# NOINLINE ptr_glTextureRenderbufferEXT #-}
 
ptr_glTextureRenderbufferEXT :: FunPtr a
ptr_glTextureRenderbufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureRenderbufferEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage1DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLsizei -> GLenum -> GLsizei -> IO ())
 
glTextureStorage1DEXT ::
                      GLuint -> GLenum -> GLsizei -> GLenum -> GLsizei -> IO ()
glTextureStorage1DEXT
  = dyn_glTextureStorage1DEXT ptr_glTextureStorage1DEXT
 
{-# NOINLINE ptr_glTextureStorage1DEXT #-}
 
ptr_glTextureStorage1DEXT :: FunPtr a
ptr_glTextureStorage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureStorage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage2DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glTextureStorage2DEXT ::
                      GLuint ->
                        GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glTextureStorage2DEXT
  = dyn_glTextureStorage2DEXT ptr_glTextureStorage2DEXT
 
{-# NOINLINE ptr_glTextureStorage2DEXT #-}
 
ptr_glTextureStorage2DEXT :: FunPtr a
ptr_glTextureStorage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureStorage2DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTextureStorage2DMultisampleEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLsizei -> GLenum -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
glTextureStorage2DMultisampleEXT ::
                                 GLuint ->
                                   GLenum ->
                                     GLsizei -> GLenum -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTextureStorage2DMultisampleEXT
  = dyn_glTextureStorage2DMultisampleEXT
      ptr_glTextureStorage2DMultisampleEXT
 
{-# NOINLINE ptr_glTextureStorage2DMultisampleEXT #-}
 
ptr_glTextureStorage2DMultisampleEXT :: FunPtr a
ptr_glTextureStorage2DMultisampleEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureStorage2DMultisampleEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage3DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ())
 
glTextureStorage3DEXT ::
                      GLuint ->
                        GLenum ->
                          GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ()
glTextureStorage3DEXT
  = dyn_glTextureStorage3DEXT ptr_glTextureStorage3DEXT
 
{-# NOINLINE ptr_glTextureStorage3DEXT #-}
 
ptr_glTextureStorage3DEXT :: FunPtr a
ptr_glTextureStorage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureStorage3DEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTextureStorage3DMultisampleEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLsizei ->
                        GLenum -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
glTextureStorage3DMultisampleEXT ::
                                 GLuint ->
                                   GLenum ->
                                     GLsizei ->
                                       GLenum -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTextureStorage3DMultisampleEXT
  = dyn_glTextureStorage3DMultisampleEXT
      ptr_glTextureStorage3DMultisampleEXT
 
{-# NOINLINE ptr_glTextureStorage3DMultisampleEXT #-}
 
ptr_glTextureStorage3DMultisampleEXT :: FunPtr a
ptr_glTextureStorage3DMultisampleEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureStorage3DMultisampleEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureSubImage1DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint -> GLint -> GLsizei -> GLenum -> GLenum -> Ptr i -> IO ())
 
glTextureSubImage1DEXT ::
                       GLuint ->
                         GLenum ->
                           GLint -> GLint -> GLsizei -> GLenum -> GLenum -> Ptr i -> IO ()
glTextureSubImage1DEXT
  = dyn_glTextureSubImage1DEXT ptr_glTextureSubImage1DEXT
 
{-# NOINLINE ptr_glTextureSubImage1DEXT #-}
 
ptr_glTextureSubImage1DEXT :: FunPtr a
ptr_glTextureSubImage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureSubImage1DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureSubImage2DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr k -> IO ())
 
glTextureSubImage2DEXT ::
                       GLuint ->
                         GLenum ->
                           GLint ->
                             GLint ->
                               GLint -> GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr k -> IO ()
glTextureSubImage2DEXT
  = dyn_glTextureSubImage2DEXT ptr_glTextureSubImage2DEXT
 
{-# NOINLINE ptr_glTextureSubImage2DEXT #-}
 
ptr_glTextureSubImage2DEXT :: FunPtr a
ptr_glTextureSubImage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureSubImage2DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureSubImage3DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLsizei ->
                                GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr m -> IO ())
 
glTextureSubImage3DEXT ::
                       GLuint ->
                         GLenum ->
                           GLint ->
                             GLint ->
                               GLint ->
                                 GLint ->
                                   GLsizei ->
                                     GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr m -> IO ()
glTextureSubImage3DEXT
  = dyn_glTextureSubImage3DEXT ptr_glTextureSubImage3DEXT
 
{-# NOINLINE ptr_glTextureSubImage3DEXT #-}
 
ptr_glTextureSubImage3DEXT :: FunPtr a
ptr_glTextureSubImage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glTextureSubImage3DEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnmapNamedBufferEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glUnmapNamedBufferEXT :: GLuint -> IO GLboolean
glUnmapNamedBufferEXT
  = dyn_glUnmapNamedBufferEXT ptr_glUnmapNamedBufferEXT
 
{-# NOINLINE ptr_glUnmapNamedBufferEXT #-}
 
ptr_glUnmapNamedBufferEXT :: FunPtr a
ptr_glUnmapNamedBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glUnmapNamedBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayBindVertexBufferEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLintptr -> GLsizei -> IO ())
 
glVertexArrayBindVertexBufferEXT ::
                                 GLuint -> GLuint -> GLuint -> GLintptr -> GLsizei -> IO ()
glVertexArrayBindVertexBufferEXT
  = dyn_glVertexArrayBindVertexBufferEXT
      ptr_glVertexArrayBindVertexBufferEXT
 
{-# NOINLINE ptr_glVertexArrayBindVertexBufferEXT #-}
 
ptr_glVertexArrayBindVertexBufferEXT :: FunPtr a
ptr_glVertexArrayBindVertexBufferEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayBindVertexBufferEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayColorOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayColorOffsetEXT ::
                            GLuint -> GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayColorOffsetEXT
  = dyn_glVertexArrayColorOffsetEXT ptr_glVertexArrayColorOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayColorOffsetEXT #-}
 
ptr_glVertexArrayColorOffsetEXT :: FunPtr a
ptr_glVertexArrayColorOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayColorOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayEdgeFlagOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayEdgeFlagOffsetEXT ::
                               GLuint -> GLuint -> GLsizei -> GLintptr -> IO ()
glVertexArrayEdgeFlagOffsetEXT
  = dyn_glVertexArrayEdgeFlagOffsetEXT
      ptr_glVertexArrayEdgeFlagOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayEdgeFlagOffsetEXT #-}
 
ptr_glVertexArrayEdgeFlagOffsetEXT :: FunPtr a
ptr_glVertexArrayEdgeFlagOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayEdgeFlagOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayFogCoordOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayFogCoordOffsetEXT ::
                               GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayFogCoordOffsetEXT
  = dyn_glVertexArrayFogCoordOffsetEXT
      ptr_glVertexArrayFogCoordOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayFogCoordOffsetEXT #-}
 
ptr_glVertexArrayFogCoordOffsetEXT :: FunPtr a
ptr_glVertexArrayFogCoordOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayFogCoordOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayIndexOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayIndexOffsetEXT ::
                            GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayIndexOffsetEXT
  = dyn_glVertexArrayIndexOffsetEXT ptr_glVertexArrayIndexOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayIndexOffsetEXT #-}
 
ptr_glVertexArrayIndexOffsetEXT :: FunPtr a
ptr_glVertexArrayIndexOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayIndexOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayMultiTexCoordOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLenum -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayMultiTexCoordOffsetEXT ::
                                    GLuint ->
                                      GLuint ->
                                        GLenum -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayMultiTexCoordOffsetEXT
  = dyn_glVertexArrayMultiTexCoordOffsetEXT
      ptr_glVertexArrayMultiTexCoordOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayMultiTexCoordOffsetEXT #-}
 
ptr_glVertexArrayMultiTexCoordOffsetEXT :: FunPtr a
ptr_glVertexArrayMultiTexCoordOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayMultiTexCoordOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayNormalOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayNormalOffsetEXT ::
                             GLuint -> GLuint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayNormalOffsetEXT
  = dyn_glVertexArrayNormalOffsetEXT ptr_glVertexArrayNormalOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayNormalOffsetEXT #-}
 
ptr_glVertexArrayNormalOffsetEXT :: FunPtr a
ptr_glVertexArrayNormalOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayNormalOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArraySecondaryColorOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArraySecondaryColorOffsetEXT ::
                                     GLuint ->
                                       GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArraySecondaryColorOffsetEXT
  = dyn_glVertexArraySecondaryColorOffsetEXT
      ptr_glVertexArraySecondaryColorOffsetEXT
 
{-# NOINLINE ptr_glVertexArraySecondaryColorOffsetEXT #-}
 
ptr_glVertexArraySecondaryColorOffsetEXT :: FunPtr a
ptr_glVertexArraySecondaryColorOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArraySecondaryColorOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayTexCoordOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayTexCoordOffsetEXT ::
                               GLuint -> GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayTexCoordOffsetEXT
  = dyn_glVertexArrayTexCoordOffsetEXT
      ptr_glVertexArrayTexCoordOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayTexCoordOffsetEXT #-}
 
ptr_glVertexArrayTexCoordOffsetEXT :: FunPtr a
ptr_glVertexArrayTexCoordOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayTexCoordOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribBindingEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
glVertexArrayVertexAttribBindingEXT ::
                                    GLuint -> GLuint -> GLuint -> IO ()
glVertexArrayVertexAttribBindingEXT
  = dyn_glVertexArrayVertexAttribBindingEXT
      ptr_glVertexArrayVertexAttribBindingEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribBindingEXT #-}
 
ptr_glVertexArrayVertexAttribBindingEXT :: FunPtr a
ptr_glVertexArrayVertexAttribBindingEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribBindingEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribDivisorEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
glVertexArrayVertexAttribDivisorEXT ::
                                    GLuint -> GLuint -> GLuint -> IO ()
glVertexArrayVertexAttribDivisorEXT
  = dyn_glVertexArrayVertexAttribDivisorEXT
      ptr_glVertexArrayVertexAttribDivisorEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribDivisorEXT #-}
 
ptr_glVertexArrayVertexAttribDivisorEXT :: FunPtr a
ptr_glVertexArrayVertexAttribDivisorEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribDivisorEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribFormatEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLenum -> GLboolean -> GLuint -> IO ())
 
glVertexArrayVertexAttribFormatEXT ::
                                   GLuint ->
                                     GLuint -> GLint -> GLenum -> GLboolean -> GLuint -> IO ()
glVertexArrayVertexAttribFormatEXT
  = dyn_glVertexArrayVertexAttribFormatEXT
      ptr_glVertexArrayVertexAttribFormatEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribFormatEXT #-}
 
ptr_glVertexArrayVertexAttribFormatEXT :: FunPtr a
ptr_glVertexArrayVertexAttribFormatEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribFormatEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribIFormatEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLint -> GLenum -> GLuint -> IO ())
 
glVertexArrayVertexAttribIFormatEXT ::
                                    GLuint -> GLuint -> GLint -> GLenum -> GLuint -> IO ()
glVertexArrayVertexAttribIFormatEXT
  = dyn_glVertexArrayVertexAttribIFormatEXT
      ptr_glVertexArrayVertexAttribIFormatEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribIFormatEXT #-}
 
ptr_glVertexArrayVertexAttribIFormatEXT :: FunPtr a
ptr_glVertexArrayVertexAttribIFormatEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribIFormatEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribIOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayVertexAttribIOffsetEXT ::
                                    GLuint ->
                                      GLuint ->
                                        GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayVertexAttribIOffsetEXT
  = dyn_glVertexArrayVertexAttribIOffsetEXT
      ptr_glVertexArrayVertexAttribIOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribIOffsetEXT #-}
 
ptr_glVertexArrayVertexAttribIOffsetEXT :: FunPtr a
ptr_glVertexArrayVertexAttribIOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribIOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribLFormatEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLint -> GLenum -> GLuint -> IO ())
 
glVertexArrayVertexAttribLFormatEXT ::
                                    GLuint -> GLuint -> GLint -> GLenum -> GLuint -> IO ()
glVertexArrayVertexAttribLFormatEXT
  = dyn_glVertexArrayVertexAttribLFormatEXT
      ptr_glVertexArrayVertexAttribLFormatEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribLFormatEXT #-}
 
ptr_glVertexArrayVertexAttribLFormatEXT :: FunPtr a
ptr_glVertexArrayVertexAttribLFormatEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribLFormatEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribLOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayVertexAttribLOffsetEXT ::
                                    GLuint ->
                                      GLuint ->
                                        GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayVertexAttribLOffsetEXT
  = dyn_glVertexArrayVertexAttribLOffsetEXT
      ptr_glVertexArrayVertexAttribLOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribLOffsetEXT #-}
 
ptr_glVertexArrayVertexAttribLOffsetEXT :: FunPtr a
ptr_glVertexArrayVertexAttribLOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribLOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexAttribOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLuint ->
                        GLint -> GLenum -> GLboolean -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayVertexAttribOffsetEXT ::
                                   GLuint ->
                                     GLuint ->
                                       GLuint ->
                                         GLint ->
                                           GLenum -> GLboolean -> GLsizei -> GLintptr -> IO ()
glVertexArrayVertexAttribOffsetEXT
  = dyn_glVertexArrayVertexAttribOffsetEXT
      ptr_glVertexArrayVertexAttribOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayVertexAttribOffsetEXT #-}
 
ptr_glVertexArrayVertexAttribOffsetEXT :: FunPtr a
ptr_glVertexArrayVertexAttribOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexAttribOffsetEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexBindingDivisorEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
glVertexArrayVertexBindingDivisorEXT ::
                                     GLuint -> GLuint -> GLuint -> IO ()
glVertexArrayVertexBindingDivisorEXT
  = dyn_glVertexArrayVertexBindingDivisorEXT
      ptr_glVertexArrayVertexBindingDivisorEXT
 
{-# NOINLINE ptr_glVertexArrayVertexBindingDivisorEXT #-}
 
ptr_glVertexArrayVertexBindingDivisorEXT :: FunPtr a
ptr_glVertexArrayVertexBindingDivisorEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexBindingDivisorEXT"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexArrayVertexOffsetEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ())
 
glVertexArrayVertexOffsetEXT ::
                             GLuint -> GLuint -> GLint -> GLenum -> GLsizei -> GLintptr -> IO ()
glVertexArrayVertexOffsetEXT
  = dyn_glVertexArrayVertexOffsetEXT ptr_glVertexArrayVertexOffsetEXT
 
{-# NOINLINE ptr_glVertexArrayVertexOffsetEXT #-}
 
ptr_glVertexArrayVertexOffsetEXT :: FunPtr a
ptr_glVertexArrayVertexOffsetEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_direct_state_access"
        "glVertexArrayVertexOffsetEXT"