-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.BlendSubtract
       (gl_FUNC_REVERSE_SUBTRACT_EXT, gl_FUNC_SUBTRACT_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FUNC_REVERSE_SUBTRACT_EXT :: GLenum
gl_FUNC_REVERSE_SUBTRACT_EXT = 32779
 
gl_FUNC_SUBTRACT_EXT :: GLenum
gl_FUNC_SUBTRACT_EXT = 32778