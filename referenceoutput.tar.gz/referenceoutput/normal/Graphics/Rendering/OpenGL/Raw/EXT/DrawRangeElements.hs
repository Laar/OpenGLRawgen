{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.DrawRangeElements
       (gl_MAX_ELEMENTS_INDICES_EXT, gl_MAX_ELEMENTS_VERTICES_EXT,
        glDrawRangeElementsEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_MAX_ELEMENTS_INDICES_EXT :: GLenum
gl_MAX_ELEMENTS_INDICES_EXT = 33001
 
gl_MAX_ELEMENTS_VERTICES_EXT :: GLenum
gl_MAX_ELEMENTS_VERTICES_EXT = 33000
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawRangeElementsEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> GLenum -> Ptr a -> IO ())
 
glDrawRangeElementsEXT ::
                       GLenum -> GLuint -> GLuint -> GLsizei -> GLenum -> Ptr a -> IO ()
glDrawRangeElementsEXT
  = dyn_glDrawRangeElementsEXT ptr_glDrawRangeElementsEXT
 
{-# NOINLINE ptr_glDrawRangeElementsEXT #-}
 
ptr_glDrawRangeElementsEXT :: FunPtr a
ptr_glDrawRangeElementsEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_range_elements"
        "glDrawRangeElementsEXT"