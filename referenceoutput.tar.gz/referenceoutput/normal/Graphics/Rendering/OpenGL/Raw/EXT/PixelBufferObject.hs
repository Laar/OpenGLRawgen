-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.PixelBufferObject
       (gl_PIXEL_PACK_BUFFER_BINDING_EXT, gl_PIXEL_PACK_BUFFER_EXT,
        gl_PIXEL_UNPACK_BUFFER_BINDING_EXT, gl_PIXEL_UNPACK_BUFFER_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PIXEL_PACK_BUFFER_BINDING_EXT :: GLenum
gl_PIXEL_PACK_BUFFER_BINDING_EXT = 35053
 
gl_PIXEL_PACK_BUFFER_EXT :: GLenum
gl_PIXEL_PACK_BUFFER_EXT = 35051
 
gl_PIXEL_UNPACK_BUFFER_BINDING_EXT :: GLenum
gl_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055
 
gl_PIXEL_UNPACK_BUFFER_EXT :: GLenum
gl_PIXEL_UNPACK_BUFFER_EXT = 35052