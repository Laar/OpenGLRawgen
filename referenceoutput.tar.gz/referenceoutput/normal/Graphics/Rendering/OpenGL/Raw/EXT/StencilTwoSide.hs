{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.StencilTwoSide
       (gl_ACTIVE_STENCIL_FACE_EXT, gl_STENCIL_TEST_TWO_SIDE_EXT,
        glActiveStencilFaceEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ACTIVE_STENCIL_FACE_EXT :: GLenum
gl_ACTIVE_STENCIL_FACE_EXT = 35089
 
gl_STENCIL_TEST_TWO_SIDE_EXT :: GLenum
gl_STENCIL_TEST_TWO_SIDE_EXT = 35088
 
foreign import CALLCONV unsafe "dynamic" dyn_glActiveStencilFaceEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glActiveStencilFaceEXT :: GLenum -> IO ()
glActiveStencilFaceEXT
  = dyn_glActiveStencilFaceEXT ptr_glActiveStencilFaceEXT
 
{-# NOINLINE ptr_glActiveStencilFaceEXT #-}
 
ptr_glActiveStencilFaceEXT :: FunPtr a
ptr_glActiveStencilFaceEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_stencil_two_side"
        "glActiveStencilFaceEXT"