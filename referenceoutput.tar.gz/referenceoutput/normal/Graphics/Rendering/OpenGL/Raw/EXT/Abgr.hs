module Graphics.Rendering.OpenGL.Raw.EXT.Abgr (gl_ABGR_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ABGR_EXT :: GLenum
gl_ABGR_EXT = 32768