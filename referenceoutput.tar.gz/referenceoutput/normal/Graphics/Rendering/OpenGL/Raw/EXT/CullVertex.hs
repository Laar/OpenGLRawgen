{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.CullVertex
       (gl_CULL_VERTEX_EXT, gl_CULL_VERTEX_EYE_POSITION_EXT,
        gl_CULL_VERTEX_OBJECT_POSITION_EXT, glCullParameterdvEXT,
        glCullParameterfvEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_CULL_VERTEX_EXT :: GLenum
gl_CULL_VERTEX_EXT = 33194
 
gl_CULL_VERTEX_EYE_POSITION_EXT :: GLenum
gl_CULL_VERTEX_EYE_POSITION_EXT = 33195
 
gl_CULL_VERTEX_OBJECT_POSITION_EXT :: GLenum
gl_CULL_VERTEX_OBJECT_POSITION_EXT = 33196
 
foreign import CALLCONV unsafe "dynamic" dyn_glCullParameterdvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLdouble -> IO ())
 
glCullParameterdvEXT :: GLenum -> Ptr GLdouble -> IO ()
glCullParameterdvEXT
  = dyn_glCullParameterdvEXT ptr_glCullParameterdvEXT
 
{-# NOINLINE ptr_glCullParameterdvEXT #-}
 
ptr_glCullParameterdvEXT :: FunPtr a
ptr_glCullParameterdvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_cull_vertex"
        "glCullParameterdvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCullParameterfvEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
glCullParameterfvEXT :: GLenum -> Ptr GLfloat -> IO ()
glCullParameterfvEXT
  = dyn_glCullParameterfvEXT ptr_glCullParameterfvEXT
 
{-# NOINLINE ptr_glCullParameterfvEXT #-}
 
ptr_glCullParameterfvEXT :: FunPtr a
ptr_glCullParameterfvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_cull_vertex"
        "glCullParameterfvEXT"