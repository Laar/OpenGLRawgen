-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureCompressionRgtc
       (gl_COMPRESSED_RED_GREEN_RGTC2_EXT, gl_COMPRESSED_RED_RGTC1_EXT,
        gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT,
        gl_COMPRESSED_SIGNED_RED_RGTC1_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPRESSED_RED_GREEN_RGTC2_EXT :: GLenum
gl_COMPRESSED_RED_GREEN_RGTC2_EXT = 36285
 
gl_COMPRESSED_RED_RGTC1_EXT :: GLenum
gl_COMPRESSED_RED_RGTC1_EXT = 36283
 
gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT :: GLenum
gl_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT = 36286
 
gl_COMPRESSED_SIGNED_RED_RGTC1_EXT :: GLenum
gl_COMPRESSED_SIGNED_RED_RGTC1_EXT = 36284