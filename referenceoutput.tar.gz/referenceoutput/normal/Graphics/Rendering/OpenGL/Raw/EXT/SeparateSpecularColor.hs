-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.SeparateSpecularColor
       (gl_LIGHT_MODEL_COLOR_CONTROL_EXT, gl_SEPARATE_SPECULAR_COLOR_EXT,
        gl_SINGLE_COLOR_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_LIGHT_MODEL_COLOR_CONTROL_EXT :: GLenum
gl_LIGHT_MODEL_COLOR_CONTROL_EXT = 33272
 
gl_SEPARATE_SPECULAR_COLOR_EXT :: GLenum
gl_SEPARATE_SPECULAR_COLOR_EXT = 33274
 
gl_SINGLE_COLOR_EXT :: GLenum
gl_SINGLE_COLOR_EXT = 33273