{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.ProvokingVertex
       (gl_FIRST_VERTEX_CONVENTION_EXT, gl_LAST_VERTEX_CONVENTION_EXT,
        gl_PROVOKING_VERTEX_EXT,
        gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT,
        glProvokingVertexEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FIRST_VERTEX_CONVENTION_EXT :: GLenum
gl_FIRST_VERTEX_CONVENTION_EXT = 36429
 
gl_LAST_VERTEX_CONVENTION_EXT :: GLenum
gl_LAST_VERTEX_CONVENTION_EXT = 36430
 
gl_PROVOKING_VERTEX_EXT :: GLenum
gl_PROVOKING_VERTEX_EXT = 36431
 
gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT :: GLenum
gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT = 36428
 
foreign import CALLCONV unsafe "dynamic" dyn_glProvokingVertexEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glProvokingVertexEXT :: GLenum -> IO ()
glProvokingVertexEXT
  = dyn_glProvokingVertexEXT ptr_glProvokingVertexEXT
 
{-# NOINLINE ptr_glProvokingVertexEXT #-}
 
ptr_glProvokingVertexEXT :: FunPtr a
ptr_glProvokingVertexEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_provoking_vertex"
        "glProvokingVertexEXT"