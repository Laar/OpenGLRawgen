-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferMultisampleBlitScaled
       (gl_SCALED_RESOLVE_FASTEST_EXT, gl_SCALED_RESOLVE_NICEST_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SCALED_RESOLVE_FASTEST_EXT :: GLenum
gl_SCALED_RESOLVE_FASTEST_EXT = 37050
 
gl_SCALED_RESOLVE_NICEST_EXT :: GLenum
gl_SCALED_RESOLVE_NICEST_EXT = 37051