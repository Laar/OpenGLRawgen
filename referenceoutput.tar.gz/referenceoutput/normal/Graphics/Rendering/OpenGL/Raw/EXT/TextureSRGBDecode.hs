-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureSRGBDecode
       (gl_DECODE_EXT, gl_SKIP_DECODE_EXT, gl_TEXTURE_SRGB_DECODE_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DECODE_EXT :: GLenum
gl_DECODE_EXT = 35401
 
gl_SKIP_DECODE_EXT :: GLenum
gl_SKIP_DECODE_EXT = 35402
 
gl_TEXTURE_SRGB_DECODE_EXT :: GLenum
gl_TEXTURE_SRGB_DECODE_EXT = 35400