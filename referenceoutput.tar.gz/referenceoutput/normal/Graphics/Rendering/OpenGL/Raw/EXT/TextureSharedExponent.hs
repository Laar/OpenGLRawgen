-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureSharedExponent
       (gl_RGB9_E5_EXT, gl_TEXTURE_SHARED_SIZE_EXT,
        gl_UNSIGNED_INT_5_9_9_9_REV_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RGB9_E5_EXT :: GLenum
gl_RGB9_E5_EXT = 35901
 
gl_TEXTURE_SHARED_SIZE_EXT :: GLenum
gl_TEXTURE_SHARED_SIZE_EXT = 35903
 
gl_UNSIGNED_INT_5_9_9_9_REV_EXT :: GLenum
gl_UNSIGNED_INT_5_9_9_9_REV_EXT = 35902