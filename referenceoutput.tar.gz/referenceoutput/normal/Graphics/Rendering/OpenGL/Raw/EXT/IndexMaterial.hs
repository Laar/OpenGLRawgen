{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.IndexMaterial
       (gl_INDEX_MATERIAL_EXT, gl_INDEX_MATERIAL_FACE_EXT,
        gl_INDEX_MATERIAL_PARAMETER_EXT, glIndexMaterialEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_INDEX_MATERIAL_EXT :: GLenum
gl_INDEX_MATERIAL_EXT = 33208
 
gl_INDEX_MATERIAL_FACE_EXT :: GLenum
gl_INDEX_MATERIAL_FACE_EXT = 33210
 
gl_INDEX_MATERIAL_PARAMETER_EXT :: GLenum
gl_INDEX_MATERIAL_PARAMETER_EXT = 33209
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexMaterialEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glIndexMaterialEXT :: GLenum -> GLenum -> IO ()
glIndexMaterialEXT = dyn_glIndexMaterialEXT ptr_glIndexMaterialEXT
 
{-# NOINLINE ptr_glIndexMaterialEXT #-}
 
ptr_glIndexMaterialEXT :: FunPtr a
ptr_glIndexMaterialEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_index_material"
        "glIndexMaterialEXT"