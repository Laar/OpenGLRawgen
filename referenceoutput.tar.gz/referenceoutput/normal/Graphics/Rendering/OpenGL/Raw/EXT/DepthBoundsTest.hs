{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.DepthBoundsTest
       (gl_DEPTH_BOUNDS_EXT, gl_DEPTH_BOUNDS_TEST_EXT, glDepthBoundsEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DEPTH_BOUNDS_EXT :: GLenum
gl_DEPTH_BOUNDS_EXT = 34961
 
gl_DEPTH_BOUNDS_TEST_EXT :: GLenum
gl_DEPTH_BOUNDS_TEST_EXT = 34960
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthBoundsEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLclampd -> GLclampd -> IO ())
 
glDepthBoundsEXT :: GLclampd -> GLclampd -> IO ()
glDepthBoundsEXT = dyn_glDepthBoundsEXT ptr_glDepthBoundsEXT
 
{-# NOINLINE ptr_glDepthBoundsEXT #-}
 
ptr_glDepthBoundsEXT :: FunPtr a
ptr_glDepthBoundsEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_depth_bounds_test"
        "glDepthBoundsEXT"