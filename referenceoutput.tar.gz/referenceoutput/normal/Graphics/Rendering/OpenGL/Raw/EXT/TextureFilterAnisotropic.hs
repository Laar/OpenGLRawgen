-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureFilterAnisotropic
       (gl_MAX_TEXTURE_MAX_ANISOTROPY_EXT, gl_TEXTURE_MAX_ANISOTROPY_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_TEXTURE_MAX_ANISOTROPY_EXT :: GLenum
gl_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 34047
 
gl_TEXTURE_MAX_ANISOTROPY_EXT :: GLenum
gl_TEXTURE_MAX_ANISOTROPY_EXT = 34046