-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureLodBias
       (gl_MAX_TEXTURE_LOD_BIAS_EXT, gl_TEXTURE_FILTER_CONTROL_EXT,
        gl_TEXTURE_LOD_BIAS_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_TEXTURE_LOD_BIAS_EXT :: GLenum
gl_MAX_TEXTURE_LOD_BIAS_EXT = 34045
 
gl_TEXTURE_FILTER_CONTROL_EXT :: GLenum
gl_TEXTURE_FILTER_CONTROL_EXT = 34048
 
gl_TEXTURE_LOD_BIAS_EXT :: GLenum
gl_TEXTURE_LOD_BIAS_EXT = 34049