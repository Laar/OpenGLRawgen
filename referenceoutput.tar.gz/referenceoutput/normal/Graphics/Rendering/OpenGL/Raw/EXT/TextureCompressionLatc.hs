-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TextureCompressionLatc
       (gl_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT,
        gl_COMPRESSED_LUMINANCE_LATC1_EXT,
        gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT,
        gl_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT :: GLenum
gl_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT = 35954
 
gl_COMPRESSED_LUMINANCE_LATC1_EXT :: GLenum
gl_COMPRESSED_LUMINANCE_LATC1_EXT = 35952
 
gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT :: GLenum
gl_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT = 35955
 
gl_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT :: GLenum
gl_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT = 35953