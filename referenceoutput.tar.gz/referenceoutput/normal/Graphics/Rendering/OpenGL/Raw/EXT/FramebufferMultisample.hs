{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferMultisample
       (gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT, gl_MAX_SAMPLES_EXT,
        gl_RENDERBUFFER_SAMPLES_EXT, glRenderbufferStorageMultisampleEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT = 36182
 
gl_MAX_SAMPLES_EXT :: GLenum
gl_MAX_SAMPLES_EXT = 36183
 
gl_RENDERBUFFER_SAMPLES_EXT :: GLenum
gl_RENDERBUFFER_SAMPLES_EXT = 36011
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glRenderbufferStorageMultisampleEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glRenderbufferStorageMultisampleEXT ::
                                    GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glRenderbufferStorageMultisampleEXT
  = dyn_glRenderbufferStorageMultisampleEXT
      ptr_glRenderbufferStorageMultisampleEXT
 
{-# NOINLINE ptr_glRenderbufferStorageMultisampleEXT #-}
 
ptr_glRenderbufferStorageMultisampleEXT :: FunPtr a
ptr_glRenderbufferStorageMultisampleEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_framebuffer_multisample"
        "glRenderbufferStorageMultisampleEXT"