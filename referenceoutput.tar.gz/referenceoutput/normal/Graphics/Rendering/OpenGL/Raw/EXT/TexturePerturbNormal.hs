{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.TexturePerturbNormal
       (gl_PERTURB_EXT, gl_TEXTURE_NORMAL_EXT, glTextureNormalEXT) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_PERTURB_EXT :: GLenum
gl_PERTURB_EXT = 34222
 
gl_TEXTURE_NORMAL_EXT :: GLenum
gl_TEXTURE_NORMAL_EXT = 34223
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureNormalEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glTextureNormalEXT :: GLenum -> IO ()
glTextureNormalEXT = dyn_glTextureNormalEXT ptr_glTextureNormalEXT
 
{-# NOINLINE ptr_glTextureNormalEXT #-}
 
ptr_glTextureNormalEXT :: FunPtr a
ptr_glTextureNormalEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_perturb_normal"
        "glTextureNormalEXT"