{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.TexturePerturbNormal
       (gl_PERTURB_EXT, gl_TEXTURE_NORMAL_EXT, glTextureNormalEXT) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PERTURB_EXT :: GLenum
gl_PERTURB_EXT = 34222
 
gl_TEXTURE_NORMAL_EXT :: GLenum
gl_TEXTURE_NORMAL_EXT = 34223
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureNormalEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glTextureNormalEXT :: GLenum -> IO ()
glTextureNormalEXT = dyn_glTextureNormalEXT ptr_glTextureNormalEXT
 
{-# NOINLINE ptr_glTextureNormalEXT #-}
 
ptr_glTextureNormalEXT :: FunPtr a
ptr_glTextureNormalEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_texture_perturb_normal"
        "glTextureNormalEXT"