{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.StencilClearTag
       (gl_STENCIL_CLEAR_TAG_VALUE_EXT, gl_STENCIL_TAG_BITS_EXT,
        glStencilClearTagEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_STENCIL_CLEAR_TAG_VALUE_EXT :: GLenum
gl_STENCIL_CLEAR_TAG_VALUE_EXT = 35059
 
gl_STENCIL_TAG_BITS_EXT :: GLenum
gl_STENCIL_TAG_BITS_EXT = 35058
 
foreign import CALLCONV unsafe "dynamic" dyn_glStencilClearTagEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> GLuint -> IO ())
 
glStencilClearTagEXT :: GLsizei -> GLuint -> IO ()
glStencilClearTagEXT
  = dyn_glStencilClearTagEXT ptr_glStencilClearTagEXT
 
{-# NOINLINE ptr_glStencilClearTagEXT #-}
 
ptr_glStencilClearTagEXT :: FunPtr a
ptr_glStencilClearTagEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_stencil_clear_tag"
        "glStencilClearTagEXT"