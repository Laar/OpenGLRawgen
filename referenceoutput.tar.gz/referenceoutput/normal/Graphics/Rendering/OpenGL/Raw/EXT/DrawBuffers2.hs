{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.DrawBuffers2
       (glColorMaskIndexedEXT, glDisableIndexedEXT, glEnableIndexedEXT,
        glGetBooleanIndexedvEXT, glGetIntegerIndexedvEXT,
        glIsEnabledIndexedEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.EXT.DirectStateAccess
       (glDisableIndexedEXT, glEnableIndexedEXT, glGetBooleanIndexedvEXT,
        glGetIntegerIndexedvEXT, glIsEnabledIndexedEXT)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorMaskIndexedEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
glColorMaskIndexedEXT ::
                      GLuint -> GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glColorMaskIndexedEXT
  = dyn_glColorMaskIndexedEXT ptr_glColorMaskIndexedEXT
 
{-# NOINLINE ptr_glColorMaskIndexedEXT #-}
 
ptr_glColorMaskIndexedEXT :: FunPtr a
ptr_glColorMaskIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glColorMaskIndexedEXT"