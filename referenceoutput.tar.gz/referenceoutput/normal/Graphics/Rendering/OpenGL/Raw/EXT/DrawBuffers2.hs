{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.DrawBuffers2
       (glColorMaskIndexedEXT, glDisableIndexedEXT, glEnableIndexedEXT,
        glGetBooleanIndexedvEXT, glGetIntegerIndexedvEXT,
        glIsEnabledIndexedEXT)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorMaskIndexedEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
glColorMaskIndexedEXT ::
                      GLuint -> GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glColorMaskIndexedEXT
  = dyn_glColorMaskIndexedEXT ptr_glColorMaskIndexedEXT
 
{-# NOINLINE ptr_glColorMaskIndexedEXT #-}
 
ptr_glColorMaskIndexedEXT :: FunPtr a
ptr_glColorMaskIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glColorMaskIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisableIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisableIndexedEXT :: GLenum -> GLuint -> IO ()
glDisableIndexedEXT
  = dyn_glDisableIndexedEXT ptr_glDisableIndexedEXT
 
{-# NOINLINE ptr_glDisableIndexedEXT #-}
 
ptr_glDisableIndexedEXT :: FunPtr a
ptr_glDisableIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glDisableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnableIndexedEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnableIndexedEXT :: GLenum -> GLuint -> IO ()
glEnableIndexedEXT = dyn_glEnableIndexedEXT ptr_glEnableIndexedEXT
 
{-# NOINLINE ptr_glEnableIndexedEXT #-}
 
ptr_glEnableIndexedEXT :: FunPtr a
ptr_glEnableIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glEnableIndexedEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBooleanIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLboolean -> IO ())
 
glGetBooleanIndexedvEXT ::
                        GLenum -> GLuint -> Ptr GLboolean -> IO ()
glGetBooleanIndexedvEXT
  = dyn_glGetBooleanIndexedvEXT ptr_glGetBooleanIndexedvEXT
 
{-# NOINLINE ptr_glGetBooleanIndexedvEXT #-}
 
ptr_glGetBooleanIndexedvEXT :: FunPtr a
ptr_glGetBooleanIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glGetBooleanIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegerIndexedvEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetIntegerIndexedvEXT :: GLenum -> GLuint -> Ptr GLint -> IO ()
glGetIntegerIndexedvEXT
  = dyn_glGetIntegerIndexedvEXT ptr_glGetIntegerIndexedvEXT
 
{-# NOINLINE ptr_glGetIntegerIndexedvEXT #-}
 
ptr_glGetIntegerIndexedvEXT :: FunPtr a
ptr_glGetIntegerIndexedvEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glGetIntegerIndexedvEXT"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsEnabledIndexedEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsEnabledIndexedEXT :: GLenum -> GLuint -> IO GLboolean
glIsEnabledIndexedEXT
  = dyn_glIsEnabledIndexedEXT ptr_glIsEnabledIndexedEXT
 
{-# NOINLINE ptr_glIsEnabledIndexedEXT #-}
 
ptr_glIsEnabledIndexedEXT :: FunPtr a
ptr_glIsEnabledIndexedEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_draw_buffers2"
        "glIsEnabledIndexedEXT"