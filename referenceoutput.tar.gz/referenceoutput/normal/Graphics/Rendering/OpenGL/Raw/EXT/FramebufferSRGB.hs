-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.EXT.FramebufferSRGB
       (gl_FRAMEBUFFER_SRGB_CAPABLE_EXT, gl_FRAMEBUFFER_SRGB_EXT) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_FRAMEBUFFER_SRGB_CAPABLE_EXT :: GLenum
gl_FRAMEBUFFER_SRGB_CAPABLE_EXT = 36282
 
gl_FRAMEBUFFER_SRGB_EXT :: GLenum
gl_FRAMEBUFFER_SRGB_EXT = 36281