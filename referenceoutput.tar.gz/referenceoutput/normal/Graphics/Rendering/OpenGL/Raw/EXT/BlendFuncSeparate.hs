{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.BlendFuncSeparate
       (gl_BLEND_DST_ALPHA_EXT, gl_BLEND_DST_RGB_EXT,
        gl_BLEND_SRC_ALPHA_EXT, gl_BLEND_SRC_RGB_EXT,
        glBlendFuncSeparateEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BLEND_DST_ALPHA_EXT :: GLenum
gl_BLEND_DST_ALPHA_EXT = 32970
 
gl_BLEND_DST_RGB_EXT :: GLenum
gl_BLEND_DST_RGB_EXT = 32968
 
gl_BLEND_SRC_ALPHA_EXT :: GLenum
gl_BLEND_SRC_ALPHA_EXT = 32971
 
gl_BLEND_SRC_RGB_EXT :: GLenum
gl_BLEND_SRC_RGB_EXT = 32969
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendFuncSeparateEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLenum -> IO ())
 
glBlendFuncSeparateEXT ::
                       GLenum -> GLenum -> GLenum -> GLenum -> IO ()
glBlendFuncSeparateEXT
  = dyn_glBlendFuncSeparateEXT ptr_glBlendFuncSeparateEXT
 
{-# NOINLINE ptr_glBlendFuncSeparateEXT #-}
 
ptr_glBlendFuncSeparateEXT :: FunPtr a
ptr_glBlendFuncSeparateEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_blend_func_separate"
        "glBlendFuncSeparateEXT"