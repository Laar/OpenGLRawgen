{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.EXT.BlendColor
       (gl_BLEND_COLOR_EXT, gl_CONSTANT_ALPHA_EXT, gl_CONSTANT_COLOR_EXT,
        gl_ONE_MINUS_CONSTANT_ALPHA_EXT, gl_ONE_MINUS_CONSTANT_COLOR_EXT,
        glBlendColorEXT)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_BLEND_COLOR_EXT :: GLenum
gl_BLEND_COLOR_EXT = 32773
 
gl_CONSTANT_ALPHA_EXT :: GLenum
gl_CONSTANT_ALPHA_EXT = 32771
 
gl_CONSTANT_COLOR_EXT :: GLenum
gl_CONSTANT_COLOR_EXT = 32769
 
gl_ONE_MINUS_CONSTANT_ALPHA_EXT :: GLenum
gl_ONE_MINUS_CONSTANT_ALPHA_EXT = 32772
 
gl_ONE_MINUS_CONSTANT_COLOR_EXT :: GLenum
gl_ONE_MINUS_CONSTANT_COLOR_EXT = 32770
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendColorEXT ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glBlendColorEXT ::
                GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glBlendColorEXT = dyn_glBlendColorEXT ptr_glBlendColorEXT
 
{-# NOINLINE ptr_glBlendColorEXT #-}
 
ptr_glBlendColorEXT :: FunPtr a
ptr_glBlendColorEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_EXT_blend_color"
        "glBlendColorEXT"