-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.TextFragmentShader
       (gl_TEXT_FRAGMENT_SHADER_ATI) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_TEXT_FRAGMENT_SHADER_ATI :: GLenum
gl_TEXT_FRAGMENT_SHADER_ATI = 33280