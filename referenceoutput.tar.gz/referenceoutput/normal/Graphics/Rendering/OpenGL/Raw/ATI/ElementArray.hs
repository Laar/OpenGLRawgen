{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.ElementArray
       (gl_ELEMENT_ARRAY_ATI, gl_ELEMENT_ARRAY_POINTER_ATI,
        gl_ELEMENT_ARRAY_TYPE_ATI, glDrawElementArrayATI,
        glDrawRangeElementArrayATI, glElementPointerATI)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ELEMENT_ARRAY_ATI :: GLenum
gl_ELEMENT_ARRAY_ATI = 34664
 
gl_ELEMENT_ARRAY_POINTER_ATI :: GLenum
gl_ELEMENT_ARRAY_POINTER_ATI = 34666
 
gl_ELEMENT_ARRAY_TYPE_ATI :: GLenum
gl_ELEMENT_ARRAY_TYPE_ATI = 34665
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawElementArrayATI
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> IO ())
 
glDrawElementArrayATI :: GLenum -> GLsizei -> IO ()
glDrawElementArrayATI
  = dyn_glDrawElementArrayATI ptr_glDrawElementArrayATI
 
{-# NOINLINE ptr_glDrawElementArrayATI #-}
 
ptr_glDrawElementArrayATI :: FunPtr a
ptr_glDrawElementArrayATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glDrawElementArrayATI"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawRangeElementArrayATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> IO ())
 
glDrawRangeElementArrayATI ::
                           GLenum -> GLuint -> GLuint -> GLsizei -> IO ()
glDrawRangeElementArrayATI
  = dyn_glDrawRangeElementArrayATI ptr_glDrawRangeElementArrayATI
 
{-# NOINLINE ptr_glDrawRangeElementArrayATI #-}
 
ptr_glDrawRangeElementArrayATI :: FunPtr a
ptr_glDrawRangeElementArrayATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glDrawRangeElementArrayATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glElementPointerATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr c -> IO ())
 
glElementPointerATI :: GLenum -> Ptr c -> IO ()
glElementPointerATI
  = dyn_glElementPointerATI ptr_glElementPointerATI
 
{-# NOINLINE ptr_glElementPointerATI #-}
 
ptr_glElementPointerATI :: FunPtr a
ptr_glElementPointerATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_element_array"
        "glElementPointerATI"