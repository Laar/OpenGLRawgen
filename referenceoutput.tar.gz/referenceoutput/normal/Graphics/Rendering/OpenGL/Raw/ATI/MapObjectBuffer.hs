{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.MapObjectBuffer
       (glMapObjectBufferATI, glUnmapObjectBufferATI) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapObjectBufferATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO (Ptr a))
 
glMapObjectBufferATI :: GLuint -> IO (Ptr a)
glMapObjectBufferATI
  = dyn_glMapObjectBufferATI ptr_glMapObjectBufferATI
 
{-# NOINLINE ptr_glMapObjectBufferATI #-}
 
ptr_glMapObjectBufferATI :: FunPtr a
ptr_glMapObjectBufferATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_map_object_buffer"
        "glMapObjectBufferATI"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUnmapObjectBufferATI
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glUnmapObjectBufferATI :: GLuint -> IO ()
glUnmapObjectBufferATI
  = dyn_glUnmapObjectBufferATI ptr_glUnmapObjectBufferATI
 
{-# NOINLINE ptr_glUnmapObjectBufferATI #-}
 
ptr_glUnmapObjectBufferATI :: FunPtr a
ptr_glUnmapObjectBufferATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_map_object_buffer"
        "glUnmapObjectBufferATI"