-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.Meminfo
       (gl_RENDERBUFFER_FREE_MEMORY_ATI, gl_TEXTURE_FREE_MEMORY_ATI,
        gl_VBO_FREE_MEMORY_ATI)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RENDERBUFFER_FREE_MEMORY_ATI :: GLenum
gl_RENDERBUFFER_FREE_MEMORY_ATI = 34813
 
gl_TEXTURE_FREE_MEMORY_ATI :: GLenum
gl_TEXTURE_FREE_MEMORY_ATI = 34812
 
gl_VBO_FREE_MEMORY_ATI :: GLenum
gl_VBO_FREE_MEMORY_ATI = 34811