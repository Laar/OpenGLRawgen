-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.TextureFloat
       (gl_ALPHA_FLOAT16_ATI, gl_ALPHA_FLOAT32_ATI,
        gl_INTENSITY_FLOAT16_ATI, gl_INTENSITY_FLOAT32_ATI,
        gl_LUMINANCE_ALPHA_FLOAT16_ATI, gl_LUMINANCE_ALPHA_FLOAT32_ATI,
        gl_LUMINANCE_FLOAT16_ATI, gl_LUMINANCE_FLOAT32_ATI,
        gl_RGBA_FLOAT16_ATI, gl_RGBA_FLOAT32_ATI, gl_RGB_FLOAT16_ATI,
        gl_RGB_FLOAT32_ATI)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ALPHA_FLOAT16_ATI :: GLenum
gl_ALPHA_FLOAT16_ATI = 34844
 
gl_ALPHA_FLOAT32_ATI :: GLenum
gl_ALPHA_FLOAT32_ATI = 34838
 
gl_INTENSITY_FLOAT16_ATI :: GLenum
gl_INTENSITY_FLOAT16_ATI = 34845
 
gl_INTENSITY_FLOAT32_ATI :: GLenum
gl_INTENSITY_FLOAT32_ATI = 34839
 
gl_LUMINANCE_ALPHA_FLOAT16_ATI :: GLenum
gl_LUMINANCE_ALPHA_FLOAT16_ATI = 34847
 
gl_LUMINANCE_ALPHA_FLOAT32_ATI :: GLenum
gl_LUMINANCE_ALPHA_FLOAT32_ATI = 34841
 
gl_LUMINANCE_FLOAT16_ATI :: GLenum
gl_LUMINANCE_FLOAT16_ATI = 34846
 
gl_LUMINANCE_FLOAT32_ATI :: GLenum
gl_LUMINANCE_FLOAT32_ATI = 34840
 
gl_RGBA_FLOAT16_ATI :: GLenum
gl_RGBA_FLOAT16_ATI = 34842
 
gl_RGBA_FLOAT32_ATI :: GLenum
gl_RGBA_FLOAT32_ATI = 34836
 
gl_RGB_FLOAT16_ATI :: GLenum
gl_RGB_FLOAT16_ATI = 34843
 
gl_RGB_FLOAT32_ATI :: GLenum
gl_RGB_FLOAT32_ATI = 34837