module Graphics.Rendering.OpenGL.Raw.ATI.PixelFormatFloat
       (gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI, gl_RGBA_FLOAT_MODE_ATI) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI :: GLenum
gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI = 34869
 
gl_RGBA_FLOAT_MODE_ATI :: GLenum
gl_RGBA_FLOAT_MODE_ATI = 34848