module Graphics.Rendering.OpenGL.Raw.ATI.TextureEnvCombine3
       (gl_MODULATE_ADD_ATI, gl_MODULATE_SIGNED_ADD_ATI,
        gl_MODULATE_SUBTRACT_ATI)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MODULATE_ADD_ATI :: GLenum
gl_MODULATE_ADD_ATI = 34628
 
gl_MODULATE_SIGNED_ADD_ATI :: GLenum
gl_MODULATE_SIGNED_ADD_ATI = 34629
 
gl_MODULATE_SUBTRACT_ATI :: GLenum
gl_MODULATE_SUBTRACT_ATI = 34630