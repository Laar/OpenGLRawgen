{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.ATI.VertexAttribArrayObject
       (glGetVertexAttribArrayObjectfvATI,
        glGetVertexAttribArrayObjectivATI, glVertexAttribArrayObjectATI)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexAttribArrayObjectfvATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetVertexAttribArrayObjectfvATI ::
                                  GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetVertexAttribArrayObjectfvATI
  = dyn_glGetVertexAttribArrayObjectfvATI
      ptr_glGetVertexAttribArrayObjectfvATI
 
{-# NOINLINE ptr_glGetVertexAttribArrayObjectfvATI #-}
 
ptr_glGetVertexAttribArrayObjectfvATI :: FunPtr a
ptr_glGetVertexAttribArrayObjectfvATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_attrib_array_object"
        "glGetVertexAttribArrayObjectfvATI"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetVertexAttribArrayObjectivATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexAttribArrayObjectivATI ::
                                  GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexAttribArrayObjectivATI
  = dyn_glGetVertexAttribArrayObjectivATI
      ptr_glGetVertexAttribArrayObjectivATI
 
{-# NOINLINE ptr_glGetVertexAttribArrayObjectivATI #-}
 
ptr_glGetVertexAttribArrayObjectivATI :: FunPtr a
ptr_glGetVertexAttribArrayObjectivATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_attrib_array_object"
        "glGetVertexAttribArrayObjectivATI"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVertexAttribArrayObjectATI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint ->
                      GLenum -> GLboolean -> GLsizei -> GLuint -> GLuint -> IO ())
 
glVertexAttribArrayObjectATI ::
                             GLuint ->
                               GLint ->
                                 GLenum -> GLboolean -> GLsizei -> GLuint -> GLuint -> IO ()
glVertexAttribArrayObjectATI
  = dyn_glVertexAttribArrayObjectATI ptr_glVertexAttribArrayObjectATI
 
{-# NOINLINE ptr_glVertexAttribArrayObjectATI #-}
 
ptr_glVertexAttribArrayObjectATI :: FunPtr a
ptr_glVertexAttribArrayObjectATI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ATI_vertex_attrib_array_object"
        "glVertexAttribArrayObjectATI"