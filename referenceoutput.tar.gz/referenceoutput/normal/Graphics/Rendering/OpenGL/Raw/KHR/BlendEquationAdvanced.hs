{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.KHR.BlendEquationAdvanced
       (gl_COLORBURN_KHR, gl_COLORDODGE_KHR, gl_DARKEN_KHR,
        gl_DIFFERENCE_KHR, gl_EXCLUSION_KHR, gl_HARDLIGHT_KHR,
        gl_HSL_COLOR_KHR, gl_HSL_HUE_KHR, gl_HSL_LUMINOSITY_KHR,
        gl_HSL_SATURATION_KHR, gl_LIGHTEN_KHR, gl_MULTIPLY_KHR,
        gl_OVERLAY_KHR, gl_SCREEN_KHR, gl_SOFTLIGHT_KHR, glBlendBarrierKHR)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLORBURN_KHR :: GLenum
gl_COLORBURN_KHR = 37530
 
gl_COLORDODGE_KHR :: GLenum
gl_COLORDODGE_KHR = 37529
 
gl_DARKEN_KHR :: GLenum
gl_DARKEN_KHR = 37527
 
gl_DIFFERENCE_KHR :: GLenum
gl_DIFFERENCE_KHR = 37534
 
gl_EXCLUSION_KHR :: GLenum
gl_EXCLUSION_KHR = 37536
 
gl_HARDLIGHT_KHR :: GLenum
gl_HARDLIGHT_KHR = 37531
 
gl_HSL_COLOR_KHR :: GLenum
gl_HSL_COLOR_KHR = 37551
 
gl_HSL_HUE_KHR :: GLenum
gl_HSL_HUE_KHR = 37549
 
gl_HSL_LUMINOSITY_KHR :: GLenum
gl_HSL_LUMINOSITY_KHR = 37552
 
gl_HSL_SATURATION_KHR :: GLenum
gl_HSL_SATURATION_KHR = 37550
 
gl_LIGHTEN_KHR :: GLenum
gl_LIGHTEN_KHR = 37528
 
gl_MULTIPLY_KHR :: GLenum
gl_MULTIPLY_KHR = 37524
 
gl_OVERLAY_KHR :: GLenum
gl_OVERLAY_KHR = 37526
 
gl_SCREEN_KHR :: GLenum
gl_SCREEN_KHR = 37525
 
gl_SOFTLIGHT_KHR :: GLenum
gl_SOFTLIGHT_KHR = 37532
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendBarrierKHR ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glBlendBarrierKHR :: IO ()
glBlendBarrierKHR = dyn_glBlendBarrierKHR ptr_glBlendBarrierKHR
 
{-# NOINLINE ptr_glBlendBarrierKHR #-}
 
ptr_glBlendBarrierKHR :: FunPtr a
ptr_glBlendBarrierKHR
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_KHR_blend_equation_advanced"
        "glBlendBarrierKHR"