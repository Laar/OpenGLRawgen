-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.KHR.Robustness
       (gl_CONTEXT_LOST, gl_CONTEXT_ROBUST_ACCESS,
        gl_GUILTY_CONTEXT_RESET, gl_INNOCENT_CONTEXT_RESET,
        gl_LOSE_CONTEXT_ON_RESET, gl_NO_ERROR, gl_NO_RESET_NOTIFICATION,
        gl_RESET_NOTIFICATION_STRATEGY, gl_UNKNOWN_CONTEXT_RESET,
        glGetGraphicsResetStatus, glGetnUniformfv, glGetnUniformiv,
        glGetnUniformuiv, glReadnPixels)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core11 (gl_NO_ERROR)
import Graphics.Rendering.OpenGL.Raw.Core.Core45
       (glGetGraphicsResetStatus, glGetnUniformfv, glGetnUniformiv,
        glGetnUniformuiv, glReadnPixels, gl_CONTEXT_LOST,
        gl_GUILTY_CONTEXT_RESET, gl_INNOCENT_CONTEXT_RESET,
        gl_LOSE_CONTEXT_ON_RESET, gl_NO_RESET_NOTIFICATION,
        gl_RESET_NOTIFICATION_STRATEGY, gl_UNKNOWN_CONTEXT_RESET)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_CONTEXT_ROBUST_ACCESS :: GLenum
gl_CONTEXT_ROBUST_ACCESS = 37107