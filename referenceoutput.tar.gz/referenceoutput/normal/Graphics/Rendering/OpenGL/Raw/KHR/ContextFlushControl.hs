-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.KHR.ContextFlushControl
       (gl_CONTEXT_RELEASE_BEHAVIOR, gl_CONTEXT_RELEASE_BEHAVIOR_FLUSH,
        gl_NONE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Core11 (gl_NONE)
import Graphics.Rendering.OpenGL.Raw.Core.Core45
       (gl_CONTEXT_RELEASE_BEHAVIOR, gl_CONTEXT_RELEASE_BEHAVIOR_FLUSH)