-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.KHR.BlendEquationAdvancedCoherent
       (gl_BLEND_ADVANCED_COHERENT_KHR) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_BLEND_ADVANCED_COHERENT_KHR :: GLenum
gl_BLEND_ADVANCED_COHERENT_KHR = 37509