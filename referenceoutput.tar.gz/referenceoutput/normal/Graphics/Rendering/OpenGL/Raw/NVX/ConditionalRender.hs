{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NVX.ConditionalRender
       (glBeginConditionalRenderNVX, glEndConditionalRenderNVX) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBeginConditionalRenderNVX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBeginConditionalRenderNVX :: GLuint -> IO ()
glBeginConditionalRenderNVX
  = dyn_glBeginConditionalRenderNVX ptr_glBeginConditionalRenderNVX
 
{-# NOINLINE ptr_glBeginConditionalRenderNVX #-}
 
ptr_glBeginConditionalRenderNVX :: FunPtr a
ptr_glBeginConditionalRenderNVX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NVX_conditional_render"
        "glBeginConditionalRenderNVX"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glEndConditionalRenderNVX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glEndConditionalRenderNVX :: IO ()
glEndConditionalRenderNVX
  = dyn_glEndConditionalRenderNVX ptr_glEndConditionalRenderNVX
 
{-# NOINLINE ptr_glEndConditionalRenderNVX #-}
 
ptr_glEndConditionalRenderNVX :: FunPtr a
ptr_glEndConditionalRenderNVX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NVX_conditional_render"
        "glEndConditionalRenderNVX"