{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.Core.Core30
       (gl_2D, gl_2_BYTES, gl_3D, gl_3D_COLOR, gl_3D_COLOR_TEXTURE,
        gl_3_BYTES, gl_4D_COLOR_TEXTURE, gl_4_BYTES, gl_ACCUM,
        gl_ACCUM_ALPHA_BITS, gl_ACCUM_BLUE_BITS, gl_ACCUM_BUFFER_BIT,
        gl_ACCUM_CLEAR_VALUE, gl_ACCUM_GREEN_BITS, gl_ACCUM_RED_BITS,
        gl_ACTIVE_ATTRIBUTES, gl_ACTIVE_ATTRIBUTE_MAX_LENGTH,
        gl_ACTIVE_TEXTURE, gl_ACTIVE_UNIFORMS,
        gl_ACTIVE_UNIFORM_MAX_LENGTH, gl_ADD, gl_ADD_SIGNED,
        gl_ALIASED_LINE_WIDTH_RANGE, gl_ALIASED_POINT_SIZE_RANGE,
        gl_ALL_ATTRIB_BITS, gl_ALPHA, gl_ALPHA12, gl_ALPHA16, gl_ALPHA4,
        gl_ALPHA8, gl_ALPHA_BIAS, gl_ALPHA_BITS, gl_ALPHA_INTEGER,
        gl_ALPHA_SCALE, gl_ALPHA_TEST, gl_ALPHA_TEST_FUNC,
        gl_ALPHA_TEST_REF, gl_ALWAYS, gl_AMBIENT, gl_AMBIENT_AND_DIFFUSE,
        gl_AND, gl_AND_INVERTED, gl_AND_REVERSE, gl_ARRAY_BUFFER,
        gl_ARRAY_BUFFER_BINDING, gl_ATTACHED_SHADERS,
        gl_ATTRIB_STACK_DEPTH, gl_AUTO_NORMAL, gl_AUX0, gl_AUX1, gl_AUX2,
        gl_AUX3, gl_AUX_BUFFERS, gl_BACK, gl_BACK_LEFT, gl_BACK_RIGHT,
        gl_BGR, gl_BGRA, gl_BGRA_INTEGER, gl_BGR_INTEGER, gl_BITMAP,
        gl_BITMAP_TOKEN, gl_BLEND, gl_BLEND_DST, gl_BLEND_DST_ALPHA,
        gl_BLEND_DST_RGB, gl_BLEND_EQUATION_ALPHA, gl_BLEND_EQUATION_RGB,
        gl_BLEND_SRC, gl_BLEND_SRC_ALPHA, gl_BLEND_SRC_RGB, gl_BLUE,
        gl_BLUE_BIAS, gl_BLUE_BITS, gl_BLUE_INTEGER, gl_BLUE_SCALE,
        gl_BOOL, gl_BOOL_VEC2, gl_BOOL_VEC3, gl_BOOL_VEC4,
        gl_BUFFER_ACCESS, gl_BUFFER_ACCESS_FLAGS, gl_BUFFER_MAPPED,
        gl_BUFFER_MAP_LENGTH, gl_BUFFER_MAP_OFFSET, gl_BUFFER_MAP_POINTER,
        gl_BUFFER_SIZE, gl_BUFFER_USAGE, gl_BYTE, gl_C3F_V3F,
        gl_C4F_N3F_V3F, gl_C4UB_V2F, gl_C4UB_V3F, gl_CCW, gl_CLAMP,
        gl_CLAMP_FRAGMENT_COLOR, gl_CLAMP_READ_COLOR, gl_CLAMP_TO_BORDER,
        gl_CLAMP_TO_EDGE, gl_CLAMP_VERTEX_COLOR, gl_CLEAR,
        gl_CLIENT_ACTIVE_TEXTURE, gl_CLIENT_ALL_ATTRIB_BITS,
        gl_CLIENT_ATTRIB_STACK_DEPTH, gl_CLIENT_PIXEL_STORE_BIT,
        gl_CLIENT_VERTEX_ARRAY_BIT, gl_CLIP_DISTANCE0, gl_CLIP_DISTANCE1,
        gl_CLIP_DISTANCE2, gl_CLIP_DISTANCE3, gl_CLIP_DISTANCE4,
        gl_CLIP_DISTANCE5, gl_CLIP_DISTANCE6, gl_CLIP_DISTANCE7,
        gl_CLIP_PLANE0, gl_CLIP_PLANE1, gl_CLIP_PLANE2, gl_CLIP_PLANE3,
        gl_CLIP_PLANE4, gl_CLIP_PLANE5, gl_COEFF, gl_COLOR, gl_COLOR_ARRAY,
        gl_COLOR_ARRAY_BUFFER_BINDING, gl_COLOR_ARRAY_POINTER,
        gl_COLOR_ARRAY_SIZE, gl_COLOR_ARRAY_STRIDE, gl_COLOR_ARRAY_TYPE,
        gl_COLOR_ATTACHMENT0, gl_COLOR_ATTACHMENT1, gl_COLOR_ATTACHMENT10,
        gl_COLOR_ATTACHMENT11, gl_COLOR_ATTACHMENT12,
        gl_COLOR_ATTACHMENT13, gl_COLOR_ATTACHMENT14,
        gl_COLOR_ATTACHMENT15, gl_COLOR_ATTACHMENT2, gl_COLOR_ATTACHMENT3,
        gl_COLOR_ATTACHMENT4, gl_COLOR_ATTACHMENT5, gl_COLOR_ATTACHMENT6,
        gl_COLOR_ATTACHMENT7, gl_COLOR_ATTACHMENT8, gl_COLOR_ATTACHMENT9,
        gl_COLOR_BUFFER_BIT, gl_COLOR_CLEAR_VALUE, gl_COLOR_INDEX,
        gl_COLOR_INDEXES, gl_COLOR_LOGIC_OP, gl_COLOR_MATERIAL,
        gl_COLOR_MATERIAL_FACE, gl_COLOR_MATERIAL_PARAMETER, gl_COLOR_SUM,
        gl_COLOR_WRITEMASK, gl_COMBINE, gl_COMBINE_ALPHA, gl_COMBINE_RGB,
        gl_COMPARE_REF_TO_TEXTURE, gl_COMPARE_R_TO_TEXTURE, gl_COMPILE,
        gl_COMPILE_AND_EXECUTE, gl_COMPILE_STATUS, gl_COMPRESSED_ALPHA,
        gl_COMPRESSED_INTENSITY, gl_COMPRESSED_LUMINANCE,
        gl_COMPRESSED_LUMINANCE_ALPHA, gl_COMPRESSED_RED,
        gl_COMPRESSED_RED_RGTC1, gl_COMPRESSED_RG, gl_COMPRESSED_RGB,
        gl_COMPRESSED_RGBA, gl_COMPRESSED_RG_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1, gl_COMPRESSED_SIGNED_RG_RGTC2,
        gl_COMPRESSED_SLUMINANCE, gl_COMPRESSED_SLUMINANCE_ALPHA,
        gl_COMPRESSED_SRGB, gl_COMPRESSED_SRGB_ALPHA,
        gl_COMPRESSED_TEXTURE_FORMATS, gl_CONSTANT, gl_CONSTANT_ALPHA,
        gl_CONSTANT_ATTENUATION, gl_CONSTANT_COLOR, gl_CONTEXT_FLAGS,
        gl_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT, gl_COORD_REPLACE, gl_COPY,
        gl_COPY_INVERTED, gl_COPY_PIXEL_TOKEN, gl_CULL_FACE,
        gl_CULL_FACE_MODE, gl_CURRENT_BIT, gl_CURRENT_COLOR,
        gl_CURRENT_FOG_COORD, gl_CURRENT_FOG_COORDINATE, gl_CURRENT_INDEX,
        gl_CURRENT_NORMAL, gl_CURRENT_PROGRAM, gl_CURRENT_QUERY,
        gl_CURRENT_RASTER_COLOR, gl_CURRENT_RASTER_DISTANCE,
        gl_CURRENT_RASTER_INDEX, gl_CURRENT_RASTER_POSITION,
        gl_CURRENT_RASTER_POSITION_VALID,
        gl_CURRENT_RASTER_SECONDARY_COLOR,
        gl_CURRENT_RASTER_TEXTURE_COORDS, gl_CURRENT_SECONDARY_COLOR,
        gl_CURRENT_TEXTURE_COORDS, gl_CURRENT_VERTEX_ATTRIB, gl_CW,
        gl_DECAL, gl_DECR, gl_DECR_WRAP, gl_DELETE_STATUS, gl_DEPTH,
        gl_DEPTH24_STENCIL8, gl_DEPTH32F_STENCIL8, gl_DEPTH_ATTACHMENT,
        gl_DEPTH_BIAS, gl_DEPTH_BITS, gl_DEPTH_BUFFER_BIT,
        gl_DEPTH_CLEAR_VALUE, gl_DEPTH_COMPONENT, gl_DEPTH_COMPONENT16,
        gl_DEPTH_COMPONENT24, gl_DEPTH_COMPONENT32, gl_DEPTH_COMPONENT32F,
        gl_DEPTH_FUNC, gl_DEPTH_RANGE, gl_DEPTH_SCALE, gl_DEPTH_STENCIL,
        gl_DEPTH_STENCIL_ATTACHMENT, gl_DEPTH_TEST, gl_DEPTH_TEXTURE_MODE,
        gl_DEPTH_WRITEMASK, gl_DIFFUSE, gl_DITHER, gl_DOMAIN, gl_DONT_CARE,
        gl_DOT3_RGB, gl_DOT3_RGBA, gl_DOUBLE, gl_DOUBLEBUFFER,
        gl_DRAW_BUFFER, gl_DRAW_BUFFER0, gl_DRAW_BUFFER1, gl_DRAW_BUFFER10,
        gl_DRAW_BUFFER11, gl_DRAW_BUFFER12, gl_DRAW_BUFFER13,
        gl_DRAW_BUFFER14, gl_DRAW_BUFFER15, gl_DRAW_BUFFER2,
        gl_DRAW_BUFFER3, gl_DRAW_BUFFER4, gl_DRAW_BUFFER5, gl_DRAW_BUFFER6,
        gl_DRAW_BUFFER7, gl_DRAW_BUFFER8, gl_DRAW_BUFFER9,
        gl_DRAW_FRAMEBUFFER, gl_DRAW_FRAMEBUFFER_BINDING,
        gl_DRAW_PIXEL_TOKEN, gl_DST_ALPHA, gl_DST_COLOR, gl_DYNAMIC_COPY,
        gl_DYNAMIC_DRAW, gl_DYNAMIC_READ, gl_EDGE_FLAG, gl_EDGE_FLAG_ARRAY,
        gl_EDGE_FLAG_ARRAY_BUFFER_BINDING, gl_EDGE_FLAG_ARRAY_POINTER,
        gl_EDGE_FLAG_ARRAY_STRIDE, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING, gl_EMISSION, gl_ENABLE_BIT,
        gl_EQUAL, gl_EQUIV, gl_EVAL_BIT, gl_EXP, gl_EXP2, gl_EXTENSIONS,
        gl_EYE_LINEAR, gl_EYE_PLANE, gl_FALSE, gl_FASTEST, gl_FEEDBACK,
        gl_FEEDBACK_BUFFER_POINTER, gl_FEEDBACK_BUFFER_SIZE,
        gl_FEEDBACK_BUFFER_TYPE, gl_FILL, gl_FIXED_ONLY, gl_FLAT, gl_FLOAT,
        gl_FLOAT_32_UNSIGNED_INT_24_8_REV, gl_FLOAT_MAT2, gl_FLOAT_MAT2x3,
        gl_FLOAT_MAT2x4, gl_FLOAT_MAT3, gl_FLOAT_MAT3x2, gl_FLOAT_MAT3x4,
        gl_FLOAT_MAT4, gl_FLOAT_MAT4x2, gl_FLOAT_MAT4x3, gl_FLOAT_VEC2,
        gl_FLOAT_VEC3, gl_FLOAT_VEC4, gl_FOG, gl_FOG_BIT, gl_FOG_COLOR,
        gl_FOG_COORD, gl_FOG_COORDINATE, gl_FOG_COORDINATE_ARRAY,
        gl_FOG_COORDINATE_ARRAY_BUFFER_BINDING,
        gl_FOG_COORDINATE_ARRAY_POINTER, gl_FOG_COORDINATE_ARRAY_STRIDE,
        gl_FOG_COORDINATE_ARRAY_TYPE, gl_FOG_COORDINATE_SOURCE,
        gl_FOG_COORD_ARRAY, gl_FOG_COORD_ARRAY_BUFFER_BINDING,
        gl_FOG_COORD_ARRAY_POINTER, gl_FOG_COORD_ARRAY_STRIDE,
        gl_FOG_COORD_ARRAY_TYPE, gl_FOG_COORD_SRC, gl_FOG_DENSITY,
        gl_FOG_END, gl_FOG_HINT, gl_FOG_INDEX, gl_FOG_MODE, gl_FOG_START,
        gl_FRAGMENT_DEPTH, gl_FRAGMENT_SHADER,
        gl_FRAGMENT_SHADER_DERIVATIVE_HINT, gl_FRAMEBUFFER,
        gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING,
        gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL, gl_FRAMEBUFFER_BINDING,
        gl_FRAMEBUFFER_COMPLETE, gl_FRAMEBUFFER_DEFAULT,
        gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER,
        gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE,
        gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER, gl_FRAMEBUFFER_SRGB,
        gl_FRAMEBUFFER_UNDEFINED, gl_FRAMEBUFFER_UNSUPPORTED, gl_FRONT,
        gl_FRONT_AND_BACK, gl_FRONT_FACE, gl_FRONT_LEFT, gl_FRONT_RIGHT,
        gl_FUNC_ADD, gl_FUNC_REVERSE_SUBTRACT, gl_FUNC_SUBTRACT,
        gl_GENERATE_MIPMAP, gl_GENERATE_MIPMAP_HINT, gl_GEQUAL, gl_GREATER,
        gl_GREEN, gl_GREEN_BIAS, gl_GREEN_BITS, gl_GREEN_INTEGER,
        gl_GREEN_SCALE, gl_HALF_FLOAT, gl_HINT_BIT, gl_INCR, gl_INCR_WRAP,
        gl_INDEX_ARRAY, gl_INDEX_ARRAY_BUFFER_BINDING,
        gl_INDEX_ARRAY_POINTER, gl_INDEX_ARRAY_STRIDE, gl_INDEX_ARRAY_TYPE,
        gl_INDEX_BITS, gl_INDEX_CLEAR_VALUE, gl_INDEX_LOGIC_OP,
        gl_INDEX_MODE, gl_INDEX_OFFSET, gl_INDEX_SHIFT, gl_INDEX_WRITEMASK,
        gl_INFO_LOG_LENGTH, gl_INT, gl_INTENSITY, gl_INTENSITY12,
        gl_INTENSITY16, gl_INTENSITY4, gl_INTENSITY8,
        gl_INTERLEAVED_ATTRIBS, gl_INTERPOLATE, gl_INT_SAMPLER_1D,
        gl_INT_SAMPLER_1D_ARRAY, gl_INT_SAMPLER_2D,
        gl_INT_SAMPLER_2D_ARRAY, gl_INT_SAMPLER_3D, gl_INT_SAMPLER_CUBE,
        gl_INT_VEC2, gl_INT_VEC3, gl_INT_VEC4, gl_INVALID_ENUM,
        gl_INVALID_FRAMEBUFFER_OPERATION, gl_INVALID_OPERATION,
        gl_INVALID_VALUE, gl_INVERT, gl_KEEP, gl_LEFT, gl_LEQUAL, gl_LESS,
        gl_LIGHT0, gl_LIGHT1, gl_LIGHT2, gl_LIGHT3, gl_LIGHT4, gl_LIGHT5,
        gl_LIGHT6, gl_LIGHT7, gl_LIGHTING, gl_LIGHTING_BIT,
        gl_LIGHT_MODEL_AMBIENT, gl_LIGHT_MODEL_COLOR_CONTROL,
        gl_LIGHT_MODEL_LOCAL_VIEWER, gl_LIGHT_MODEL_TWO_SIDE, gl_LINE,
        gl_LINEAR, gl_LINEAR_ATTENUATION, gl_LINEAR_MIPMAP_LINEAR,
        gl_LINEAR_MIPMAP_NEAREST, gl_LINES, gl_LINE_BIT, gl_LINE_LOOP,
        gl_LINE_RESET_TOKEN, gl_LINE_SMOOTH, gl_LINE_SMOOTH_HINT,
        gl_LINE_STIPPLE, gl_LINE_STIPPLE_PATTERN, gl_LINE_STIPPLE_REPEAT,
        gl_LINE_STRIP, gl_LINE_TOKEN, gl_LINE_WIDTH,
        gl_LINE_WIDTH_GRANULARITY, gl_LINE_WIDTH_RANGE, gl_LINK_STATUS,
        gl_LIST_BASE, gl_LIST_BIT, gl_LIST_INDEX, gl_LIST_MODE, gl_LOAD,
        gl_LOGIC_OP, gl_LOGIC_OP_MODE, gl_LOWER_LEFT, gl_LUMINANCE,
        gl_LUMINANCE12, gl_LUMINANCE12_ALPHA12, gl_LUMINANCE12_ALPHA4,
        gl_LUMINANCE16, gl_LUMINANCE16_ALPHA16, gl_LUMINANCE4,
        gl_LUMINANCE4_ALPHA4, gl_LUMINANCE6_ALPHA2, gl_LUMINANCE8,
        gl_LUMINANCE8_ALPHA8, gl_LUMINANCE_ALPHA, gl_MAJOR_VERSION,
        gl_MAP1_COLOR_4, gl_MAP1_GRID_DOMAIN, gl_MAP1_GRID_SEGMENTS,
        gl_MAP1_INDEX, gl_MAP1_NORMAL, gl_MAP1_TEXTURE_COORD_1,
        gl_MAP1_TEXTURE_COORD_2, gl_MAP1_TEXTURE_COORD_3,
        gl_MAP1_TEXTURE_COORD_4, gl_MAP1_VERTEX_3, gl_MAP1_VERTEX_4,
        gl_MAP2_COLOR_4, gl_MAP2_GRID_DOMAIN, gl_MAP2_GRID_SEGMENTS,
        gl_MAP2_INDEX, gl_MAP2_NORMAL, gl_MAP2_TEXTURE_COORD_1,
        gl_MAP2_TEXTURE_COORD_2, gl_MAP2_TEXTURE_COORD_3,
        gl_MAP2_TEXTURE_COORD_4, gl_MAP2_VERTEX_3, gl_MAP2_VERTEX_4,
        gl_MAP_COLOR, gl_MAP_FLUSH_EXPLICIT_BIT,
        gl_MAP_INVALIDATE_BUFFER_BIT, gl_MAP_INVALIDATE_RANGE_BIT,
        gl_MAP_READ_BIT, gl_MAP_STENCIL, gl_MAP_UNSYNCHRONIZED_BIT,
        gl_MAP_WRITE_BIT, gl_MATRIX_MODE, gl_MAX, gl_MAX_3D_TEXTURE_SIZE,
        gl_MAX_ARRAY_TEXTURE_LAYERS, gl_MAX_ATTRIB_STACK_DEPTH,
        gl_MAX_CLIENT_ATTRIB_STACK_DEPTH, gl_MAX_CLIP_DISTANCES,
        gl_MAX_CLIP_PLANES, gl_MAX_COLOR_ATTACHMENTS,
        gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS, gl_MAX_CUBE_MAP_TEXTURE_SIZE,
        gl_MAX_DRAW_BUFFERS, gl_MAX_ELEMENTS_INDICES,
        gl_MAX_ELEMENTS_VERTICES, gl_MAX_EVAL_ORDER,
        gl_MAX_FRAGMENT_UNIFORM_COMPONENTS, gl_MAX_LIGHTS,
        gl_MAX_LIST_NESTING, gl_MAX_MODELVIEW_STACK_DEPTH,
        gl_MAX_NAME_STACK_DEPTH, gl_MAX_PIXEL_MAP_TABLE,
        gl_MAX_PROGRAM_TEXEL_OFFSET, gl_MAX_PROJECTION_STACK_DEPTH,
        gl_MAX_RENDERBUFFER_SIZE, gl_MAX_SAMPLES, gl_MAX_TEXTURE_COORDS,
        gl_MAX_TEXTURE_IMAGE_UNITS, gl_MAX_TEXTURE_LOD_BIAS,
        gl_MAX_TEXTURE_SIZE, gl_MAX_TEXTURE_STACK_DEPTH,
        gl_MAX_TEXTURE_UNITS,
        gl_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS,
        gl_MAX_VARYING_COMPONENTS, gl_MAX_VARYING_FLOATS,
        gl_MAX_VERTEX_ATTRIBS, gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS,
        gl_MAX_VERTEX_UNIFORM_COMPONENTS, gl_MAX_VIEWPORT_DIMS, gl_MIN,
        gl_MINOR_VERSION, gl_MIN_PROGRAM_TEXEL_OFFSET, gl_MIRRORED_REPEAT,
        gl_MODELVIEW, gl_MODELVIEW_MATRIX, gl_MODELVIEW_STACK_DEPTH,
        gl_MODULATE, gl_MULT, gl_MULTISAMPLE, gl_MULTISAMPLE_BIT,
        gl_N3F_V3F, gl_NAME_STACK_DEPTH, gl_NAND, gl_NEAREST,
        gl_NEAREST_MIPMAP_LINEAR, gl_NEAREST_MIPMAP_NEAREST, gl_NEVER,
        gl_NICEST, gl_NONE, gl_NOOP, gl_NOR, gl_NORMALIZE, gl_NORMAL_ARRAY,
        gl_NORMAL_ARRAY_BUFFER_BINDING, gl_NORMAL_ARRAY_POINTER,
        gl_NORMAL_ARRAY_STRIDE, gl_NORMAL_ARRAY_TYPE, gl_NORMAL_MAP,
        gl_NOTEQUAL, gl_NO_ERROR, gl_NUM_COMPRESSED_TEXTURE_FORMATS,
        gl_NUM_EXTENSIONS, gl_OBJECT_LINEAR, gl_OBJECT_PLANE, gl_ONE,
        gl_ONE_MINUS_CONSTANT_ALPHA, gl_ONE_MINUS_CONSTANT_COLOR,
        gl_ONE_MINUS_DST_ALPHA, gl_ONE_MINUS_DST_COLOR,
        gl_ONE_MINUS_SRC_ALPHA, gl_ONE_MINUS_SRC_COLOR, gl_OPERAND0_ALPHA,
        gl_OPERAND0_RGB, gl_OPERAND1_ALPHA, gl_OPERAND1_RGB,
        gl_OPERAND2_ALPHA, gl_OPERAND2_RGB, gl_OR, gl_ORDER,
        gl_OR_INVERTED, gl_OR_REVERSE, gl_OUT_OF_MEMORY, gl_PACK_ALIGNMENT,
        gl_PACK_IMAGE_HEIGHT, gl_PACK_LSB_FIRST, gl_PACK_ROW_LENGTH,
        gl_PACK_SKIP_IMAGES, gl_PACK_SKIP_PIXELS, gl_PACK_SKIP_ROWS,
        gl_PACK_SWAP_BYTES, gl_PASS_THROUGH_TOKEN,
        gl_PERSPECTIVE_CORRECTION_HINT, gl_PIXEL_MAP_A_TO_A,
        gl_PIXEL_MAP_A_TO_A_SIZE, gl_PIXEL_MAP_B_TO_B,
        gl_PIXEL_MAP_B_TO_B_SIZE, gl_PIXEL_MAP_G_TO_G,
        gl_PIXEL_MAP_G_TO_G_SIZE, gl_PIXEL_MAP_I_TO_A,
        gl_PIXEL_MAP_I_TO_A_SIZE, gl_PIXEL_MAP_I_TO_B,
        gl_PIXEL_MAP_I_TO_B_SIZE, gl_PIXEL_MAP_I_TO_G,
        gl_PIXEL_MAP_I_TO_G_SIZE, gl_PIXEL_MAP_I_TO_I,
        gl_PIXEL_MAP_I_TO_I_SIZE, gl_PIXEL_MAP_I_TO_R,
        gl_PIXEL_MAP_I_TO_R_SIZE, gl_PIXEL_MAP_R_TO_R,
        gl_PIXEL_MAP_R_TO_R_SIZE, gl_PIXEL_MAP_S_TO_S,
        gl_PIXEL_MAP_S_TO_S_SIZE, gl_PIXEL_MODE_BIT, gl_PIXEL_PACK_BUFFER,
        gl_PIXEL_PACK_BUFFER_BINDING, gl_PIXEL_UNPACK_BUFFER,
        gl_PIXEL_UNPACK_BUFFER_BINDING, gl_POINT, gl_POINTS, gl_POINT_BIT,
        gl_POINT_DISTANCE_ATTENUATION, gl_POINT_FADE_THRESHOLD_SIZE,
        gl_POINT_SIZE, gl_POINT_SIZE_GRANULARITY, gl_POINT_SIZE_MAX,
        gl_POINT_SIZE_MIN, gl_POINT_SIZE_RANGE, gl_POINT_SMOOTH,
        gl_POINT_SMOOTH_HINT, gl_POINT_SPRITE,
        gl_POINT_SPRITE_COORD_ORIGIN, gl_POINT_TOKEN, gl_POLYGON,
        gl_POLYGON_BIT, gl_POLYGON_MODE, gl_POLYGON_OFFSET_FACTOR,
        gl_POLYGON_OFFSET_FILL, gl_POLYGON_OFFSET_LINE,
        gl_POLYGON_OFFSET_POINT, gl_POLYGON_OFFSET_UNITS,
        gl_POLYGON_SMOOTH, gl_POLYGON_SMOOTH_HINT, gl_POLYGON_STIPPLE,
        gl_POLYGON_STIPPLE_BIT, gl_POLYGON_TOKEN, gl_POSITION, gl_PREVIOUS,
        gl_PRIMARY_COLOR, gl_PRIMITIVES_GENERATED, gl_PROJECTION,
        gl_PROJECTION_MATRIX, gl_PROJECTION_STACK_DEPTH,
        gl_PROXY_TEXTURE_1D, gl_PROXY_TEXTURE_1D_ARRAY,
        gl_PROXY_TEXTURE_2D, gl_PROXY_TEXTURE_2D_ARRAY,
        gl_PROXY_TEXTURE_3D, gl_PROXY_TEXTURE_CUBE_MAP, gl_Q,
        gl_QUADRATIC_ATTENUATION, gl_QUADS, gl_QUAD_STRIP,
        gl_QUERY_BY_REGION_NO_WAIT, gl_QUERY_BY_REGION_WAIT,
        gl_QUERY_COUNTER_BITS, gl_QUERY_NO_WAIT, gl_QUERY_RESULT,
        gl_QUERY_RESULT_AVAILABLE, gl_QUERY_WAIT, gl_R, gl_R11F_G11F_B10F,
        gl_R16, gl_R16F, gl_R16I, gl_R16UI, gl_R32F, gl_R32I, gl_R32UI,
        gl_R3_G3_B2, gl_R8, gl_R8I, gl_R8UI, gl_RASTERIZER_DISCARD,
        gl_READ_BUFFER, gl_READ_FRAMEBUFFER, gl_READ_FRAMEBUFFER_BINDING,
        gl_READ_ONLY, gl_READ_WRITE, gl_RED, gl_RED_BIAS, gl_RED_BITS,
        gl_RED_INTEGER, gl_RED_SCALE, gl_REFLECTION_MAP, gl_RENDER,
        gl_RENDERBUFFER, gl_RENDERBUFFER_ALPHA_SIZE,
        gl_RENDERBUFFER_BINDING, gl_RENDERBUFFER_BLUE_SIZE,
        gl_RENDERBUFFER_DEPTH_SIZE, gl_RENDERBUFFER_GREEN_SIZE,
        gl_RENDERBUFFER_HEIGHT, gl_RENDERBUFFER_INTERNAL_FORMAT,
        gl_RENDERBUFFER_RED_SIZE, gl_RENDERBUFFER_SAMPLES,
        gl_RENDERBUFFER_STENCIL_SIZE, gl_RENDERBUFFER_WIDTH, gl_RENDERER,
        gl_RENDER_MODE, gl_REPEAT, gl_REPLACE, gl_RESCALE_NORMAL,
        gl_RETURN, gl_RG, gl_RG16, gl_RG16F, gl_RG16I, gl_RG16UI, gl_RG32F,
        gl_RG32I, gl_RG32UI, gl_RG8, gl_RG8I, gl_RG8UI, gl_RGB, gl_RGB10,
        gl_RGB10_A2, gl_RGB12, gl_RGB16, gl_RGB16F, gl_RGB16I, gl_RGB16UI,
        gl_RGB32F, gl_RGB32I, gl_RGB32UI, gl_RGB4, gl_RGB5, gl_RGB5_A1,
        gl_RGB8, gl_RGB8I, gl_RGB8UI, gl_RGB9_E5, gl_RGBA, gl_RGBA12,
        gl_RGBA16, gl_RGBA16F, gl_RGBA16I, gl_RGBA16UI, gl_RGBA2,
        gl_RGBA32F, gl_RGBA32I, gl_RGBA32UI, gl_RGBA4, gl_RGBA8, gl_RGBA8I,
        gl_RGBA8UI, gl_RGBA_INTEGER, gl_RGBA_MODE, gl_RGB_INTEGER,
        gl_RGB_SCALE, gl_RG_INTEGER, gl_RIGHT, gl_S, gl_SAMPLER_1D,
        gl_SAMPLER_1D_ARRAY, gl_SAMPLER_1D_ARRAY_SHADOW,
        gl_SAMPLER_1D_SHADOW, gl_SAMPLER_2D, gl_SAMPLER_2D_ARRAY,
        gl_SAMPLER_2D_ARRAY_SHADOW, gl_SAMPLER_2D_SHADOW, gl_SAMPLER_3D,
        gl_SAMPLER_CUBE, gl_SAMPLER_CUBE_SHADOW, gl_SAMPLES,
        gl_SAMPLES_PASSED, gl_SAMPLE_ALPHA_TO_COVERAGE,
        gl_SAMPLE_ALPHA_TO_ONE, gl_SAMPLE_BUFFERS, gl_SAMPLE_COVERAGE,
        gl_SAMPLE_COVERAGE_INVERT, gl_SAMPLE_COVERAGE_VALUE,
        gl_SCISSOR_BIT, gl_SCISSOR_BOX, gl_SCISSOR_TEST,
        gl_SECONDARY_COLOR_ARRAY, gl_SECONDARY_COLOR_ARRAY_BUFFER_BINDING,
        gl_SECONDARY_COLOR_ARRAY_POINTER, gl_SECONDARY_COLOR_ARRAY_SIZE,
        gl_SECONDARY_COLOR_ARRAY_STRIDE, gl_SECONDARY_COLOR_ARRAY_TYPE,
        gl_SELECT, gl_SELECTION_BUFFER_POINTER, gl_SELECTION_BUFFER_SIZE,
        gl_SEPARATE_ATTRIBS, gl_SEPARATE_SPECULAR_COLOR, gl_SET,
        gl_SHADER_SOURCE_LENGTH, gl_SHADER_TYPE, gl_SHADE_MODEL,
        gl_SHADING_LANGUAGE_VERSION, gl_SHININESS, gl_SHORT,
        gl_SINGLE_COLOR, gl_SLUMINANCE, gl_SLUMINANCE8,
        gl_SLUMINANCE8_ALPHA8, gl_SLUMINANCE_ALPHA, gl_SMOOTH,
        gl_SMOOTH_LINE_WIDTH_GRANULARITY, gl_SMOOTH_LINE_WIDTH_RANGE,
        gl_SMOOTH_POINT_SIZE_GRANULARITY, gl_SMOOTH_POINT_SIZE_RANGE,
        gl_SOURCE0_ALPHA, gl_SOURCE0_RGB, gl_SOURCE1_ALPHA, gl_SOURCE1_RGB,
        gl_SOURCE2_ALPHA, gl_SOURCE2_RGB, gl_SPECULAR, gl_SPHERE_MAP,
        gl_SPOT_CUTOFF, gl_SPOT_DIRECTION, gl_SPOT_EXPONENT, gl_SRC0_ALPHA,
        gl_SRC0_RGB, gl_SRC1_ALPHA, gl_SRC1_RGB, gl_SRC2_ALPHA,
        gl_SRC2_RGB, gl_SRC_ALPHA, gl_SRC_ALPHA_SATURATE, gl_SRC_COLOR,
        gl_SRGB, gl_SRGB8, gl_SRGB8_ALPHA8, gl_SRGB_ALPHA,
        gl_STACK_OVERFLOW, gl_STACK_UNDERFLOW, gl_STATIC_COPY,
        gl_STATIC_DRAW, gl_STATIC_READ, gl_STENCIL, gl_STENCIL_ATTACHMENT,
        gl_STENCIL_BACK_FAIL, gl_STENCIL_BACK_FUNC,
        gl_STENCIL_BACK_PASS_DEPTH_FAIL, gl_STENCIL_BACK_PASS_DEPTH_PASS,
        gl_STENCIL_BACK_REF, gl_STENCIL_BACK_VALUE_MASK,
        gl_STENCIL_BACK_WRITEMASK, gl_STENCIL_BITS, gl_STENCIL_BUFFER_BIT,
        gl_STENCIL_CLEAR_VALUE, gl_STENCIL_FAIL, gl_STENCIL_FUNC,
        gl_STENCIL_INDEX, gl_STENCIL_INDEX1, gl_STENCIL_INDEX16,
        gl_STENCIL_INDEX4, gl_STENCIL_INDEX8, gl_STENCIL_PASS_DEPTH_FAIL,
        gl_STENCIL_PASS_DEPTH_PASS, gl_STENCIL_REF, gl_STENCIL_TEST,
        gl_STENCIL_VALUE_MASK, gl_STENCIL_WRITEMASK, gl_STEREO,
        gl_STREAM_COPY, gl_STREAM_DRAW, gl_STREAM_READ, gl_SUBPIXEL_BITS,
        gl_SUBTRACT, gl_T, gl_T2F_C3F_V3F, gl_T2F_C4F_N3F_V3F,
        gl_T2F_C4UB_V3F, gl_T2F_N3F_V3F, gl_T2F_V3F, gl_T4F_C4F_N3F_V4F,
        gl_T4F_V4F, gl_TEXTURE, gl_TEXTURE0, gl_TEXTURE1, gl_TEXTURE10,
        gl_TEXTURE11, gl_TEXTURE12, gl_TEXTURE13, gl_TEXTURE14,
        gl_TEXTURE15, gl_TEXTURE16, gl_TEXTURE17, gl_TEXTURE18,
        gl_TEXTURE19, gl_TEXTURE2, gl_TEXTURE20, gl_TEXTURE21,
        gl_TEXTURE22, gl_TEXTURE23, gl_TEXTURE24, gl_TEXTURE25,
        gl_TEXTURE26, gl_TEXTURE27, gl_TEXTURE28, gl_TEXTURE29,
        gl_TEXTURE3, gl_TEXTURE30, gl_TEXTURE31, gl_TEXTURE4, gl_TEXTURE5,
        gl_TEXTURE6, gl_TEXTURE7, gl_TEXTURE8, gl_TEXTURE9, gl_TEXTURE_1D,
        gl_TEXTURE_1D_ARRAY, gl_TEXTURE_2D, gl_TEXTURE_2D_ARRAY,
        gl_TEXTURE_3D, gl_TEXTURE_ALPHA_SIZE, gl_TEXTURE_ALPHA_TYPE,
        gl_TEXTURE_BASE_LEVEL, gl_TEXTURE_BINDING_1D,
        gl_TEXTURE_BINDING_1D_ARRAY, gl_TEXTURE_BINDING_2D,
        gl_TEXTURE_BINDING_2D_ARRAY, gl_TEXTURE_BINDING_3D,
        gl_TEXTURE_BINDING_CUBE_MAP, gl_TEXTURE_BIT, gl_TEXTURE_BLUE_SIZE,
        gl_TEXTURE_BLUE_TYPE, gl_TEXTURE_BORDER, gl_TEXTURE_BORDER_COLOR,
        gl_TEXTURE_COMPARE_FUNC, gl_TEXTURE_COMPARE_MODE,
        gl_TEXTURE_COMPONENTS, gl_TEXTURE_COMPRESSED,
        gl_TEXTURE_COMPRESSED_IMAGE_SIZE, gl_TEXTURE_COMPRESSION_HINT,
        gl_TEXTURE_COORD_ARRAY, gl_TEXTURE_COORD_ARRAY_BUFFER_BINDING,
        gl_TEXTURE_COORD_ARRAY_POINTER, gl_TEXTURE_COORD_ARRAY_SIZE,
        gl_TEXTURE_COORD_ARRAY_STRIDE, gl_TEXTURE_COORD_ARRAY_TYPE,
        gl_TEXTURE_CUBE_MAP, gl_TEXTURE_CUBE_MAP_NEGATIVE_X,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_Y, gl_TEXTURE_CUBE_MAP_NEGATIVE_Z,
        gl_TEXTURE_CUBE_MAP_POSITIVE_X, gl_TEXTURE_CUBE_MAP_POSITIVE_Y,
        gl_TEXTURE_CUBE_MAP_POSITIVE_Z, gl_TEXTURE_DEPTH,
        gl_TEXTURE_DEPTH_SIZE, gl_TEXTURE_DEPTH_TYPE, gl_TEXTURE_ENV,
        gl_TEXTURE_ENV_COLOR, gl_TEXTURE_ENV_MODE,
        gl_TEXTURE_FILTER_CONTROL, gl_TEXTURE_GEN_MODE, gl_TEXTURE_GEN_Q,
        gl_TEXTURE_GEN_R, gl_TEXTURE_GEN_S, gl_TEXTURE_GEN_T,
        gl_TEXTURE_GREEN_SIZE, gl_TEXTURE_GREEN_TYPE, gl_TEXTURE_HEIGHT,
        gl_TEXTURE_INTENSITY_SIZE, gl_TEXTURE_INTERNAL_FORMAT,
        gl_TEXTURE_LOD_BIAS, gl_TEXTURE_LUMINANCE_SIZE,
        gl_TEXTURE_MAG_FILTER, gl_TEXTURE_MATRIX, gl_TEXTURE_MAX_LEVEL,
        gl_TEXTURE_MAX_LOD, gl_TEXTURE_MIN_FILTER, gl_TEXTURE_MIN_LOD,
        gl_TEXTURE_PRIORITY, gl_TEXTURE_RED_SIZE, gl_TEXTURE_RED_TYPE,
        gl_TEXTURE_RESIDENT, gl_TEXTURE_SHARED_SIZE,
        gl_TEXTURE_STACK_DEPTH, gl_TEXTURE_STENCIL_SIZE, gl_TEXTURE_WIDTH,
        gl_TEXTURE_WRAP_R, gl_TEXTURE_WRAP_S, gl_TEXTURE_WRAP_T,
        gl_TRANSFORM_BIT, gl_TRANSFORM_FEEDBACK_BUFFER,
        gl_TRANSFORM_FEEDBACK_BUFFER_BINDING,
        gl_TRANSFORM_FEEDBACK_BUFFER_MODE,
        gl_TRANSFORM_FEEDBACK_BUFFER_SIZE,
        gl_TRANSFORM_FEEDBACK_BUFFER_START,
        gl_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN,
        gl_TRANSFORM_FEEDBACK_VARYINGS,
        gl_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH,
        gl_TRANSPOSE_COLOR_MATRIX, gl_TRANSPOSE_MODELVIEW_MATRIX,
        gl_TRANSPOSE_PROJECTION_MATRIX, gl_TRANSPOSE_TEXTURE_MATRIX,
        gl_TRIANGLES, gl_TRIANGLE_FAN, gl_TRIANGLE_STRIP, gl_TRUE,
        gl_UNPACK_ALIGNMENT, gl_UNPACK_IMAGE_HEIGHT, gl_UNPACK_LSB_FIRST,
        gl_UNPACK_ROW_LENGTH, gl_UNPACK_SKIP_IMAGES, gl_UNPACK_SKIP_PIXELS,
        gl_UNPACK_SKIP_ROWS, gl_UNPACK_SWAP_BYTES, gl_UNSIGNED_BYTE,
        gl_UNSIGNED_BYTE_2_3_3_REV, gl_UNSIGNED_BYTE_3_3_2,
        gl_UNSIGNED_INT, gl_UNSIGNED_INT_10F_11F_11F_REV,
        gl_UNSIGNED_INT_10_10_10_2, gl_UNSIGNED_INT_24_8,
        gl_UNSIGNED_INT_2_10_10_10_REV, gl_UNSIGNED_INT_5_9_9_9_REV,
        gl_UNSIGNED_INT_8_8_8_8, gl_UNSIGNED_INT_8_8_8_8_REV,
        gl_UNSIGNED_INT_SAMPLER_1D, gl_UNSIGNED_INT_SAMPLER_1D_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_2D, gl_UNSIGNED_INT_SAMPLER_2D_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_3D, gl_UNSIGNED_INT_SAMPLER_CUBE,
        gl_UNSIGNED_INT_VEC2, gl_UNSIGNED_INT_VEC3, gl_UNSIGNED_INT_VEC4,
        gl_UNSIGNED_NORMALIZED, gl_UNSIGNED_SHORT,
        gl_UNSIGNED_SHORT_1_5_5_5_REV, gl_UNSIGNED_SHORT_4_4_4_4,
        gl_UNSIGNED_SHORT_4_4_4_4_REV, gl_UNSIGNED_SHORT_5_5_5_1,
        gl_UNSIGNED_SHORT_5_6_5, gl_UNSIGNED_SHORT_5_6_5_REV,
        gl_UPPER_LEFT, gl_V2F, gl_V3F, gl_VALIDATE_STATUS, gl_VENDOR,
        gl_VERSION, gl_VERTEX_ARRAY, gl_VERTEX_ARRAY_BINDING,
        gl_VERTEX_ARRAY_BUFFER_BINDING, gl_VERTEX_ARRAY_POINTER,
        gl_VERTEX_ARRAY_SIZE, gl_VERTEX_ARRAY_STRIDE, gl_VERTEX_ARRAY_TYPE,
        gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ATTRIB_ARRAY_ENABLED, gl_VERTEX_ATTRIB_ARRAY_INTEGER,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED, gl_VERTEX_ATTRIB_ARRAY_POINTER,
        gl_VERTEX_ATTRIB_ARRAY_SIZE, gl_VERTEX_ATTRIB_ARRAY_STRIDE,
        gl_VERTEX_ATTRIB_ARRAY_TYPE, gl_VERTEX_PROGRAM_POINT_SIZE,
        gl_VERTEX_PROGRAM_TWO_SIDE, gl_VERTEX_SHADER, gl_VIEWPORT,
        gl_VIEWPORT_BIT, gl_WEIGHT_ARRAY_BUFFER_BINDING, gl_WRITE_ONLY,
        gl_XOR, gl_ZERO, gl_ZOOM_X, gl_ZOOM_Y, glAccum, glActiveTexture,
        glAlphaFunc, glAreTexturesResident, glArrayElement, glAttachShader,
        glBegin, glBeginConditionalRender, glBeginQuery,
        glBeginTransformFeedback, glBindAttribLocation, glBindBuffer,
        glBindBufferBase, glBindBufferRange, glBindFragDataLocation,
        glBindFramebuffer, glBindRenderbuffer, glBindTexture,
        glBindVertexArray, glBitmap, glBlendColor, glBlendEquation,
        glBlendEquationSeparate, glBlendFunc, glBlendFuncSeparate,
        glBlitFramebuffer, glBufferData, glBufferSubData, glCallList,
        glCallLists, glCheckFramebufferStatus, glClampColor, glClear,
        glClearAccum, glClearBufferfi, glClearBufferfv, glClearBufferiv,
        glClearBufferuiv, glClearColor, glClearDepth, glClearIndex,
        glClearStencil, glClientActiveTexture, glClipPlane, glColor3b,
        glColor3bv, glColor3d, glColor3dv, glColor3f, glColor3fv,
        glColor3i, glColor3iv, glColor3s, glColor3sv, glColor3ub,
        glColor3ubv, glColor3ui, glColor3uiv, glColor3us, glColor3usv,
        glColor4b, glColor4bv, glColor4d, glColor4dv, glColor4f,
        glColor4fv, glColor4i, glColor4iv, glColor4s, glColor4sv,
        glColor4ub, glColor4ubv, glColor4ui, glColor4uiv, glColor4us,
        glColor4usv, glColorMask, glColorMaski, glColorMaterial,
        glColorPointer, glCompileShader, glCompressedTexImage1D,
        glCompressedTexImage2D, glCompressedTexImage3D,
        glCompressedTexSubImage1D, glCompressedTexSubImage2D,
        glCompressedTexSubImage3D, glCopyPixels, glCopyTexImage1D,
        glCopyTexImage2D, glCopyTexSubImage1D, glCopyTexSubImage2D,
        glCopyTexSubImage3D, glCreateProgram, glCreateShader, glCullFace,
        glDeleteBuffers, glDeleteFramebuffers, glDeleteLists,
        glDeleteProgram, glDeleteQueries, glDeleteRenderbuffers,
        glDeleteShader, glDeleteTextures, glDeleteVertexArrays,
        glDepthFunc, glDepthMask, glDepthRange, glDetachShader, glDisable,
        glDisableClientState, glDisableVertexAttribArray, glDisablei,
        glDrawArrays, glDrawBuffer, glDrawBuffers, glDrawElements,
        glDrawPixels, glDrawRangeElements, glEdgeFlag, glEdgeFlagPointer,
        glEdgeFlagv, glEnable, glEnableClientState,
        glEnableVertexAttribArray, glEnablei, glEnd,
        glEndConditionalRender, glEndList, glEndQuery,
        glEndTransformFeedback, glEvalCoord1d, glEvalCoord1dv,
        glEvalCoord1f, glEvalCoord1fv, glEvalCoord2d, glEvalCoord2dv,
        glEvalCoord2f, glEvalCoord2fv, glEvalMesh1, glEvalMesh2,
        glEvalPoint1, glEvalPoint2, glFeedbackBuffer, glFinish, glFlush,
        glFlushMappedBufferRange, glFogCoordPointer, glFogCoordd,
        glFogCoorddv, glFogCoordf, glFogCoordfv, glFogf, glFogfv, glFogi,
        glFogiv, glFramebufferRenderbuffer, glFramebufferTexture1D,
        glFramebufferTexture2D, glFramebufferTexture3D,
        glFramebufferTextureLayer, glFrontFace, glFrustum, glGenBuffers,
        glGenFramebuffers, glGenLists, glGenQueries, glGenRenderbuffers,
        glGenTextures, glGenVertexArrays, glGenerateMipmap,
        glGetActiveAttrib, glGetActiveUniform, glGetAttachedShaders,
        glGetAttribLocation, glGetBooleani_v, glGetBooleanv,
        glGetBufferParameteriv, glGetBufferPointerv, glGetBufferSubData,
        glGetClipPlane, glGetCompressedTexImage, glGetDoublev, glGetError,
        glGetFloatv, glGetFragDataLocation,
        glGetFramebufferAttachmentParameteriv, glGetIntegeri_v,
        glGetIntegerv, glGetLightfv, glGetLightiv, glGetMapdv, glGetMapfv,
        glGetMapiv, glGetMaterialfv, glGetMaterialiv, glGetPixelMapfv,
        glGetPixelMapuiv, glGetPixelMapusv, glGetPointerv,
        glGetPolygonStipple, glGetProgramInfoLog, glGetProgramiv,
        glGetQueryObjectiv, glGetQueryObjectuiv, glGetQueryiv,
        glGetRenderbufferParameteriv, glGetShaderInfoLog,
        glGetShaderSource, glGetShaderiv, glGetString, glGetStringi,
        glGetTexEnvfv, glGetTexEnviv, glGetTexGendv, glGetTexGenfv,
        glGetTexGeniv, glGetTexImage, glGetTexLevelParameterfv,
        glGetTexLevelParameteriv, glGetTexParameterIiv,
        glGetTexParameterIuiv, glGetTexParameterfv, glGetTexParameteriv,
        glGetTransformFeedbackVarying, glGetUniformLocation,
        glGetUniformfv, glGetUniformiv, glGetUniformuiv,
        glGetVertexAttribIiv, glGetVertexAttribIuiv,
        glGetVertexAttribPointerv, glGetVertexAttribdv,
        glGetVertexAttribfv, glGetVertexAttribiv, glHint, glIndexMask,
        glIndexPointer, glIndexd, glIndexdv, glIndexf, glIndexfv, glIndexi,
        glIndexiv, glIndexs, glIndexsv, glIndexub, glIndexubv, glInitNames,
        glInterleavedArrays, glIsBuffer, glIsEnabled, glIsEnabledi,
        glIsFramebuffer, glIsList, glIsProgram, glIsQuery,
        glIsRenderbuffer, glIsShader, glIsTexture, glIsVertexArray,
        glLightModelf, glLightModelfv, glLightModeli, glLightModeliv,
        glLightf, glLightfv, glLighti, glLightiv, glLineStipple,
        glLineWidth, glLinkProgram, glListBase, glLoadIdentity,
        glLoadMatrixd, glLoadMatrixf, glLoadName, glLoadTransposeMatrixd,
        glLoadTransposeMatrixf, glLogicOp, glMap1d, glMap1f, glMap2d,
        glMap2f, glMapBuffer, glMapBufferRange, glMapGrid1d, glMapGrid1f,
        glMapGrid2d, glMapGrid2f, glMaterialf, glMaterialfv, glMateriali,
        glMaterialiv, glMatrixMode, glMultMatrixd, glMultMatrixf,
        glMultTransposeMatrixd, glMultTransposeMatrixf, glMultiDrawArrays,
        glMultiDrawElements, glMultiTexCoord1d, glMultiTexCoord1dv,
        glMultiTexCoord1f, glMultiTexCoord1fv, glMultiTexCoord1i,
        glMultiTexCoord1iv, glMultiTexCoord1s, glMultiTexCoord1sv,
        glMultiTexCoord2d, glMultiTexCoord2dv, glMultiTexCoord2f,
        glMultiTexCoord2fv, glMultiTexCoord2i, glMultiTexCoord2iv,
        glMultiTexCoord2s, glMultiTexCoord2sv, glMultiTexCoord3d,
        glMultiTexCoord3dv, glMultiTexCoord3f, glMultiTexCoord3fv,
        glMultiTexCoord3i, glMultiTexCoord3iv, glMultiTexCoord3s,
        glMultiTexCoord3sv, glMultiTexCoord4d, glMultiTexCoord4dv,
        glMultiTexCoord4f, glMultiTexCoord4fv, glMultiTexCoord4i,
        glMultiTexCoord4iv, glMultiTexCoord4s, glMultiTexCoord4sv,
        glNewList, glNormal3b, glNormal3bv, glNormal3d, glNormal3dv,
        glNormal3f, glNormal3fv, glNormal3i, glNormal3iv, glNormal3s,
        glNormal3sv, glNormalPointer, glOrtho, glPassThrough, glPixelMapfv,
        glPixelMapuiv, glPixelMapusv, glPixelStoref, glPixelStorei,
        glPixelTransferf, glPixelTransferi, glPixelZoom, glPointParameterf,
        glPointParameterfv, glPointParameteri, glPointParameteriv,
        glPointSize, glPolygonMode, glPolygonOffset, glPolygonStipple,
        glPopAttrib, glPopClientAttrib, glPopMatrix, glPopName,
        glPrioritizeTextures, glPushAttrib, glPushClientAttrib,
        glPushMatrix, glPushName, glRasterPos2d, glRasterPos2dv,
        glRasterPos2f, glRasterPos2fv, glRasterPos2i, glRasterPos2iv,
        glRasterPos2s, glRasterPos2sv, glRasterPos3d, glRasterPos3dv,
        glRasterPos3f, glRasterPos3fv, glRasterPos3i, glRasterPos3iv,
        glRasterPos3s, glRasterPos3sv, glRasterPos4d, glRasterPos4dv,
        glRasterPos4f, glRasterPos4fv, glRasterPos4i, glRasterPos4iv,
        glRasterPos4s, glRasterPos4sv, glReadBuffer, glReadPixels, glRectd,
        glRectdv, glRectf, glRectfv, glRecti, glRectiv, glRects, glRectsv,
        glRenderMode, glRenderbufferStorage,
        glRenderbufferStorageMultisample, glRotated, glRotatef,
        glSampleCoverage, glScaled, glScalef, glScissor,
        glSecondaryColor3b, glSecondaryColor3bv, glSecondaryColor3d,
        glSecondaryColor3dv, glSecondaryColor3f, glSecondaryColor3fv,
        glSecondaryColor3i, glSecondaryColor3iv, glSecondaryColor3s,
        glSecondaryColor3sv, glSecondaryColor3ub, glSecondaryColor3ubv,
        glSecondaryColor3ui, glSecondaryColor3uiv, glSecondaryColor3us,
        glSecondaryColor3usv, glSecondaryColorPointer, glSelectBuffer,
        glShadeModel, glShaderSource, glStencilFunc, glStencilFuncSeparate,
        glStencilMask, glStencilMaskSeparate, glStencilOp,
        glStencilOpSeparate, glTexCoord1d, glTexCoord1dv, glTexCoord1f,
        glTexCoord1fv, glTexCoord1i, glTexCoord1iv, glTexCoord1s,
        glTexCoord1sv, glTexCoord2d, glTexCoord2dv, glTexCoord2f,
        glTexCoord2fv, glTexCoord2i, glTexCoord2iv, glTexCoord2s,
        glTexCoord2sv, glTexCoord3d, glTexCoord3dv, glTexCoord3f,
        glTexCoord3fv, glTexCoord3i, glTexCoord3iv, glTexCoord3s,
        glTexCoord3sv, glTexCoord4d, glTexCoord4dv, glTexCoord4f,
        glTexCoord4fv, glTexCoord4i, glTexCoord4iv, glTexCoord4s,
        glTexCoord4sv, glTexCoordPointer, glTexEnvf, glTexEnvfv, glTexEnvi,
        glTexEnviv, glTexGend, glTexGendv, glTexGenf, glTexGenfv,
        glTexGeni, glTexGeniv, glTexImage1D, glTexImage2D, glTexImage3D,
        glTexParameterIiv, glTexParameterIuiv, glTexParameterf,
        glTexParameterfv, glTexParameteri, glTexParameteriv,
        glTexSubImage1D, glTexSubImage2D, glTexSubImage3D,
        glTransformFeedbackVaryings, glTranslated, glTranslatef,
        glUniform1f, glUniform1fv, glUniform1i, glUniform1iv, glUniform1ui,
        glUniform1uiv, glUniform2f, glUniform2fv, glUniform2i,
        glUniform2iv, glUniform2ui, glUniform2uiv, glUniform3f,
        glUniform3fv, glUniform3i, glUniform3iv, glUniform3ui,
        glUniform3uiv, glUniform4f, glUniform4fv, glUniform4i,
        glUniform4iv, glUniform4ui, glUniform4uiv, glUniformMatrix2fv,
        glUniformMatrix2x3fv, glUniformMatrix2x4fv, glUniformMatrix3fv,
        glUniformMatrix3x2fv, glUniformMatrix3x4fv, glUniformMatrix4fv,
        glUniformMatrix4x2fv, glUniformMatrix4x3fv, glUnmapBuffer,
        glUseProgram, glValidateProgram, glVertex2d, glVertex2dv,
        glVertex2f, glVertex2fv, glVertex2i, glVertex2iv, glVertex2s,
        glVertex2sv, glVertex3d, glVertex3dv, glVertex3f, glVertex3fv,
        glVertex3i, glVertex3iv, glVertex3s, glVertex3sv, glVertex4d,
        glVertex4dv, glVertex4f, glVertex4fv, glVertex4i, glVertex4iv,
        glVertex4s, glVertex4sv, glVertexAttrib1d, glVertexAttrib1dv,
        glVertexAttrib1f, glVertexAttrib1fv, glVertexAttrib1s,
        glVertexAttrib1sv, glVertexAttrib2d, glVertexAttrib2dv,
        glVertexAttrib2f, glVertexAttrib2fv, glVertexAttrib2s,
        glVertexAttrib2sv, glVertexAttrib3d, glVertexAttrib3dv,
        glVertexAttrib3f, glVertexAttrib3fv, glVertexAttrib3s,
        glVertexAttrib3sv, glVertexAttrib4Nbv, glVertexAttrib4Niv,
        glVertexAttrib4Nsv, glVertexAttrib4Nub, glVertexAttrib4Nubv,
        glVertexAttrib4Nuiv, glVertexAttrib4Nusv, glVertexAttrib4bv,
        glVertexAttrib4d, glVertexAttrib4dv, glVertexAttrib4f,
        glVertexAttrib4fv, glVertexAttrib4iv, glVertexAttrib4s,
        glVertexAttrib4sv, glVertexAttrib4ubv, glVertexAttrib4uiv,
        glVertexAttrib4usv, glVertexAttribI1i, glVertexAttribI1iv,
        glVertexAttribI1ui, glVertexAttribI1uiv, glVertexAttribI2i,
        glVertexAttribI2iv, glVertexAttribI2ui, glVertexAttribI2uiv,
        glVertexAttribI3i, glVertexAttribI3iv, glVertexAttribI3ui,
        glVertexAttribI3uiv, glVertexAttribI4bv, glVertexAttribI4i,
        glVertexAttribI4iv, glVertexAttribI4sv, glVertexAttribI4ubv,
        glVertexAttribI4ui, glVertexAttribI4uiv, glVertexAttribI4usv,
        glVertexAttribIPointer, glVertexAttribPointer, glVertexPointer,
        glViewport, glWindowPos2d, glWindowPos2dv, glWindowPos2f,
        glWindowPos2fv, glWindowPos2i, glWindowPos2iv, glWindowPos2s,
        glWindowPos2sv, glWindowPos3d, glWindowPos3dv, glWindowPos3f,
        glWindowPos3fv, glWindowPos3i, glWindowPos3iv, glWindowPos3s,
        glWindowPos3sv)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Core.Core10
       (glAccum, glAlphaFunc, glBegin, glBitmap, glBlendFunc, glCallList,
        glCallLists, glClear, glClearAccum, glClearColor, glClearDepth,
        glClearIndex, glClearStencil, glClipPlane, glColor3b, glColor3bv,
        glColor3d, glColor3dv, glColor3f, glColor3fv, glColor3i,
        glColor3iv, glColor3s, glColor3sv, glColor3ub, glColor3ubv,
        glColor3ui, glColor3uiv, glColor3us, glColor3usv, glColor4b,
        glColor4bv, glColor4d, glColor4dv, glColor4f, glColor4fv,
        glColor4i, glColor4iv, glColor4s, glColor4sv, glColor4ub,
        glColor4ubv, glColor4ui, glColor4uiv, glColor4us, glColor4usv,
        glColorMask, glColorMaterial, glCopyPixels, glCullFace,
        glDeleteLists, glDepthFunc, glDepthMask, glDepthRange, glDisable,
        glDrawBuffer, glDrawPixels, glEdgeFlag, glEdgeFlagv, glEnable,
        glEnd, glEndList, glEvalCoord1d, glEvalCoord1dv, glEvalCoord1f,
        glEvalCoord1fv, glEvalCoord2d, glEvalCoord2dv, glEvalCoord2f,
        glEvalCoord2fv, glEvalMesh1, glEvalMesh2, glEvalPoint1,
        glEvalPoint2, glFeedbackBuffer, glFinish, glFlush, glFogf, glFogfv,
        glFogi, glFogiv, glFrontFace, glFrustum, glGenLists, glGetBooleanv,
        glGetClipPlane, glGetDoublev, glGetError, glGetFloatv,
        glGetIntegerv, glGetLightfv, glGetLightiv, glGetMapdv, glGetMapfv,
        glGetMapiv, glGetMaterialfv, glGetMaterialiv, glGetPixelMapfv,
        glGetPixelMapuiv, glGetPixelMapusv, glGetPolygonStipple,
        glGetString, glGetTexEnvfv, glGetTexEnviv, glGetTexGendv,
        glGetTexGenfv, glGetTexGeniv, glGetTexImage,
        glGetTexLevelParameterfv, glGetTexLevelParameteriv,
        glGetTexParameterfv, glGetTexParameteriv, glHint, glIndexMask,
        glIndexd, glIndexdv, glIndexf, glIndexfv, glIndexi, glIndexiv,
        glIndexs, glIndexsv, glInitNames, glIsEnabled, glIsList,
        glLightModelf, glLightModelfv, glLightModeli, glLightModeliv,
        glLightf, glLightfv, glLighti, glLightiv, glLineStipple,
        glLineWidth, glListBase, glLoadIdentity, glLoadMatrixd,
        glLoadMatrixf, glLoadName, glLogicOp, glMap1d, glMap1f, glMap2d,
        glMap2f, glMapGrid1d, glMapGrid1f, glMapGrid2d, glMapGrid2f,
        glMaterialf, glMaterialfv, glMateriali, glMaterialiv, glMatrixMode,
        glMultMatrixd, glMultMatrixf, glNewList, glNormal3b, glNormal3bv,
        glNormal3d, glNormal3dv, glNormal3f, glNormal3fv, glNormal3i,
        glNormal3iv, glNormal3s, glNormal3sv, glOrtho, glPassThrough,
        glPixelMapfv, glPixelMapuiv, glPixelMapusv, glPixelStoref,
        glPixelStorei, glPixelTransferf, glPixelTransferi, glPixelZoom,
        glPointSize, glPolygonMode, glPolygonStipple, glPopAttrib,
        glPopMatrix, glPopName, glPushAttrib, glPushMatrix, glPushName,
        glRasterPos2d, glRasterPos2dv, glRasterPos2f, glRasterPos2fv,
        glRasterPos2i, glRasterPos2iv, glRasterPos2s, glRasterPos2sv,
        glRasterPos3d, glRasterPos3dv, glRasterPos3f, glRasterPos3fv,
        glRasterPos3i, glRasterPos3iv, glRasterPos3s, glRasterPos3sv,
        glRasterPos4d, glRasterPos4dv, glRasterPos4f, glRasterPos4fv,
        glRasterPos4i, glRasterPos4iv, glRasterPos4s, glRasterPos4sv,
        glReadBuffer, glReadPixels, glRectd, glRectdv, glRectf, glRectfv,
        glRecti, glRectiv, glRects, glRectsv, glRenderMode, glRotated,
        glRotatef, glScaled, glScalef, glScissor, glSelectBuffer,
        glShadeModel, glStencilFunc, glStencilMask, glStencilOp,
        glTexCoord1d, glTexCoord1dv, glTexCoord1f, glTexCoord1fv,
        glTexCoord1i, glTexCoord1iv, glTexCoord1s, glTexCoord1sv,
        glTexCoord2d, glTexCoord2dv, glTexCoord2f, glTexCoord2fv,
        glTexCoord2i, glTexCoord2iv, glTexCoord2s, glTexCoord2sv,
        glTexCoord3d, glTexCoord3dv, glTexCoord3f, glTexCoord3fv,
        glTexCoord3i, glTexCoord3iv, glTexCoord3s, glTexCoord3sv,
        glTexCoord4d, glTexCoord4dv, glTexCoord4f, glTexCoord4fv,
        glTexCoord4i, glTexCoord4iv, glTexCoord4s, glTexCoord4sv,
        glTexEnvf, glTexEnvfv, glTexEnvi, glTexEnviv, glTexGend,
        glTexGendv, glTexGenf, glTexGenfv, glTexGeni, glTexGeniv,
        glTexImage1D, glTexImage2D, glTexParameterf, glTexParameterfv,
        glTexParameteri, glTexParameteriv, glTranslated, glTranslatef,
        glVertex2d, glVertex2dv, glVertex2f, glVertex2fv, glVertex2i,
        glVertex2iv, glVertex2s, glVertex2sv, glVertex3d, glVertex3dv,
        glVertex3f, glVertex3fv, glVertex3i, glVertex3iv, glVertex3s,
        glVertex3sv, glVertex4d, glVertex4dv, glVertex4f, glVertex4fv,
        glVertex4i, glVertex4iv, glVertex4s, glVertex4sv, glViewport)
import Graphics.Rendering.OpenGL.Raw.Core.Core11
       (glAreTexturesResident, glArrayElement, glBindTexture,
        glColorPointer, glCopyTexImage1D, glCopyTexImage2D,
        glCopyTexSubImage1D, glCopyTexSubImage2D, glDeleteTextures,
        glDisableClientState, glDrawArrays, glDrawElements,
        glEdgeFlagPointer, glEnableClientState, glGenTextures,
        glGetPointerv, glIndexPointer, glIndexub, glIndexubv,
        glInterleavedArrays, glIsTexture, glNormalPointer, glPolygonOffset,
        glPopClientAttrib, glPrioritizeTextures, glPushClientAttrib,
        glTexCoordPointer, glTexSubImage1D, glTexSubImage2D,
        glVertexPointer, gl_2D, gl_2_BYTES, gl_3D, gl_3D_COLOR,
        gl_3D_COLOR_TEXTURE, gl_3_BYTES, gl_4D_COLOR_TEXTURE, gl_4_BYTES,
        gl_ACCUM, gl_ACCUM_ALPHA_BITS, gl_ACCUM_BLUE_BITS,
        gl_ACCUM_BUFFER_BIT, gl_ACCUM_CLEAR_VALUE, gl_ACCUM_GREEN_BITS,
        gl_ACCUM_RED_BITS, gl_ADD, gl_ALL_ATTRIB_BITS, gl_ALPHA,
        gl_ALPHA12, gl_ALPHA16, gl_ALPHA4, gl_ALPHA8, gl_ALPHA_BIAS,
        gl_ALPHA_BITS, gl_ALPHA_SCALE, gl_ALPHA_TEST, gl_ALPHA_TEST_FUNC,
        gl_ALPHA_TEST_REF, gl_ALWAYS, gl_AMBIENT, gl_AMBIENT_AND_DIFFUSE,
        gl_AND, gl_AND_INVERTED, gl_AND_REVERSE, gl_ATTRIB_STACK_DEPTH,
        gl_AUTO_NORMAL, gl_AUX0, gl_AUX1, gl_AUX2, gl_AUX3, gl_AUX_BUFFERS,
        gl_BACK, gl_BACK_LEFT, gl_BACK_RIGHT, gl_BITMAP, gl_BITMAP_TOKEN,
        gl_BLEND, gl_BLEND_DST, gl_BLEND_SRC, gl_BLUE, gl_BLUE_BIAS,
        gl_BLUE_BITS, gl_BLUE_SCALE, gl_BYTE, gl_C3F_V3F, gl_C4F_N3F_V3F,
        gl_C4UB_V2F, gl_C4UB_V3F, gl_CCW, gl_CLAMP, gl_CLEAR,
        gl_CLIENT_ALL_ATTRIB_BITS, gl_CLIENT_ATTRIB_STACK_DEPTH,
        gl_CLIENT_PIXEL_STORE_BIT, gl_CLIENT_VERTEX_ARRAY_BIT,
        gl_CLIP_PLANE0, gl_CLIP_PLANE1, gl_CLIP_PLANE2, gl_CLIP_PLANE3,
        gl_CLIP_PLANE4, gl_CLIP_PLANE5, gl_COEFF, gl_COLOR, gl_COLOR_ARRAY,
        gl_COLOR_ARRAY_POINTER, gl_COLOR_ARRAY_SIZE, gl_COLOR_ARRAY_STRIDE,
        gl_COLOR_ARRAY_TYPE, gl_COLOR_BUFFER_BIT, gl_COLOR_CLEAR_VALUE,
        gl_COLOR_INDEX, gl_COLOR_INDEXES, gl_COLOR_LOGIC_OP,
        gl_COLOR_MATERIAL, gl_COLOR_MATERIAL_FACE,
        gl_COLOR_MATERIAL_PARAMETER, gl_COLOR_WRITEMASK, gl_COMPILE,
        gl_COMPILE_AND_EXECUTE, gl_CONSTANT_ATTENUATION, gl_COPY,
        gl_COPY_INVERTED, gl_COPY_PIXEL_TOKEN, gl_CULL_FACE,
        gl_CULL_FACE_MODE, gl_CURRENT_BIT, gl_CURRENT_COLOR,
        gl_CURRENT_INDEX, gl_CURRENT_NORMAL, gl_CURRENT_RASTER_COLOR,
        gl_CURRENT_RASTER_DISTANCE, gl_CURRENT_RASTER_INDEX,
        gl_CURRENT_RASTER_POSITION, gl_CURRENT_RASTER_POSITION_VALID,
        gl_CURRENT_RASTER_TEXTURE_COORDS, gl_CURRENT_TEXTURE_COORDS, gl_CW,
        gl_DECAL, gl_DECR, gl_DEPTH, gl_DEPTH_BIAS, gl_DEPTH_BITS,
        gl_DEPTH_BUFFER_BIT, gl_DEPTH_CLEAR_VALUE, gl_DEPTH_COMPONENT,
        gl_DEPTH_FUNC, gl_DEPTH_RANGE, gl_DEPTH_SCALE, gl_DEPTH_TEST,
        gl_DEPTH_WRITEMASK, gl_DIFFUSE, gl_DITHER, gl_DOMAIN, gl_DONT_CARE,
        gl_DOUBLE, gl_DOUBLEBUFFER, gl_DRAW_BUFFER, gl_DRAW_PIXEL_TOKEN,
        gl_DST_ALPHA, gl_DST_COLOR, gl_EDGE_FLAG, gl_EDGE_FLAG_ARRAY,
        gl_EDGE_FLAG_ARRAY_POINTER, gl_EDGE_FLAG_ARRAY_STRIDE, gl_EMISSION,
        gl_ENABLE_BIT, gl_EQUAL, gl_EQUIV, gl_EVAL_BIT, gl_EXP, gl_EXP2,
        gl_EXTENSIONS, gl_EYE_LINEAR, gl_EYE_PLANE, gl_FALSE, gl_FASTEST,
        gl_FEEDBACK, gl_FEEDBACK_BUFFER_POINTER, gl_FEEDBACK_BUFFER_SIZE,
        gl_FEEDBACK_BUFFER_TYPE, gl_FILL, gl_FLAT, gl_FLOAT, gl_FOG,
        gl_FOG_BIT, gl_FOG_COLOR, gl_FOG_DENSITY, gl_FOG_END, gl_FOG_HINT,
        gl_FOG_INDEX, gl_FOG_MODE, gl_FOG_START, gl_FRONT,
        gl_FRONT_AND_BACK, gl_FRONT_FACE, gl_FRONT_LEFT, gl_FRONT_RIGHT,
        gl_GEQUAL, gl_GREATER, gl_GREEN, gl_GREEN_BIAS, gl_GREEN_BITS,
        gl_GREEN_SCALE, gl_HINT_BIT, gl_INCR, gl_INDEX_ARRAY,
        gl_INDEX_ARRAY_POINTER, gl_INDEX_ARRAY_STRIDE, gl_INDEX_ARRAY_TYPE,
        gl_INDEX_BITS, gl_INDEX_CLEAR_VALUE, gl_INDEX_LOGIC_OP,
        gl_INDEX_MODE, gl_INDEX_OFFSET, gl_INDEX_SHIFT, gl_INDEX_WRITEMASK,
        gl_INT, gl_INTENSITY, gl_INTENSITY12, gl_INTENSITY16,
        gl_INTENSITY4, gl_INTENSITY8, gl_INVALID_ENUM,
        gl_INVALID_OPERATION, gl_INVALID_VALUE, gl_INVERT, gl_KEEP,
        gl_LEFT, gl_LEQUAL, gl_LESS, gl_LIGHT0, gl_LIGHT1, gl_LIGHT2,
        gl_LIGHT3, gl_LIGHT4, gl_LIGHT5, gl_LIGHT6, gl_LIGHT7, gl_LIGHTING,
        gl_LIGHTING_BIT, gl_LIGHT_MODEL_AMBIENT,
        gl_LIGHT_MODEL_LOCAL_VIEWER, gl_LIGHT_MODEL_TWO_SIDE, gl_LINE,
        gl_LINEAR, gl_LINEAR_ATTENUATION, gl_LINEAR_MIPMAP_LINEAR,
        gl_LINEAR_MIPMAP_NEAREST, gl_LINES, gl_LINE_BIT, gl_LINE_LOOP,
        gl_LINE_RESET_TOKEN, gl_LINE_SMOOTH, gl_LINE_SMOOTH_HINT,
        gl_LINE_STIPPLE, gl_LINE_STIPPLE_PATTERN, gl_LINE_STIPPLE_REPEAT,
        gl_LINE_STRIP, gl_LINE_TOKEN, gl_LINE_WIDTH,
        gl_LINE_WIDTH_GRANULARITY, gl_LINE_WIDTH_RANGE, gl_LIST_BASE,
        gl_LIST_BIT, gl_LIST_INDEX, gl_LIST_MODE, gl_LOAD, gl_LOGIC_OP,
        gl_LOGIC_OP_MODE, gl_LUMINANCE, gl_LUMINANCE12,
        gl_LUMINANCE12_ALPHA12, gl_LUMINANCE12_ALPHA4, gl_LUMINANCE16,
        gl_LUMINANCE16_ALPHA16, gl_LUMINANCE4, gl_LUMINANCE4_ALPHA4,
        gl_LUMINANCE6_ALPHA2, gl_LUMINANCE8, gl_LUMINANCE8_ALPHA8,
        gl_LUMINANCE_ALPHA, gl_MAP1_COLOR_4, gl_MAP1_GRID_DOMAIN,
        gl_MAP1_GRID_SEGMENTS, gl_MAP1_INDEX, gl_MAP1_NORMAL,
        gl_MAP1_TEXTURE_COORD_1, gl_MAP1_TEXTURE_COORD_2,
        gl_MAP1_TEXTURE_COORD_3, gl_MAP1_TEXTURE_COORD_4, gl_MAP1_VERTEX_3,
        gl_MAP1_VERTEX_4, gl_MAP2_COLOR_4, gl_MAP2_GRID_DOMAIN,
        gl_MAP2_GRID_SEGMENTS, gl_MAP2_INDEX, gl_MAP2_NORMAL,
        gl_MAP2_TEXTURE_COORD_1, gl_MAP2_TEXTURE_COORD_2,
        gl_MAP2_TEXTURE_COORD_3, gl_MAP2_TEXTURE_COORD_4, gl_MAP2_VERTEX_3,
        gl_MAP2_VERTEX_4, gl_MAP_COLOR, gl_MAP_STENCIL, gl_MATRIX_MODE,
        gl_MAX_ATTRIB_STACK_DEPTH, gl_MAX_CLIENT_ATTRIB_STACK_DEPTH,
        gl_MAX_CLIP_PLANES, gl_MAX_EVAL_ORDER, gl_MAX_LIGHTS,
        gl_MAX_LIST_NESTING, gl_MAX_MODELVIEW_STACK_DEPTH,
        gl_MAX_NAME_STACK_DEPTH, gl_MAX_PIXEL_MAP_TABLE,
        gl_MAX_PROJECTION_STACK_DEPTH, gl_MAX_TEXTURE_SIZE,
        gl_MAX_TEXTURE_STACK_DEPTH, gl_MAX_VIEWPORT_DIMS, gl_MODELVIEW,
        gl_MODELVIEW_MATRIX, gl_MODELVIEW_STACK_DEPTH, gl_MODULATE,
        gl_MULT, gl_N3F_V3F, gl_NAME_STACK_DEPTH, gl_NAND, gl_NEAREST,
        gl_NEAREST_MIPMAP_LINEAR, gl_NEAREST_MIPMAP_NEAREST, gl_NEVER,
        gl_NICEST, gl_NONE, gl_NOOP, gl_NOR, gl_NORMALIZE, gl_NORMAL_ARRAY,
        gl_NORMAL_ARRAY_POINTER, gl_NORMAL_ARRAY_STRIDE,
        gl_NORMAL_ARRAY_TYPE, gl_NOTEQUAL, gl_NO_ERROR, gl_OBJECT_LINEAR,
        gl_OBJECT_PLANE, gl_ONE, gl_ONE_MINUS_DST_ALPHA,
        gl_ONE_MINUS_DST_COLOR, gl_ONE_MINUS_SRC_ALPHA,
        gl_ONE_MINUS_SRC_COLOR, gl_OR, gl_ORDER, gl_OR_INVERTED,
        gl_OR_REVERSE, gl_OUT_OF_MEMORY, gl_PACK_ALIGNMENT,
        gl_PACK_LSB_FIRST, gl_PACK_ROW_LENGTH, gl_PACK_SKIP_PIXELS,
        gl_PACK_SKIP_ROWS, gl_PACK_SWAP_BYTES, gl_PASS_THROUGH_TOKEN,
        gl_PERSPECTIVE_CORRECTION_HINT, gl_PIXEL_MAP_A_TO_A,
        gl_PIXEL_MAP_A_TO_A_SIZE, gl_PIXEL_MAP_B_TO_B,
        gl_PIXEL_MAP_B_TO_B_SIZE, gl_PIXEL_MAP_G_TO_G,
        gl_PIXEL_MAP_G_TO_G_SIZE, gl_PIXEL_MAP_I_TO_A,
        gl_PIXEL_MAP_I_TO_A_SIZE, gl_PIXEL_MAP_I_TO_B,
        gl_PIXEL_MAP_I_TO_B_SIZE, gl_PIXEL_MAP_I_TO_G,
        gl_PIXEL_MAP_I_TO_G_SIZE, gl_PIXEL_MAP_I_TO_I,
        gl_PIXEL_MAP_I_TO_I_SIZE, gl_PIXEL_MAP_I_TO_R,
        gl_PIXEL_MAP_I_TO_R_SIZE, gl_PIXEL_MAP_R_TO_R,
        gl_PIXEL_MAP_R_TO_R_SIZE, gl_PIXEL_MAP_S_TO_S,
        gl_PIXEL_MAP_S_TO_S_SIZE, gl_PIXEL_MODE_BIT, gl_POINT, gl_POINTS,
        gl_POINT_BIT, gl_POINT_SIZE, gl_POINT_SIZE_GRANULARITY,
        gl_POINT_SIZE_RANGE, gl_POINT_SMOOTH, gl_POINT_SMOOTH_HINT,
        gl_POINT_TOKEN, gl_POLYGON, gl_POLYGON_BIT, gl_POLYGON_MODE,
        gl_POLYGON_OFFSET_FACTOR, gl_POLYGON_OFFSET_FILL,
        gl_POLYGON_OFFSET_LINE, gl_POLYGON_OFFSET_POINT,
        gl_POLYGON_OFFSET_UNITS, gl_POLYGON_SMOOTH, gl_POLYGON_SMOOTH_HINT,
        gl_POLYGON_STIPPLE, gl_POLYGON_STIPPLE_BIT, gl_POLYGON_TOKEN,
        gl_POSITION, gl_PROJECTION, gl_PROJECTION_MATRIX,
        gl_PROJECTION_STACK_DEPTH, gl_PROXY_TEXTURE_1D,
        gl_PROXY_TEXTURE_2D, gl_Q, gl_QUADRATIC_ATTENUATION, gl_QUADS,
        gl_QUAD_STRIP, gl_R, gl_R3_G3_B2, gl_READ_BUFFER, gl_RED,
        gl_RED_BIAS, gl_RED_BITS, gl_RED_SCALE, gl_RENDER, gl_RENDERER,
        gl_RENDER_MODE, gl_REPEAT, gl_REPLACE, gl_RETURN, gl_RGB, gl_RGB10,
        gl_RGB10_A2, gl_RGB12, gl_RGB16, gl_RGB4, gl_RGB5, gl_RGB5_A1,
        gl_RGB8, gl_RGBA, gl_RGBA12, gl_RGBA16, gl_RGBA2, gl_RGBA4,
        gl_RGBA8, gl_RGBA_MODE, gl_RIGHT, gl_S, gl_SCISSOR_BIT,
        gl_SCISSOR_BOX, gl_SCISSOR_TEST, gl_SELECT,
        gl_SELECTION_BUFFER_POINTER, gl_SELECTION_BUFFER_SIZE, gl_SET,
        gl_SHADE_MODEL, gl_SHININESS, gl_SHORT, gl_SMOOTH, gl_SPECULAR,
        gl_SPHERE_MAP, gl_SPOT_CUTOFF, gl_SPOT_DIRECTION, gl_SPOT_EXPONENT,
        gl_SRC_ALPHA, gl_SRC_ALPHA_SATURATE, gl_SRC_COLOR,
        gl_STACK_OVERFLOW, gl_STACK_UNDERFLOW, gl_STENCIL, gl_STENCIL_BITS,
        gl_STENCIL_BUFFER_BIT, gl_STENCIL_CLEAR_VALUE, gl_STENCIL_FAIL,
        gl_STENCIL_FUNC, gl_STENCIL_INDEX, gl_STENCIL_PASS_DEPTH_FAIL,
        gl_STENCIL_PASS_DEPTH_PASS, gl_STENCIL_REF, gl_STENCIL_TEST,
        gl_STENCIL_VALUE_MASK, gl_STENCIL_WRITEMASK, gl_STEREO,
        gl_SUBPIXEL_BITS, gl_T, gl_T2F_C3F_V3F, gl_T2F_C4F_N3F_V3F,
        gl_T2F_C4UB_V3F, gl_T2F_N3F_V3F, gl_T2F_V3F, gl_T4F_C4F_N3F_V4F,
        gl_T4F_V4F, gl_TEXTURE, gl_TEXTURE_1D, gl_TEXTURE_2D,
        gl_TEXTURE_ALPHA_SIZE, gl_TEXTURE_BINDING_1D,
        gl_TEXTURE_BINDING_2D, gl_TEXTURE_BIT, gl_TEXTURE_BLUE_SIZE,
        gl_TEXTURE_BORDER, gl_TEXTURE_BORDER_COLOR, gl_TEXTURE_COMPONENTS,
        gl_TEXTURE_COORD_ARRAY, gl_TEXTURE_COORD_ARRAY_POINTER,
        gl_TEXTURE_COORD_ARRAY_SIZE, gl_TEXTURE_COORD_ARRAY_STRIDE,
        gl_TEXTURE_COORD_ARRAY_TYPE, gl_TEXTURE_ENV, gl_TEXTURE_ENV_COLOR,
        gl_TEXTURE_ENV_MODE, gl_TEXTURE_GEN_MODE, gl_TEXTURE_GEN_Q,
        gl_TEXTURE_GEN_R, gl_TEXTURE_GEN_S, gl_TEXTURE_GEN_T,
        gl_TEXTURE_GREEN_SIZE, gl_TEXTURE_HEIGHT,
        gl_TEXTURE_INTENSITY_SIZE, gl_TEXTURE_INTERNAL_FORMAT,
        gl_TEXTURE_LUMINANCE_SIZE, gl_TEXTURE_MAG_FILTER,
        gl_TEXTURE_MATRIX, gl_TEXTURE_MIN_FILTER, gl_TEXTURE_PRIORITY,
        gl_TEXTURE_RED_SIZE, gl_TEXTURE_RESIDENT, gl_TEXTURE_STACK_DEPTH,
        gl_TEXTURE_WIDTH, gl_TEXTURE_WRAP_S, gl_TEXTURE_WRAP_T,
        gl_TRANSFORM_BIT, gl_TRIANGLES, gl_TRIANGLE_FAN, gl_TRIANGLE_STRIP,
        gl_TRUE, gl_UNPACK_ALIGNMENT, gl_UNPACK_LSB_FIRST,
        gl_UNPACK_ROW_LENGTH, gl_UNPACK_SKIP_PIXELS, gl_UNPACK_SKIP_ROWS,
        gl_UNPACK_SWAP_BYTES, gl_UNSIGNED_BYTE, gl_UNSIGNED_INT,
        gl_UNSIGNED_SHORT, gl_V2F, gl_V3F, gl_VENDOR, gl_VERSION,
        gl_VERTEX_ARRAY, gl_VERTEX_ARRAY_POINTER, gl_VERTEX_ARRAY_SIZE,
        gl_VERTEX_ARRAY_STRIDE, gl_VERTEX_ARRAY_TYPE, gl_VIEWPORT,
        gl_VIEWPORT_BIT, gl_XOR, gl_ZERO, gl_ZOOM_X, gl_ZOOM_Y)
import Graphics.Rendering.OpenGL.Raw.Core.Core12
       (glCopyTexSubImage3D, glDrawRangeElements, glTexImage3D,
        glTexSubImage3D, gl_ALIASED_LINE_WIDTH_RANGE,
        gl_ALIASED_POINT_SIZE_RANGE, gl_BGR, gl_BGRA, gl_CLAMP_TO_EDGE,
        gl_LIGHT_MODEL_COLOR_CONTROL, gl_MAX_3D_TEXTURE_SIZE,
        gl_MAX_ELEMENTS_INDICES, gl_MAX_ELEMENTS_VERTICES,
        gl_PACK_IMAGE_HEIGHT, gl_PACK_SKIP_IMAGES, gl_PROXY_TEXTURE_3D,
        gl_RESCALE_NORMAL, gl_SEPARATE_SPECULAR_COLOR, gl_SINGLE_COLOR,
        gl_SMOOTH_LINE_WIDTH_GRANULARITY, gl_SMOOTH_LINE_WIDTH_RANGE,
        gl_SMOOTH_POINT_SIZE_GRANULARITY, gl_SMOOTH_POINT_SIZE_RANGE,
        gl_TEXTURE_3D, gl_TEXTURE_BASE_LEVEL, gl_TEXTURE_BINDING_3D,
        gl_TEXTURE_DEPTH, gl_TEXTURE_MAX_LEVEL, gl_TEXTURE_MAX_LOD,
        gl_TEXTURE_MIN_LOD, gl_TEXTURE_WRAP_R, gl_UNPACK_IMAGE_HEIGHT,
        gl_UNPACK_SKIP_IMAGES, gl_UNSIGNED_BYTE_2_3_3_REV,
        gl_UNSIGNED_BYTE_3_3_2, gl_UNSIGNED_INT_10_10_10_2,
        gl_UNSIGNED_INT_2_10_10_10_REV, gl_UNSIGNED_INT_8_8_8_8,
        gl_UNSIGNED_INT_8_8_8_8_REV, gl_UNSIGNED_SHORT_1_5_5_5_REV,
        gl_UNSIGNED_SHORT_4_4_4_4, gl_UNSIGNED_SHORT_4_4_4_4_REV,
        gl_UNSIGNED_SHORT_5_5_5_1, gl_UNSIGNED_SHORT_5_6_5,
        gl_UNSIGNED_SHORT_5_6_5_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Core13
       (glActiveTexture, glClientActiveTexture, glCompressedTexImage1D,
        glCompressedTexImage2D, glCompressedTexImage3D,
        glCompressedTexSubImage1D, glCompressedTexSubImage2D,
        glCompressedTexSubImage3D, glGetCompressedTexImage,
        glLoadTransposeMatrixd, glLoadTransposeMatrixf,
        glMultTransposeMatrixd, glMultTransposeMatrixf, glMultiTexCoord1d,
        glMultiTexCoord1dv, glMultiTexCoord1f, glMultiTexCoord1fv,
        glMultiTexCoord1i, glMultiTexCoord1iv, glMultiTexCoord1s,
        glMultiTexCoord1sv, glMultiTexCoord2d, glMultiTexCoord2dv,
        glMultiTexCoord2f, glMultiTexCoord2fv, glMultiTexCoord2i,
        glMultiTexCoord2iv, glMultiTexCoord2s, glMultiTexCoord2sv,
        glMultiTexCoord3d, glMultiTexCoord3dv, glMultiTexCoord3f,
        glMultiTexCoord3fv, glMultiTexCoord3i, glMultiTexCoord3iv,
        glMultiTexCoord3s, glMultiTexCoord3sv, glMultiTexCoord4d,
        glMultiTexCoord4dv, glMultiTexCoord4f, glMultiTexCoord4fv,
        glMultiTexCoord4i, glMultiTexCoord4iv, glMultiTexCoord4s,
        glMultiTexCoord4sv, glSampleCoverage, gl_ACTIVE_TEXTURE,
        gl_ADD_SIGNED, gl_CLAMP_TO_BORDER, gl_CLIENT_ACTIVE_TEXTURE,
        gl_COMBINE, gl_COMBINE_ALPHA, gl_COMBINE_RGB, gl_COMPRESSED_ALPHA,
        gl_COMPRESSED_INTENSITY, gl_COMPRESSED_LUMINANCE,
        gl_COMPRESSED_LUMINANCE_ALPHA, gl_COMPRESSED_RGB,
        gl_COMPRESSED_RGBA, gl_COMPRESSED_TEXTURE_FORMATS, gl_CONSTANT,
        gl_DOT3_RGB, gl_DOT3_RGBA, gl_INTERPOLATE,
        gl_MAX_CUBE_MAP_TEXTURE_SIZE, gl_MAX_TEXTURE_UNITS, gl_MULTISAMPLE,
        gl_MULTISAMPLE_BIT, gl_NORMAL_MAP,
        gl_NUM_COMPRESSED_TEXTURE_FORMATS, gl_OPERAND0_ALPHA,
        gl_OPERAND0_RGB, gl_OPERAND1_ALPHA, gl_OPERAND1_RGB,
        gl_OPERAND2_ALPHA, gl_OPERAND2_RGB, gl_PREVIOUS, gl_PRIMARY_COLOR,
        gl_PROXY_TEXTURE_CUBE_MAP, gl_REFLECTION_MAP, gl_RGB_SCALE,
        gl_SAMPLES, gl_SAMPLE_ALPHA_TO_COVERAGE, gl_SAMPLE_ALPHA_TO_ONE,
        gl_SAMPLE_BUFFERS, gl_SAMPLE_COVERAGE, gl_SAMPLE_COVERAGE_INVERT,
        gl_SAMPLE_COVERAGE_VALUE, gl_SOURCE0_ALPHA, gl_SOURCE0_RGB,
        gl_SOURCE1_ALPHA, gl_SOURCE1_RGB, gl_SOURCE2_ALPHA, gl_SOURCE2_RGB,
        gl_SUBTRACT, gl_TEXTURE0, gl_TEXTURE1, gl_TEXTURE10, gl_TEXTURE11,
        gl_TEXTURE12, gl_TEXTURE13, gl_TEXTURE14, gl_TEXTURE15,
        gl_TEXTURE16, gl_TEXTURE17, gl_TEXTURE18, gl_TEXTURE19,
        gl_TEXTURE2, gl_TEXTURE20, gl_TEXTURE21, gl_TEXTURE22,
        gl_TEXTURE23, gl_TEXTURE24, gl_TEXTURE25, gl_TEXTURE26,
        gl_TEXTURE27, gl_TEXTURE28, gl_TEXTURE29, gl_TEXTURE3,
        gl_TEXTURE30, gl_TEXTURE31, gl_TEXTURE4, gl_TEXTURE5, gl_TEXTURE6,
        gl_TEXTURE7, gl_TEXTURE8, gl_TEXTURE9, gl_TEXTURE_BINDING_CUBE_MAP,
        gl_TEXTURE_COMPRESSED, gl_TEXTURE_COMPRESSED_IMAGE_SIZE,
        gl_TEXTURE_COMPRESSION_HINT, gl_TEXTURE_CUBE_MAP,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_X, gl_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_Z, gl_TEXTURE_CUBE_MAP_POSITIVE_X,
        gl_TEXTURE_CUBE_MAP_POSITIVE_Y, gl_TEXTURE_CUBE_MAP_POSITIVE_Z,
        gl_TRANSPOSE_COLOR_MATRIX, gl_TRANSPOSE_MODELVIEW_MATRIX,
        gl_TRANSPOSE_PROJECTION_MATRIX, gl_TRANSPOSE_TEXTURE_MATRIX)
import Graphics.Rendering.OpenGL.Raw.Core.Core14
       (glBlendColor, glBlendEquation, glBlendFuncSeparate,
        glFogCoordPointer, glFogCoordd, glFogCoorddv, glFogCoordf,
        glFogCoordfv, glMultiDrawArrays, glMultiDrawElements,
        glPointParameterf, glPointParameterfv, glPointParameteri,
        glPointParameteriv, glSecondaryColor3b, glSecondaryColor3bv,
        glSecondaryColor3d, glSecondaryColor3dv, glSecondaryColor3f,
        glSecondaryColor3fv, glSecondaryColor3i, glSecondaryColor3iv,
        glSecondaryColor3s, glSecondaryColor3sv, glSecondaryColor3ub,
        glSecondaryColor3ubv, glSecondaryColor3ui, glSecondaryColor3uiv,
        glSecondaryColor3us, glSecondaryColor3usv, glSecondaryColorPointer,
        glWindowPos2d, glWindowPos2dv, glWindowPos2f, glWindowPos2fv,
        glWindowPos2i, glWindowPos2iv, glWindowPos2s, glWindowPos2sv,
        glWindowPos3d, glWindowPos3dv, glWindowPos3f, glWindowPos3fv,
        glWindowPos3i, glWindowPos3iv, glWindowPos3s, glWindowPos3sv,
        gl_BLEND_DST_ALPHA, gl_BLEND_DST_RGB, gl_BLEND_SRC_ALPHA,
        gl_BLEND_SRC_RGB, gl_COLOR_SUM, gl_COMPARE_R_TO_TEXTURE,
        gl_CONSTANT_ALPHA, gl_CONSTANT_COLOR, gl_CURRENT_FOG_COORDINATE,
        gl_CURRENT_SECONDARY_COLOR, gl_DECR_WRAP, gl_DEPTH_COMPONENT16,
        gl_DEPTH_COMPONENT24, gl_DEPTH_COMPONENT32, gl_DEPTH_TEXTURE_MODE,
        gl_FOG_COORDINATE, gl_FOG_COORDINATE_ARRAY,
        gl_FOG_COORDINATE_ARRAY_POINTER, gl_FOG_COORDINATE_ARRAY_STRIDE,
        gl_FOG_COORDINATE_ARRAY_TYPE, gl_FOG_COORDINATE_SOURCE,
        gl_FRAGMENT_DEPTH, gl_FUNC_ADD, gl_FUNC_REVERSE_SUBTRACT,
        gl_FUNC_SUBTRACT, gl_GENERATE_MIPMAP, gl_GENERATE_MIPMAP_HINT,
        gl_INCR_WRAP, gl_MAX, gl_MAX_TEXTURE_LOD_BIAS, gl_MIN,
        gl_MIRRORED_REPEAT, gl_ONE_MINUS_CONSTANT_ALPHA,
        gl_ONE_MINUS_CONSTANT_COLOR, gl_POINT_DISTANCE_ATTENUATION,
        gl_POINT_FADE_THRESHOLD_SIZE, gl_POINT_SIZE_MAX, gl_POINT_SIZE_MIN,
        gl_SECONDARY_COLOR_ARRAY, gl_SECONDARY_COLOR_ARRAY_POINTER,
        gl_SECONDARY_COLOR_ARRAY_SIZE, gl_SECONDARY_COLOR_ARRAY_STRIDE,
        gl_SECONDARY_COLOR_ARRAY_TYPE, gl_TEXTURE_COMPARE_FUNC,
        gl_TEXTURE_COMPARE_MODE, gl_TEXTURE_DEPTH_SIZE,
        gl_TEXTURE_FILTER_CONTROL, gl_TEXTURE_LOD_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Core15
       (glBeginQuery, glBindBuffer, glBufferData, glBufferSubData,
        glDeleteBuffers, glDeleteQueries, glEndQuery, glGenBuffers,
        glGenQueries, glGetBufferParameteriv, glGetBufferPointerv,
        glGetBufferSubData, glGetQueryObjectiv, glGetQueryObjectuiv,
        glGetQueryiv, glIsBuffer, glIsQuery, glMapBuffer, glUnmapBuffer,
        gl_ARRAY_BUFFER, gl_ARRAY_BUFFER_BINDING, gl_BUFFER_ACCESS,
        gl_BUFFER_MAPPED, gl_BUFFER_MAP_POINTER, gl_BUFFER_SIZE,
        gl_BUFFER_USAGE, gl_COLOR_ARRAY_BUFFER_BINDING,
        gl_CURRENT_FOG_COORD, gl_CURRENT_QUERY, gl_DYNAMIC_COPY,
        gl_DYNAMIC_DRAW, gl_DYNAMIC_READ,
        gl_EDGE_FLAG_ARRAY_BUFFER_BINDING, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING, gl_FOG_COORD,
        gl_FOG_COORDINATE_ARRAY_BUFFER_BINDING, gl_FOG_COORD_ARRAY,
        gl_FOG_COORD_ARRAY_BUFFER_BINDING, gl_FOG_COORD_ARRAY_POINTER,
        gl_FOG_COORD_ARRAY_STRIDE, gl_FOG_COORD_ARRAY_TYPE,
        gl_FOG_COORD_SRC, gl_INDEX_ARRAY_BUFFER_BINDING,
        gl_NORMAL_ARRAY_BUFFER_BINDING, gl_QUERY_COUNTER_BITS,
        gl_QUERY_RESULT, gl_QUERY_RESULT_AVAILABLE, gl_READ_ONLY,
        gl_READ_WRITE, gl_SAMPLES_PASSED,
        gl_SECONDARY_COLOR_ARRAY_BUFFER_BINDING, gl_SRC0_ALPHA,
        gl_SRC0_RGB, gl_SRC1_ALPHA, gl_SRC1_RGB, gl_SRC2_ALPHA,
        gl_SRC2_RGB, gl_STATIC_COPY, gl_STATIC_DRAW, gl_STATIC_READ,
        gl_STREAM_COPY, gl_STREAM_DRAW, gl_STREAM_READ,
        gl_TEXTURE_COORD_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_WEIGHT_ARRAY_BUFFER_BINDING, gl_WRITE_ONLY)
import Graphics.Rendering.OpenGL.Raw.Core.Core20
       (glAttachShader, glBindAttribLocation, glBlendEquationSeparate,
        glCompileShader, glCreateProgram, glCreateShader, glDeleteProgram,
        glDeleteShader, glDetachShader, glDisableVertexAttribArray,
        glDrawBuffers, glEnableVertexAttribArray, glGetActiveAttrib,
        glGetActiveUniform, glGetAttachedShaders, glGetAttribLocation,
        glGetProgramInfoLog, glGetProgramiv, glGetShaderInfoLog,
        glGetShaderSource, glGetShaderiv, glGetUniformLocation,
        glGetUniformfv, glGetUniformiv, glGetVertexAttribPointerv,
        glGetVertexAttribdv, glGetVertexAttribfv, glGetVertexAttribiv,
        glIsProgram, glIsShader, glLinkProgram, glShaderSource,
        glStencilFuncSeparate, glStencilMaskSeparate, glStencilOpSeparate,
        glUniform1f, glUniform1fv, glUniform1i, glUniform1iv, glUniform2f,
        glUniform2fv, glUniform2i, glUniform2iv, glUniform3f, glUniform3fv,
        glUniform3i, glUniform3iv, glUniform4f, glUniform4fv, glUniform4i,
        glUniform4iv, glUniformMatrix2fv, glUniformMatrix3fv,
        glUniformMatrix4fv, glUseProgram, glValidateProgram,
        glVertexAttrib1d, glVertexAttrib1dv, glVertexAttrib1f,
        glVertexAttrib1fv, glVertexAttrib1s, glVertexAttrib1sv,
        glVertexAttrib2d, glVertexAttrib2dv, glVertexAttrib2f,
        glVertexAttrib2fv, glVertexAttrib2s, glVertexAttrib2sv,
        glVertexAttrib3d, glVertexAttrib3dv, glVertexAttrib3f,
        glVertexAttrib3fv, glVertexAttrib3s, glVertexAttrib3sv,
        glVertexAttrib4Nbv, glVertexAttrib4Niv, glVertexAttrib4Nsv,
        glVertexAttrib4Nub, glVertexAttrib4Nubv, glVertexAttrib4Nuiv,
        glVertexAttrib4Nusv, glVertexAttrib4bv, glVertexAttrib4d,
        glVertexAttrib4dv, glVertexAttrib4f, glVertexAttrib4fv,
        glVertexAttrib4iv, glVertexAttrib4s, glVertexAttrib4sv,
        glVertexAttrib4ubv, glVertexAttrib4uiv, glVertexAttrib4usv,
        glVertexAttribPointer, gl_ACTIVE_ATTRIBUTES,
        gl_ACTIVE_ATTRIBUTE_MAX_LENGTH, gl_ACTIVE_UNIFORMS,
        gl_ACTIVE_UNIFORM_MAX_LENGTH, gl_ATTACHED_SHADERS,
        gl_BLEND_EQUATION_ALPHA, gl_BLEND_EQUATION_RGB, gl_BOOL,
        gl_BOOL_VEC2, gl_BOOL_VEC3, gl_BOOL_VEC4, gl_COMPILE_STATUS,
        gl_COORD_REPLACE, gl_CURRENT_PROGRAM, gl_CURRENT_VERTEX_ATTRIB,
        gl_DELETE_STATUS, gl_DRAW_BUFFER0, gl_DRAW_BUFFER1,
        gl_DRAW_BUFFER10, gl_DRAW_BUFFER11, gl_DRAW_BUFFER12,
        gl_DRAW_BUFFER13, gl_DRAW_BUFFER14, gl_DRAW_BUFFER15,
        gl_DRAW_BUFFER2, gl_DRAW_BUFFER3, gl_DRAW_BUFFER4, gl_DRAW_BUFFER5,
        gl_DRAW_BUFFER6, gl_DRAW_BUFFER7, gl_DRAW_BUFFER8, gl_DRAW_BUFFER9,
        gl_FLOAT_MAT2, gl_FLOAT_MAT3, gl_FLOAT_MAT4, gl_FLOAT_VEC2,
        gl_FLOAT_VEC3, gl_FLOAT_VEC4, gl_FRAGMENT_SHADER,
        gl_FRAGMENT_SHADER_DERIVATIVE_HINT, gl_INFO_LOG_LENGTH,
        gl_INT_VEC2, gl_INT_VEC3, gl_INT_VEC4, gl_LINK_STATUS,
        gl_LOWER_LEFT, gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS,
        gl_MAX_DRAW_BUFFERS, gl_MAX_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_TEXTURE_COORDS, gl_MAX_TEXTURE_IMAGE_UNITS,
        gl_MAX_VARYING_FLOATS, gl_MAX_VERTEX_ATTRIBS,
        gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS,
        gl_MAX_VERTEX_UNIFORM_COMPONENTS, gl_POINT_SPRITE,
        gl_POINT_SPRITE_COORD_ORIGIN, gl_SAMPLER_1D, gl_SAMPLER_1D_SHADOW,
        gl_SAMPLER_2D, gl_SAMPLER_2D_SHADOW, gl_SAMPLER_3D,
        gl_SAMPLER_CUBE, gl_SHADER_SOURCE_LENGTH, gl_SHADER_TYPE,
        gl_SHADING_LANGUAGE_VERSION, gl_STENCIL_BACK_FAIL,
        gl_STENCIL_BACK_FUNC, gl_STENCIL_BACK_PASS_DEPTH_FAIL,
        gl_STENCIL_BACK_PASS_DEPTH_PASS, gl_STENCIL_BACK_REF,
        gl_STENCIL_BACK_VALUE_MASK, gl_STENCIL_BACK_WRITEMASK,
        gl_UPPER_LEFT, gl_VALIDATE_STATUS, gl_VERTEX_ATTRIB_ARRAY_ENABLED,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED, gl_VERTEX_ATTRIB_ARRAY_POINTER,
        gl_VERTEX_ATTRIB_ARRAY_SIZE, gl_VERTEX_ATTRIB_ARRAY_STRIDE,
        gl_VERTEX_ATTRIB_ARRAY_TYPE, gl_VERTEX_PROGRAM_POINT_SIZE,
        gl_VERTEX_PROGRAM_TWO_SIDE, gl_VERTEX_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Core21
       (glUniformMatrix2x3fv, glUniformMatrix2x4fv, glUniformMatrix3x2fv,
        glUniformMatrix3x4fv, glUniformMatrix4x2fv, glUniformMatrix4x3fv,
        gl_COMPRESSED_SLUMINANCE, gl_COMPRESSED_SLUMINANCE_ALPHA,
        gl_COMPRESSED_SRGB, gl_COMPRESSED_SRGB_ALPHA,
        gl_CURRENT_RASTER_SECONDARY_COLOR, gl_FLOAT_MAT2x3,
        gl_FLOAT_MAT2x4, gl_FLOAT_MAT3x2, gl_FLOAT_MAT3x4, gl_FLOAT_MAT4x2,
        gl_FLOAT_MAT4x3, gl_PIXEL_PACK_BUFFER,
        gl_PIXEL_PACK_BUFFER_BINDING, gl_PIXEL_UNPACK_BUFFER,
        gl_PIXEL_UNPACK_BUFFER_BINDING, gl_SLUMINANCE, gl_SLUMINANCE8,
        gl_SLUMINANCE8_ALPHA8, gl_SLUMINANCE_ALPHA, gl_SRGB, gl_SRGB8,
        gl_SRGB8_ALPHA8, gl_SRGB_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ALPHA_INTEGER :: GLenum
gl_ALPHA_INTEGER = 36247
 
gl_BGRA_INTEGER :: GLenum
gl_BGRA_INTEGER = 36251
 
gl_BGR_INTEGER :: GLenum
gl_BGR_INTEGER = 36250
 
gl_BLUE_INTEGER :: GLenum
gl_BLUE_INTEGER = 36246
 
gl_BUFFER_ACCESS_FLAGS :: GLenum
gl_BUFFER_ACCESS_FLAGS = 37151
 
gl_BUFFER_MAP_LENGTH :: GLenum
gl_BUFFER_MAP_LENGTH = 37152
 
gl_BUFFER_MAP_OFFSET :: GLenum
gl_BUFFER_MAP_OFFSET = 37153
 
gl_CLAMP_FRAGMENT_COLOR :: GLenum
gl_CLAMP_FRAGMENT_COLOR = 35099
 
gl_CLAMP_READ_COLOR :: GLenum
gl_CLAMP_READ_COLOR = 35100
 
gl_CLAMP_VERTEX_COLOR :: GLenum
gl_CLAMP_VERTEX_COLOR = 35098
 
gl_CLIP_DISTANCE0 :: GLenum
gl_CLIP_DISTANCE0 = 12288
 
gl_CLIP_DISTANCE1 :: GLenum
gl_CLIP_DISTANCE1 = 12289
 
gl_CLIP_DISTANCE2 :: GLenum
gl_CLIP_DISTANCE2 = 12290
 
gl_CLIP_DISTANCE3 :: GLenum
gl_CLIP_DISTANCE3 = 12291
 
gl_CLIP_DISTANCE4 :: GLenum
gl_CLIP_DISTANCE4 = 12292
 
gl_CLIP_DISTANCE5 :: GLenum
gl_CLIP_DISTANCE5 = 12293
 
gl_CLIP_DISTANCE6 :: GLenum
gl_CLIP_DISTANCE6 = 12294
 
gl_CLIP_DISTANCE7 :: GLenum
gl_CLIP_DISTANCE7 = 12295
 
gl_COLOR_ATTACHMENT0 :: GLenum
gl_COLOR_ATTACHMENT0 = 36064
 
gl_COLOR_ATTACHMENT1 :: GLenum
gl_COLOR_ATTACHMENT1 = 36065
 
gl_COLOR_ATTACHMENT10 :: GLenum
gl_COLOR_ATTACHMENT10 = 36074
 
gl_COLOR_ATTACHMENT11 :: GLenum
gl_COLOR_ATTACHMENT11 = 36075
 
gl_COLOR_ATTACHMENT12 :: GLenum
gl_COLOR_ATTACHMENT12 = 36076
 
gl_COLOR_ATTACHMENT13 :: GLenum
gl_COLOR_ATTACHMENT13 = 36077
 
gl_COLOR_ATTACHMENT14 :: GLenum
gl_COLOR_ATTACHMENT14 = 36078
 
gl_COLOR_ATTACHMENT15 :: GLenum
gl_COLOR_ATTACHMENT15 = 36079
 
gl_COLOR_ATTACHMENT2 :: GLenum
gl_COLOR_ATTACHMENT2 = 36066
 
gl_COLOR_ATTACHMENT3 :: GLenum
gl_COLOR_ATTACHMENT3 = 36067
 
gl_COLOR_ATTACHMENT4 :: GLenum
gl_COLOR_ATTACHMENT4 = 36068
 
gl_COLOR_ATTACHMENT5 :: GLenum
gl_COLOR_ATTACHMENT5 = 36069
 
gl_COLOR_ATTACHMENT6 :: GLenum
gl_COLOR_ATTACHMENT6 = 36070
 
gl_COLOR_ATTACHMENT7 :: GLenum
gl_COLOR_ATTACHMENT7 = 36071
 
gl_COLOR_ATTACHMENT8 :: GLenum
gl_COLOR_ATTACHMENT8 = 36072
 
gl_COLOR_ATTACHMENT9 :: GLenum
gl_COLOR_ATTACHMENT9 = 36073
 
gl_COMPARE_REF_TO_TEXTURE :: GLenum
gl_COMPARE_REF_TO_TEXTURE = 34894
 
gl_COMPRESSED_RED :: GLenum
gl_COMPRESSED_RED = 33317
 
gl_COMPRESSED_RED_RGTC1 :: GLenum
gl_COMPRESSED_RED_RGTC1 = 36283
 
gl_COMPRESSED_RG :: GLenum
gl_COMPRESSED_RG = 33318
 
gl_COMPRESSED_RG_RGTC2 :: GLenum
gl_COMPRESSED_RG_RGTC2 = 36285
 
gl_COMPRESSED_SIGNED_RED_RGTC1 :: GLenum
gl_COMPRESSED_SIGNED_RED_RGTC1 = 36284
 
gl_COMPRESSED_SIGNED_RG_RGTC2 :: GLenum
gl_COMPRESSED_SIGNED_RG_RGTC2 = 36286
 
gl_CONTEXT_FLAGS :: GLenum
gl_CONTEXT_FLAGS = 33310
 
gl_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT :: GLenum
gl_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT = 1
 
gl_DEPTH24_STENCIL8 :: GLenum
gl_DEPTH24_STENCIL8 = 35056
 
gl_DEPTH32F_STENCIL8 :: GLenum
gl_DEPTH32F_STENCIL8 = 36013
 
gl_DEPTH_ATTACHMENT :: GLenum
gl_DEPTH_ATTACHMENT = 36096
 
gl_DEPTH_COMPONENT32F :: GLenum
gl_DEPTH_COMPONENT32F = 36012
 
gl_DEPTH_STENCIL :: GLenum
gl_DEPTH_STENCIL = 34041
 
gl_DEPTH_STENCIL_ATTACHMENT :: GLenum
gl_DEPTH_STENCIL_ATTACHMENT = 33306
 
gl_DRAW_FRAMEBUFFER :: GLenum
gl_DRAW_FRAMEBUFFER = 36009
 
gl_DRAW_FRAMEBUFFER_BINDING :: GLenum
gl_DRAW_FRAMEBUFFER_BINDING = 36006
 
gl_FIXED_ONLY :: GLenum
gl_FIXED_ONLY = 35101
 
gl_FLOAT_32_UNSIGNED_INT_24_8_REV :: GLenum
gl_FLOAT_32_UNSIGNED_INT_24_8_REV = 36269
 
gl_FRAMEBUFFER :: GLenum
gl_FRAMEBUFFER = 36160
 
gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE = 33301
 
gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE = 33300
 
gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = 33296
 
gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = 33297
 
gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = 33302
 
gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE = 33299
 
gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = 36049
 
gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = 36048
 
gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE = 33298
 
gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE = 33303
 
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = 36051
 
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = 36052
 
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL :: GLenum
gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = 36050
 
gl_FRAMEBUFFER_BINDING :: GLenum
gl_FRAMEBUFFER_BINDING = 36006
 
gl_FRAMEBUFFER_COMPLETE :: GLenum
gl_FRAMEBUFFER_COMPLETE = 36053
 
gl_FRAMEBUFFER_DEFAULT :: GLenum
gl_FRAMEBUFFER_DEFAULT = 33304
 
gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 36054
 
gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER = 36059
 
gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 36055
 
gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE = 36182
 
gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER :: GLenum
gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER = 36060
 
gl_FRAMEBUFFER_SRGB :: GLenum
gl_FRAMEBUFFER_SRGB = 36281
 
gl_FRAMEBUFFER_UNDEFINED :: GLenum
gl_FRAMEBUFFER_UNDEFINED = 33305
 
gl_FRAMEBUFFER_UNSUPPORTED :: GLenum
gl_FRAMEBUFFER_UNSUPPORTED = 36061
 
gl_GREEN_INTEGER :: GLenum
gl_GREEN_INTEGER = 36245
 
gl_HALF_FLOAT :: GLenum
gl_HALF_FLOAT = 5131
 
gl_INTERLEAVED_ATTRIBS :: GLenum
gl_INTERLEAVED_ATTRIBS = 35980
 
gl_INT_SAMPLER_1D :: GLenum
gl_INT_SAMPLER_1D = 36297
 
gl_INT_SAMPLER_1D_ARRAY :: GLenum
gl_INT_SAMPLER_1D_ARRAY = 36302
 
gl_INT_SAMPLER_2D :: GLenum
gl_INT_SAMPLER_2D = 36298
 
gl_INT_SAMPLER_2D_ARRAY :: GLenum
gl_INT_SAMPLER_2D_ARRAY = 36303
 
gl_INT_SAMPLER_3D :: GLenum
gl_INT_SAMPLER_3D = 36299
 
gl_INT_SAMPLER_CUBE :: GLenum
gl_INT_SAMPLER_CUBE = 36300
 
gl_INVALID_FRAMEBUFFER_OPERATION :: GLenum
gl_INVALID_FRAMEBUFFER_OPERATION = 1286
 
gl_MAJOR_VERSION :: GLenum
gl_MAJOR_VERSION = 33307
 
gl_MAP_FLUSH_EXPLICIT_BIT :: GLenum
gl_MAP_FLUSH_EXPLICIT_BIT = 16
 
gl_MAP_INVALIDATE_BUFFER_BIT :: GLenum
gl_MAP_INVALIDATE_BUFFER_BIT = 8
 
gl_MAP_INVALIDATE_RANGE_BIT :: GLenum
gl_MAP_INVALIDATE_RANGE_BIT = 4
 
gl_MAP_READ_BIT :: GLenum
gl_MAP_READ_BIT = 1
 
gl_MAP_UNSYNCHRONIZED_BIT :: GLenum
gl_MAP_UNSYNCHRONIZED_BIT = 32
 
gl_MAP_WRITE_BIT :: GLenum
gl_MAP_WRITE_BIT = 2
 
gl_MAX_ARRAY_TEXTURE_LAYERS :: GLenum
gl_MAX_ARRAY_TEXTURE_LAYERS = 35071
 
gl_MAX_CLIP_DISTANCES :: GLenum
gl_MAX_CLIP_DISTANCES = 3378
 
gl_MAX_COLOR_ATTACHMENTS :: GLenum
gl_MAX_COLOR_ATTACHMENTS = 36063
 
gl_MAX_PROGRAM_TEXEL_OFFSET :: GLenum
gl_MAX_PROGRAM_TEXEL_OFFSET = 35077
 
gl_MAX_RENDERBUFFER_SIZE :: GLenum
gl_MAX_RENDERBUFFER_SIZE = 34024
 
gl_MAX_SAMPLES :: GLenum
gl_MAX_SAMPLES = 36183
 
gl_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS :: GLenum
gl_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS = 35978
 
gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS :: GLenum
gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS = 35979
 
gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS :: GLenum
gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS = 35968
 
gl_MAX_VARYING_COMPONENTS :: GLenum
gl_MAX_VARYING_COMPONENTS = 35659
 
gl_MINOR_VERSION :: GLenum
gl_MINOR_VERSION = 33308
 
gl_MIN_PROGRAM_TEXEL_OFFSET :: GLenum
gl_MIN_PROGRAM_TEXEL_OFFSET = 35076
 
gl_NUM_EXTENSIONS :: GLenum
gl_NUM_EXTENSIONS = 33309
 
gl_PRIMITIVES_GENERATED :: GLenum
gl_PRIMITIVES_GENERATED = 35975
 
gl_PROXY_TEXTURE_1D_ARRAY :: GLenum
gl_PROXY_TEXTURE_1D_ARRAY = 35865
 
gl_PROXY_TEXTURE_2D_ARRAY :: GLenum
gl_PROXY_TEXTURE_2D_ARRAY = 35867
 
gl_QUERY_BY_REGION_NO_WAIT :: GLenum
gl_QUERY_BY_REGION_NO_WAIT = 36374
 
gl_QUERY_BY_REGION_WAIT :: GLenum
gl_QUERY_BY_REGION_WAIT = 36373
 
gl_QUERY_NO_WAIT :: GLenum
gl_QUERY_NO_WAIT = 36372
 
gl_QUERY_WAIT :: GLenum
gl_QUERY_WAIT = 36371
 
gl_R11F_G11F_B10F :: GLenum
gl_R11F_G11F_B10F = 35898
 
gl_R16 :: GLenum
gl_R16 = 33322
 
gl_R16F :: GLenum
gl_R16F = 33325
 
gl_R16I :: GLenum
gl_R16I = 33331
 
gl_R16UI :: GLenum
gl_R16UI = 33332
 
gl_R32F :: GLenum
gl_R32F = 33326
 
gl_R32I :: GLenum
gl_R32I = 33333
 
gl_R32UI :: GLenum
gl_R32UI = 33334
 
gl_R8 :: GLenum
gl_R8 = 33321
 
gl_R8I :: GLenum
gl_R8I = 33329
 
gl_R8UI :: GLenum
gl_R8UI = 33330
 
gl_RASTERIZER_DISCARD :: GLenum
gl_RASTERIZER_DISCARD = 35977
 
gl_READ_FRAMEBUFFER :: GLenum
gl_READ_FRAMEBUFFER = 36008
 
gl_READ_FRAMEBUFFER_BINDING :: GLenum
gl_READ_FRAMEBUFFER_BINDING = 36010
 
gl_RED_INTEGER :: GLenum
gl_RED_INTEGER = 36244
 
gl_RENDERBUFFER :: GLenum
gl_RENDERBUFFER = 36161
 
gl_RENDERBUFFER_ALPHA_SIZE :: GLenum
gl_RENDERBUFFER_ALPHA_SIZE = 36179
 
gl_RENDERBUFFER_BINDING :: GLenum
gl_RENDERBUFFER_BINDING = 36007
 
gl_RENDERBUFFER_BLUE_SIZE :: GLenum
gl_RENDERBUFFER_BLUE_SIZE = 36178
 
gl_RENDERBUFFER_DEPTH_SIZE :: GLenum
gl_RENDERBUFFER_DEPTH_SIZE = 36180
 
gl_RENDERBUFFER_GREEN_SIZE :: GLenum
gl_RENDERBUFFER_GREEN_SIZE = 36177
 
gl_RENDERBUFFER_HEIGHT :: GLenum
gl_RENDERBUFFER_HEIGHT = 36163
 
gl_RENDERBUFFER_INTERNAL_FORMAT :: GLenum
gl_RENDERBUFFER_INTERNAL_FORMAT = 36164
 
gl_RENDERBUFFER_RED_SIZE :: GLenum
gl_RENDERBUFFER_RED_SIZE = 36176
 
gl_RENDERBUFFER_SAMPLES :: GLenum
gl_RENDERBUFFER_SAMPLES = 36011
 
gl_RENDERBUFFER_STENCIL_SIZE :: GLenum
gl_RENDERBUFFER_STENCIL_SIZE = 36181
 
gl_RENDERBUFFER_WIDTH :: GLenum
gl_RENDERBUFFER_WIDTH = 36162
 
gl_RG :: GLenum
gl_RG = 33319
 
gl_RG16 :: GLenum
gl_RG16 = 33324
 
gl_RG16F :: GLenum
gl_RG16F = 33327
 
gl_RG16I :: GLenum
gl_RG16I = 33337
 
gl_RG16UI :: GLenum
gl_RG16UI = 33338
 
gl_RG32F :: GLenum
gl_RG32F = 33328
 
gl_RG32I :: GLenum
gl_RG32I = 33339
 
gl_RG32UI :: GLenum
gl_RG32UI = 33340
 
gl_RG8 :: GLenum
gl_RG8 = 33323
 
gl_RG8I :: GLenum
gl_RG8I = 33335
 
gl_RG8UI :: GLenum
gl_RG8UI = 33336
 
gl_RGB16F :: GLenum
gl_RGB16F = 34843
 
gl_RGB16I :: GLenum
gl_RGB16I = 36233
 
gl_RGB16UI :: GLenum
gl_RGB16UI = 36215
 
gl_RGB32F :: GLenum
gl_RGB32F = 34837
 
gl_RGB32I :: GLenum
gl_RGB32I = 36227
 
gl_RGB32UI :: GLenum
gl_RGB32UI = 36209
 
gl_RGB8I :: GLenum
gl_RGB8I = 36239
 
gl_RGB8UI :: GLenum
gl_RGB8UI = 36221
 
gl_RGB9_E5 :: GLenum
gl_RGB9_E5 = 35901
 
gl_RGBA16F :: GLenum
gl_RGBA16F = 34842
 
gl_RGBA16I :: GLenum
gl_RGBA16I = 36232
 
gl_RGBA16UI :: GLenum
gl_RGBA16UI = 36214
 
gl_RGBA32F :: GLenum
gl_RGBA32F = 34836
 
gl_RGBA32I :: GLenum
gl_RGBA32I = 36226
 
gl_RGBA32UI :: GLenum
gl_RGBA32UI = 36208
 
gl_RGBA8I :: GLenum
gl_RGBA8I = 36238
 
gl_RGBA8UI :: GLenum
gl_RGBA8UI = 36220
 
gl_RGBA_INTEGER :: GLenum
gl_RGBA_INTEGER = 36249
 
gl_RGB_INTEGER :: GLenum
gl_RGB_INTEGER = 36248
 
gl_RG_INTEGER :: GLenum
gl_RG_INTEGER = 33320
 
gl_SAMPLER_1D_ARRAY :: GLenum
gl_SAMPLER_1D_ARRAY = 36288
 
gl_SAMPLER_1D_ARRAY_SHADOW :: GLenum
gl_SAMPLER_1D_ARRAY_SHADOW = 36291
 
gl_SAMPLER_2D_ARRAY :: GLenum
gl_SAMPLER_2D_ARRAY = 36289
 
gl_SAMPLER_2D_ARRAY_SHADOW :: GLenum
gl_SAMPLER_2D_ARRAY_SHADOW = 36292
 
gl_SAMPLER_CUBE_SHADOW :: GLenum
gl_SAMPLER_CUBE_SHADOW = 36293
 
gl_SEPARATE_ATTRIBS :: GLenum
gl_SEPARATE_ATTRIBS = 35981
 
gl_STENCIL_ATTACHMENT :: GLenum
gl_STENCIL_ATTACHMENT = 36128
 
gl_STENCIL_INDEX1 :: GLenum
gl_STENCIL_INDEX1 = 36166
 
gl_STENCIL_INDEX16 :: GLenum
gl_STENCIL_INDEX16 = 36169
 
gl_STENCIL_INDEX4 :: GLenum
gl_STENCIL_INDEX4 = 36167
 
gl_STENCIL_INDEX8 :: GLenum
gl_STENCIL_INDEX8 = 36168
 
gl_TEXTURE_1D_ARRAY :: GLenum
gl_TEXTURE_1D_ARRAY = 35864
 
gl_TEXTURE_2D_ARRAY :: GLenum
gl_TEXTURE_2D_ARRAY = 35866
 
gl_TEXTURE_ALPHA_TYPE :: GLenum
gl_TEXTURE_ALPHA_TYPE = 35859
 
gl_TEXTURE_BINDING_1D_ARRAY :: GLenum
gl_TEXTURE_BINDING_1D_ARRAY = 35868
 
gl_TEXTURE_BINDING_2D_ARRAY :: GLenum
gl_TEXTURE_BINDING_2D_ARRAY = 35869
 
gl_TEXTURE_BLUE_TYPE :: GLenum
gl_TEXTURE_BLUE_TYPE = 35858
 
gl_TEXTURE_DEPTH_TYPE :: GLenum
gl_TEXTURE_DEPTH_TYPE = 35862
 
gl_TEXTURE_GREEN_TYPE :: GLenum
gl_TEXTURE_GREEN_TYPE = 35857
 
gl_TEXTURE_RED_TYPE :: GLenum
gl_TEXTURE_RED_TYPE = 35856
 
gl_TEXTURE_SHARED_SIZE :: GLenum
gl_TEXTURE_SHARED_SIZE = 35903
 
gl_TEXTURE_STENCIL_SIZE :: GLenum
gl_TEXTURE_STENCIL_SIZE = 35057
 
gl_TRANSFORM_FEEDBACK_BUFFER :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER = 35982
 
gl_TRANSFORM_FEEDBACK_BUFFER_BINDING :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_BINDING = 35983
 
gl_TRANSFORM_FEEDBACK_BUFFER_MODE :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_MODE = 35967
 
gl_TRANSFORM_FEEDBACK_BUFFER_SIZE :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_SIZE = 35973
 
gl_TRANSFORM_FEEDBACK_BUFFER_START :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_START = 35972
 
gl_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN :: GLenum
gl_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN = 35976
 
gl_TRANSFORM_FEEDBACK_VARYINGS :: GLenum
gl_TRANSFORM_FEEDBACK_VARYINGS = 35971
 
gl_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH :: GLenum
gl_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH = 35958
 
gl_UNSIGNED_INT_10F_11F_11F_REV :: GLenum
gl_UNSIGNED_INT_10F_11F_11F_REV = 35899
 
gl_UNSIGNED_INT_24_8 :: GLenum
gl_UNSIGNED_INT_24_8 = 34042
 
gl_UNSIGNED_INT_5_9_9_9_REV :: GLenum
gl_UNSIGNED_INT_5_9_9_9_REV = 35902
 
gl_UNSIGNED_INT_SAMPLER_1D :: GLenum
gl_UNSIGNED_INT_SAMPLER_1D = 36305
 
gl_UNSIGNED_INT_SAMPLER_1D_ARRAY :: GLenum
gl_UNSIGNED_INT_SAMPLER_1D_ARRAY = 36310
 
gl_UNSIGNED_INT_SAMPLER_2D :: GLenum
gl_UNSIGNED_INT_SAMPLER_2D = 36306
 
gl_UNSIGNED_INT_SAMPLER_2D_ARRAY :: GLenum
gl_UNSIGNED_INT_SAMPLER_2D_ARRAY = 36311
 
gl_UNSIGNED_INT_SAMPLER_3D :: GLenum
gl_UNSIGNED_INT_SAMPLER_3D = 36307
 
gl_UNSIGNED_INT_SAMPLER_CUBE :: GLenum
gl_UNSIGNED_INT_SAMPLER_CUBE = 36308
 
gl_UNSIGNED_INT_VEC2 :: GLenum
gl_UNSIGNED_INT_VEC2 = 36294
 
gl_UNSIGNED_INT_VEC3 :: GLenum
gl_UNSIGNED_INT_VEC3 = 36295
 
gl_UNSIGNED_INT_VEC4 :: GLenum
gl_UNSIGNED_INT_VEC4 = 36296
 
gl_UNSIGNED_NORMALIZED :: GLenum
gl_UNSIGNED_NORMALIZED = 35863
 
gl_VERTEX_ARRAY_BINDING :: GLenum
gl_VERTEX_ARRAY_BINDING = 34229
 
gl_VERTEX_ATTRIB_ARRAY_INTEGER :: GLenum
gl_VERTEX_ATTRIB_ARRAY_INTEGER = 35069
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBeginConditionalRender ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glBeginConditionalRender :: GLuint -> GLenum -> IO ()
glBeginConditionalRender
  = dyn_glBeginConditionalRender ptr_glBeginConditionalRender
 
{-# NOINLINE ptr_glBeginConditionalRender #-}
 
ptr_glBeginConditionalRender :: FunPtr a
ptr_glBeginConditionalRender
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBeginConditionalRender"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBeginTransformFeedback ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glBeginTransformFeedback :: GLenum -> IO ()
glBeginTransformFeedback
  = dyn_glBeginTransformFeedback ptr_glBeginTransformFeedback
 
{-# NOINLINE ptr_glBeginTransformFeedback #-}
 
ptr_glBeginTransformFeedback :: FunPtr a
ptr_glBeginTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBeginTransformFeedback"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindBufferBase ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> IO ())
 
glBindBufferBase :: GLenum -> GLuint -> GLuint -> IO ()
glBindBufferBase = dyn_glBindBufferBase ptr_glBindBufferBase
 
{-# NOINLINE ptr_glBindBufferBase #-}
 
ptr_glBindBufferBase :: FunPtr a
ptr_glBindBufferBase
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindBufferBase"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLintptr -> GLsizeiptr -> IO ())
 
glBindBufferRange ::
                  GLenum -> GLuint -> GLuint -> GLintptr -> GLsizeiptr -> IO ()
glBindBufferRange = dyn_glBindBufferRange ptr_glBindBufferRange
 
{-# NOINLINE ptr_glBindBufferRange #-}
 
ptr_glBindBufferRange :: FunPtr a
ptr_glBindBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindBufferRange"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindFragDataLocation
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> Ptr GLchar -> IO ())
 
glBindFragDataLocation :: GLuint -> GLuint -> Ptr GLchar -> IO ()
glBindFragDataLocation
  = dyn_glBindFragDataLocation ptr_glBindFragDataLocation
 
{-# NOINLINE ptr_glBindFragDataLocation #-}
 
ptr_glBindFragDataLocation :: FunPtr a
ptr_glBindFragDataLocation
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindFragDataLocation"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindFramebuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindFramebuffer :: GLenum -> GLuint -> IO ()
glBindFramebuffer = dyn_glBindFramebuffer ptr_glBindFramebuffer
 
{-# NOINLINE ptr_glBindFramebuffer #-}
 
ptr_glBindFramebuffer :: FunPtr a
ptr_glBindFramebuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindFramebuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindRenderbuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindRenderbuffer :: GLenum -> GLuint -> IO ()
glBindRenderbuffer = dyn_glBindRenderbuffer ptr_glBindRenderbuffer
 
{-# NOINLINE ptr_glBindRenderbuffer #-}
 
ptr_glBindRenderbuffer :: FunPtr a
ptr_glBindRenderbuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindRenderbuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindVertexArray ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBindVertexArray :: GLuint -> IO ()
glBindVertexArray = dyn_glBindVertexArray ptr_glBindVertexArray
 
{-# NOINLINE ptr_glBindVertexArray #-}
 
ptr_glBindVertexArray :: FunPtr a
ptr_glBindVertexArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBindVertexArray"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlitFramebuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLbitfield -> GLenum -> IO ())
 
glBlitFramebuffer ::
                  GLint ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint -> GLint -> GLint -> GLint -> GLbitfield -> GLenum -> IO ()
glBlitFramebuffer = dyn_glBlitFramebuffer ptr_glBlitFramebuffer
 
{-# NOINLINE ptr_glBlitFramebuffer #-}
 
ptr_glBlitFramebuffer :: FunPtr a
ptr_glBlitFramebuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glBlitFramebuffer"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCheckFramebufferStatus ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO GLenum)
 
glCheckFramebufferStatus :: GLenum -> IO GLenum
glCheckFramebufferStatus
  = dyn_glCheckFramebufferStatus ptr_glCheckFramebufferStatus
 
{-# NOINLINE ptr_glCheckFramebufferStatus #-}
 
ptr_glCheckFramebufferStatus :: FunPtr a
ptr_glCheckFramebufferStatus
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glCheckFramebufferStatus"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClampColor ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glClampColor :: GLenum -> GLenum -> IO ()
glClampColor = dyn_glClampColor ptr_glClampColor
 
{-# NOINLINE ptr_glClampColor #-}
 
ptr_glClampColor :: FunPtr a
ptr_glClampColor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glClampColor"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearBufferfi ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLfloat -> GLint -> IO ())
 
glClearBufferfi :: GLenum -> GLint -> GLfloat -> GLint -> IO ()
glClearBufferfi = dyn_glClearBufferfi ptr_glClearBufferfi
 
{-# NOINLINE ptr_glClearBufferfi #-}
 
ptr_glClearBufferfi :: FunPtr a
ptr_glClearBufferfi
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glClearBufferfi"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearBufferfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLfloat -> IO ())
 
glClearBufferfv :: GLenum -> GLint -> Ptr GLfloat -> IO ()
glClearBufferfv = dyn_glClearBufferfv ptr_glClearBufferfv
 
{-# NOINLINE ptr_glClearBufferfv #-}
 
ptr_glClearBufferfv :: FunPtr a
ptr_glClearBufferfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glClearBufferfv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearBufferiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLint -> IO ())
 
glClearBufferiv :: GLenum -> GLint -> Ptr GLint -> IO ()
glClearBufferiv = dyn_glClearBufferiv ptr_glClearBufferiv
 
{-# NOINLINE ptr_glClearBufferiv #-}
 
ptr_glClearBufferiv :: FunPtr a
ptr_glClearBufferiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glClearBufferiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearBufferuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLuint -> IO ())
 
glClearBufferuiv :: GLenum -> GLint -> Ptr GLuint -> IO ()
glClearBufferuiv = dyn_glClearBufferuiv ptr_glClearBufferuiv
 
{-# NOINLINE ptr_glClearBufferuiv #-}
 
ptr_glClearBufferuiv :: FunPtr a
ptr_glClearBufferuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glClearBufferuiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorMaski ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
glColorMaski ::
             GLuint -> GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glColorMaski = dyn_glColorMaski ptr_glColorMaski
 
{-# NOINLINE ptr_glColorMaski #-}
 
ptr_glColorMaski :: FunPtr a
ptr_glColorMaski
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glColorMaski"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteFramebuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteFramebuffers :: GLsizei -> Ptr GLuint -> IO ()
glDeleteFramebuffers
  = dyn_glDeleteFramebuffers ptr_glDeleteFramebuffers
 
{-# NOINLINE ptr_glDeleteFramebuffers #-}
 
ptr_glDeleteFramebuffers :: FunPtr a
ptr_glDeleteFramebuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glDeleteFramebuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteRenderbuffers
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteRenderbuffers :: GLsizei -> Ptr GLuint -> IO ()
glDeleteRenderbuffers
  = dyn_glDeleteRenderbuffers ptr_glDeleteRenderbuffers
 
{-# NOINLINE ptr_glDeleteRenderbuffers #-}
 
ptr_glDeleteRenderbuffers :: FunPtr a
ptr_glDeleteRenderbuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glDeleteRenderbuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteVertexArrays ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteVertexArrays :: GLsizei -> Ptr GLuint -> IO ()
glDeleteVertexArrays
  = dyn_glDeleteVertexArrays ptr_glDeleteVertexArrays
 
{-# NOINLINE ptr_glDeleteVertexArrays #-}
 
ptr_glDeleteVertexArrays :: FunPtr a
ptr_glDeleteVertexArrays
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glDeleteVertexArrays"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDisablei ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDisablei :: GLenum -> GLuint -> IO ()
glDisablei = dyn_glDisablei ptr_glDisablei
 
{-# NOINLINE ptr_glDisablei #-}
 
ptr_glDisablei :: FunPtr a
ptr_glDisablei
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glDisablei"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEnablei ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glEnablei :: GLenum -> GLuint -> IO ()
glEnablei = dyn_glEnablei ptr_glEnablei
 
{-# NOINLINE ptr_glEnablei #-}
 
ptr_glEnablei :: FunPtr a
ptr_glEnablei
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glEnablei"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndConditionalRender
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glEndConditionalRender :: IO ()
glEndConditionalRender
  = dyn_glEndConditionalRender ptr_glEndConditionalRender
 
{-# NOINLINE ptr_glEndConditionalRender #-}
 
ptr_glEndConditionalRender :: FunPtr a
ptr_glEndConditionalRender
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glEndConditionalRender"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndTransformFeedback
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glEndTransformFeedback :: IO ()
glEndTransformFeedback
  = dyn_glEndTransformFeedback ptr_glEndTransformFeedback
 
{-# NOINLINE ptr_glEndTransformFeedback #-}
 
ptr_glEndTransformFeedback :: FunPtr a
ptr_glEndTransformFeedback
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glEndTransformFeedback"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFlushMappedBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> IO ())
 
glFlushMappedBufferRange ::
                         GLenum -> GLintptr -> GLsizeiptr -> IO ()
glFlushMappedBufferRange
  = dyn_glFlushMappedBufferRange ptr_glFlushMappedBufferRange
 
{-# NOINLINE ptr_glFlushMappedBufferRange #-}
 
ptr_glFlushMappedBufferRange :: FunPtr a
ptr_glFlushMappedBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFlushMappedBufferRange"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferRenderbuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLuint -> IO ())
 
glFramebufferRenderbuffer ::
                          GLenum -> GLenum -> GLenum -> GLuint -> IO ()
glFramebufferRenderbuffer
  = dyn_glFramebufferRenderbuffer ptr_glFramebufferRenderbuffer
 
{-# NOINLINE ptr_glFramebufferRenderbuffer #-}
 
ptr_glFramebufferRenderbuffer :: FunPtr a
ptr_glFramebufferRenderbuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFramebufferRenderbuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFramebufferTexture1D
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLuint -> GLint -> IO ())
 
glFramebufferTexture1D ::
                       GLenum -> GLenum -> GLenum -> GLuint -> GLint -> IO ()
glFramebufferTexture1D
  = dyn_glFramebufferTexture1D ptr_glFramebufferTexture1D
 
{-# NOINLINE ptr_glFramebufferTexture1D #-}
 
ptr_glFramebufferTexture1D :: FunPtr a
ptr_glFramebufferTexture1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFramebufferTexture1D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFramebufferTexture2D
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLuint -> GLint -> IO ())
 
glFramebufferTexture2D ::
                       GLenum -> GLenum -> GLenum -> GLuint -> GLint -> IO ()
glFramebufferTexture2D
  = dyn_glFramebufferTexture2D ptr_glFramebufferTexture2D
 
{-# NOINLINE ptr_glFramebufferTexture2D #-}
 
ptr_glFramebufferTexture2D :: FunPtr a
ptr_glFramebufferTexture2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFramebufferTexture2D"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFramebufferTexture3D
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ())
 
glFramebufferTexture3D ::
                       GLenum -> GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ()
glFramebufferTexture3D
  = dyn_glFramebufferTexture3D ptr_glFramebufferTexture3D
 
{-# NOINLINE ptr_glFramebufferTexture3D #-}
 
ptr_glFramebufferTexture3D :: FunPtr a
ptr_glFramebufferTexture3D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFramebufferTexture3D"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFramebufferTextureLayer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ())
 
glFramebufferTextureLayer ::
                          GLenum -> GLenum -> GLuint -> GLint -> GLint -> IO ()
glFramebufferTextureLayer
  = dyn_glFramebufferTextureLayer ptr_glFramebufferTextureLayer
 
{-# NOINLINE ptr_glFramebufferTextureLayer #-}
 
ptr_glFramebufferTextureLayer :: FunPtr a
ptr_glFramebufferTextureLayer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glFramebufferTextureLayer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenFramebuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenFramebuffers :: GLsizei -> Ptr GLuint -> IO ()
glGenFramebuffers = dyn_glGenFramebuffers ptr_glGenFramebuffers
 
{-# NOINLINE ptr_glGenFramebuffers #-}
 
ptr_glGenFramebuffers :: FunPtr a
ptr_glGenFramebuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGenFramebuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenRenderbuffers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenRenderbuffers :: GLsizei -> Ptr GLuint -> IO ()
glGenRenderbuffers = dyn_glGenRenderbuffers ptr_glGenRenderbuffers
 
{-# NOINLINE ptr_glGenRenderbuffers #-}
 
ptr_glGenRenderbuffers :: FunPtr a
ptr_glGenRenderbuffers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGenRenderbuffers"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenVertexArrays ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenVertexArrays :: GLsizei -> Ptr GLuint -> IO ()
glGenVertexArrays = dyn_glGenVertexArrays ptr_glGenVertexArrays
 
{-# NOINLINE ptr_glGenVertexArrays #-}
 
ptr_glGenVertexArrays :: FunPtr a
ptr_glGenVertexArrays
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGenVertexArrays"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenerateMipmap ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glGenerateMipmap :: GLenum -> IO ()
glGenerateMipmap = dyn_glGenerateMipmap ptr_glGenerateMipmap
 
{-# NOINLINE ptr_glGenerateMipmap #-}
 
ptr_glGenerateMipmap :: FunPtr a
ptr_glGenerateMipmap
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGenerateMipmap"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetBooleani_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLboolean -> IO ())
 
glGetBooleani_v :: GLenum -> GLuint -> Ptr GLboolean -> IO ()
glGetBooleani_v = dyn_glGetBooleani_v ptr_glGetBooleani_v
 
{-# NOINLINE ptr_glGetBooleani_v #-}
 
ptr_glGetBooleani_v :: FunPtr a
ptr_glGetBooleani_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetBooleani_v"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFragDataLocation
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLchar -> IO GLint)
 
glGetFragDataLocation :: GLuint -> Ptr GLchar -> IO GLint
glGetFragDataLocation
  = dyn_glGetFragDataLocation ptr_glGetFragDataLocation
 
{-# NOINLINE ptr_glGetFragDataLocation #-}
 
ptr_glGetFragDataLocation :: FunPtr a
ptr_glGetFragDataLocation
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetFragDataLocation"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFramebufferAttachmentParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetFramebufferAttachmentParameteriv ::
                                      GLenum -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetFramebufferAttachmentParameteriv
  = dyn_glGetFramebufferAttachmentParameteriv
      ptr_glGetFramebufferAttachmentParameteriv
 
{-# NOINLINE ptr_glGetFramebufferAttachmentParameteriv #-}
 
ptr_glGetFramebufferAttachmentParameteriv :: FunPtr a
ptr_glGetFramebufferAttachmentParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetFramebufferAttachmentParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegeri_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLint -> IO ())
 
glGetIntegeri_v :: GLenum -> GLuint -> Ptr GLint -> IO ()
glGetIntegeri_v = dyn_glGetIntegeri_v ptr_glGetIntegeri_v
 
{-# NOINLINE ptr_glGetIntegeri_v #-}
 
ptr_glGetIntegeri_v :: FunPtr a
ptr_glGetIntegeri_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetIntegeri_v"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetRenderbufferParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetRenderbufferParameteriv ::
                             GLenum -> GLenum -> Ptr GLint -> IO ()
glGetRenderbufferParameteriv
  = dyn_glGetRenderbufferParameteriv ptr_glGetRenderbufferParameteriv
 
{-# NOINLINE ptr_glGetRenderbufferParameteriv #-}
 
ptr_glGetRenderbufferParameteriv :: FunPtr a
ptr_glGetRenderbufferParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetRenderbufferParameteriv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetStringi ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO (Ptr GLubyte))
 
glGetStringi :: GLenum -> GLuint -> IO (Ptr GLubyte)
glGetStringi = dyn_glGetStringi ptr_glGetStringi
 
{-# NOINLINE ptr_glGetStringi #-}
 
ptr_glGetStringi :: FunPtr a
ptr_glGetStringi
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetStringi"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexParameterIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetTexParameterIiv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetTexParameterIiv
  = dyn_glGetTexParameterIiv ptr_glGetTexParameterIiv
 
{-# NOINLINE ptr_glGetTexParameterIiv #-}
 
ptr_glGetTexParameterIiv :: FunPtr a
ptr_glGetTexParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetTexParameterIiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexParameterIuiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glGetTexParameterIuiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glGetTexParameterIuiv
  = dyn_glGetTexParameterIuiv ptr_glGetTexParameterIuiv
 
{-# NOINLINE ptr_glGetTexParameterIuiv #-}
 
ptr_glGetTexParameterIuiv :: FunPtr a
ptr_glGetTexParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetTexParameterIuiv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetTransformFeedbackVarying ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLsizei ->
                        Ptr GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr GLchar -> IO ())
 
glGetTransformFeedbackVarying ::
                              GLuint ->
                                GLuint ->
                                  GLsizei ->
                                    Ptr GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr GLchar -> IO ()
glGetTransformFeedbackVarying
  = dyn_glGetTransformFeedbackVarying
      ptr_glGetTransformFeedbackVarying
 
{-# NOINLINE ptr_glGetTransformFeedbackVarying #-}
 
ptr_glGetTransformFeedbackVarying :: FunPtr a
ptr_glGetTransformFeedbackVarying
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetTransformFeedbackVarying"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> Ptr GLuint -> IO ())
 
glGetUniformuiv :: GLuint -> GLint -> Ptr GLuint -> IO ()
glGetUniformuiv = dyn_glGetUniformuiv ptr_glGetUniformuiv
 
{-# NOINLINE ptr_glGetUniformuiv #-}
 
ptr_glGetUniformuiv :: FunPtr a
ptr_glGetUniformuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetUniformuiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetVertexAttribIiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetVertexAttribIiv
  = dyn_glGetVertexAttribIiv ptr_glGetVertexAttribIiv
 
{-# NOINLINE ptr_glGetVertexAttribIiv #-}
 
ptr_glGetVertexAttribIiv :: FunPtr a
ptr_glGetVertexAttribIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetVertexAttribIiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribIuiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
glGetVertexAttribIuiv :: GLuint -> GLenum -> Ptr GLuint -> IO ()
glGetVertexAttribIuiv
  = dyn_glGetVertexAttribIuiv ptr_glGetVertexAttribIuiv
 
{-# NOINLINE ptr_glGetVertexAttribIuiv #-}
 
ptr_glGetVertexAttribIuiv :: FunPtr a
ptr_glGetVertexAttribIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glGetVertexAttribIuiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsEnabledi ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glIsEnabledi :: GLenum -> GLuint -> IO GLboolean
glIsEnabledi = dyn_glIsEnabledi ptr_glIsEnabledi
 
{-# NOINLINE ptr_glIsEnabledi #-}
 
ptr_glIsEnabledi :: FunPtr a
ptr_glIsEnabledi
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glIsEnabledi"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsFramebuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsFramebuffer :: GLuint -> IO GLboolean
glIsFramebuffer = dyn_glIsFramebuffer ptr_glIsFramebuffer
 
{-# NOINLINE ptr_glIsFramebuffer #-}
 
ptr_glIsFramebuffer :: FunPtr a
ptr_glIsFramebuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glIsFramebuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsRenderbuffer ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsRenderbuffer :: GLuint -> IO GLboolean
glIsRenderbuffer = dyn_glIsRenderbuffer ptr_glIsRenderbuffer
 
{-# NOINLINE ptr_glIsRenderbuffer #-}
 
ptr_glIsRenderbuffer :: FunPtr a
ptr_glIsRenderbuffer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glIsRenderbuffer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsVertexArray ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsVertexArray :: GLuint -> IO GLboolean
glIsVertexArray = dyn_glIsVertexArray ptr_glIsVertexArray
 
{-# NOINLINE ptr_glIsVertexArray #-}
 
ptr_glIsVertexArray :: FunPtr a
ptr_glIsVertexArray
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glIsVertexArray"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a))
 
glMapBufferRange ::
                 GLenum -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a)
glMapBufferRange = dyn_glMapBufferRange ptr_glMapBufferRange
 
{-# NOINLINE ptr_glMapBufferRange #-}
 
ptr_glMapBufferRange :: FunPtr a
ptr_glMapBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glMapBufferRange"
 
foreign import CALLCONV unsafe "dynamic" dyn_glRenderbufferStorage
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glRenderbufferStorage ::
                      GLenum -> GLenum -> GLsizei -> GLsizei -> IO ()
glRenderbufferStorage
  = dyn_glRenderbufferStorage ptr_glRenderbufferStorage
 
{-# NOINLINE ptr_glRenderbufferStorage #-}
 
ptr_glRenderbufferStorage :: FunPtr a
ptr_glRenderbufferStorage
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glRenderbufferStorage"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glRenderbufferStorageMultisample ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
glRenderbufferStorageMultisample ::
                                 GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glRenderbufferStorageMultisample
  = dyn_glRenderbufferStorageMultisample
      ptr_glRenderbufferStorageMultisample
 
{-# NOINLINE ptr_glRenderbufferStorageMultisample #-}
 
ptr_glRenderbufferStorageMultisample :: FunPtr a
ptr_glRenderbufferStorageMultisample
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glRenderbufferStorageMultisample"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameterIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glTexParameterIiv :: GLenum -> GLenum -> Ptr GLint -> IO ()
glTexParameterIiv = dyn_glTexParameterIiv ptr_glTexParameterIiv
 
{-# NOINLINE ptr_glTexParameterIiv #-}
 
ptr_glTexParameterIiv :: FunPtr a
ptr_glTexParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glTexParameterIiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexParameterIuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
glTexParameterIuiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glTexParameterIuiv = dyn_glTexParameterIuiv ptr_glTexParameterIuiv
 
{-# NOINLINE ptr_glTexParameterIuiv #-}
 
ptr_glTexParameterIuiv :: FunPtr a
ptr_glTexParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glTexParameterIuiv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTransformFeedbackVaryings ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr (Ptr GLchar) -> GLenum -> IO ())
 
glTransformFeedbackVaryings ::
                            GLuint -> GLsizei -> Ptr (Ptr GLchar) -> GLenum -> IO ()
glTransformFeedbackVaryings
  = dyn_glTransformFeedbackVaryings ptr_glTransformFeedbackVaryings
 
{-# NOINLINE ptr_glTransformFeedbackVaryings #-}
 
ptr_glTransformFeedbackVaryings :: FunPtr a
ptr_glTransformFeedbackVaryings
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glTransformFeedbackVaryings"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint -> IO ())
 
glUniform1ui :: GLint -> GLuint -> IO ()
glUniform1ui = dyn_glUniform1ui ptr_glUniform1ui
 
{-# NOINLINE ptr_glUniform1ui #-}
 
ptr_glUniform1ui :: FunPtr a
ptr_glUniform1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform1ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glUniform1uiv :: GLint -> GLsizei -> Ptr GLuint -> IO ()
glUniform1uiv = dyn_glUniform1uiv ptr_glUniform1uiv
 
{-# NOINLINE ptr_glUniform1uiv #-}
 
ptr_glUniform1uiv :: FunPtr a
ptr_glUniform1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform1uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint -> GLuint -> IO ())
 
glUniform2ui :: GLint -> GLuint -> GLuint -> IO ()
glUniform2ui = dyn_glUniform2ui ptr_glUniform2ui
 
{-# NOINLINE ptr_glUniform2ui #-}
 
ptr_glUniform2ui :: FunPtr a
ptr_glUniform2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform2ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glUniform2uiv :: GLint -> GLsizei -> Ptr GLuint -> IO ()
glUniform2uiv = dyn_glUniform2uiv ptr_glUniform2uiv
 
{-# NOINLINE ptr_glUniform2uiv #-}
 
ptr_glUniform2uiv :: FunPtr a
ptr_glUniform2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform2uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint -> GLuint -> GLuint -> IO ())
 
glUniform3ui :: GLint -> GLuint -> GLuint -> GLuint -> IO ()
glUniform3ui = dyn_glUniform3ui ptr_glUniform3ui
 
{-# NOINLINE ptr_glUniform3ui #-}
 
ptr_glUniform3ui :: FunPtr a
ptr_glUniform3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform3ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glUniform3uiv :: GLint -> GLsizei -> Ptr GLuint -> IO ()
glUniform3uiv = dyn_glUniform3uiv ptr_glUniform3uiv
 
{-# NOINLINE ptr_glUniform3uiv #-}
 
ptr_glUniform3uiv :: FunPtr a
ptr_glUniform3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform3uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glUniform4ui ::
             GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glUniform4ui = dyn_glUniform4ui ptr_glUniform4ui
 
{-# NOINLINE ptr_glUniform4ui #-}
 
ptr_glUniform4ui :: FunPtr a
ptr_glUniform4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform4ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glUniform4uiv :: GLint -> GLsizei -> Ptr GLuint -> IO ()
glUniform4uiv = dyn_glUniform4uiv ptr_glUniform4uiv
 
{-# NOINLINE ptr_glUniform4uiv #-}
 
ptr_glUniform4uiv :: FunPtr a
ptr_glUniform4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glUniform4uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> IO ())
 
glVertexAttribI1i :: GLuint -> GLint -> IO ()
glVertexAttribI1i = dyn_glVertexAttribI1i ptr_glVertexAttribI1i
 
{-# NOINLINE ptr_glVertexAttribI1i #-}
 
ptr_glVertexAttribI1i :: FunPtr a
ptr_glVertexAttribI1i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI1i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI1iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI1iv = dyn_glVertexAttribI1iv ptr_glVertexAttribI1iv
 
{-# NOINLINE ptr_glVertexAttribI1iv #-}
 
ptr_glVertexAttribI1iv :: FunPtr a
ptr_glVertexAttribI1iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI1iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glVertexAttribI1ui :: GLuint -> GLuint -> IO ()
glVertexAttribI1ui = dyn_glVertexAttribI1ui ptr_glVertexAttribI1ui
 
{-# NOINLINE ptr_glVertexAttribI1ui #-}
 
ptr_glVertexAttribI1ui :: FunPtr a
ptr_glVertexAttribI1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI1ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI1uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI1uiv
  = dyn_glVertexAttribI1uiv ptr_glVertexAttribI1uiv
 
{-# NOINLINE ptr_glVertexAttribI1uiv #-}
 
ptr_glVertexAttribI1uiv :: FunPtr a
ptr_glVertexAttribI1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI1uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> IO ())
 
glVertexAttribI2i :: GLuint -> GLint -> GLint -> IO ()
glVertexAttribI2i = dyn_glVertexAttribI2i ptr_glVertexAttribI2i
 
{-# NOINLINE ptr_glVertexAttribI2i #-}
 
ptr_glVertexAttribI2i :: FunPtr a
ptr_glVertexAttribI2i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI2i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI2iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI2iv = dyn_glVertexAttribI2iv ptr_glVertexAttribI2iv
 
{-# NOINLINE ptr_glVertexAttribI2iv #-}
 
ptr_glVertexAttribI2iv :: FunPtr a
ptr_glVertexAttribI2iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI2iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI2ui :: GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI2ui = dyn_glVertexAttribI2ui ptr_glVertexAttribI2ui
 
{-# NOINLINE ptr_glVertexAttribI2ui #-}
 
ptr_glVertexAttribI2ui :: FunPtr a
ptr_glVertexAttribI2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI2ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI2uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI2uiv
  = dyn_glVertexAttribI2uiv ptr_glVertexAttribI2uiv
 
{-# NOINLINE ptr_glVertexAttribI2uiv #-}
 
ptr_glVertexAttribI2uiv :: FunPtr a
ptr_glVertexAttribI2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI2uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> IO ())
 
glVertexAttribI3i :: GLuint -> GLint -> GLint -> GLint -> IO ()
glVertexAttribI3i = dyn_glVertexAttribI3i ptr_glVertexAttribI3i
 
{-# NOINLINE ptr_glVertexAttribI3i #-}
 
ptr_glVertexAttribI3i :: FunPtr a
ptr_glVertexAttribI3i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI3i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI3iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI3iv = dyn_glVertexAttribI3iv ptr_glVertexAttribI3iv
 
{-# NOINLINE ptr_glVertexAttribI3iv #-}
 
ptr_glVertexAttribI3iv :: FunPtr a
ptr_glVertexAttribI3iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI3iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI3ui :: GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI3ui = dyn_glVertexAttribI3ui ptr_glVertexAttribI3ui
 
{-# NOINLINE ptr_glVertexAttribI3ui #-}
 
ptr_glVertexAttribI3ui :: FunPtr a
ptr_glVertexAttribI3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI3ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI3uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI3uiv
  = dyn_glVertexAttribI3uiv ptr_glVertexAttribI3uiv
 
{-# NOINLINE ptr_glVertexAttribI3uiv #-}
 
ptr_glVertexAttribI3uiv :: FunPtr a
ptr_glVertexAttribI3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI3uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4bv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLbyte -> IO ())
 
glVertexAttribI4bv :: GLuint -> Ptr GLbyte -> IO ()
glVertexAttribI4bv = dyn_glVertexAttribI4bv ptr_glVertexAttribI4bv
 
{-# NOINLINE ptr_glVertexAttribI4bv #-}
 
ptr_glVertexAttribI4bv :: FunPtr a
ptr_glVertexAttribI4bv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4bv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glVertexAttribI4i ::
                  GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glVertexAttribI4i = dyn_glVertexAttribI4i ptr_glVertexAttribI4i
 
{-# NOINLINE ptr_glVertexAttribI4i #-}
 
ptr_glVertexAttribI4i :: FunPtr a
ptr_glVertexAttribI4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glVertexAttribI4iv :: GLuint -> Ptr GLint -> IO ()
glVertexAttribI4iv = dyn_glVertexAttribI4iv ptr_glVertexAttribI4iv
 
{-# NOINLINE ptr_glVertexAttribI4iv #-}
 
ptr_glVertexAttribI4iv :: FunPtr a
ptr_glVertexAttribI4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4sv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLshort -> IO ())
 
glVertexAttribI4sv :: GLuint -> Ptr GLshort -> IO ()
glVertexAttribI4sv = dyn_glVertexAttribI4sv ptr_glVertexAttribI4sv
 
{-# NOINLINE ptr_glVertexAttribI4sv #-}
 
ptr_glVertexAttribI4sv :: FunPtr a
ptr_glVertexAttribI4sv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4sv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4ubv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLubyte -> IO ())
 
glVertexAttribI4ubv :: GLuint -> Ptr GLubyte -> IO ()
glVertexAttribI4ubv
  = dyn_glVertexAttribI4ubv ptr_glVertexAttribI4ubv
 
{-# NOINLINE ptr_glVertexAttribI4ubv #-}
 
ptr_glVertexAttribI4ubv :: FunPtr a
ptr_glVertexAttribI4ubv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4ubv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glVertexAttribI4ui ::
                   GLuint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glVertexAttribI4ui = dyn_glVertexAttribI4ui ptr_glVertexAttribI4ui
 
{-# NOINLINE ptr_glVertexAttribI4ui #-}
 
ptr_glVertexAttribI4ui :: FunPtr a
ptr_glVertexAttribI4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLuint -> IO ())
 
glVertexAttribI4uiv :: GLuint -> Ptr GLuint -> IO ()
glVertexAttribI4uiv
  = dyn_glVertexAttribI4uiv ptr_glVertexAttribI4uiv
 
{-# NOINLINE ptr_glVertexAttribI4uiv #-}
 
ptr_glVertexAttribI4uiv :: FunPtr a
ptr_glVertexAttribI4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribI4usv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLushort -> IO ())
 
glVertexAttribI4usv :: GLuint -> Ptr GLushort -> IO ()
glVertexAttribI4usv
  = dyn_glVertexAttribI4usv ptr_glVertexAttribI4usv
 
{-# NOINLINE ptr_glVertexAttribI4usv #-}
 
ptr_glVertexAttribI4usv :: FunPtr a
ptr_glVertexAttribI4usv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribI4usv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribIPointer
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glVertexAttribIPointer ::
                       GLuint -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ()
glVertexAttribIPointer
  = dyn_glVertexAttribIPointer ptr_glVertexAttribIPointer
 
{-# NOINLINE ptr_glVertexAttribIPointer #-}
 
ptr_glVertexAttribIPointer :: FunPtr a
ptr_glVertexAttribIPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_0"
        "glVertexAttribIPointer"