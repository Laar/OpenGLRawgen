{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.Core.Core41
       (module Graphics.Rendering.OpenGL.Raw.Types, gl_ACTIVE_ATTRIBUTES,
        gl_ACTIVE_ATTRIBUTE_MAX_LENGTH, gl_ACTIVE_PROGRAM,
        gl_ACTIVE_SUBROUTINES, gl_ACTIVE_SUBROUTINE_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINE_UNIFORMS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH, gl_ACTIVE_TEXTURE,
        gl_ACTIVE_UNIFORMS, gl_ACTIVE_UNIFORM_BLOCKS,
        gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH,
        gl_ACTIVE_UNIFORM_MAX_LENGTH, gl_ALIASED_LINE_WIDTH_RANGE,
        gl_ALL_SHADER_BITS, gl_ALPHA, gl_ALREADY_SIGNALED, gl_ALWAYS,
        gl_AND, gl_AND_INVERTED, gl_AND_REVERSE, gl_ANY_SAMPLES_PASSED,
        gl_ARRAY_BUFFER, gl_ARRAY_BUFFER_BINDING, gl_ATTACHED_SHADERS,
        gl_BACK, gl_BACK_LEFT, gl_BACK_RIGHT, gl_BGR, gl_BGRA,
        gl_BGRA_INTEGER, gl_BGR_INTEGER, gl_BLEND, gl_BLEND_DST,
        gl_BLEND_DST_ALPHA, gl_BLEND_DST_RGB, gl_BLEND_EQUATION_ALPHA,
        gl_BLEND_EQUATION_RGB, gl_BLEND_SRC, gl_BLEND_SRC_ALPHA,
        gl_BLEND_SRC_RGB, gl_BLUE, gl_BLUE_INTEGER, gl_BOOL, gl_BOOL_VEC2,
        gl_BOOL_VEC3, gl_BOOL_VEC4, gl_BUFFER_ACCESS,
        gl_BUFFER_ACCESS_FLAGS, gl_BUFFER_MAPPED, gl_BUFFER_MAP_LENGTH,
        gl_BUFFER_MAP_OFFSET, gl_BUFFER_MAP_POINTER, gl_BUFFER_SIZE,
        gl_BUFFER_USAGE, gl_BYTE, gl_CCW, gl_CLAMP_READ_COLOR,
        gl_CLAMP_TO_BORDER, gl_CLAMP_TO_EDGE, gl_CLEAR, gl_CLIP_DISTANCE0,
        gl_CLIP_DISTANCE1, gl_CLIP_DISTANCE2, gl_CLIP_DISTANCE3,
        gl_CLIP_DISTANCE4, gl_CLIP_DISTANCE5, gl_CLIP_DISTANCE6,
        gl_CLIP_DISTANCE7, gl_COLOR, gl_COLOR_ATTACHMENT0,
        gl_COLOR_ATTACHMENT1, gl_COLOR_ATTACHMENT10, gl_COLOR_ATTACHMENT11,
        gl_COLOR_ATTACHMENT12, gl_COLOR_ATTACHMENT13,
        gl_COLOR_ATTACHMENT14, gl_COLOR_ATTACHMENT15, gl_COLOR_ATTACHMENT2,
        gl_COLOR_ATTACHMENT3, gl_COLOR_ATTACHMENT4, gl_COLOR_ATTACHMENT5,
        gl_COLOR_ATTACHMENT6, gl_COLOR_ATTACHMENT7, gl_COLOR_ATTACHMENT8,
        gl_COLOR_ATTACHMENT9, gl_COLOR_BUFFER_BIT, gl_COLOR_CLEAR_VALUE,
        gl_COLOR_LOGIC_OP, gl_COLOR_WRITEMASK, gl_COMPARE_REF_TO_TEXTURE,
        gl_COMPATIBLE_SUBROUTINES, gl_COMPILE_STATUS, gl_COMPRESSED_RED,
        gl_COMPRESSED_RED_RGTC1, gl_COMPRESSED_RG, gl_COMPRESSED_RGB,
        gl_COMPRESSED_RGBA, gl_COMPRESSED_RG_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1, gl_COMPRESSED_SIGNED_RG_RGTC2,
        gl_COMPRESSED_SRGB, gl_COMPRESSED_SRGB_ALPHA,
        gl_COMPRESSED_TEXTURE_FORMATS, gl_CONDITION_SATISFIED,
        gl_CONSTANT_ALPHA, gl_CONSTANT_COLOR,
        gl_CONTEXT_COMPATIBILITY_PROFILE_BIT, gl_CONTEXT_CORE_PROFILE_BIT,
        gl_CONTEXT_FLAGS, gl_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT,
        gl_CONTEXT_PROFILE_MASK, gl_COPY, gl_COPY_INVERTED,
        gl_COPY_READ_BUFFER, gl_COPY_WRITE_BUFFER, gl_CULL_FACE,
        gl_CULL_FACE_MODE, gl_CURRENT_PROGRAM, gl_CURRENT_QUERY,
        gl_CURRENT_VERTEX_ATTRIB, gl_CW, gl_DECR, gl_DECR_WRAP,
        gl_DELETE_STATUS, gl_DEPTH, gl_DEPTH24_STENCIL8,
        gl_DEPTH32F_STENCIL8, gl_DEPTH_ATTACHMENT, gl_DEPTH_BUFFER_BIT,
        gl_DEPTH_CLAMP, gl_DEPTH_CLEAR_VALUE, gl_DEPTH_COMPONENT,
        gl_DEPTH_COMPONENT16, gl_DEPTH_COMPONENT24, gl_DEPTH_COMPONENT32,
        gl_DEPTH_COMPONENT32F, gl_DEPTH_FUNC, gl_DEPTH_RANGE,
        gl_DEPTH_STENCIL, gl_DEPTH_STENCIL_ATTACHMENT, gl_DEPTH_TEST,
        gl_DEPTH_WRITEMASK, gl_DITHER, gl_DONT_CARE, gl_DOUBLE,
        gl_DOUBLEBUFFER, gl_DOUBLE_MAT2, gl_DOUBLE_MAT2x3,
        gl_DOUBLE_MAT2x4, gl_DOUBLE_MAT3, gl_DOUBLE_MAT3x2,
        gl_DOUBLE_MAT3x4, gl_DOUBLE_MAT4, gl_DOUBLE_MAT4x2,
        gl_DOUBLE_MAT4x3, gl_DOUBLE_VEC2, gl_DOUBLE_VEC3, gl_DOUBLE_VEC4,
        gl_DRAW_BUFFER, gl_DRAW_BUFFER0, gl_DRAW_BUFFER1, gl_DRAW_BUFFER10,
        gl_DRAW_BUFFER11, gl_DRAW_BUFFER12, gl_DRAW_BUFFER13,
        gl_DRAW_BUFFER14, gl_DRAW_BUFFER15, gl_DRAW_BUFFER2,
        gl_DRAW_BUFFER3, gl_DRAW_BUFFER4, gl_DRAW_BUFFER5, gl_DRAW_BUFFER6,
        gl_DRAW_BUFFER7, gl_DRAW_BUFFER8, gl_DRAW_BUFFER9,
        gl_DRAW_FRAMEBUFFER, gl_DRAW_FRAMEBUFFER_BINDING,
        gl_DRAW_INDIRECT_BUFFER, gl_DRAW_INDIRECT_BUFFER_BINDING,
        gl_DST_ALPHA, gl_DST_COLOR, gl_DYNAMIC_COPY, gl_DYNAMIC_DRAW,
        gl_DYNAMIC_READ, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING, gl_EQUAL, gl_EQUIV, gl_EXTENSIONS,
        gl_FALSE, gl_FASTEST, gl_FILL, gl_FIRST_VERTEX_CONVENTION,
        gl_FIXED, gl_FIXED_ONLY, gl_FLOAT,
        gl_FLOAT_32_UNSIGNED_INT_24_8_REV, gl_FLOAT_MAT2, gl_FLOAT_MAT2x3,
        gl_FLOAT_MAT2x4, gl_FLOAT_MAT3, gl_FLOAT_MAT3x2, gl_FLOAT_MAT3x4,
        gl_FLOAT_MAT4, gl_FLOAT_MAT4x2, gl_FLOAT_MAT4x3, gl_FLOAT_VEC2,
        gl_FLOAT_VEC3, gl_FLOAT_VEC4, gl_FRACTIONAL_EVEN,
        gl_FRACTIONAL_ODD, gl_FRAGMENT_INTERPOLATION_OFFSET_BITS,
        gl_FRAGMENT_SHADER, gl_FRAGMENT_SHADER_BIT,
        gl_FRAGMENT_SHADER_DERIVATIVE_HINT, gl_FRAMEBUFFER,
        gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING,
        gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_LAYERED,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL, gl_FRAMEBUFFER_BINDING,
        gl_FRAMEBUFFER_COMPLETE, gl_FRAMEBUFFER_DEFAULT,
        gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER,
        gl_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS,
        gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE,
        gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER, gl_FRAMEBUFFER_SRGB,
        gl_FRAMEBUFFER_UNDEFINED, gl_FRAMEBUFFER_UNSUPPORTED, gl_FRONT,
        gl_FRONT_AND_BACK, gl_FRONT_FACE, gl_FRONT_LEFT, gl_FRONT_RIGHT,
        gl_FUNC_ADD, gl_FUNC_REVERSE_SUBTRACT, gl_FUNC_SUBTRACT,
        gl_GEOMETRY_INPUT_TYPE, gl_GEOMETRY_OUTPUT_TYPE,
        gl_GEOMETRY_SHADER, gl_GEOMETRY_SHADER_BIT,
        gl_GEOMETRY_SHADER_INVOCATIONS, gl_GEOMETRY_VERTICES_OUT,
        gl_GEQUAL, gl_GREATER, gl_GREEN, gl_GREEN_INTEGER, gl_HALF_FLOAT,
        gl_HIGH_FLOAT, gl_HIGH_INT, gl_IMPLEMENTATION_COLOR_READ_FORMAT,
        gl_IMPLEMENTATION_COLOR_READ_TYPE, gl_INCR, gl_INCR_WRAP,
        gl_INFO_LOG_LENGTH, gl_INT, gl_INTERLEAVED_ATTRIBS,
        gl_INT_2_10_10_10_REV, gl_INT_SAMPLER_1D, gl_INT_SAMPLER_1D_ARRAY,
        gl_INT_SAMPLER_2D, gl_INT_SAMPLER_2D_ARRAY,
        gl_INT_SAMPLER_2D_MULTISAMPLE, gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_INT_SAMPLER_2D_RECT, gl_INT_SAMPLER_3D, gl_INT_SAMPLER_BUFFER,
        gl_INT_SAMPLER_CUBE, gl_INT_SAMPLER_CUBE_MAP_ARRAY, gl_INT_VEC2,
        gl_INT_VEC3, gl_INT_VEC4, gl_INVALID_ENUM,
        gl_INVALID_FRAMEBUFFER_OPERATION, gl_INVALID_INDEX,
        gl_INVALID_OPERATION, gl_INVALID_VALUE, gl_INVERT, gl_ISOLINES,
        gl_KEEP, gl_LAST_VERTEX_CONVENTION, gl_LAYER_PROVOKING_VERTEX,
        gl_LEFT, gl_LEQUAL, gl_LESS, gl_LINE, gl_LINEAR,
        gl_LINEAR_MIPMAP_LINEAR, gl_LINEAR_MIPMAP_NEAREST, gl_LINES,
        gl_LINES_ADJACENCY, gl_LINE_LOOP, gl_LINE_SMOOTH,
        gl_LINE_SMOOTH_HINT, gl_LINE_STRIP, gl_LINE_STRIP_ADJACENCY,
        gl_LINE_WIDTH, gl_LINE_WIDTH_GRANULARITY, gl_LINE_WIDTH_RANGE,
        gl_LINK_STATUS, gl_LOGIC_OP_MODE, gl_LOWER_LEFT, gl_LOW_FLOAT,
        gl_LOW_INT, gl_MAJOR_VERSION, gl_MAP_FLUSH_EXPLICIT_BIT,
        gl_MAP_INVALIDATE_BUFFER_BIT, gl_MAP_INVALIDATE_RANGE_BIT,
        gl_MAP_READ_BIT, gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_WRITE_BIT,
        gl_MAX, gl_MAX_3D_TEXTURE_SIZE, gl_MAX_ARRAY_TEXTURE_LAYERS,
        gl_MAX_CLIP_DISTANCES, gl_MAX_COLOR_ATTACHMENTS,
        gl_MAX_COLOR_TEXTURE_SAMPLES,
        gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS,
        gl_MAX_COMBINED_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS,
        gl_MAX_CUBE_MAP_TEXTURE_SIZE, gl_MAX_DEPTH_TEXTURE_SAMPLES,
        gl_MAX_DRAW_BUFFERS, gl_MAX_DUAL_SOURCE_DRAW_BUFFERS,
        gl_MAX_ELEMENTS_INDICES, gl_MAX_ELEMENTS_VERTICES,
        gl_MAX_FRAGMENT_INPUT_COMPONENTS,
        gl_MAX_FRAGMENT_INTERPOLATION_OFFSET,
        gl_MAX_FRAGMENT_UNIFORM_BLOCKS, gl_MAX_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_FRAGMENT_UNIFORM_VECTORS, gl_MAX_GEOMETRY_INPUT_COMPONENTS,
        gl_MAX_GEOMETRY_OUTPUT_COMPONENTS, gl_MAX_GEOMETRY_OUTPUT_VERTICES,
        gl_MAX_GEOMETRY_SHADER_INVOCATIONS,
        gl_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS,
        gl_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_GEOMETRY_UNIFORM_COMPONENTS, gl_MAX_INTEGER_SAMPLES,
        gl_MAX_PATCH_VERTICES, gl_MAX_PROGRAM_TEXEL_OFFSET,
        gl_MAX_PROGRAM_TEXTURE_GATHER_OFFSET,
        gl_MAX_RECTANGLE_TEXTURE_SIZE, gl_MAX_RENDERBUFFER_SIZE,
        gl_MAX_SAMPLES, gl_MAX_SAMPLE_MASK_WORDS,
        gl_MAX_SERVER_WAIT_TIMEOUT, gl_MAX_SUBROUTINES,
        gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_MAX_TESS_CONTROL_INPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_UNIFORM_BLOCKS,
        gl_MAX_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_TESS_EVALUATION_INPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_EVALUATION_UNIFORM_BLOCKS,
        gl_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS, gl_MAX_TESS_GEN_LEVEL,
        gl_MAX_TESS_PATCH_COMPONENTS, gl_MAX_TEXTURE_BUFFER_SIZE,
        gl_MAX_TEXTURE_IMAGE_UNITS, gl_MAX_TEXTURE_LOD_BIAS,
        gl_MAX_TEXTURE_SIZE, gl_MAX_TRANSFORM_FEEDBACK_BUFFERS,
        gl_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS,
        gl_MAX_UNIFORM_BLOCK_SIZE, gl_MAX_UNIFORM_BUFFER_BINDINGS,
        gl_MAX_VARYING_COMPONENTS, gl_MAX_VARYING_FLOATS,
        gl_MAX_VARYING_VECTORS, gl_MAX_VERTEX_ATTRIBS,
        gl_MAX_VERTEX_OUTPUT_COMPONENTS, gl_MAX_VERTEX_STREAMS,
        gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS, gl_MAX_VERTEX_UNIFORM_BLOCKS,
        gl_MAX_VERTEX_UNIFORM_COMPONENTS, gl_MAX_VERTEX_UNIFORM_VECTORS,
        gl_MAX_VIEWPORTS, gl_MAX_VIEWPORT_DIMS, gl_MEDIUM_FLOAT,
        gl_MEDIUM_INT, gl_MIN, gl_MINOR_VERSION,
        gl_MIN_FRAGMENT_INTERPOLATION_OFFSET, gl_MIN_PROGRAM_TEXEL_OFFSET,
        gl_MIN_PROGRAM_TEXTURE_GATHER_OFFSET, gl_MIN_SAMPLE_SHADING_VALUE,
        gl_MIRRORED_REPEAT, gl_MULTISAMPLE, gl_NAND, gl_NEAREST,
        gl_NEAREST_MIPMAP_LINEAR, gl_NEAREST_MIPMAP_NEAREST, gl_NEVER,
        gl_NICEST, gl_NONE, gl_NOOP, gl_NOR, gl_NOTEQUAL, gl_NO_ERROR,
        gl_NUM_COMPATIBLE_SUBROUTINES, gl_NUM_COMPRESSED_TEXTURE_FORMATS,
        gl_NUM_EXTENSIONS, gl_NUM_PROGRAM_BINARY_FORMATS,
        gl_NUM_SHADER_BINARY_FORMATS, gl_OBJECT_TYPE, gl_ONE,
        gl_ONE_MINUS_CONSTANT_ALPHA, gl_ONE_MINUS_CONSTANT_COLOR,
        gl_ONE_MINUS_DST_ALPHA, gl_ONE_MINUS_DST_COLOR,
        gl_ONE_MINUS_SRC1_ALPHA, gl_ONE_MINUS_SRC1_COLOR,
        gl_ONE_MINUS_SRC_ALPHA, gl_ONE_MINUS_SRC_COLOR, gl_OR,
        gl_OR_INVERTED, gl_OR_REVERSE, gl_OUT_OF_MEMORY, gl_PACK_ALIGNMENT,
        gl_PACK_IMAGE_HEIGHT, gl_PACK_LSB_FIRST, gl_PACK_ROW_LENGTH,
        gl_PACK_SKIP_IMAGES, gl_PACK_SKIP_PIXELS, gl_PACK_SKIP_ROWS,
        gl_PACK_SWAP_BYTES, gl_PATCHES, gl_PATCH_DEFAULT_INNER_LEVEL,
        gl_PATCH_DEFAULT_OUTER_LEVEL, gl_PATCH_VERTICES,
        gl_PIXEL_PACK_BUFFER, gl_PIXEL_PACK_BUFFER_BINDING,
        gl_PIXEL_UNPACK_BUFFER, gl_PIXEL_UNPACK_BUFFER_BINDING, gl_POINT,
        gl_POINTS, gl_POINT_FADE_THRESHOLD_SIZE, gl_POINT_SIZE,
        gl_POINT_SIZE_GRANULARITY, gl_POINT_SIZE_RANGE,
        gl_POINT_SPRITE_COORD_ORIGIN, gl_POLYGON_MODE,
        gl_POLYGON_OFFSET_FACTOR, gl_POLYGON_OFFSET_FILL,
        gl_POLYGON_OFFSET_LINE, gl_POLYGON_OFFSET_POINT,
        gl_POLYGON_OFFSET_UNITS, gl_POLYGON_SMOOTH, gl_POLYGON_SMOOTH_HINT,
        gl_PRIMITIVES_GENERATED, gl_PRIMITIVE_RESTART,
        gl_PRIMITIVE_RESTART_INDEX, gl_PROGRAM_BINARY_FORMATS,
        gl_PROGRAM_BINARY_LENGTH, gl_PROGRAM_BINARY_RETRIEVABLE_HINT,
        gl_PROGRAM_PIPELINE_BINDING, gl_PROGRAM_POINT_SIZE,
        gl_PROGRAM_SEPARABLE, gl_PROVOKING_VERTEX, gl_PROXY_TEXTURE_1D,
        gl_PROXY_TEXTURE_1D_ARRAY, gl_PROXY_TEXTURE_2D,
        gl_PROXY_TEXTURE_2D_ARRAY, gl_PROXY_TEXTURE_2D_MULTISAMPLE,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY, gl_PROXY_TEXTURE_3D,
        gl_PROXY_TEXTURE_CUBE_MAP, gl_PROXY_TEXTURE_CUBE_MAP_ARRAY,
        gl_PROXY_TEXTURE_RECTANGLE, gl_QUADS,
        gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION,
        gl_QUERY_BY_REGION_NO_WAIT, gl_QUERY_BY_REGION_WAIT,
        gl_QUERY_COUNTER_BITS, gl_QUERY_NO_WAIT, gl_QUERY_RESULT,
        gl_QUERY_RESULT_AVAILABLE, gl_QUERY_WAIT, gl_R11F_G11F_B10F,
        gl_R16, gl_R16F, gl_R16I, gl_R16UI, gl_R16_SNORM, gl_R32F, gl_R32I,
        gl_R32UI, gl_R3_G3_B2, gl_R8, gl_R8I, gl_R8UI, gl_R8_SNORM,
        gl_RASTERIZER_DISCARD, gl_READ_BUFFER, gl_READ_FRAMEBUFFER,
        gl_READ_FRAMEBUFFER_BINDING, gl_READ_ONLY, gl_READ_WRITE, gl_RED,
        gl_RED_INTEGER, gl_RENDERBUFFER, gl_RENDERBUFFER_ALPHA_SIZE,
        gl_RENDERBUFFER_BINDING, gl_RENDERBUFFER_BLUE_SIZE,
        gl_RENDERBUFFER_DEPTH_SIZE, gl_RENDERBUFFER_GREEN_SIZE,
        gl_RENDERBUFFER_HEIGHT, gl_RENDERBUFFER_INTERNAL_FORMAT,
        gl_RENDERBUFFER_RED_SIZE, gl_RENDERBUFFER_SAMPLES,
        gl_RENDERBUFFER_STENCIL_SIZE, gl_RENDERBUFFER_WIDTH, gl_RENDERER,
        gl_REPEAT, gl_REPLACE, gl_RG, gl_RG16, gl_RG16F, gl_RG16I,
        gl_RG16UI, gl_RG16_SNORM, gl_RG32F, gl_RG32I, gl_RG32UI, gl_RG8,
        gl_RG8I, gl_RG8UI, gl_RG8_SNORM, gl_RGB, gl_RGB10, gl_RGB10_A2,
        gl_RGB10_A2UI, gl_RGB12, gl_RGB16, gl_RGB16F, gl_RGB16I,
        gl_RGB16UI, gl_RGB16_SNORM, gl_RGB32F, gl_RGB32I, gl_RGB32UI,
        gl_RGB4, gl_RGB5, gl_RGB565, gl_RGB5_A1, gl_RGB8, gl_RGB8I,
        gl_RGB8UI, gl_RGB8_SNORM, gl_RGB9_E5, gl_RGBA, gl_RGBA12,
        gl_RGBA16, gl_RGBA16F, gl_RGBA16I, gl_RGBA16UI, gl_RGBA16_SNORM,
        gl_RGBA2, gl_RGBA32F, gl_RGBA32I, gl_RGBA32UI, gl_RGBA4, gl_RGBA8,
        gl_RGBA8I, gl_RGBA8UI, gl_RGBA8_SNORM, gl_RGBA_INTEGER,
        gl_RGB_INTEGER, gl_RG_INTEGER, gl_RIGHT, gl_SAMPLER_1D,
        gl_SAMPLER_1D_ARRAY, gl_SAMPLER_1D_ARRAY_SHADOW,
        gl_SAMPLER_1D_SHADOW, gl_SAMPLER_2D, gl_SAMPLER_2D_ARRAY,
        gl_SAMPLER_2D_ARRAY_SHADOW, gl_SAMPLER_2D_MULTISAMPLE,
        gl_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_SAMPLER_2D_RECT,
        gl_SAMPLER_2D_RECT_SHADOW, gl_SAMPLER_2D_SHADOW, gl_SAMPLER_3D,
        gl_SAMPLER_BINDING, gl_SAMPLER_BUFFER, gl_SAMPLER_CUBE,
        gl_SAMPLER_CUBE_MAP_ARRAY, gl_SAMPLER_CUBE_MAP_ARRAY_SHADOW,
        gl_SAMPLER_CUBE_SHADOW, gl_SAMPLES, gl_SAMPLES_PASSED,
        gl_SAMPLE_ALPHA_TO_COVERAGE, gl_SAMPLE_ALPHA_TO_ONE,
        gl_SAMPLE_BUFFERS, gl_SAMPLE_COVERAGE, gl_SAMPLE_COVERAGE_INVERT,
        gl_SAMPLE_COVERAGE_VALUE, gl_SAMPLE_MASK, gl_SAMPLE_MASK_VALUE,
        gl_SAMPLE_POSITION, gl_SAMPLE_SHADING, gl_SCISSOR_BOX,
        gl_SCISSOR_TEST, gl_SEPARATE_ATTRIBS, gl_SET,
        gl_SHADER_BINARY_FORMATS, gl_SHADER_COMPILER,
        gl_SHADER_SOURCE_LENGTH, gl_SHADER_TYPE,
        gl_SHADING_LANGUAGE_VERSION, gl_SHORT, gl_SIGNALED,
        gl_SIGNED_NORMALIZED, gl_SMOOTH_LINE_WIDTH_GRANULARITY,
        gl_SMOOTH_LINE_WIDTH_RANGE, gl_SMOOTH_POINT_SIZE_GRANULARITY,
        gl_SMOOTH_POINT_SIZE_RANGE, gl_SRC1_ALPHA, gl_SRC1_COLOR,
        gl_SRC_ALPHA, gl_SRC_ALPHA_SATURATE, gl_SRC_COLOR, gl_SRGB,
        gl_SRGB8, gl_SRGB8_ALPHA8, gl_SRGB_ALPHA, gl_STATIC_COPY,
        gl_STATIC_DRAW, gl_STATIC_READ, gl_STENCIL, gl_STENCIL_ATTACHMENT,
        gl_STENCIL_BACK_FAIL, gl_STENCIL_BACK_FUNC,
        gl_STENCIL_BACK_PASS_DEPTH_FAIL, gl_STENCIL_BACK_PASS_DEPTH_PASS,
        gl_STENCIL_BACK_REF, gl_STENCIL_BACK_VALUE_MASK,
        gl_STENCIL_BACK_WRITEMASK, gl_STENCIL_BUFFER_BIT,
        gl_STENCIL_CLEAR_VALUE, gl_STENCIL_FAIL, gl_STENCIL_FUNC,
        gl_STENCIL_INDEX, gl_STENCIL_INDEX1, gl_STENCIL_INDEX16,
        gl_STENCIL_INDEX4, gl_STENCIL_INDEX8, gl_STENCIL_PASS_DEPTH_FAIL,
        gl_STENCIL_PASS_DEPTH_PASS, gl_STENCIL_REF, gl_STENCIL_TEST,
        gl_STENCIL_VALUE_MASK, gl_STENCIL_WRITEMASK, gl_STEREO,
        gl_STREAM_COPY, gl_STREAM_DRAW, gl_STREAM_READ, gl_SUBPIXEL_BITS,
        gl_SYNC_CONDITION, gl_SYNC_FENCE, gl_SYNC_FLAGS,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_STATUS, gl_TESS_CONTROL_OUTPUT_VERTICES,
        gl_TESS_CONTROL_SHADER, gl_TESS_CONTROL_SHADER_BIT,
        gl_TESS_EVALUATION_SHADER, gl_TESS_EVALUATION_SHADER_BIT,
        gl_TESS_GEN_MODE, gl_TESS_GEN_POINT_MODE, gl_TESS_GEN_SPACING,
        gl_TESS_GEN_VERTEX_ORDER, gl_TEXTURE, gl_TEXTURE0, gl_TEXTURE1,
        gl_TEXTURE10, gl_TEXTURE11, gl_TEXTURE12, gl_TEXTURE13,
        gl_TEXTURE14, gl_TEXTURE15, gl_TEXTURE16, gl_TEXTURE17,
        gl_TEXTURE18, gl_TEXTURE19, gl_TEXTURE2, gl_TEXTURE20,
        gl_TEXTURE21, gl_TEXTURE22, gl_TEXTURE23, gl_TEXTURE24,
        gl_TEXTURE25, gl_TEXTURE26, gl_TEXTURE27, gl_TEXTURE28,
        gl_TEXTURE29, gl_TEXTURE3, gl_TEXTURE30, gl_TEXTURE31, gl_TEXTURE4,
        gl_TEXTURE5, gl_TEXTURE6, gl_TEXTURE7, gl_TEXTURE8, gl_TEXTURE9,
        gl_TEXTURE_1D, gl_TEXTURE_1D_ARRAY, gl_TEXTURE_2D,
        gl_TEXTURE_2D_ARRAY, gl_TEXTURE_2D_MULTISAMPLE,
        gl_TEXTURE_2D_MULTISAMPLE_ARRAY, gl_TEXTURE_3D,
        gl_TEXTURE_ALPHA_SIZE, gl_TEXTURE_ALPHA_TYPE,
        gl_TEXTURE_BASE_LEVEL, gl_TEXTURE_BINDING_1D,
        gl_TEXTURE_BINDING_1D_ARRAY, gl_TEXTURE_BINDING_2D,
        gl_TEXTURE_BINDING_2D_ARRAY, gl_TEXTURE_BINDING_2D_MULTISAMPLE,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY, gl_TEXTURE_BINDING_3D,
        gl_TEXTURE_BINDING_BUFFER, gl_TEXTURE_BINDING_CUBE_MAP,
        gl_TEXTURE_BINDING_CUBE_MAP_ARRAY, gl_TEXTURE_BINDING_RECTANGLE,
        gl_TEXTURE_BLUE_SIZE, gl_TEXTURE_BLUE_TYPE,
        gl_TEXTURE_BORDER_COLOR, gl_TEXTURE_BUFFER,
        gl_TEXTURE_BUFFER_DATA_STORE_BINDING, gl_TEXTURE_COMPARE_FUNC,
        gl_TEXTURE_COMPARE_MODE, gl_TEXTURE_COMPRESSED,
        gl_TEXTURE_COMPRESSED_IMAGE_SIZE, gl_TEXTURE_COMPRESSION_HINT,
        gl_TEXTURE_CUBE_MAP, gl_TEXTURE_CUBE_MAP_ARRAY,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_X, gl_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_Z, gl_TEXTURE_CUBE_MAP_POSITIVE_X,
        gl_TEXTURE_CUBE_MAP_POSITIVE_Y, gl_TEXTURE_CUBE_MAP_POSITIVE_Z,
        gl_TEXTURE_CUBE_MAP_SEAMLESS, gl_TEXTURE_DEPTH,
        gl_TEXTURE_DEPTH_SIZE, gl_TEXTURE_DEPTH_TYPE,
        gl_TEXTURE_FIXED_SAMPLE_LOCATIONS, gl_TEXTURE_GREEN_SIZE,
        gl_TEXTURE_GREEN_TYPE, gl_TEXTURE_HEIGHT,
        gl_TEXTURE_INTERNAL_FORMAT, gl_TEXTURE_LOD_BIAS,
        gl_TEXTURE_MAG_FILTER, gl_TEXTURE_MAX_LEVEL, gl_TEXTURE_MAX_LOD,
        gl_TEXTURE_MIN_FILTER, gl_TEXTURE_MIN_LOD, gl_TEXTURE_RECTANGLE,
        gl_TEXTURE_RED_SIZE, gl_TEXTURE_RED_TYPE, gl_TEXTURE_SAMPLES,
        gl_TEXTURE_SHARED_SIZE, gl_TEXTURE_STENCIL_SIZE,
        gl_TEXTURE_SWIZZLE_A, gl_TEXTURE_SWIZZLE_B, gl_TEXTURE_SWIZZLE_G,
        gl_TEXTURE_SWIZZLE_R, gl_TEXTURE_SWIZZLE_RGBA, gl_TEXTURE_WIDTH,
        gl_TEXTURE_WRAP_R, gl_TEXTURE_WRAP_S, gl_TEXTURE_WRAP_T,
        gl_TIMEOUT_EXPIRED, gl_TIMEOUT_IGNORED, gl_TIMESTAMP,
        gl_TIME_ELAPSED, gl_TRANSFORM_FEEDBACK,
        gl_TRANSFORM_FEEDBACK_BINDING, gl_TRANSFORM_FEEDBACK_BUFFER,
        gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_BINDING,
        gl_TRANSFORM_FEEDBACK_BUFFER_MODE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED,
        gl_TRANSFORM_FEEDBACK_BUFFER_SIZE,
        gl_TRANSFORM_FEEDBACK_BUFFER_START,
        gl_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN,
        gl_TRANSFORM_FEEDBACK_VARYINGS,
        gl_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH, gl_TRIANGLES,
        gl_TRIANGLES_ADJACENCY, gl_TRIANGLE_FAN, gl_TRIANGLE_STRIP,
        gl_TRIANGLE_STRIP_ADJACENCY, gl_TRUE, gl_UNDEFINED_VERTEX,
        gl_UNIFORM_ARRAY_STRIDE, gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES, gl_UNIFORM_BLOCK_BINDING,
        gl_UNIFORM_BLOCK_DATA_SIZE, gl_UNIFORM_BLOCK_INDEX,
        gl_UNIFORM_BLOCK_NAME_LENGTH,
        gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER, gl_UNIFORM_BUFFER,
        gl_UNIFORM_BUFFER_BINDING, gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT,
        gl_UNIFORM_BUFFER_SIZE, gl_UNIFORM_BUFFER_START,
        gl_UNIFORM_IS_ROW_MAJOR, gl_UNIFORM_MATRIX_STRIDE,
        gl_UNIFORM_NAME_LENGTH, gl_UNIFORM_OFFSET, gl_UNIFORM_SIZE,
        gl_UNIFORM_TYPE, gl_UNPACK_ALIGNMENT, gl_UNPACK_IMAGE_HEIGHT,
        gl_UNPACK_LSB_FIRST, gl_UNPACK_ROW_LENGTH, gl_UNPACK_SKIP_IMAGES,
        gl_UNPACK_SKIP_PIXELS, gl_UNPACK_SKIP_ROWS, gl_UNPACK_SWAP_BYTES,
        gl_UNSIGNALED, gl_UNSIGNED_BYTE, gl_UNSIGNED_BYTE_2_3_3_REV,
        gl_UNSIGNED_BYTE_3_3_2, gl_UNSIGNED_INT,
        gl_UNSIGNED_INT_10F_11F_11F_REV, gl_UNSIGNED_INT_10_10_10_2,
        gl_UNSIGNED_INT_24_8, gl_UNSIGNED_INT_2_10_10_10_REV,
        gl_UNSIGNED_INT_5_9_9_9_REV, gl_UNSIGNED_INT_8_8_8_8,
        gl_UNSIGNED_INT_8_8_8_8_REV, gl_UNSIGNED_INT_SAMPLER_1D,
        gl_UNSIGNED_INT_SAMPLER_1D_ARRAY, gl_UNSIGNED_INT_SAMPLER_2D,
        gl_UNSIGNED_INT_SAMPLER_2D_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_2D_RECT, gl_UNSIGNED_INT_SAMPLER_3D,
        gl_UNSIGNED_INT_SAMPLER_BUFFER, gl_UNSIGNED_INT_SAMPLER_CUBE,
        gl_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY, gl_UNSIGNED_INT_VEC2,
        gl_UNSIGNED_INT_VEC3, gl_UNSIGNED_INT_VEC4, gl_UNSIGNED_NORMALIZED,
        gl_UNSIGNED_SHORT, gl_UNSIGNED_SHORT_1_5_5_5_REV,
        gl_UNSIGNED_SHORT_4_4_4_4, gl_UNSIGNED_SHORT_4_4_4_4_REV,
        gl_UNSIGNED_SHORT_5_5_5_1, gl_UNSIGNED_SHORT_5_6_5,
        gl_UNSIGNED_SHORT_5_6_5_REV, gl_UPPER_LEFT, gl_VALIDATE_STATUS,
        gl_VENDOR, gl_VERSION, gl_VERTEX_ARRAY_BINDING,
        gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_VERTEX_ATTRIB_ARRAY_DIVISOR, gl_VERTEX_ATTRIB_ARRAY_ENABLED,
        gl_VERTEX_ATTRIB_ARRAY_INTEGER, gl_VERTEX_ATTRIB_ARRAY_NORMALIZED,
        gl_VERTEX_ATTRIB_ARRAY_POINTER, gl_VERTEX_ATTRIB_ARRAY_SIZE,
        gl_VERTEX_ATTRIB_ARRAY_STRIDE, gl_VERTEX_ATTRIB_ARRAY_TYPE,
        gl_VERTEX_PROGRAM_POINT_SIZE, gl_VERTEX_SHADER,
        gl_VERTEX_SHADER_BIT, gl_VIEWPORT, gl_VIEWPORT_BOUNDS_RANGE,
        gl_VIEWPORT_INDEX_PROVOKING_VERTEX, gl_VIEWPORT_SUBPIXEL_BITS,
        gl_WAIT_FAILED, gl_WRITE_ONLY, gl_XOR, gl_ZERO,
        glActiveShaderProgram, glActiveTexture, glAttachShader,
        glBeginConditionalRender, glBeginQuery, glBeginQueryIndexed,
        glBeginTransformFeedback, glBindAttribLocation, glBindBuffer,
        glBindBufferBase, glBindBufferRange, glBindFragDataLocation,
        glBindFragDataLocationIndexed, glBindFramebuffer,
        glBindProgramPipeline, glBindRenderbuffer, glBindSampler,
        glBindTexture, glBindTransformFeedback, glBindVertexArray,
        glBlendColor, glBlendEquation, glBlendEquationSeparate,
        glBlendEquationSeparatei, glBlendEquationi, glBlendFunc,
        glBlendFuncSeparate, glBlendFuncSeparatei, glBlendFunci,
        glBlitFramebuffer, glBufferData, glBufferSubData,
        glCheckFramebufferStatus, glClampColor, glClear, glClearBufferfi,
        glClearBufferfv, glClearBufferiv, glClearBufferuiv, glClearColor,
        glClearDepth, glClearDepthf, glClearStencil, glClientWaitSync,
        glColorMask, glColorMaski, glCompileShader, glCompressedTexImage1D,
        glCompressedTexImage2D, glCompressedTexImage3D,
        glCompressedTexSubImage1D, glCompressedTexSubImage2D,
        glCompressedTexSubImage3D, glCopyBufferSubData, glCopyTexImage1D,
        glCopyTexImage2D, glCopyTexSubImage1D, glCopyTexSubImage2D,
        glCopyTexSubImage3D, glCreateProgram, glCreateShader,
        glCreateShaderProgramv, glCullFace, glDeleteBuffers,
        glDeleteFramebuffers, glDeleteProgram, glDeleteProgramPipelines,
        glDeleteQueries, glDeleteRenderbuffers, glDeleteSamplers,
        glDeleteShader, glDeleteSync, glDeleteTextures,
        glDeleteTransformFeedbacks, glDeleteVertexArrays, glDepthFunc,
        glDepthMask, glDepthRange, glDepthRangeArrayv, glDepthRangeIndexed,
        glDepthRangef, glDetachShader, glDisable,
        glDisableVertexAttribArray, glDisablei, glDrawArrays,
        glDrawArraysIndirect, glDrawArraysInstanced, glDrawBuffer,
        glDrawBuffers, glDrawElements, glDrawElementsBaseVertex,
        glDrawElementsIndirect, glDrawElementsInstanced,
        glDrawElementsInstancedBaseVertex, glDrawRangeElements,
        glDrawRangeElementsBaseVertex, glDrawTransformFeedback,
        glDrawTransformFeedbackStream, glEnable, glEnableVertexAttribArray,
        glEnablei, glEndConditionalRender, glEndQuery, glEndQueryIndexed,
        glEndTransformFeedback, glFenceSync, glFinish, glFlush,
        glFlushMappedBufferRange, glFramebufferRenderbuffer,
        glFramebufferTexture, glFramebufferTexture1D,
        glFramebufferTexture2D, glFramebufferTexture3D,
        glFramebufferTextureLayer, glFrontFace, glGenBuffers,
        glGenFramebuffers, glGenProgramPipelines, glGenQueries,
        glGenRenderbuffers, glGenSamplers, glGenTextures,
        glGenTransformFeedbacks, glGenVertexArrays, glGenerateMipmap,
        glGetActiveAttrib, glGetActiveSubroutineName,
        glGetActiveSubroutineUniformName, glGetActiveSubroutineUniformiv,
        glGetActiveUniform, glGetActiveUniformBlockName,
        glGetActiveUniformBlockiv, glGetActiveUniformName,
        glGetActiveUniformsiv, glGetAttachedShaders, glGetAttribLocation,
        glGetBooleani_v, glGetBooleanv, glGetBufferParameteri64v,
        glGetBufferParameteriv, glGetBufferPointerv, glGetBufferSubData,
        glGetCompressedTexImage, glGetDoublei_v, glGetDoublev, glGetError,
        glGetFloati_v, glGetFloatv, glGetFragDataIndex,
        glGetFragDataLocation, glGetFramebufferAttachmentParameteriv,
        glGetInteger64i_v, glGetInteger64v, glGetIntegeri_v, glGetIntegerv,
        glGetMultisamplefv, glGetProgramBinary, glGetProgramInfoLog,
        glGetProgramPipelineInfoLog, glGetProgramPipelineiv,
        glGetProgramStageiv, glGetProgramiv, glGetQueryIndexediv,
        glGetQueryObjecti64v, glGetQueryObjectiv, glGetQueryObjectui64v,
        glGetQueryObjectuiv, glGetQueryiv, glGetRenderbufferParameteriv,
        glGetSamplerParameterIiv, glGetSamplerParameterIuiv,
        glGetSamplerParameterfv, glGetSamplerParameteriv,
        glGetShaderInfoLog, glGetShaderPrecisionFormat, glGetShaderSource,
        glGetShaderiv, glGetString, glGetStringi, glGetSubroutineIndex,
        glGetSubroutineUniformLocation, glGetSynciv, glGetTexImage,
        glGetTexLevelParameterfv, glGetTexLevelParameteriv,
        glGetTexParameterIiv, glGetTexParameterIuiv, glGetTexParameterfv,
        glGetTexParameteriv, glGetTransformFeedbackVarying,
        glGetUniformBlockIndex, glGetUniformIndices, glGetUniformLocation,
        glGetUniformSubroutineuiv, glGetUniformdv, glGetUniformfv,
        glGetUniformiv, glGetUniformuiv, glGetVertexAttribIiv,
        glGetVertexAttribIuiv, glGetVertexAttribLdv,
        glGetVertexAttribPointerv, glGetVertexAttribdv,
        glGetVertexAttribfv, glGetVertexAttribiv, glHint, glIsBuffer,
        glIsEnabled, glIsEnabledi, glIsFramebuffer, glIsProgram,
        glIsProgramPipeline, glIsQuery, glIsRenderbuffer, glIsSampler,
        glIsShader, glIsSync, glIsTexture, glIsTransformFeedback,
        glIsVertexArray, glLineWidth, glLinkProgram, glLogicOp,
        glMapBuffer, glMapBufferRange, glMinSampleShading,
        glMultiDrawArrays, glMultiDrawElements,
        glMultiDrawElementsBaseVertex, glPatchParameterfv,
        glPatchParameteri, glPauseTransformFeedback, glPixelStoref,
        glPixelStorei, glPointParameterf, glPointParameterfv,
        glPointParameteri, glPointParameteriv, glPointSize, glPolygonMode,
        glPolygonOffset, glPrimitiveRestartIndex, glProgramBinary,
        glProgramParameteri, glProgramUniform1d, glProgramUniform1dv,
        glProgramUniform1f, glProgramUniform1fv, glProgramUniform1i,
        glProgramUniform1iv, glProgramUniform1ui, glProgramUniform1uiv,
        glProgramUniform2d, glProgramUniform2dv, glProgramUniform2f,
        glProgramUniform2fv, glProgramUniform2i, glProgramUniform2iv,
        glProgramUniform2ui, glProgramUniform2uiv, glProgramUniform3d,
        glProgramUniform3dv, glProgramUniform3f, glProgramUniform3fv,
        glProgramUniform3i, glProgramUniform3iv, glProgramUniform3ui,
        glProgramUniform3uiv, glProgramUniform4d, glProgramUniform4dv,
        glProgramUniform4f, glProgramUniform4fv, glProgramUniform4i,
        glProgramUniform4iv, glProgramUniform4ui, glProgramUniform4uiv,
        glProgramUniformMatrix2dv, glProgramUniformMatrix2fv,
        glProgramUniformMatrix2x3dv, glProgramUniformMatrix2x3fv,
        glProgramUniformMatrix2x4dv, glProgramUniformMatrix2x4fv,
        glProgramUniformMatrix3dv, glProgramUniformMatrix3fv,
        glProgramUniformMatrix3x2dv, glProgramUniformMatrix3x2fv,
        glProgramUniformMatrix3x4dv, glProgramUniformMatrix3x4fv,
        glProgramUniformMatrix4dv, glProgramUniformMatrix4fv,
        glProgramUniformMatrix4x2dv, glProgramUniformMatrix4x2fv,
        glProgramUniformMatrix4x3dv, glProgramUniformMatrix4x3fv,
        glProvokingVertex, glQueryCounter, glReadBuffer, glReadPixels,
        glReleaseShaderCompiler, glRenderbufferStorage,
        glRenderbufferStorageMultisample, glResumeTransformFeedback,
        glSampleCoverage, glSampleMaski, glSamplerParameterIiv,
        glSamplerParameterIuiv, glSamplerParameterf, glSamplerParameterfv,
        glSamplerParameteri, glSamplerParameteriv, glScissor,
        glScissorArrayv, glScissorIndexed, glScissorIndexedv,
        glShaderBinary, glShaderSource, glStencilFunc,
        glStencilFuncSeparate, glStencilMask, glStencilMaskSeparate,
        glStencilOp, glStencilOpSeparate, glTexBuffer, glTexImage1D,
        glTexImage2D, glTexImage2DMultisample, glTexImage3D,
        glTexImage3DMultisample, glTexParameterIiv, glTexParameterIuiv,
        glTexParameterf, glTexParameterfv, glTexParameteri,
        glTexParameteriv, glTexSubImage1D, glTexSubImage2D,
        glTexSubImage3D, glTransformFeedbackVaryings, glUniform1d,
        glUniform1dv, glUniform1f, glUniform1fv, glUniform1i, glUniform1iv,
        glUniform1ui, glUniform1uiv, glUniform2d, glUniform2dv,
        glUniform2f, glUniform2fv, glUniform2i, glUniform2iv, glUniform2ui,
        glUniform2uiv, glUniform3d, glUniform3dv, glUniform3f,
        glUniform3fv, glUniform3i, glUniform3iv, glUniform3ui,
        glUniform3uiv, glUniform4d, glUniform4dv, glUniform4f,
        glUniform4fv, glUniform4i, glUniform4iv, glUniform4ui,
        glUniform4uiv, glUniformBlockBinding, glUniformMatrix2dv,
        glUniformMatrix2fv, glUniformMatrix2x3dv, glUniformMatrix2x3fv,
        glUniformMatrix2x4dv, glUniformMatrix2x4fv, glUniformMatrix3dv,
        glUniformMatrix3fv, glUniformMatrix3x2dv, glUniformMatrix3x2fv,
        glUniformMatrix3x4dv, glUniformMatrix3x4fv, glUniformMatrix4dv,
        glUniformMatrix4fv, glUniformMatrix4x2dv, glUniformMatrix4x2fv,
        glUniformMatrix4x3dv, glUniformMatrix4x3fv,
        glUniformSubroutinesuiv, glUnmapBuffer, glUseProgram,
        glUseProgramStages, glValidateProgram, glValidateProgramPipeline,
        glVertexAttrib1d, glVertexAttrib1dv, glVertexAttrib1f,
        glVertexAttrib1fv, glVertexAttrib1s, glVertexAttrib1sv,
        glVertexAttrib2d, glVertexAttrib2dv, glVertexAttrib2f,
        glVertexAttrib2fv, glVertexAttrib2s, glVertexAttrib2sv,
        glVertexAttrib3d, glVertexAttrib3dv, glVertexAttrib3f,
        glVertexAttrib3fv, glVertexAttrib3s, glVertexAttrib3sv,
        glVertexAttrib4Nbv, glVertexAttrib4Niv, glVertexAttrib4Nsv,
        glVertexAttrib4Nub, glVertexAttrib4Nubv, glVertexAttrib4Nuiv,
        glVertexAttrib4Nusv, glVertexAttrib4bv, glVertexAttrib4d,
        glVertexAttrib4dv, glVertexAttrib4f, glVertexAttrib4fv,
        glVertexAttrib4iv, glVertexAttrib4s, glVertexAttrib4sv,
        glVertexAttrib4ubv, glVertexAttrib4uiv, glVertexAttrib4usv,
        glVertexAttribDivisor, glVertexAttribI1i, glVertexAttribI1iv,
        glVertexAttribI1ui, glVertexAttribI1uiv, glVertexAttribI2i,
        glVertexAttribI2iv, glVertexAttribI2ui, glVertexAttribI2uiv,
        glVertexAttribI3i, glVertexAttribI3iv, glVertexAttribI3ui,
        glVertexAttribI3uiv, glVertexAttribI4bv, glVertexAttribI4i,
        glVertexAttribI4iv, glVertexAttribI4sv, glVertexAttribI4ubv,
        glVertexAttribI4ui, glVertexAttribI4uiv, glVertexAttribI4usv,
        glVertexAttribIPointer, glVertexAttribL1d, glVertexAttribL1dv,
        glVertexAttribL2d, glVertexAttribL2dv, glVertexAttribL3d,
        glVertexAttribL3dv, glVertexAttribL4d, glVertexAttribL4dv,
        glVertexAttribLPointer, glVertexAttribP1ui, glVertexAttribP1uiv,
        glVertexAttribP2ui, glVertexAttribP2uiv, glVertexAttribP3ui,
        glVertexAttribP3uiv, glVertexAttribP4ui, glVertexAttribP4uiv,
        glVertexAttribPointer, glViewport, glViewportArrayv,
        glViewportIndexedf, glViewportIndexedfv, glWaitSync)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Core.Core10
       (glBlendFunc, glClear, glClearColor, glClearDepth, glClearStencil,
        glColorMask, glCullFace, glDepthFunc, glDepthMask, glDepthRange,
        glDisable, glDrawBuffer, glEnable, glFinish, glFlush, glFrontFace,
        glGetBooleanv, glGetDoublev, glGetError, glGetFloatv,
        glGetIntegerv, glGetString, glGetTexImage,
        glGetTexLevelParameterfv, glGetTexLevelParameteriv,
        glGetTexParameterfv, glGetTexParameteriv, glHint, glIsEnabled,
        glLineWidth, glLogicOp, glPixelStoref, glPixelStorei, glPointSize,
        glPolygonMode, glReadBuffer, glReadPixels, glScissor,
        glStencilFunc, glStencilMask, glStencilOp, glTexImage1D,
        glTexImage2D, glTexParameterf, glTexParameterfv, glTexParameteri,
        glTexParameteriv, glViewport)
import Graphics.Rendering.OpenGL.Raw.Core.Core11
       (glBindTexture, glCopyTexImage1D, glCopyTexImage2D,
        glCopyTexSubImage1D, glCopyTexSubImage2D, glDeleteTextures,
        glDrawArrays, glDrawElements, glGenTextures, glIsTexture,
        glPolygonOffset, glTexSubImage1D, glTexSubImage2D, gl_ALPHA,
        gl_ALWAYS, gl_AND, gl_AND_INVERTED, gl_AND_REVERSE, gl_BACK,
        gl_BACK_LEFT, gl_BACK_RIGHT, gl_BLEND, gl_BLEND_DST, gl_BLEND_SRC,
        gl_BLUE, gl_BYTE, gl_CCW, gl_CLEAR, gl_COLOR, gl_COLOR_BUFFER_BIT,
        gl_COLOR_CLEAR_VALUE, gl_COLOR_LOGIC_OP, gl_COLOR_WRITEMASK,
        gl_COPY, gl_COPY_INVERTED, gl_CULL_FACE, gl_CULL_FACE_MODE, gl_CW,
        gl_DECR, gl_DEPTH, gl_DEPTH_BUFFER_BIT, gl_DEPTH_CLEAR_VALUE,
        gl_DEPTH_COMPONENT, gl_DEPTH_FUNC, gl_DEPTH_RANGE, gl_DEPTH_TEST,
        gl_DEPTH_WRITEMASK, gl_DITHER, gl_DONT_CARE, gl_DOUBLE,
        gl_DOUBLEBUFFER, gl_DRAW_BUFFER, gl_DST_ALPHA, gl_DST_COLOR,
        gl_EQUAL, gl_EQUIV, gl_EXTENSIONS, gl_FALSE, gl_FASTEST, gl_FILL,
        gl_FLOAT, gl_FRONT, gl_FRONT_AND_BACK, gl_FRONT_FACE,
        gl_FRONT_LEFT, gl_FRONT_RIGHT, gl_GEQUAL, gl_GREATER, gl_GREEN,
        gl_INCR, gl_INT, gl_INVALID_ENUM, gl_INVALID_OPERATION,
        gl_INVALID_VALUE, gl_INVERT, gl_KEEP, gl_LEFT, gl_LEQUAL, gl_LESS,
        gl_LINE, gl_LINEAR, gl_LINEAR_MIPMAP_LINEAR,
        gl_LINEAR_MIPMAP_NEAREST, gl_LINES, gl_LINE_LOOP, gl_LINE_SMOOTH,
        gl_LINE_SMOOTH_HINT, gl_LINE_STRIP, gl_LINE_WIDTH,
        gl_LINE_WIDTH_GRANULARITY, gl_LINE_WIDTH_RANGE, gl_LOGIC_OP_MODE,
        gl_MAX_TEXTURE_SIZE, gl_MAX_VIEWPORT_DIMS, gl_NAND, gl_NEAREST,
        gl_NEAREST_MIPMAP_LINEAR, gl_NEAREST_MIPMAP_NEAREST, gl_NEVER,
        gl_NICEST, gl_NONE, gl_NOOP, gl_NOR, gl_NOTEQUAL, gl_NO_ERROR,
        gl_ONE, gl_ONE_MINUS_DST_ALPHA, gl_ONE_MINUS_DST_COLOR,
        gl_ONE_MINUS_SRC_ALPHA, gl_ONE_MINUS_SRC_COLOR, gl_OR,
        gl_OR_INVERTED, gl_OR_REVERSE, gl_OUT_OF_MEMORY, gl_PACK_ALIGNMENT,
        gl_PACK_LSB_FIRST, gl_PACK_ROW_LENGTH, gl_PACK_SKIP_PIXELS,
        gl_PACK_SKIP_ROWS, gl_PACK_SWAP_BYTES, gl_POINT, gl_POINTS,
        gl_POINT_SIZE, gl_POINT_SIZE_GRANULARITY, gl_POINT_SIZE_RANGE,
        gl_POLYGON_MODE, gl_POLYGON_OFFSET_FACTOR, gl_POLYGON_OFFSET_FILL,
        gl_POLYGON_OFFSET_LINE, gl_POLYGON_OFFSET_POINT,
        gl_POLYGON_OFFSET_UNITS, gl_POLYGON_SMOOTH, gl_POLYGON_SMOOTH_HINT,
        gl_PROXY_TEXTURE_1D, gl_PROXY_TEXTURE_2D, gl_QUADS, gl_R3_G3_B2,
        gl_READ_BUFFER, gl_RED, gl_RENDERER, gl_REPEAT, gl_REPLACE, gl_RGB,
        gl_RGB10, gl_RGB10_A2, gl_RGB12, gl_RGB16, gl_RGB4, gl_RGB5,
        gl_RGB5_A1, gl_RGB8, gl_RGBA, gl_RGBA12, gl_RGBA16, gl_RGBA2,
        gl_RGBA4, gl_RGBA8, gl_RIGHT, gl_SCISSOR_BOX, gl_SCISSOR_TEST,
        gl_SET, gl_SHORT, gl_SRC_ALPHA, gl_SRC_ALPHA_SATURATE,
        gl_SRC_COLOR, gl_STENCIL, gl_STENCIL_BUFFER_BIT,
        gl_STENCIL_CLEAR_VALUE, gl_STENCIL_FAIL, gl_STENCIL_FUNC,
        gl_STENCIL_INDEX, gl_STENCIL_PASS_DEPTH_FAIL,
        gl_STENCIL_PASS_DEPTH_PASS, gl_STENCIL_REF, gl_STENCIL_TEST,
        gl_STENCIL_VALUE_MASK, gl_STENCIL_WRITEMASK, gl_STEREO,
        gl_SUBPIXEL_BITS, gl_TEXTURE, gl_TEXTURE_1D, gl_TEXTURE_2D,
        gl_TEXTURE_ALPHA_SIZE, gl_TEXTURE_BINDING_1D,
        gl_TEXTURE_BINDING_2D, gl_TEXTURE_BLUE_SIZE,
        gl_TEXTURE_BORDER_COLOR, gl_TEXTURE_GREEN_SIZE, gl_TEXTURE_HEIGHT,
        gl_TEXTURE_INTERNAL_FORMAT, gl_TEXTURE_MAG_FILTER,
        gl_TEXTURE_MIN_FILTER, gl_TEXTURE_RED_SIZE, gl_TEXTURE_WIDTH,
        gl_TEXTURE_WRAP_S, gl_TEXTURE_WRAP_T, gl_TRIANGLES,
        gl_TRIANGLE_FAN, gl_TRIANGLE_STRIP, gl_TRUE, gl_UNPACK_ALIGNMENT,
        gl_UNPACK_LSB_FIRST, gl_UNPACK_ROW_LENGTH, gl_UNPACK_SKIP_PIXELS,
        gl_UNPACK_SKIP_ROWS, gl_UNPACK_SWAP_BYTES, gl_UNSIGNED_BYTE,
        gl_UNSIGNED_INT, gl_UNSIGNED_SHORT, gl_VENDOR, gl_VERSION,
        gl_VIEWPORT, gl_XOR, gl_ZERO)
import Graphics.Rendering.OpenGL.Raw.Core.Core12
       (glCopyTexSubImage3D, glDrawRangeElements, glTexImage3D,
        glTexSubImage3D, gl_ALIASED_LINE_WIDTH_RANGE, gl_BGR, gl_BGRA,
        gl_CLAMP_TO_EDGE, gl_MAX_3D_TEXTURE_SIZE, gl_MAX_ELEMENTS_INDICES,
        gl_MAX_ELEMENTS_VERTICES, gl_PACK_IMAGE_HEIGHT,
        gl_PACK_SKIP_IMAGES, gl_PROXY_TEXTURE_3D,
        gl_SMOOTH_LINE_WIDTH_GRANULARITY, gl_SMOOTH_LINE_WIDTH_RANGE,
        gl_SMOOTH_POINT_SIZE_GRANULARITY, gl_SMOOTH_POINT_SIZE_RANGE,
        gl_TEXTURE_3D, gl_TEXTURE_BASE_LEVEL, gl_TEXTURE_BINDING_3D,
        gl_TEXTURE_DEPTH, gl_TEXTURE_MAX_LEVEL, gl_TEXTURE_MAX_LOD,
        gl_TEXTURE_MIN_LOD, gl_TEXTURE_WRAP_R, gl_UNPACK_IMAGE_HEIGHT,
        gl_UNPACK_SKIP_IMAGES, gl_UNSIGNED_BYTE_2_3_3_REV,
        gl_UNSIGNED_BYTE_3_3_2, gl_UNSIGNED_INT_10_10_10_2,
        gl_UNSIGNED_INT_2_10_10_10_REV, gl_UNSIGNED_INT_8_8_8_8,
        gl_UNSIGNED_INT_8_8_8_8_REV, gl_UNSIGNED_SHORT_1_5_5_5_REV,
        gl_UNSIGNED_SHORT_4_4_4_4, gl_UNSIGNED_SHORT_4_4_4_4_REV,
        gl_UNSIGNED_SHORT_5_5_5_1, gl_UNSIGNED_SHORT_5_6_5,
        gl_UNSIGNED_SHORT_5_6_5_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Core13
       (glActiveTexture, glCompressedTexImage1D, glCompressedTexImage2D,
        glCompressedTexImage3D, glCompressedTexSubImage1D,
        glCompressedTexSubImage2D, glCompressedTexSubImage3D,
        glGetCompressedTexImage, glSampleCoverage, gl_ACTIVE_TEXTURE,
        gl_CLAMP_TO_BORDER, gl_COMPRESSED_RGB, gl_COMPRESSED_RGBA,
        gl_COMPRESSED_TEXTURE_FORMATS, gl_MAX_CUBE_MAP_TEXTURE_SIZE,
        gl_MULTISAMPLE, gl_NUM_COMPRESSED_TEXTURE_FORMATS,
        gl_PROXY_TEXTURE_CUBE_MAP, gl_SAMPLES, gl_SAMPLE_ALPHA_TO_COVERAGE,
        gl_SAMPLE_ALPHA_TO_ONE, gl_SAMPLE_BUFFERS, gl_SAMPLE_COVERAGE,
        gl_SAMPLE_COVERAGE_INVERT, gl_SAMPLE_COVERAGE_VALUE, gl_TEXTURE0,
        gl_TEXTURE1, gl_TEXTURE10, gl_TEXTURE11, gl_TEXTURE12,
        gl_TEXTURE13, gl_TEXTURE14, gl_TEXTURE15, gl_TEXTURE16,
        gl_TEXTURE17, gl_TEXTURE18, gl_TEXTURE19, gl_TEXTURE2,
        gl_TEXTURE20, gl_TEXTURE21, gl_TEXTURE22, gl_TEXTURE23,
        gl_TEXTURE24, gl_TEXTURE25, gl_TEXTURE26, gl_TEXTURE27,
        gl_TEXTURE28, gl_TEXTURE29, gl_TEXTURE3, gl_TEXTURE30,
        gl_TEXTURE31, gl_TEXTURE4, gl_TEXTURE5, gl_TEXTURE6, gl_TEXTURE7,
        gl_TEXTURE8, gl_TEXTURE9, gl_TEXTURE_BINDING_CUBE_MAP,
        gl_TEXTURE_COMPRESSED, gl_TEXTURE_COMPRESSED_IMAGE_SIZE,
        gl_TEXTURE_COMPRESSION_HINT, gl_TEXTURE_CUBE_MAP,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_X, gl_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        gl_TEXTURE_CUBE_MAP_NEGATIVE_Z, gl_TEXTURE_CUBE_MAP_POSITIVE_X,
        gl_TEXTURE_CUBE_MAP_POSITIVE_Y, gl_TEXTURE_CUBE_MAP_POSITIVE_Z)
import Graphics.Rendering.OpenGL.Raw.Core.Core14
       (glBlendColor, glBlendEquation, glBlendFuncSeparate,
        glMultiDrawArrays, glMultiDrawElements, glPointParameterf,
        glPointParameterfv, glPointParameteri, glPointParameteriv,
        gl_BLEND_DST_ALPHA, gl_BLEND_DST_RGB, gl_BLEND_SRC_ALPHA,
        gl_BLEND_SRC_RGB, gl_CONSTANT_ALPHA, gl_CONSTANT_COLOR,
        gl_DECR_WRAP, gl_DEPTH_COMPONENT16, gl_DEPTH_COMPONENT24,
        gl_DEPTH_COMPONENT32, gl_FUNC_ADD, gl_FUNC_REVERSE_SUBTRACT,
        gl_FUNC_SUBTRACT, gl_INCR_WRAP, gl_MAX, gl_MAX_TEXTURE_LOD_BIAS,
        gl_MIN, gl_MIRRORED_REPEAT, gl_ONE_MINUS_CONSTANT_ALPHA,
        gl_ONE_MINUS_CONSTANT_COLOR, gl_POINT_FADE_THRESHOLD_SIZE,
        gl_TEXTURE_COMPARE_FUNC, gl_TEXTURE_COMPARE_MODE,
        gl_TEXTURE_DEPTH_SIZE, gl_TEXTURE_LOD_BIAS)
import Graphics.Rendering.OpenGL.Raw.Core.Core15
       (glBeginQuery, glBindBuffer, glBufferData, glBufferSubData,
        glDeleteBuffers, glDeleteQueries, glEndQuery, glGenBuffers,
        glGenQueries, glGetBufferParameteriv, glGetBufferPointerv,
        glGetBufferSubData, glGetQueryObjectiv, glGetQueryObjectuiv,
        glGetQueryiv, glIsBuffer, glIsQuery, glMapBuffer, glUnmapBuffer,
        gl_ARRAY_BUFFER, gl_ARRAY_BUFFER_BINDING, gl_BUFFER_ACCESS,
        gl_BUFFER_MAPPED, gl_BUFFER_MAP_POINTER, gl_BUFFER_SIZE,
        gl_BUFFER_USAGE, gl_CURRENT_QUERY, gl_DYNAMIC_COPY,
        gl_DYNAMIC_DRAW, gl_DYNAMIC_READ, gl_ELEMENT_ARRAY_BUFFER,
        gl_ELEMENT_ARRAY_BUFFER_BINDING, gl_QUERY_COUNTER_BITS,
        gl_QUERY_RESULT, gl_QUERY_RESULT_AVAILABLE, gl_READ_ONLY,
        gl_READ_WRITE, gl_SAMPLES_PASSED, gl_SRC1_ALPHA, gl_STATIC_COPY,
        gl_STATIC_DRAW, gl_STATIC_READ, gl_STREAM_COPY, gl_STREAM_DRAW,
        gl_STREAM_READ, gl_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING,
        gl_WRITE_ONLY)
import Graphics.Rendering.OpenGL.Raw.Core.Core20
       (glAttachShader, glBindAttribLocation, glBlendEquationSeparate,
        glCompileShader, glCreateProgram, glCreateShader, glDeleteProgram,
        glDeleteShader, glDetachShader, glDisableVertexAttribArray,
        glDrawBuffers, glEnableVertexAttribArray, glGetActiveAttrib,
        glGetActiveUniform, glGetAttachedShaders, glGetAttribLocation,
        glGetProgramInfoLog, glGetProgramiv, glGetShaderInfoLog,
        glGetShaderSource, glGetShaderiv, glGetUniformLocation,
        glGetUniformfv, glGetUniformiv, glGetVertexAttribPointerv,
        glGetVertexAttribdv, glGetVertexAttribfv, glGetVertexAttribiv,
        glIsProgram, glIsShader, glLinkProgram, glShaderSource,
        glStencilFuncSeparate, glStencilMaskSeparate, glStencilOpSeparate,
        glUniform1f, glUniform1fv, glUniform1i, glUniform1iv, glUniform2f,
        glUniform2fv, glUniform2i, glUniform2iv, glUniform3f, glUniform3fv,
        glUniform3i, glUniform3iv, glUniform4f, glUniform4fv, glUniform4i,
        glUniform4iv, glUniformMatrix2fv, glUniformMatrix3fv,
        glUniformMatrix4fv, glUseProgram, glValidateProgram,
        glVertexAttrib1d, glVertexAttrib1dv, glVertexAttrib1f,
        glVertexAttrib1fv, glVertexAttrib1s, glVertexAttrib1sv,
        glVertexAttrib2d, glVertexAttrib2dv, glVertexAttrib2f,
        glVertexAttrib2fv, glVertexAttrib2s, glVertexAttrib2sv,
        glVertexAttrib3d, glVertexAttrib3dv, glVertexAttrib3f,
        glVertexAttrib3fv, glVertexAttrib3s, glVertexAttrib3sv,
        glVertexAttrib4Nbv, glVertexAttrib4Niv, glVertexAttrib4Nsv,
        glVertexAttrib4Nub, glVertexAttrib4Nubv, glVertexAttrib4Nuiv,
        glVertexAttrib4Nusv, glVertexAttrib4bv, glVertexAttrib4d,
        glVertexAttrib4dv, glVertexAttrib4f, glVertexAttrib4fv,
        glVertexAttrib4iv, glVertexAttrib4s, glVertexAttrib4sv,
        glVertexAttrib4ubv, glVertexAttrib4uiv, glVertexAttrib4usv,
        glVertexAttribPointer, gl_ACTIVE_ATTRIBUTES,
        gl_ACTIVE_ATTRIBUTE_MAX_LENGTH, gl_ACTIVE_UNIFORMS,
        gl_ACTIVE_UNIFORM_MAX_LENGTH, gl_ATTACHED_SHADERS,
        gl_BLEND_EQUATION_ALPHA, gl_BLEND_EQUATION_RGB, gl_BOOL,
        gl_BOOL_VEC2, gl_BOOL_VEC3, gl_BOOL_VEC4, gl_COMPILE_STATUS,
        gl_CURRENT_PROGRAM, gl_CURRENT_VERTEX_ATTRIB, gl_DELETE_STATUS,
        gl_DRAW_BUFFER0, gl_DRAW_BUFFER1, gl_DRAW_BUFFER10,
        gl_DRAW_BUFFER11, gl_DRAW_BUFFER12, gl_DRAW_BUFFER13,
        gl_DRAW_BUFFER14, gl_DRAW_BUFFER15, gl_DRAW_BUFFER2,
        gl_DRAW_BUFFER3, gl_DRAW_BUFFER4, gl_DRAW_BUFFER5, gl_DRAW_BUFFER6,
        gl_DRAW_BUFFER7, gl_DRAW_BUFFER8, gl_DRAW_BUFFER9, gl_FLOAT_MAT2,
        gl_FLOAT_MAT3, gl_FLOAT_MAT4, gl_FLOAT_VEC2, gl_FLOAT_VEC3,
        gl_FLOAT_VEC4, gl_FRAGMENT_SHADER,
        gl_FRAGMENT_SHADER_DERIVATIVE_HINT, gl_INFO_LOG_LENGTH,
        gl_INT_VEC2, gl_INT_VEC3, gl_INT_VEC4, gl_LINK_STATUS,
        gl_LOWER_LEFT, gl_MAX_COMBINED_TEXTURE_IMAGE_UNITS,
        gl_MAX_DRAW_BUFFERS, gl_MAX_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_TEXTURE_IMAGE_UNITS, gl_MAX_VARYING_FLOATS,
        gl_MAX_VERTEX_ATTRIBS, gl_MAX_VERTEX_TEXTURE_IMAGE_UNITS,
        gl_MAX_VERTEX_UNIFORM_COMPONENTS, gl_POINT_SPRITE_COORD_ORIGIN,
        gl_SAMPLER_1D, gl_SAMPLER_1D_SHADOW, gl_SAMPLER_2D,
        gl_SAMPLER_2D_SHADOW, gl_SAMPLER_3D, gl_SAMPLER_CUBE,
        gl_SHADER_SOURCE_LENGTH, gl_SHADER_TYPE,
        gl_SHADING_LANGUAGE_VERSION, gl_STENCIL_BACK_FAIL,
        gl_STENCIL_BACK_FUNC, gl_STENCIL_BACK_PASS_DEPTH_FAIL,
        gl_STENCIL_BACK_PASS_DEPTH_PASS, gl_STENCIL_BACK_REF,
        gl_STENCIL_BACK_VALUE_MASK, gl_STENCIL_BACK_WRITEMASK,
        gl_UPPER_LEFT, gl_VALIDATE_STATUS, gl_VERTEX_ATTRIB_ARRAY_ENABLED,
        gl_VERTEX_ATTRIB_ARRAY_NORMALIZED, gl_VERTEX_ATTRIB_ARRAY_POINTER,
        gl_VERTEX_ATTRIB_ARRAY_SIZE, gl_VERTEX_ATTRIB_ARRAY_STRIDE,
        gl_VERTEX_ATTRIB_ARRAY_TYPE, gl_VERTEX_PROGRAM_POINT_SIZE,
        gl_VERTEX_SHADER)
import Graphics.Rendering.OpenGL.Raw.Core.Core21
       (glUniformMatrix2x3fv, glUniformMatrix2x4fv, glUniformMatrix3x2fv,
        glUniformMatrix3x4fv, glUniformMatrix4x2fv, glUniformMatrix4x3fv,
        gl_COMPRESSED_SRGB, gl_COMPRESSED_SRGB_ALPHA, gl_FLOAT_MAT2x3,
        gl_FLOAT_MAT2x4, gl_FLOAT_MAT3x2, gl_FLOAT_MAT3x4, gl_FLOAT_MAT4x2,
        gl_FLOAT_MAT4x3, gl_PIXEL_PACK_BUFFER,
        gl_PIXEL_PACK_BUFFER_BINDING, gl_PIXEL_UNPACK_BUFFER,
        gl_PIXEL_UNPACK_BUFFER_BINDING, gl_SRGB, gl_SRGB8, gl_SRGB8_ALPHA8,
        gl_SRGB_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Core.Core30
       (glBeginConditionalRender, glBeginTransformFeedback,
        glBindBufferBase, glBindBufferRange, glBindFragDataLocation,
        glBindFramebuffer, glBindRenderbuffer, glBindVertexArray,
        glBlitFramebuffer, glCheckFramebufferStatus, glClampColor,
        glClearBufferfi, glClearBufferfv, glClearBufferiv,
        glClearBufferuiv, glColorMaski, glDeleteFramebuffers,
        glDeleteRenderbuffers, glDeleteVertexArrays, glDisablei, glEnablei,
        glEndConditionalRender, glEndTransformFeedback,
        glFlushMappedBufferRange, glFramebufferRenderbuffer,
        glFramebufferTexture1D, glFramebufferTexture2D,
        glFramebufferTexture3D, glFramebufferTextureLayer,
        glGenFramebuffers, glGenRenderbuffers, glGenVertexArrays,
        glGenerateMipmap, glGetBooleani_v, glGetFragDataLocation,
        glGetFramebufferAttachmentParameteriv, glGetIntegeri_v,
        glGetRenderbufferParameteriv, glGetStringi, glGetTexParameterIiv,
        glGetTexParameterIuiv, glGetTransformFeedbackVarying,
        glGetUniformuiv, glGetVertexAttribIiv, glGetVertexAttribIuiv,
        glIsEnabledi, glIsFramebuffer, glIsRenderbuffer, glIsVertexArray,
        glMapBufferRange, glRenderbufferStorage,
        glRenderbufferStorageMultisample, glTexParameterIiv,
        glTexParameterIuiv, glTransformFeedbackVaryings, glUniform1ui,
        glUniform1uiv, glUniform2ui, glUniform2uiv, glUniform3ui,
        glUniform3uiv, glUniform4ui, glUniform4uiv, glVertexAttribI1i,
        glVertexAttribI1iv, glVertexAttribI1ui, glVertexAttribI1uiv,
        glVertexAttribI2i, glVertexAttribI2iv, glVertexAttribI2ui,
        glVertexAttribI2uiv, glVertexAttribI3i, glVertexAttribI3iv,
        glVertexAttribI3ui, glVertexAttribI3uiv, glVertexAttribI4bv,
        glVertexAttribI4i, glVertexAttribI4iv, glVertexAttribI4sv,
        glVertexAttribI4ubv, glVertexAttribI4ui, glVertexAttribI4uiv,
        glVertexAttribI4usv, glVertexAttribIPointer, gl_BGRA_INTEGER,
        gl_BGR_INTEGER, gl_BLUE_INTEGER, gl_BUFFER_ACCESS_FLAGS,
        gl_BUFFER_MAP_LENGTH, gl_BUFFER_MAP_OFFSET, gl_CLAMP_READ_COLOR,
        gl_CLIP_DISTANCE0, gl_CLIP_DISTANCE1, gl_CLIP_DISTANCE2,
        gl_CLIP_DISTANCE3, gl_CLIP_DISTANCE4, gl_CLIP_DISTANCE5,
        gl_CLIP_DISTANCE6, gl_CLIP_DISTANCE7, gl_COLOR_ATTACHMENT0,
        gl_COLOR_ATTACHMENT1, gl_COLOR_ATTACHMENT10, gl_COLOR_ATTACHMENT11,
        gl_COLOR_ATTACHMENT12, gl_COLOR_ATTACHMENT13,
        gl_COLOR_ATTACHMENT14, gl_COLOR_ATTACHMENT15, gl_COLOR_ATTACHMENT2,
        gl_COLOR_ATTACHMENT3, gl_COLOR_ATTACHMENT4, gl_COLOR_ATTACHMENT5,
        gl_COLOR_ATTACHMENT6, gl_COLOR_ATTACHMENT7, gl_COLOR_ATTACHMENT8,
        gl_COLOR_ATTACHMENT9, gl_COMPARE_REF_TO_TEXTURE, gl_COMPRESSED_RED,
        gl_COMPRESSED_RED_RGTC1, gl_COMPRESSED_RG, gl_COMPRESSED_RG_RGTC2,
        gl_COMPRESSED_SIGNED_RED_RGTC1, gl_COMPRESSED_SIGNED_RG_RGTC2,
        gl_CONTEXT_FLAGS, gl_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT,
        gl_DEPTH24_STENCIL8, gl_DEPTH32F_STENCIL8, gl_DEPTH_ATTACHMENT,
        gl_DEPTH_COMPONENT32F, gl_DEPTH_STENCIL,
        gl_DEPTH_STENCIL_ATTACHMENT, gl_DRAW_FRAMEBUFFER,
        gl_DRAW_FRAMEBUFFER_BINDING, gl_FIXED_ONLY,
        gl_FLOAT_32_UNSIGNED_INT_24_8_REV, gl_FRAMEBUFFER,
        gl_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING,
        gl_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
        gl_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
        gl_FRAMEBUFFER_ATTACHMENT_RED_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER,
        gl_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL, gl_FRAMEBUFFER_BINDING,
        gl_FRAMEBUFFER_COMPLETE, gl_FRAMEBUFFER_DEFAULT,
        gl_FRAMEBUFFER_INCOMPLETE_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER,
        gl_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT,
        gl_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE,
        gl_FRAMEBUFFER_INCOMPLETE_READ_BUFFER, gl_FRAMEBUFFER_SRGB,
        gl_FRAMEBUFFER_UNDEFINED, gl_FRAMEBUFFER_UNSUPPORTED,
        gl_GREEN_INTEGER, gl_HALF_FLOAT, gl_INTERLEAVED_ATTRIBS,
        gl_INT_SAMPLER_1D, gl_INT_SAMPLER_1D_ARRAY, gl_INT_SAMPLER_2D,
        gl_INT_SAMPLER_2D_ARRAY, gl_INT_SAMPLER_3D, gl_INT_SAMPLER_CUBE,
        gl_INVALID_FRAMEBUFFER_OPERATION, gl_MAJOR_VERSION,
        gl_MAP_FLUSH_EXPLICIT_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_READ_BIT,
        gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_WRITE_BIT,
        gl_MAX_ARRAY_TEXTURE_LAYERS, gl_MAX_CLIP_DISTANCES,
        gl_MAX_COLOR_ATTACHMENTS, gl_MAX_PROGRAM_TEXEL_OFFSET,
        gl_MAX_RENDERBUFFER_SIZE, gl_MAX_SAMPLES,
        gl_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS,
        gl_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS,
        gl_MAX_VARYING_COMPONENTS, gl_MINOR_VERSION,
        gl_MIN_PROGRAM_TEXEL_OFFSET, gl_NUM_EXTENSIONS,
        gl_PRIMITIVES_GENERATED, gl_PROXY_TEXTURE_1D_ARRAY,
        gl_PROXY_TEXTURE_2D_ARRAY, gl_QUERY_BY_REGION_NO_WAIT,
        gl_QUERY_BY_REGION_WAIT, gl_QUERY_NO_WAIT, gl_QUERY_WAIT,
        gl_R11F_G11F_B10F, gl_R16, gl_R16F, gl_R16I, gl_R16UI, gl_R32F,
        gl_R32I, gl_R32UI, gl_R8, gl_R8I, gl_R8UI, gl_RASTERIZER_DISCARD,
        gl_READ_FRAMEBUFFER, gl_READ_FRAMEBUFFER_BINDING, gl_RED_INTEGER,
        gl_RENDERBUFFER, gl_RENDERBUFFER_ALPHA_SIZE,
        gl_RENDERBUFFER_BINDING, gl_RENDERBUFFER_BLUE_SIZE,
        gl_RENDERBUFFER_DEPTH_SIZE, gl_RENDERBUFFER_GREEN_SIZE,
        gl_RENDERBUFFER_HEIGHT, gl_RENDERBUFFER_INTERNAL_FORMAT,
        gl_RENDERBUFFER_RED_SIZE, gl_RENDERBUFFER_SAMPLES,
        gl_RENDERBUFFER_STENCIL_SIZE, gl_RENDERBUFFER_WIDTH, gl_RG,
        gl_RG16, gl_RG16F, gl_RG16I, gl_RG16UI, gl_RG32F, gl_RG32I,
        gl_RG32UI, gl_RG8, gl_RG8I, gl_RG8UI, gl_RGB16F, gl_RGB16I,
        gl_RGB16UI, gl_RGB32F, gl_RGB32I, gl_RGB32UI, gl_RGB8I, gl_RGB8UI,
        gl_RGB9_E5, gl_RGBA16F, gl_RGBA16I, gl_RGBA16UI, gl_RGBA32F,
        gl_RGBA32I, gl_RGBA32UI, gl_RGBA8I, gl_RGBA8UI, gl_RGBA_INTEGER,
        gl_RGB_INTEGER, gl_RG_INTEGER, gl_SAMPLER_1D_ARRAY,
        gl_SAMPLER_1D_ARRAY_SHADOW, gl_SAMPLER_2D_ARRAY,
        gl_SAMPLER_2D_ARRAY_SHADOW, gl_SAMPLER_CUBE_SHADOW,
        gl_SEPARATE_ATTRIBS, gl_STENCIL_ATTACHMENT, gl_STENCIL_INDEX1,
        gl_STENCIL_INDEX16, gl_STENCIL_INDEX4, gl_STENCIL_INDEX8,
        gl_TEXTURE_1D_ARRAY, gl_TEXTURE_2D_ARRAY, gl_TEXTURE_ALPHA_TYPE,
        gl_TEXTURE_BINDING_1D_ARRAY, gl_TEXTURE_BINDING_2D_ARRAY,
        gl_TEXTURE_BLUE_TYPE, gl_TEXTURE_DEPTH_TYPE, gl_TEXTURE_GREEN_TYPE,
        gl_TEXTURE_RED_TYPE, gl_TEXTURE_SHARED_SIZE,
        gl_TEXTURE_STENCIL_SIZE, gl_TRANSFORM_FEEDBACK_BUFFER,
        gl_TRANSFORM_FEEDBACK_BUFFER_BINDING,
        gl_TRANSFORM_FEEDBACK_BUFFER_MODE,
        gl_TRANSFORM_FEEDBACK_BUFFER_SIZE,
        gl_TRANSFORM_FEEDBACK_BUFFER_START,
        gl_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN,
        gl_TRANSFORM_FEEDBACK_VARYINGS,
        gl_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH,
        gl_UNSIGNED_INT_10F_11F_11F_REV, gl_UNSIGNED_INT_24_8,
        gl_UNSIGNED_INT_5_9_9_9_REV, gl_UNSIGNED_INT_SAMPLER_1D,
        gl_UNSIGNED_INT_SAMPLER_1D_ARRAY, gl_UNSIGNED_INT_SAMPLER_2D,
        gl_UNSIGNED_INT_SAMPLER_2D_ARRAY, gl_UNSIGNED_INT_SAMPLER_3D,
        gl_UNSIGNED_INT_SAMPLER_CUBE, gl_UNSIGNED_INT_VEC2,
        gl_UNSIGNED_INT_VEC3, gl_UNSIGNED_INT_VEC4, gl_UNSIGNED_NORMALIZED,
        gl_VERTEX_ARRAY_BINDING, gl_VERTEX_ATTRIB_ARRAY_INTEGER)
import Graphics.Rendering.OpenGL.Raw.Core.Core31
       (glCopyBufferSubData, glDrawArraysInstanced,
        glDrawElementsInstanced, glGetActiveUniformBlockName,
        glGetActiveUniformBlockiv, glGetActiveUniformName,
        glGetActiveUniformsiv, glGetUniformBlockIndex, glGetUniformIndices,
        glPrimitiveRestartIndex, glTexBuffer, glUniformBlockBinding,
        gl_ACTIVE_UNIFORM_BLOCKS, gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH,
        gl_COPY_READ_BUFFER, gl_COPY_WRITE_BUFFER, gl_INT_SAMPLER_2D_RECT,
        gl_INT_SAMPLER_BUFFER, gl_INVALID_INDEX,
        gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS,
        gl_MAX_FRAGMENT_UNIFORM_BLOCKS, gl_MAX_RECTANGLE_TEXTURE_SIZE,
        gl_MAX_TEXTURE_BUFFER_SIZE, gl_MAX_UNIFORM_BLOCK_SIZE,
        gl_MAX_UNIFORM_BUFFER_BINDINGS, gl_MAX_VERTEX_UNIFORM_BLOCKS,
        gl_PRIMITIVE_RESTART, gl_PRIMITIVE_RESTART_INDEX,
        gl_PROXY_TEXTURE_RECTANGLE, gl_R16_SNORM, gl_R8_SNORM,
        gl_RG16_SNORM, gl_RG8_SNORM, gl_RGB16_SNORM, gl_RGB8_SNORM,
        gl_RGBA16_SNORM, gl_RGBA8_SNORM, gl_SAMPLER_2D_RECT,
        gl_SAMPLER_2D_RECT_SHADOW, gl_SAMPLER_BUFFER, gl_SIGNED_NORMALIZED,
        gl_TEXTURE_BINDING_BUFFER, gl_TEXTURE_BINDING_RECTANGLE,
        gl_TEXTURE_BUFFER, gl_TEXTURE_BUFFER_DATA_STORE_BINDING,
        gl_TEXTURE_RECTANGLE, gl_UNIFORM_ARRAY_STRIDE,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES, gl_UNIFORM_BLOCK_BINDING,
        gl_UNIFORM_BLOCK_DATA_SIZE, gl_UNIFORM_BLOCK_INDEX,
        gl_UNIFORM_BLOCK_NAME_LENGTH,
        gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER, gl_UNIFORM_BUFFER,
        gl_UNIFORM_BUFFER_BINDING, gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT,
        gl_UNIFORM_BUFFER_SIZE, gl_UNIFORM_BUFFER_START,
        gl_UNIFORM_IS_ROW_MAJOR, gl_UNIFORM_MATRIX_STRIDE,
        gl_UNIFORM_NAME_LENGTH, gl_UNIFORM_OFFSET, gl_UNIFORM_SIZE,
        gl_UNIFORM_TYPE, gl_UNSIGNED_INT_SAMPLER_2D_RECT,
        gl_UNSIGNED_INT_SAMPLER_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Core.Core32
       (glClientWaitSync, glDeleteSync, glDrawElementsBaseVertex,
        glDrawElementsInstancedBaseVertex, glDrawRangeElementsBaseVertex,
        glFenceSync, glFramebufferTexture, glGetBufferParameteri64v,
        glGetInteger64i_v, glGetInteger64v, glGetMultisamplefv,
        glGetSynciv, glIsSync, glMultiDrawElementsBaseVertex,
        glProvokingVertex, glSampleMaski, glTexImage2DMultisample,
        glTexImage3DMultisample, glWaitSync, gl_ALREADY_SIGNALED,
        gl_CONDITION_SATISFIED, gl_CONTEXT_COMPATIBILITY_PROFILE_BIT,
        gl_CONTEXT_CORE_PROFILE_BIT, gl_CONTEXT_PROFILE_MASK,
        gl_DEPTH_CLAMP, gl_FIRST_VERTEX_CONVENTION,
        gl_FRAMEBUFFER_ATTACHMENT_LAYERED,
        gl_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS, gl_GEOMETRY_INPUT_TYPE,
        gl_GEOMETRY_OUTPUT_TYPE, gl_GEOMETRY_SHADER,
        gl_GEOMETRY_VERTICES_OUT, gl_INT_SAMPLER_2D_MULTISAMPLE,
        gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_LAST_VERTEX_CONVENTION,
        gl_LINES_ADJACENCY, gl_LINE_STRIP_ADJACENCY,
        gl_MAX_COLOR_TEXTURE_SAMPLES, gl_MAX_DEPTH_TEXTURE_SAMPLES,
        gl_MAX_FRAGMENT_INPUT_COMPONENTS, gl_MAX_GEOMETRY_INPUT_COMPONENTS,
        gl_MAX_GEOMETRY_OUTPUT_COMPONENTS, gl_MAX_GEOMETRY_OUTPUT_VERTICES,
        gl_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS,
        gl_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_GEOMETRY_UNIFORM_COMPONENTS, gl_MAX_INTEGER_SAMPLES,
        gl_MAX_SAMPLE_MASK_WORDS, gl_MAX_SERVER_WAIT_TIMEOUT,
        gl_MAX_VERTEX_OUTPUT_COMPONENTS, gl_OBJECT_TYPE,
        gl_PROGRAM_POINT_SIZE, gl_PROVOKING_VERTEX,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION,
        gl_SAMPLER_2D_MULTISAMPLE, gl_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_SAMPLE_MASK, gl_SAMPLE_MASK_VALUE, gl_SAMPLE_POSITION,
        gl_SIGNALED, gl_SYNC_CONDITION, gl_SYNC_FENCE, gl_SYNC_FLAGS,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_STATUS, gl_TEXTURE_2D_MULTISAMPLE,
        gl_TEXTURE_2D_MULTISAMPLE_ARRAY, gl_TEXTURE_BINDING_2D_MULTISAMPLE,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_CUBE_MAP_SEAMLESS, gl_TEXTURE_FIXED_SAMPLE_LOCATIONS,
        gl_TEXTURE_SAMPLES, gl_TIMEOUT_EXPIRED, gl_TIMEOUT_IGNORED,
        gl_TRIANGLES_ADJACENCY, gl_TRIANGLE_STRIP_ADJACENCY, gl_UNSIGNALED,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_WAIT_FAILED)
import Graphics.Rendering.OpenGL.Raw.Core.Core33
       (glBindFragDataLocationIndexed, glBindSampler, glDeleteSamplers,
        glGenSamplers, glGetFragDataIndex, glGetQueryObjecti64v,
        glGetQueryObjectui64v, glGetSamplerParameterIiv,
        glGetSamplerParameterIuiv, glGetSamplerParameterfv,
        glGetSamplerParameteriv, glIsSampler, glQueryCounter,
        glSamplerParameterIiv, glSamplerParameterIuiv, glSamplerParameterf,
        glSamplerParameterfv, glSamplerParameteri, glSamplerParameteriv,
        glVertexAttribDivisor, glVertexAttribP1ui, glVertexAttribP1uiv,
        glVertexAttribP2ui, glVertexAttribP2uiv, glVertexAttribP3ui,
        glVertexAttribP3uiv, glVertexAttribP4ui, glVertexAttribP4uiv,
        gl_ANY_SAMPLES_PASSED, gl_INT_2_10_10_10_REV,
        gl_MAX_DUAL_SOURCE_DRAW_BUFFERS, gl_ONE_MINUS_SRC1_ALPHA,
        gl_ONE_MINUS_SRC1_COLOR, gl_RGB10_A2UI, gl_SAMPLER_BINDING,
        gl_SRC1_COLOR, gl_TEXTURE_SWIZZLE_A, gl_TEXTURE_SWIZZLE_B,
        gl_TEXTURE_SWIZZLE_G, gl_TEXTURE_SWIZZLE_R,
        gl_TEXTURE_SWIZZLE_RGBA, gl_TIMESTAMP, gl_TIME_ELAPSED,
        gl_VERTEX_ATTRIB_ARRAY_DIVISOR)
import Graphics.Rendering.OpenGL.Raw.Core.Core40
       (glBeginQueryIndexed, glBindTransformFeedback,
        glBlendEquationSeparatei, glBlendEquationi, glBlendFuncSeparatei,
        glBlendFunci, glDeleteTransformFeedbacks, glDrawArraysIndirect,
        glDrawElementsIndirect, glDrawTransformFeedback,
        glDrawTransformFeedbackStream, glEndQueryIndexed,
        glGenTransformFeedbacks, glGetActiveSubroutineName,
        glGetActiveSubroutineUniformName, glGetActiveSubroutineUniformiv,
        glGetProgramStageiv, glGetQueryIndexediv, glGetSubroutineIndex,
        glGetSubroutineUniformLocation, glGetUniformSubroutineuiv,
        glGetUniformdv, glIsTransformFeedback, glMinSampleShading,
        glPatchParameterfv, glPatchParameteri, glPauseTransformFeedback,
        glResumeTransformFeedback, glUniform1d, glUniform1dv, glUniform2d,
        glUniform2dv, glUniform3d, glUniform3dv, glUniform4d, glUniform4dv,
        glUniformMatrix2dv, glUniformMatrix2x3dv, glUniformMatrix2x4dv,
        glUniformMatrix3dv, glUniformMatrix3x2dv, glUniformMatrix3x4dv,
        glUniformMatrix4dv, glUniformMatrix4x2dv, glUniformMatrix4x3dv,
        glUniformSubroutinesuiv, gl_ACTIVE_SUBROUTINES,
        gl_ACTIVE_SUBROUTINE_MAX_LENGTH, gl_ACTIVE_SUBROUTINE_UNIFORMS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH, gl_COMPATIBLE_SUBROUTINES,
        gl_DOUBLE_MAT2, gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2x4, gl_DOUBLE_MAT3,
        gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3x4, gl_DOUBLE_MAT4,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4x3, gl_DOUBLE_VEC2, gl_DOUBLE_VEC3,
        gl_DOUBLE_VEC4, gl_DRAW_INDIRECT_BUFFER,
        gl_DRAW_INDIRECT_BUFFER_BINDING, gl_FRACTIONAL_EVEN,
        gl_FRACTIONAL_ODD, gl_FRAGMENT_INTERPOLATION_OFFSET_BITS,
        gl_GEOMETRY_SHADER_INVOCATIONS, gl_INT_SAMPLER_CUBE_MAP_ARRAY,
        gl_ISOLINES, gl_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS,
        gl_MAX_FRAGMENT_INTERPOLATION_OFFSET,
        gl_MAX_GEOMETRY_SHADER_INVOCATIONS, gl_MAX_PATCH_VERTICES,
        gl_MAX_PROGRAM_TEXTURE_GATHER_OFFSET, gl_MAX_SUBROUTINES,
        gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_MAX_TESS_CONTROL_INPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS,
        gl_MAX_TESS_CONTROL_UNIFORM_BLOCKS,
        gl_MAX_TESS_CONTROL_UNIFORM_COMPONENTS,
        gl_MAX_TESS_EVALUATION_INPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS,
        gl_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS,
        gl_MAX_TESS_EVALUATION_UNIFORM_BLOCKS,
        gl_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS, gl_MAX_TESS_GEN_LEVEL,
        gl_MAX_TESS_PATCH_COMPONENTS, gl_MAX_TRANSFORM_FEEDBACK_BUFFERS,
        gl_MAX_VERTEX_STREAMS, gl_MIN_FRAGMENT_INTERPOLATION_OFFSET,
        gl_MIN_PROGRAM_TEXTURE_GATHER_OFFSET, gl_MIN_SAMPLE_SHADING_VALUE,
        gl_NUM_COMPATIBLE_SUBROUTINES, gl_PATCHES,
        gl_PATCH_DEFAULT_INNER_LEVEL, gl_PATCH_DEFAULT_OUTER_LEVEL,
        gl_PATCH_VERTICES, gl_PROXY_TEXTURE_CUBE_MAP_ARRAY,
        gl_SAMPLER_CUBE_MAP_ARRAY, gl_SAMPLER_CUBE_MAP_ARRAY_SHADOW,
        gl_SAMPLE_SHADING, gl_TESS_CONTROL_OUTPUT_VERTICES,
        gl_TESS_CONTROL_SHADER, gl_TESS_EVALUATION_SHADER,
        gl_TESS_GEN_MODE, gl_TESS_GEN_POINT_MODE, gl_TESS_GEN_SPACING,
        gl_TESS_GEN_VERTEX_ORDER, gl_TEXTURE_BINDING_CUBE_MAP_ARRAY,
        gl_TEXTURE_CUBE_MAP_ARRAY, gl_TRANSFORM_FEEDBACK,
        gl_TRANSFORM_FEEDBACK_BINDING, gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER,
        gl_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_ACTIVE_PROGRAM :: GLenum
gl_ACTIVE_PROGRAM = 33369
 
gl_ALL_SHADER_BITS :: GLenum
gl_ALL_SHADER_BITS = 4294967295
 
gl_FIXED :: GLenum
gl_FIXED = 5132
 
gl_FRAGMENT_SHADER_BIT :: GLenum
gl_FRAGMENT_SHADER_BIT = 2
 
gl_GEOMETRY_SHADER_BIT :: GLenum
gl_GEOMETRY_SHADER_BIT = 4
 
gl_HIGH_FLOAT :: GLenum
gl_HIGH_FLOAT = 36338
 
gl_HIGH_INT :: GLenum
gl_HIGH_INT = 36341
 
gl_IMPLEMENTATION_COLOR_READ_FORMAT :: GLenum
gl_IMPLEMENTATION_COLOR_READ_FORMAT = 35739
 
gl_IMPLEMENTATION_COLOR_READ_TYPE :: GLenum
gl_IMPLEMENTATION_COLOR_READ_TYPE = 35738
 
gl_LAYER_PROVOKING_VERTEX :: GLenum
gl_LAYER_PROVOKING_VERTEX = 33374
 
gl_LOW_FLOAT :: GLenum
gl_LOW_FLOAT = 36336
 
gl_LOW_INT :: GLenum
gl_LOW_INT = 36339
 
gl_MAX_FRAGMENT_UNIFORM_VECTORS :: GLenum
gl_MAX_FRAGMENT_UNIFORM_VECTORS = 36349
 
gl_MAX_VARYING_VECTORS :: GLenum
gl_MAX_VARYING_VECTORS = 36348
 
gl_MAX_VERTEX_UNIFORM_VECTORS :: GLenum
gl_MAX_VERTEX_UNIFORM_VECTORS = 36347
 
gl_MAX_VIEWPORTS :: GLenum
gl_MAX_VIEWPORTS = 33371
 
gl_MEDIUM_FLOAT :: GLenum
gl_MEDIUM_FLOAT = 36337
 
gl_MEDIUM_INT :: GLenum
gl_MEDIUM_INT = 36340
 
gl_NUM_PROGRAM_BINARY_FORMATS :: GLenum
gl_NUM_PROGRAM_BINARY_FORMATS = 34814
 
gl_NUM_SHADER_BINARY_FORMATS :: GLenum
gl_NUM_SHADER_BINARY_FORMATS = 36345
 
gl_PROGRAM_BINARY_FORMATS :: GLenum
gl_PROGRAM_BINARY_FORMATS = 34815
 
gl_PROGRAM_BINARY_LENGTH :: GLenum
gl_PROGRAM_BINARY_LENGTH = 34625
 
gl_PROGRAM_BINARY_RETRIEVABLE_HINT :: GLenum
gl_PROGRAM_BINARY_RETRIEVABLE_HINT = 33367
 
gl_PROGRAM_PIPELINE_BINDING :: GLenum
gl_PROGRAM_PIPELINE_BINDING = 33370
 
gl_PROGRAM_SEPARABLE :: GLenum
gl_PROGRAM_SEPARABLE = 33368
 
gl_RGB565 :: GLenum
gl_RGB565 = 36194
 
gl_SHADER_BINARY_FORMATS :: GLenum
gl_SHADER_BINARY_FORMATS = 36344
 
gl_SHADER_COMPILER :: GLenum
gl_SHADER_COMPILER = 36346
 
gl_TESS_CONTROL_SHADER_BIT :: GLenum
gl_TESS_CONTROL_SHADER_BIT = 8
 
gl_TESS_EVALUATION_SHADER_BIT :: GLenum
gl_TESS_EVALUATION_SHADER_BIT = 16
 
gl_UNDEFINED_VERTEX :: GLenum
gl_UNDEFINED_VERTEX = 33376
 
gl_VERTEX_SHADER_BIT :: GLenum
gl_VERTEX_SHADER_BIT = 1
 
gl_VIEWPORT_BOUNDS_RANGE :: GLenum
gl_VIEWPORT_BOUNDS_RANGE = 33373
 
gl_VIEWPORT_INDEX_PROVOKING_VERTEX :: GLenum
gl_VIEWPORT_INDEX_PROVOKING_VERTEX = 33375
 
gl_VIEWPORT_SUBPIXEL_BITS :: GLenum
gl_VIEWPORT_SUBPIXEL_BITS = 33372
 
foreign import CALLCONV unsafe "dynamic" dyn_glActiveShaderProgram
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
glActiveShaderProgram :: GLuint -> GLuint -> IO ()
glActiveShaderProgram
  = dyn_glActiveShaderProgram ptr_glActiveShaderProgram
 
{-# NOINLINE ptr_glActiveShaderProgram #-}
 
ptr_glActiveShaderProgram :: FunPtr a
ptr_glActiveShaderProgram
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glActiveShaderProgram"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindProgramPipeline
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBindProgramPipeline :: GLuint -> IO ()
glBindProgramPipeline
  = dyn_glBindProgramPipeline ptr_glBindProgramPipeline
 
{-# NOINLINE ptr_glBindProgramPipeline #-}
 
ptr_glBindProgramPipeline :: FunPtr a
ptr_glBindProgramPipeline
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glBindProgramPipeline"
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearDepthf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
glClearDepthf :: GLfloat -> IO ()
glClearDepthf = dyn_glClearDepthf ptr_glClearDepthf
 
{-# NOINLINE ptr_glClearDepthf #-}
 
ptr_glClearDepthf :: FunPtr a
ptr_glClearDepthf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glClearDepthf"
 
foreign import CALLCONV unsafe "dynamic" dyn_glCreateShaderProgramv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr (Ptr GLchar) -> IO GLuint)
 
glCreateShaderProgramv ::
                       GLenum -> GLsizei -> Ptr (Ptr GLchar) -> IO GLuint
glCreateShaderProgramv
  = dyn_glCreateShaderProgramv ptr_glCreateShaderProgramv
 
{-# NOINLINE ptr_glCreateShaderProgramv #-}
 
ptr_glCreateShaderProgramv :: FunPtr a
ptr_glCreateShaderProgramv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glCreateShaderProgramv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDeleteProgramPipelines ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteProgramPipelines :: GLsizei -> Ptr GLuint -> IO ()
glDeleteProgramPipelines
  = dyn_glDeleteProgramPipelines ptr_glDeleteProgramPipelines
 
{-# NOINLINE ptr_glDeleteProgramPipelines #-}
 
ptr_glDeleteProgramPipelines :: FunPtr a
ptr_glDeleteProgramPipelines
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glDeleteProgramPipelines"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangeArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLdouble -> IO ())
 
glDepthRangeArrayv :: GLuint -> GLsizei -> Ptr GLdouble -> IO ()
glDepthRangeArrayv = dyn_glDepthRangeArrayv ptr_glDepthRangeArrayv
 
{-# NOINLINE ptr_glDepthRangeArrayv #-}
 
ptr_glDepthRangeArrayv :: FunPtr a
ptr_glDepthRangeArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glDepthRangeArrayv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangeIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> IO ())
 
glDepthRangeIndexed :: GLuint -> GLdouble -> GLdouble -> IO ()
glDepthRangeIndexed
  = dyn_glDepthRangeIndexed ptr_glDepthRangeIndexed
 
{-# NOINLINE ptr_glDepthRangeIndexed #-}
 
ptr_glDepthRangeIndexed :: FunPtr a
ptr_glDepthRangeIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glDepthRangeIndexed"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangef ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> IO ())
 
glDepthRangef :: GLfloat -> GLfloat -> IO ()
glDepthRangef = dyn_glDepthRangef ptr_glDepthRangef
 
{-# NOINLINE ptr_glDepthRangef #-}
 
ptr_glDepthRangef :: FunPtr a
ptr_glDepthRangef
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glDepthRangef"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenProgramPipelines
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenProgramPipelines :: GLsizei -> Ptr GLuint -> IO ()
glGenProgramPipelines
  = dyn_glGenProgramPipelines ptr_glGenProgramPipelines
 
{-# NOINLINE ptr_glGenProgramPipelines #-}
 
ptr_glGenProgramPipelines :: FunPtr a
ptr_glGenProgramPipelines
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGenProgramPipelines"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDoublei_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
glGetDoublei_v :: GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetDoublei_v = dyn_glGetDoublei_v ptr_glGetDoublei_v
 
{-# NOINLINE ptr_glGetDoublei_v #-}
 
ptr_glGetDoublei_v :: FunPtr a
ptr_glGetDoublei_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetDoublei_v"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFloati_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
glGetFloati_v :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetFloati_v = dyn_glGetFloati_v ptr_glGetFloati_v
 
{-# NOINLINE ptr_glGetFloati_v #-}
 
ptr_glGetFloati_v :: FunPtr a
ptr_glGetFloati_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetFloati_v"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramBinary ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr f -> IO ())
 
glGetProgramBinary ::
                   GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr f -> IO ()
glGetProgramBinary = dyn_glGetProgramBinary ptr_glGetProgramBinary
 
{-# NOINLINE ptr_glGetProgramBinary #-}
 
ptr_glGetProgramBinary :: FunPtr a
ptr_glGetProgramBinary
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetProgramBinary"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetProgramPipelineInfoLog ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
glGetProgramPipelineInfoLog ::
                            GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetProgramPipelineInfoLog
  = dyn_glGetProgramPipelineInfoLog ptr_glGetProgramPipelineInfoLog
 
{-# NOINLINE ptr_glGetProgramPipelineInfoLog #-}
 
ptr_glGetProgramPipelineInfoLog :: FunPtr a
ptr_glGetProgramPipelineInfoLog
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetProgramPipelineInfoLog"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramPipelineiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetProgramPipelineiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetProgramPipelineiv
  = dyn_glGetProgramPipelineiv ptr_glGetProgramPipelineiv
 
{-# NOINLINE ptr_glGetProgramPipelineiv #-}
 
ptr_glGetProgramPipelineiv :: FunPtr a
ptr_glGetProgramPipelineiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetProgramPipelineiv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetShaderPrecisionFormat ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> Ptr GLint -> IO ())
 
glGetShaderPrecisionFormat ::
                           GLenum -> GLenum -> Ptr GLint -> Ptr GLint -> IO ()
glGetShaderPrecisionFormat
  = dyn_glGetShaderPrecisionFormat ptr_glGetShaderPrecisionFormat
 
{-# NOINLINE ptr_glGetShaderPrecisionFormat #-}
 
ptr_glGetShaderPrecisionFormat :: FunPtr a
ptr_glGetShaderPrecisionFormat
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetShaderPrecisionFormat"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetVertexAttribLdv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLdouble -> IO ())
 
glGetVertexAttribLdv :: GLuint -> GLenum -> Ptr GLdouble -> IO ()
glGetVertexAttribLdv
  = dyn_glGetVertexAttribLdv ptr_glGetVertexAttribLdv
 
{-# NOINLINE ptr_glGetVertexAttribLdv #-}
 
ptr_glGetVertexAttribLdv :: FunPtr a
ptr_glGetVertexAttribLdv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glGetVertexAttribLdv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsProgramPipeline ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsProgramPipeline :: GLuint -> IO GLboolean
glIsProgramPipeline
  = dyn_glIsProgramPipeline ptr_glIsProgramPipeline
 
{-# NOINLINE ptr_glIsProgramPipeline #-}
 
ptr_glIsProgramPipeline :: FunPtr a
ptr_glIsProgramPipeline
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glIsProgramPipeline"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramBinary ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr d -> GLsizei -> IO ())
 
glProgramBinary :: GLuint -> GLenum -> Ptr d -> GLsizei -> IO ()
glProgramBinary = dyn_glProgramBinary ptr_glProgramBinary
 
{-# NOINLINE ptr_glProgramBinary #-}
 
ptr_glProgramBinary :: FunPtr a
ptr_glProgramBinary
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramBinary"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
glProgramParameteri :: GLuint -> GLenum -> GLint -> IO ()
glProgramParameteri
  = dyn_glProgramParameteri ptr_glProgramParameteri
 
{-# NOINLINE ptr_glProgramParameteri #-}
 
ptr_glProgramParameteri :: FunPtr a
ptr_glProgramParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramParameteri"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> IO ())
 
glProgramUniform1d :: GLuint -> GLint -> GLdouble -> IO ()
glProgramUniform1d = dyn_glProgramUniform1d ptr_glProgramUniform1d
 
{-# NOINLINE ptr_glProgramUniform1d #-}
 
ptr_glProgramUniform1d :: FunPtr a
ptr_glProgramUniform1d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform1dv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform1dv
  = dyn_glProgramUniform1dv ptr_glProgramUniform1dv
 
{-# NOINLINE ptr_glProgramUniform1dv #-}
 
ptr_glProgramUniform1dv :: FunPtr a
ptr_glProgramUniform1dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> IO ())
 
glProgramUniform1f :: GLuint -> GLint -> GLfloat -> IO ()
glProgramUniform1f = dyn_glProgramUniform1f ptr_glProgramUniform1f
 
{-# NOINLINE ptr_glProgramUniform1f #-}
 
ptr_glProgramUniform1f :: FunPtr a
ptr_glProgramUniform1f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1f"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform1fv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform1fv
  = dyn_glProgramUniform1fv ptr_glProgramUniform1fv
 
{-# NOINLINE ptr_glProgramUniform1fv #-}
 
ptr_glProgramUniform1fv :: FunPtr a
ptr_glProgramUniform1fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1fv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> IO ())
 
glProgramUniform1i :: GLuint -> GLint -> GLint -> IO ()
glProgramUniform1i = dyn_glProgramUniform1i ptr_glProgramUniform1i
 
{-# NOINLINE ptr_glProgramUniform1i #-}
 
ptr_glProgramUniform1i :: FunPtr a
ptr_glProgramUniform1i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform1iv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform1iv
  = dyn_glProgramUniform1iv ptr_glProgramUniform1iv
 
{-# NOINLINE ptr_glProgramUniform1iv #-}
 
ptr_glProgramUniform1iv :: FunPtr a
ptr_glProgramUniform1iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> IO ())
 
glProgramUniform1ui :: GLuint -> GLint -> GLuint -> IO ()
glProgramUniform1ui
  = dyn_glProgramUniform1ui ptr_glProgramUniform1ui
 
{-# NOINLINE ptr_glProgramUniform1ui #-}
 
ptr_glProgramUniform1ui :: FunPtr a
ptr_glProgramUniform1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform1uiv ::
                     GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform1uiv
  = dyn_glProgramUniform1uiv ptr_glProgramUniform1uiv
 
{-# NOINLINE ptr_glProgramUniform1uiv #-}
 
ptr_glProgramUniform1uiv :: FunPtr a
ptr_glProgramUniform1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform1uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform2d ::
                   GLuint -> GLint -> GLdouble -> GLdouble -> IO ()
glProgramUniform2d = dyn_glProgramUniform2d ptr_glProgramUniform2d
 
{-# NOINLINE ptr_glProgramUniform2d #-}
 
ptr_glProgramUniform2d :: FunPtr a
ptr_glProgramUniform2d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform2dv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform2dv
  = dyn_glProgramUniform2dv ptr_glProgramUniform2dv
 
{-# NOINLINE ptr_glProgramUniform2dv #-}
 
ptr_glProgramUniform2dv :: FunPtr a
ptr_glProgramUniform2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform2f ::
                   GLuint -> GLint -> GLfloat -> GLfloat -> IO ()
glProgramUniform2f = dyn_glProgramUniform2f ptr_glProgramUniform2f
 
{-# NOINLINE ptr_glProgramUniform2f #-}
 
ptr_glProgramUniform2f :: FunPtr a
ptr_glProgramUniform2f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2f"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform2fv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform2fv
  = dyn_glProgramUniform2fv ptr_glProgramUniform2fv
 
{-# NOINLINE ptr_glProgramUniform2fv #-}
 
ptr_glProgramUniform2fv :: FunPtr a
ptr_glProgramUniform2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2fv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform2i :: GLuint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform2i = dyn_glProgramUniform2i ptr_glProgramUniform2i
 
{-# NOINLINE ptr_glProgramUniform2i #-}
 
ptr_glProgramUniform2i :: FunPtr a
ptr_glProgramUniform2i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform2iv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform2iv
  = dyn_glProgramUniform2iv ptr_glProgramUniform2iv
 
{-# NOINLINE ptr_glProgramUniform2iv #-}
 
ptr_glProgramUniform2iv :: FunPtr a
ptr_glProgramUniform2iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> IO ())
 
glProgramUniform2ui :: GLuint -> GLint -> GLuint -> GLuint -> IO ()
glProgramUniform2ui
  = dyn_glProgramUniform2ui ptr_glProgramUniform2ui
 
{-# NOINLINE ptr_glProgramUniform2ui #-}
 
ptr_glProgramUniform2ui :: FunPtr a
ptr_glProgramUniform2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform2uiv ::
                     GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform2uiv
  = dyn_glProgramUniform2uiv ptr_glProgramUniform2uiv
 
{-# NOINLINE ptr_glProgramUniform2uiv #-}
 
ptr_glProgramUniform2uiv :: FunPtr a
ptr_glProgramUniform2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform2uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform3d ::
                   GLuint -> GLint -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramUniform3d = dyn_glProgramUniform3d ptr_glProgramUniform3d
 
{-# NOINLINE ptr_glProgramUniform3d #-}
 
ptr_glProgramUniform3d :: FunPtr a
ptr_glProgramUniform3d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform3dv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform3dv
  = dyn_glProgramUniform3dv ptr_glProgramUniform3dv
 
{-# NOINLINE ptr_glProgramUniform3dv #-}
 
ptr_glProgramUniform3dv :: FunPtr a
ptr_glProgramUniform3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform3f ::
                   GLuint -> GLint -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramUniform3f = dyn_glProgramUniform3f ptr_glProgramUniform3f
 
{-# NOINLINE ptr_glProgramUniform3f #-}
 
ptr_glProgramUniform3f :: FunPtr a
ptr_glProgramUniform3f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3f"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform3fv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform3fv
  = dyn_glProgramUniform3fv ptr_glProgramUniform3fv
 
{-# NOINLINE ptr_glProgramUniform3fv #-}
 
ptr_glProgramUniform3fv :: FunPtr a
ptr_glProgramUniform3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3fv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform3i ::
                   GLuint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform3i = dyn_glProgramUniform3i ptr_glProgramUniform3i
 
{-# NOINLINE ptr_glProgramUniform3i #-}
 
ptr_glProgramUniform3i :: FunPtr a
ptr_glProgramUniform3i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform3iv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform3iv
  = dyn_glProgramUniform3iv ptr_glProgramUniform3iv
 
{-# NOINLINE ptr_glProgramUniform3iv #-}
 
ptr_glProgramUniform3iv :: FunPtr a
ptr_glProgramUniform3iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramUniform3ui ::
                    GLuint -> GLint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramUniform3ui
  = dyn_glProgramUniform3ui ptr_glProgramUniform3ui
 
{-# NOINLINE ptr_glProgramUniform3ui #-}
 
ptr_glProgramUniform3ui :: FunPtr a
ptr_glProgramUniform3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform3uiv ::
                     GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform3uiv
  = dyn_glProgramUniform3uiv ptr_glProgramUniform3uiv
 
{-# NOINLINE ptr_glProgramUniform3uiv #-}
 
ptr_glProgramUniform3uiv :: FunPtr a
ptr_glProgramUniform3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform3uiv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glProgramUniform4d ::
                   GLuint ->
                     GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glProgramUniform4d = dyn_glProgramUniform4d ptr_glProgramUniform4d
 
{-# NOINLINE ptr_glProgramUniform4d #-}
 
ptr_glProgramUniform4d :: FunPtr a
ptr_glProgramUniform4d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
glProgramUniform4dv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLdouble -> IO ()
glProgramUniform4dv
  = dyn_glProgramUniform4dv ptr_glProgramUniform4dv
 
{-# NOINLINE ptr_glProgramUniform4dv #-}
 
ptr_glProgramUniform4dv :: FunPtr a
ptr_glProgramUniform4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4f ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glProgramUniform4f ::
                   GLuint ->
                     GLint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glProgramUniform4f = dyn_glProgramUniform4f ptr_glProgramUniform4f
 
{-# NOINLINE ptr_glProgramUniform4f #-}
 
ptr_glProgramUniform4f :: FunPtr a
ptr_glProgramUniform4f
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4f"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ())
 
glProgramUniform4fv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLfloat -> IO ()
glProgramUniform4fv
  = dyn_glProgramUniform4fv ptr_glProgramUniform4fv
 
{-# NOINLINE ptr_glProgramUniform4fv #-}
 
ptr_glProgramUniform4fv :: FunPtr a
ptr_glProgramUniform4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4fv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4i ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLint -> GLint -> GLint -> IO ())
 
glProgramUniform4i ::
                   GLuint -> GLint -> GLint -> GLint -> GLint -> GLint -> IO ()
glProgramUniform4i = dyn_glProgramUniform4i ptr_glProgramUniform4i
 
{-# NOINLINE ptr_glProgramUniform4i #-}
 
ptr_glProgramUniform4i :: FunPtr a
ptr_glProgramUniform4i
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4i"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4iv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ())
 
glProgramUniform4iv ::
                    GLuint -> GLint -> GLsizei -> Ptr GLint -> IO ()
glProgramUniform4iv
  = dyn_glProgramUniform4iv ptr_glProgramUniform4iv
 
{-# NOINLINE ptr_glProgramUniform4iv #-}
 
ptr_glProgramUniform4iv :: FunPtr a
ptr_glProgramUniform4iv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4iv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ())
 
glProgramUniform4ui ::
                    GLuint -> GLint -> GLuint -> GLuint -> GLuint -> GLuint -> IO ()
glProgramUniform4ui
  = dyn_glProgramUniform4ui ptr_glProgramUniform4ui
 
{-# NOINLINE ptr_glProgramUniform4ui #-}
 
ptr_glProgramUniform4ui :: FunPtr a
ptr_glProgramUniform4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4ui"
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramUniform4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ())
 
glProgramUniform4uiv ::
                     GLuint -> GLint -> GLsizei -> Ptr GLuint -> IO ()
glProgramUniform4uiv
  = dyn_glProgramUniform4uiv ptr_glProgramUniform4uiv
 
{-# NOINLINE ptr_glProgramUniform4uiv #-}
 
ptr_glProgramUniform4uiv :: FunPtr a
ptr_glProgramUniform4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniform4uiv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2dv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2dv
  = dyn_glProgramUniformMatrix2dv ptr_glProgramUniformMatrix2dv
 
{-# NOINLINE ptr_glProgramUniformMatrix2dv #-}
 
ptr_glProgramUniformMatrix2dv :: FunPtr a
ptr_glProgramUniformMatrix2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2fv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2fv
  = dyn_glProgramUniformMatrix2fv ptr_glProgramUniformMatrix2fv
 
{-# NOINLINE ptr_glProgramUniformMatrix2fv #-}
 
ptr_glProgramUniformMatrix2fv :: FunPtr a
ptr_glProgramUniformMatrix2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2x3dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2x3dv
  = dyn_glProgramUniformMatrix2x3dv ptr_glProgramUniformMatrix2x3dv
 
{-# NOINLINE ptr_glProgramUniformMatrix2x3dv #-}
 
ptr_glProgramUniformMatrix2x3dv :: FunPtr a
ptr_glProgramUniformMatrix2x3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2x3dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2x3fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2x3fv
  = dyn_glProgramUniformMatrix2x3fv ptr_glProgramUniformMatrix2x3fv
 
{-# NOINLINE ptr_glProgramUniformMatrix2x3fv #-}
 
ptr_glProgramUniformMatrix2x3fv :: FunPtr a
ptr_glProgramUniformMatrix2x3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2x3fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix2x4dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix2x4dv
  = dyn_glProgramUniformMatrix2x4dv ptr_glProgramUniformMatrix2x4dv
 
{-# NOINLINE ptr_glProgramUniformMatrix2x4dv #-}
 
ptr_glProgramUniformMatrix2x4dv :: FunPtr a
ptr_glProgramUniformMatrix2x4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2x4dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix2x4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix2x4fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix2x4fv
  = dyn_glProgramUniformMatrix2x4fv ptr_glProgramUniformMatrix2x4fv
 
{-# NOINLINE ptr_glProgramUniformMatrix2x4fv #-}
 
ptr_glProgramUniformMatrix2x4fv :: FunPtr a
ptr_glProgramUniformMatrix2x4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix2x4fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3dv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3dv
  = dyn_glProgramUniformMatrix3dv ptr_glProgramUniformMatrix3dv
 
{-# NOINLINE ptr_glProgramUniformMatrix3dv #-}
 
ptr_glProgramUniformMatrix3dv :: FunPtr a
ptr_glProgramUniformMatrix3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3fv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3fv
  = dyn_glProgramUniformMatrix3fv ptr_glProgramUniformMatrix3fv
 
{-# NOINLINE ptr_glProgramUniformMatrix3fv #-}
 
ptr_glProgramUniformMatrix3fv :: FunPtr a
ptr_glProgramUniformMatrix3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3x2dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3x2dv
  = dyn_glProgramUniformMatrix3x2dv ptr_glProgramUniformMatrix3x2dv
 
{-# NOINLINE ptr_glProgramUniformMatrix3x2dv #-}
 
ptr_glProgramUniformMatrix3x2dv :: FunPtr a
ptr_glProgramUniformMatrix3x2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3x2dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3x2fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3x2fv
  = dyn_glProgramUniformMatrix3x2fv ptr_glProgramUniformMatrix3x2fv
 
{-# NOINLINE ptr_glProgramUniformMatrix3x2fv #-}
 
ptr_glProgramUniformMatrix3x2fv :: FunPtr a
ptr_glProgramUniformMatrix3x2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3x2fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix3x4dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix3x4dv
  = dyn_glProgramUniformMatrix3x4dv ptr_glProgramUniformMatrix3x4dv
 
{-# NOINLINE ptr_glProgramUniformMatrix3x4dv #-}
 
ptr_glProgramUniformMatrix3x4dv :: FunPtr a
ptr_glProgramUniformMatrix3x4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3x4dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix3x4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix3x4fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix3x4fv
  = dyn_glProgramUniformMatrix3x4fv ptr_glProgramUniformMatrix3x4fv
 
{-# NOINLINE ptr_glProgramUniformMatrix3x4fv #-}
 
ptr_glProgramUniformMatrix3x4fv :: FunPtr a
ptr_glProgramUniformMatrix3x4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix3x4fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4dv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4dv
  = dyn_glProgramUniformMatrix4dv ptr_glProgramUniformMatrix4dv
 
{-# NOINLINE ptr_glProgramUniformMatrix4dv #-}
 
ptr_glProgramUniformMatrix4dv :: FunPtr a
ptr_glProgramUniformMatrix4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4fv ::
                          GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4fv
  = dyn_glProgramUniformMatrix4fv ptr_glProgramUniformMatrix4fv
 
{-# NOINLINE ptr_glProgramUniformMatrix4fv #-}
 
ptr_glProgramUniformMatrix4fv :: FunPtr a
ptr_glProgramUniformMatrix4fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4x2dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4x2dv
  = dyn_glProgramUniformMatrix4x2dv ptr_glProgramUniformMatrix4x2dv
 
{-# NOINLINE ptr_glProgramUniformMatrix4x2dv #-}
 
ptr_glProgramUniformMatrix4x2dv :: FunPtr a
ptr_glProgramUniformMatrix4x2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4x2dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x2fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4x2fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4x2fv
  = dyn_glProgramUniformMatrix4x2fv ptr_glProgramUniformMatrix4x2fv
 
{-# NOINLINE ptr_glProgramUniformMatrix4x2fv #-}
 
ptr_glProgramUniformMatrix4x2fv :: FunPtr a
ptr_glProgramUniformMatrix4x2fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4x2fv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
glProgramUniformMatrix4x3dv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glProgramUniformMatrix4x3dv
  = dyn_glProgramUniformMatrix4x3dv ptr_glProgramUniformMatrix4x3dv
 
{-# NOINLINE ptr_glProgramUniformMatrix4x3dv #-}
 
ptr_glProgramUniformMatrix4x3dv :: FunPtr a
ptr_glProgramUniformMatrix4x3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4x3dv"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glProgramUniformMatrix4x3fv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ())
 
glProgramUniformMatrix4x3fv ::
                            GLuint -> GLint -> GLsizei -> GLboolean -> Ptr GLfloat -> IO ()
glProgramUniformMatrix4x3fv
  = dyn_glProgramUniformMatrix4x3fv ptr_glProgramUniformMatrix4x3fv
 
{-# NOINLINE ptr_glProgramUniformMatrix4x3fv #-}
 
ptr_glProgramUniformMatrix4x3fv :: FunPtr a
ptr_glProgramUniformMatrix4x3fv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glProgramUniformMatrix4x3fv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glReleaseShaderCompiler
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glReleaseShaderCompiler :: IO ()
glReleaseShaderCompiler
  = dyn_glReleaseShaderCompiler ptr_glReleaseShaderCompiler
 
{-# NOINLINE ptr_glReleaseShaderCompiler #-}
 
ptr_glReleaseShaderCompiler :: FunPtr a
ptr_glReleaseShaderCompiler
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glReleaseShaderCompiler"
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLint -> IO ())
 
glScissorArrayv :: GLuint -> GLsizei -> Ptr GLint -> IO ()
glScissorArrayv = dyn_glScissorArrayv ptr_glScissorArrayv
 
{-# NOINLINE ptr_glScissorArrayv #-}
 
ptr_glScissorArrayv :: FunPtr a
ptr_glScissorArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glScissorArrayv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
glScissorIndexed ::
                 GLuint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glScissorIndexed = dyn_glScissorIndexed ptr_glScissorIndexed
 
{-# NOINLINE ptr_glScissorIndexed #-}
 
ptr_glScissorIndexed :: FunPtr a
ptr_glScissorIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glScissorIndexed"
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorIndexedv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
glScissorIndexedv :: GLuint -> Ptr GLint -> IO ()
glScissorIndexedv = dyn_glScissorIndexedv ptr_glScissorIndexedv
 
{-# NOINLINE ptr_glScissorIndexedv #-}
 
ptr_glScissorIndexedv :: FunPtr a
ptr_glScissorIndexedv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glScissorIndexedv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glShaderBinary ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> GLenum -> Ptr e -> GLsizei -> IO ())
 
glShaderBinary ::
               GLsizei -> Ptr GLuint -> GLenum -> Ptr e -> GLsizei -> IO ()
glShaderBinary = dyn_glShaderBinary ptr_glShaderBinary
 
{-# NOINLINE ptr_glShaderBinary #-}
 
ptr_glShaderBinary :: FunPtr a
ptr_glShaderBinary
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glShaderBinary"
 
foreign import CALLCONV unsafe "dynamic" dyn_glUseProgramStages ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLbitfield -> GLuint -> IO ())
 
glUseProgramStages :: GLuint -> GLbitfield -> GLuint -> IO ()
glUseProgramStages = dyn_glUseProgramStages ptr_glUseProgramStages
 
{-# NOINLINE ptr_glUseProgramStages #-}
 
ptr_glUseProgramStages :: FunPtr a
ptr_glUseProgramStages
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glUseProgramStages"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glValidateProgramPipeline ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glValidateProgramPipeline :: GLuint -> IO ()
glValidateProgramPipeline
  = dyn_glValidateProgramPipeline ptr_glValidateProgramPipeline
 
{-# NOINLINE ptr_glValidateProgramPipeline #-}
 
ptr_glValidateProgramPipeline :: FunPtr a
ptr_glValidateProgramPipeline
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glValidateProgramPipeline"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL1d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> IO ())
 
glVertexAttribL1d :: GLuint -> GLdouble -> IO ()
glVertexAttribL1d = dyn_glVertexAttribL1d ptr_glVertexAttribL1d
 
{-# NOINLINE ptr_glVertexAttribL1d #-}
 
ptr_glVertexAttribL1d :: FunPtr a
ptr_glVertexAttribL1d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL1d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL1dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttribL1dv :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttribL1dv = dyn_glVertexAttribL1dv ptr_glVertexAttribL1dv
 
{-# NOINLINE ptr_glVertexAttribL1dv #-}
 
ptr_glVertexAttribL1dv :: FunPtr a
ptr_glVertexAttribL1dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL1dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL2d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> IO ())
 
glVertexAttribL2d :: GLuint -> GLdouble -> GLdouble -> IO ()
glVertexAttribL2d = dyn_glVertexAttribL2d ptr_glVertexAttribL2d
 
{-# NOINLINE ptr_glVertexAttribL2d #-}
 
ptr_glVertexAttribL2d :: FunPtr a
ptr_glVertexAttribL2d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL2d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttribL2dv :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttribL2dv = dyn_glVertexAttribL2dv ptr_glVertexAttribL2dv
 
{-# NOINLINE ptr_glVertexAttribL2dv #-}
 
ptr_glVertexAttribL2dv :: FunPtr a
ptr_glVertexAttribL2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL2dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL3d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glVertexAttribL3d ::
                  GLuint -> GLdouble -> GLdouble -> GLdouble -> IO ()
glVertexAttribL3d = dyn_glVertexAttribL3d ptr_glVertexAttribL3d
 
{-# NOINLINE ptr_glVertexAttribL3d #-}
 
ptr_glVertexAttribL3d :: FunPtr a
ptr_glVertexAttribL3d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL3d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttribL3dv :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttribL3dv = dyn_glVertexAttribL3dv ptr_glVertexAttribL3dv
 
{-# NOINLINE ptr_glVertexAttribL3dv #-}
 
ptr_glVertexAttribL3dv :: FunPtr a
ptr_glVertexAttribL3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL3dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL4d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
glVertexAttribL4d ::
                  GLuint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glVertexAttribL4d = dyn_glVertexAttribL4d ptr_glVertexAttribL4d
 
{-# NOINLINE ptr_glVertexAttribL4d #-}
 
ptr_glVertexAttribL4d :: FunPtr a
ptr_glVertexAttribL4d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL4d"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribL4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLdouble -> IO ())
 
glVertexAttribL4dv :: GLuint -> Ptr GLdouble -> IO ()
glVertexAttribL4dv = dyn_glVertexAttribL4dv ptr_glVertexAttribL4dv
 
{-# NOINLINE ptr_glVertexAttribL4dv #-}
 
ptr_glVertexAttribL4dv :: FunPtr a
ptr_glVertexAttribL4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribL4dv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribLPointer
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ())
 
glVertexAttribLPointer ::
                       GLuint -> GLint -> GLenum -> GLsizei -> Ptr f -> IO ()
glVertexAttribLPointer
  = dyn_glVertexAttribLPointer ptr_glVertexAttribLPointer
 
{-# NOINLINE ptr_glVertexAttribLPointer #-}
 
ptr_glVertexAttribLPointer :: FunPtr a
ptr_glVertexAttribLPointer
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glVertexAttribLPointer"
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
glViewportArrayv :: GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glViewportArrayv = dyn_glViewportArrayv ptr_glViewportArrayv
 
{-# NOINLINE ptr_glViewportArrayv #-}
 
ptr_glViewportArrayv :: FunPtr a
ptr_glViewportArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glViewportArrayv"
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportIndexedf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glViewportIndexedf ::
                   GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glViewportIndexedf = dyn_glViewportIndexedf ptr_glViewportIndexedf
 
{-# NOINLINE ptr_glViewportIndexedf #-}
 
ptr_glViewportIndexedf :: FunPtr a
ptr_glViewportIndexedf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glViewportIndexedf"
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportIndexedfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
glViewportIndexedfv :: GLuint -> Ptr GLfloat -> IO ()
glViewportIndexedfv
  = dyn_glViewportIndexedfv ptr_glViewportIndexedfv
 
{-# NOINLINE ptr_glViewportIndexedfv #-}
 
ptr_glViewportIndexedfv :: FunPtr a
ptr_glViewportIndexedfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_4_1"
        "glViewportIndexedfv"