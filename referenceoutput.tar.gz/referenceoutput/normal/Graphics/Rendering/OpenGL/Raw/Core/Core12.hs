-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.Core.Core12
       (module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12,
        module Graphics.Rendering.OpenGL.Raw.Types)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
import Graphics.Rendering.OpenGL.Raw.Types