-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.KHR
       (module Graphics.Rendering.OpenGL.Raw.KHR.Debug,
        module Graphics.Rendering.OpenGL.Raw.KHR.DebugCompatibility,
        module Graphics.Rendering.OpenGL.Raw.KHR.TextureCompressionAstcLdr)
       where
import Graphics.Rendering.OpenGL.Raw.KHR.Debug
import Graphics.Rendering.OpenGL.Raw.KHR.DebugCompatibility
import Graphics.Rendering.OpenGL.Raw.KHR.TextureCompressionAstcLdr