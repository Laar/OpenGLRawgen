{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.APPLE.ElementArray
       (gl_ELEMENT_ARRAY_APPLE, gl_ELEMENT_ARRAY_POINTER_APPLE,
        gl_ELEMENT_ARRAY_TYPE_APPLE, glDrawElementArrayAPPLE,
        glDrawRangeElementArrayAPPLE, glElementPointerAPPLE,
        glMultiDrawElementArrayAPPLE, glMultiDrawRangeElementArrayAPPLE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ELEMENT_ARRAY_APPLE :: GLenum
gl_ELEMENT_ARRAY_APPLE = 35340
 
gl_ELEMENT_ARRAY_POINTER_APPLE :: GLenum
gl_ELEMENT_ARRAY_POINTER_APPLE = 35342
 
gl_ELEMENT_ARRAY_TYPE_APPLE :: GLenum
gl_ELEMENT_ARRAY_TYPE_APPLE = 35341
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawElementArrayAPPLE
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> IO ())
 
glDrawElementArrayAPPLE :: GLenum -> GLint -> GLsizei -> IO ()
glDrawElementArrayAPPLE
  = dyn_glDrawElementArrayAPPLE ptr_glDrawElementArrayAPPLE
 
{-# NOINLINE ptr_glDrawElementArrayAPPLE #-}
 
ptr_glDrawElementArrayAPPLE :: FunPtr a
ptr_glDrawElementArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glDrawElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawRangeElementArrayAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLint -> GLsizei -> IO ())
 
glDrawRangeElementArrayAPPLE ::
                             GLenum -> GLuint -> GLuint -> GLint -> GLsizei -> IO ()
glDrawRangeElementArrayAPPLE
  = dyn_glDrawRangeElementArrayAPPLE ptr_glDrawRangeElementArrayAPPLE
 
{-# NOINLINE ptr_glDrawRangeElementArrayAPPLE #-}
 
ptr_glDrawRangeElementArrayAPPLE :: FunPtr a
ptr_glDrawRangeElementArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glDrawRangeElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glElementPointerAPPLE
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> IO ())
 
glElementPointerAPPLE :: GLenum -> Ptr a -> IO ()
glElementPointerAPPLE
  = dyn_glElementPointerAPPLE ptr_glElementPointerAPPLE
 
{-# NOINLINE ptr_glElementPointerAPPLE #-}
 
ptr_glElementPointerAPPLE :: FunPtr a
ptr_glElementPointerAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glElementPointerAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementArrayAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ())
 
glMultiDrawElementArrayAPPLE ::
                             GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ()
glMultiDrawElementArrayAPPLE
  = dyn_glMultiDrawElementArrayAPPLE ptr_glMultiDrawElementArrayAPPLE
 
{-# NOINLINE ptr_glMultiDrawElementArrayAPPLE #-}
 
ptr_glMultiDrawElementArrayAPPLE :: FunPtr a
ptr_glMultiDrawElementArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glMultiDrawElementArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawRangeElementArrayAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLuint -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ())
 
glMultiDrawRangeElementArrayAPPLE ::
                                  GLenum ->
                                    GLuint -> GLuint -> Ptr GLint -> Ptr GLsizei -> GLsizei -> IO ()
glMultiDrawRangeElementArrayAPPLE
  = dyn_glMultiDrawRangeElementArrayAPPLE
      ptr_glMultiDrawRangeElementArrayAPPLE
 
{-# NOINLINE ptr_glMultiDrawRangeElementArrayAPPLE #-}
 
ptr_glMultiDrawRangeElementArrayAPPLE :: FunPtr a
ptr_glMultiDrawRangeElementArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_element_array"
        "glMultiDrawRangeElementArrayAPPLE"