-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.Rgb422
       (gl_RGB_422_APPLE, gl_RGB_RAW_422_APPLE,
        gl_UNSIGNED_SHORT_8_8_APPLE, gl_UNSIGNED_SHORT_8_8_REV_APPLE)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_RGB_422_APPLE :: GLenum
gl_RGB_422_APPLE = 35359
 
gl_RGB_RAW_422_APPLE :: GLenum
gl_RGB_RAW_422_APPLE = 35409
 
gl_UNSIGNED_SHORT_8_8_APPLE :: GLenum
gl_UNSIGNED_SHORT_8_8_APPLE = 34234
 
gl_UNSIGNED_SHORT_8_8_REV_APPLE :: GLenum
gl_UNSIGNED_SHORT_8_8_REV_APPLE = 34235