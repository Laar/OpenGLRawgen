-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.ClientStorage
       (gl_UNPACK_CLIENT_STORAGE_APPLE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_UNPACK_CLIENT_STORAGE_APPLE :: GLenum
gl_UNPACK_CLIENT_STORAGE_APPLE = 34226