{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.Fence
       (gl_DRAW_PIXELS_APPLE, gl_FENCE_APPLE, glDeleteFencesAPPLE,
        glFinishFenceAPPLE, glFinishObjectAPPLE, glGenFencesAPPLE,
        glIsFenceAPPLE, glSetFenceAPPLE, glTestFenceAPPLE,
        glTestObjectAPPLE)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DRAW_PIXELS_APPLE :: GLenum
gl_DRAW_PIXELS_APPLE = 35338
 
gl_FENCE_APPLE :: GLenum
gl_FENCE_APPLE = 35339
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteFencesAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteFencesAPPLE :: GLsizei -> Ptr GLuint -> IO ()
glDeleteFencesAPPLE
  = dyn_glDeleteFencesAPPLE ptr_glDeleteFencesAPPLE
 
{-# NOINLINE ptr_glDeleteFencesAPPLE #-}
 
ptr_glDeleteFencesAPPLE :: FunPtr a
ptr_glDeleteFencesAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glDeleteFencesAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishFenceAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glFinishFenceAPPLE :: GLuint -> IO ()
glFinishFenceAPPLE = dyn_glFinishFenceAPPLE ptr_glFinishFenceAPPLE
 
{-# NOINLINE ptr_glFinishFenceAPPLE #-}
 
ptr_glFinishFenceAPPLE :: FunPtr a
ptr_glFinishFenceAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glFinishFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishObjectAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
glFinishObjectAPPLE :: GLenum -> GLint -> IO ()
glFinishObjectAPPLE
  = dyn_glFinishObjectAPPLE ptr_glFinishObjectAPPLE
 
{-# NOINLINE ptr_glFinishObjectAPPLE #-}
 
ptr_glFinishObjectAPPLE :: FunPtr a
ptr_glFinishObjectAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glFinishObjectAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenFencesAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenFencesAPPLE :: GLsizei -> Ptr GLuint -> IO ()
glGenFencesAPPLE = dyn_glGenFencesAPPLE ptr_glGenFencesAPPLE
 
{-# NOINLINE ptr_glGenFencesAPPLE #-}
 
ptr_glGenFencesAPPLE :: FunPtr a
ptr_glGenFencesAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glGenFencesAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsFenceAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsFenceAPPLE :: GLuint -> IO GLboolean
glIsFenceAPPLE = dyn_glIsFenceAPPLE ptr_glIsFenceAPPLE
 
{-# NOINLINE ptr_glIsFenceAPPLE #-}
 
ptr_glIsFenceAPPLE :: FunPtr a
ptr_glIsFenceAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glIsFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetFenceAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glSetFenceAPPLE :: GLuint -> IO ()
glSetFenceAPPLE = dyn_glSetFenceAPPLE ptr_glSetFenceAPPLE
 
{-# NOINLINE ptr_glSetFenceAPPLE #-}
 
ptr_glSetFenceAPPLE :: FunPtr a
ptr_glSetFenceAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glSetFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestFenceAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glTestFenceAPPLE :: GLuint -> IO GLboolean
glTestFenceAPPLE = dyn_glTestFenceAPPLE ptr_glTestFenceAPPLE
 
{-# NOINLINE ptr_glTestFenceAPPLE #-}
 
ptr_glTestFenceAPPLE :: FunPtr a
ptr_glTestFenceAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glTestFenceAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestObjectAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO GLboolean)
 
glTestObjectAPPLE :: GLenum -> GLuint -> IO GLboolean
glTestObjectAPPLE = dyn_glTestObjectAPPLE ptr_glTestObjectAPPLE
 
{-# NOINLINE ptr_glTestObjectAPPLE #-}
 
ptr_glTestObjectAPPLE :: FunPtr a
ptr_glTestObjectAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_fence"
        "glTestObjectAPPLE"