-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.Ycbcr422
       (gl_UNSIGNED_SHORT_8_8_APPLE, gl_UNSIGNED_SHORT_8_8_REV_APPLE,
        gl_YCBCR_422_APPLE)
       where
import Graphics.Rendering.OpenGL.Raw.APPLE.Rgb422
       (gl_UNSIGNED_SHORT_8_8_APPLE)
import Graphics.Rendering.OpenGL.Raw.APPLE.Rgb422
       (gl_UNSIGNED_SHORT_8_8_REV_APPLE)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_YCBCR_422_APPLE :: GLenum
gl_YCBCR_422_APPLE = 34233