{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.VertexArrayObject
       (gl_VERTEX_ARRAY_BINDING_APPLE, glBindVertexArrayAPPLE,
        glDeleteVertexArraysAPPLE, glGenVertexArraysAPPLE,
        glIsVertexArrayAPPLE)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_VERTEX_ARRAY_BINDING_APPLE :: GLenum
gl_VERTEX_ARRAY_BINDING_APPLE = 34229
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindVertexArrayAPPLE
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glBindVertexArrayAPPLE :: GLuint -> IO ()
glBindVertexArrayAPPLE
  = dyn_glBindVertexArrayAPPLE ptr_glBindVertexArrayAPPLE
 
{-# NOINLINE ptr_glBindVertexArrayAPPLE #-}
 
ptr_glBindVertexArrayAPPLE :: FunPtr a
ptr_glBindVertexArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_vertex_array_object"
        "glBindVertexArrayAPPLE"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDeleteVertexArraysAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteVertexArraysAPPLE :: GLsizei -> Ptr GLuint -> IO ()
glDeleteVertexArraysAPPLE
  = dyn_glDeleteVertexArraysAPPLE ptr_glDeleteVertexArraysAPPLE
 
{-# NOINLINE ptr_glDeleteVertexArraysAPPLE #-}
 
ptr_glDeleteVertexArraysAPPLE :: FunPtr a
ptr_glDeleteVertexArraysAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_vertex_array_object"
        "glDeleteVertexArraysAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenVertexArraysAPPLE
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenVertexArraysAPPLE :: GLsizei -> Ptr GLuint -> IO ()
glGenVertexArraysAPPLE
  = dyn_glGenVertexArraysAPPLE ptr_glGenVertexArraysAPPLE
 
{-# NOINLINE ptr_glGenVertexArraysAPPLE #-}
 
ptr_glGenVertexArraysAPPLE :: FunPtr a
ptr_glGenVertexArraysAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_vertex_array_object"
        "glGenVertexArraysAPPLE"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsVertexArrayAPPLE ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsVertexArrayAPPLE :: GLuint -> IO GLboolean
glIsVertexArrayAPPLE
  = dyn_glIsVertexArrayAPPLE ptr_glIsVertexArrayAPPLE
 
{-# NOINLINE ptr_glIsVertexArrayAPPLE #-}
 
ptr_glIsVertexArrayAPPLE :: FunPtr a
ptr_glIsVertexArrayAPPLE
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_APPLE_vertex_array_object"
        "glIsVertexArrayAPPLE"