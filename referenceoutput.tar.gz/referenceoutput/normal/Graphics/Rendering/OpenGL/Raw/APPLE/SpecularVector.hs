-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.APPLE.SpecularVector
       (gl_LIGHT_MODEL_SPECULAR_VECTOR_APPLE) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_LIGHT_MODEL_SPECULAR_VECTOR_APPLE :: GLenum
gl_LIGHT_MODEL_SPECULAR_VECTOR_APPLE = 34224