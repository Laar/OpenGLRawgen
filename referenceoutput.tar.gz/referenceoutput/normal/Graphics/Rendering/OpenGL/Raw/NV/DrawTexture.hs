{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.DrawTexture
       (glDrawTextureNV) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawTextureNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
glDrawTextureNV ::
                GLuint ->
                  GLuint ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glDrawTextureNV = dyn_glDrawTextureNV ptr_glDrawTextureNV
 
{-# NOINLINE ptr_glDrawTextureNV #-}
 
ptr_glDrawTextureNV :: FunPtr a
ptr_glDrawTextureNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_draw_texture"
        "glDrawTextureNV"