{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.VertexArrayRange
       (gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV,
        gl_VERTEX_ARRAY_RANGE_LENGTH_NV, gl_VERTEX_ARRAY_RANGE_NV,
        gl_VERTEX_ARRAY_RANGE_POINTER_NV, gl_VERTEX_ARRAY_RANGE_VALID_NV,
        glFlushVertexArrayRangeNV, glVertexArrayRangeNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV :: GLenum
gl_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV = 34080
 
gl_VERTEX_ARRAY_RANGE_LENGTH_NV :: GLenum
gl_VERTEX_ARRAY_RANGE_LENGTH_NV = 34078
 
gl_VERTEX_ARRAY_RANGE_NV :: GLenum
gl_VERTEX_ARRAY_RANGE_NV = 34077
 
gl_VERTEX_ARRAY_RANGE_POINTER_NV :: GLenum
gl_VERTEX_ARRAY_RANGE_POINTER_NV = 34081
 
gl_VERTEX_ARRAY_RANGE_VALID_NV :: GLenum
gl_VERTEX_ARRAY_RANGE_VALID_NV = 34079
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFlushVertexArrayRangeNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glFlushVertexArrayRangeNV :: IO ()
glFlushVertexArrayRangeNV
  = dyn_glFlushVertexArrayRangeNV ptr_glFlushVertexArrayRangeNV
 
{-# NOINLINE ptr_glFlushVertexArrayRangeNV #-}
 
ptr_glFlushVertexArrayRangeNV :: FunPtr a
ptr_glFlushVertexArrayRangeNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_array_range"
        "glFlushVertexArrayRangeNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexArrayRangeNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr c -> IO ())
 
glVertexArrayRangeNV :: GLsizei -> Ptr c -> IO ()
glVertexArrayRangeNV
  = dyn_glVertexArrayRangeNV ptr_glVertexArrayRangeNV
 
{-# NOINLINE ptr_glVertexArrayRangeNV #-}
 
ptr_glVertexArrayRangeNV :: FunPtr a
ptr_glVertexArrayRangeNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_array_range"
        "glVertexArrayRangeNV"