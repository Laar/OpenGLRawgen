-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TessellationProgram5
       (gl_MAX_PROGRAM_PATCH_ATTRIBS_NV, gl_TESS_CONTROL_PROGRAM_NV,
        gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV,
        gl_TESS_EVALUATION_PROGRAM_NV,
        gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_PROGRAM_PATCH_ATTRIBS_NV :: GLenum
gl_MAX_PROGRAM_PATCH_ATTRIBS_NV = 34520
 
gl_TESS_CONTROL_PROGRAM_NV :: GLenum
gl_TESS_CONTROL_PROGRAM_NV = 35102
 
gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV :: GLenum
gl_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV = 35956
 
gl_TESS_EVALUATION_PROGRAM_NV :: GLenum
gl_TESS_EVALUATION_PROGRAM_NV = 35103
 
gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV :: GLenum
gl_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV = 35957