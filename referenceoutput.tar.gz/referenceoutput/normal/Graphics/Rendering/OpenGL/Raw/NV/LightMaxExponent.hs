module Graphics.Rendering.OpenGL.Raw.NV.LightMaxExponent
       (gl_MAX_SHININESS_NV, gl_MAX_SPOT_EXPONENT_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_SHININESS_NV :: GLenum
gl_MAX_SHININESS_NV = 34052
 
gl_MAX_SPOT_EXPONENT_NV :: GLenum
gl_MAX_SPOT_EXPONENT_NV = 34053