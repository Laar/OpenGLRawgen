{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.Evaluators
       (gl_EVAL_2D_NV, gl_EVAL_FRACTIONAL_TESSELLATION_NV,
        gl_EVAL_TRIANGULAR_2D_NV, gl_EVAL_VERTEX_ATTRIB0_NV,
        gl_EVAL_VERTEX_ATTRIB10_NV, gl_EVAL_VERTEX_ATTRIB11_NV,
        gl_EVAL_VERTEX_ATTRIB12_NV, gl_EVAL_VERTEX_ATTRIB13_NV,
        gl_EVAL_VERTEX_ATTRIB14_NV, gl_EVAL_VERTEX_ATTRIB15_NV,
        gl_EVAL_VERTEX_ATTRIB1_NV, gl_EVAL_VERTEX_ATTRIB2_NV,
        gl_EVAL_VERTEX_ATTRIB3_NV, gl_EVAL_VERTEX_ATTRIB4_NV,
        gl_EVAL_VERTEX_ATTRIB5_NV, gl_EVAL_VERTEX_ATTRIB6_NV,
        gl_EVAL_VERTEX_ATTRIB7_NV, gl_EVAL_VERTEX_ATTRIB8_NV,
        gl_EVAL_VERTEX_ATTRIB9_NV, gl_MAP_ATTRIB_U_ORDER_NV,
        gl_MAP_ATTRIB_V_ORDER_NV, gl_MAP_TESSELLATION_NV,
        gl_MAX_MAP_TESSELLATION_NV, gl_MAX_RATIONAL_EVAL_ORDER_NV,
        glEvalMapsNV, glGetMapAttribParameterfvNV,
        glGetMapAttribParameterivNV, glGetMapControlPointsNV,
        glGetMapParameterfvNV, glGetMapParameterivNV, glMapControlPointsNV,
        glMapParameterfvNV, glMapParameterivNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_EVAL_2D_NV :: GLenum
gl_EVAL_2D_NV = 34496
 
gl_EVAL_FRACTIONAL_TESSELLATION_NV :: GLenum
gl_EVAL_FRACTIONAL_TESSELLATION_NV = 34501
 
gl_EVAL_TRIANGULAR_2D_NV :: GLenum
gl_EVAL_TRIANGULAR_2D_NV = 34497
 
gl_EVAL_VERTEX_ATTRIB0_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB0_NV = 34502
 
gl_EVAL_VERTEX_ATTRIB10_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB10_NV = 34512
 
gl_EVAL_VERTEX_ATTRIB11_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB11_NV = 34513
 
gl_EVAL_VERTEX_ATTRIB12_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB12_NV = 34514
 
gl_EVAL_VERTEX_ATTRIB13_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB13_NV = 34515
 
gl_EVAL_VERTEX_ATTRIB14_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB14_NV = 34516
 
gl_EVAL_VERTEX_ATTRIB15_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB15_NV = 34517
 
gl_EVAL_VERTEX_ATTRIB1_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB1_NV = 34503
 
gl_EVAL_VERTEX_ATTRIB2_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB2_NV = 34504
 
gl_EVAL_VERTEX_ATTRIB3_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB3_NV = 34505
 
gl_EVAL_VERTEX_ATTRIB4_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB4_NV = 34506
 
gl_EVAL_VERTEX_ATTRIB5_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB5_NV = 34507
 
gl_EVAL_VERTEX_ATTRIB6_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB6_NV = 34508
 
gl_EVAL_VERTEX_ATTRIB7_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB7_NV = 34509
 
gl_EVAL_VERTEX_ATTRIB8_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB8_NV = 34510
 
gl_EVAL_VERTEX_ATTRIB9_NV :: GLenum
gl_EVAL_VERTEX_ATTRIB9_NV = 34511
 
gl_MAP_ATTRIB_U_ORDER_NV :: GLenum
gl_MAP_ATTRIB_U_ORDER_NV = 34499
 
gl_MAP_ATTRIB_V_ORDER_NV :: GLenum
gl_MAP_ATTRIB_V_ORDER_NV = 34500
 
gl_MAP_TESSELLATION_NV :: GLenum
gl_MAP_TESSELLATION_NV = 34498
 
gl_MAX_MAP_TESSELLATION_NV :: GLenum
gl_MAX_MAP_TESSELLATION_NV = 34518
 
gl_MAX_RATIONAL_EVAL_ORDER_NV :: GLenum
gl_MAX_RATIONAL_EVAL_ORDER_NV = 34519
 
foreign import CALLCONV unsafe "dynamic" dyn_glEvalMapsNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
glEvalMapsNV :: GLenum -> GLenum -> IO ()
glEvalMapsNV = dyn_glEvalMapsNV ptr_glEvalMapsNV
 
{-# NOINLINE ptr_glEvalMapsNV #-}
 
ptr_glEvalMapsNV :: FunPtr a
ptr_glEvalMapsNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glEvalMapsNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMapAttribParameterfvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMapAttribParameterfvNV ::
                            GLenum -> GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetMapAttribParameterfvNV
  = dyn_glGetMapAttribParameterfvNV ptr_glGetMapAttribParameterfvNV
 
{-# NOINLINE ptr_glGetMapAttribParameterfvNV #-}
 
ptr_glGetMapAttribParameterfvNV :: FunPtr a
ptr_glGetMapAttribParameterfvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapAttribParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetMapAttribParameterivNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetMapAttribParameterivNV ::
                            GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetMapAttribParameterivNV
  = dyn_glGetMapAttribParameterivNV ptr_glGetMapAttribParameterivNV
 
{-# NOINLINE ptr_glGetMapAttribParameterivNV #-}
 
ptr_glGetMapAttribParameterivNV :: FunPtr a
ptr_glGetMapAttribParameterivNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapAttribParameterivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapControlPointsNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint ->
                      GLenum -> GLsizei -> GLsizei -> GLboolean -> Ptr h -> IO ())
 
glGetMapControlPointsNV ::
                        GLenum ->
                          GLuint ->
                            GLenum -> GLsizei -> GLsizei -> GLboolean -> Ptr h -> IO ()
glGetMapControlPointsNV
  = dyn_glGetMapControlPointsNV ptr_glGetMapControlPointsNV
 
{-# NOINLINE ptr_glGetMapControlPointsNV #-}
 
ptr_glGetMapControlPointsNV :: FunPtr a
ptr_glGetMapControlPointsNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapControlPointsNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapParameterfvNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetMapParameterfvNV :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetMapParameterfvNV
  = dyn_glGetMapParameterfvNV ptr_glGetMapParameterfvNV
 
{-# NOINLINE ptr_glGetMapParameterfvNV #-}
 
ptr_glGetMapParameterfvNV :: FunPtr a
ptr_glGetMapParameterfvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMapParameterivNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glGetMapParameterivNV :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetMapParameterivNV
  = dyn_glGetMapParameterivNV ptr_glGetMapParameterivNV
 
{-# NOINLINE ptr_glGetMapParameterivNV #-}
 
ptr_glGetMapParameterivNV :: FunPtr a
ptr_glGetMapParameterivNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glGetMapParameterivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapControlPointsNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint ->
                      GLenum ->
                        GLsizei ->
                          GLsizei -> GLint -> GLint -> GLboolean -> Ptr j -> IO ())
 
glMapControlPointsNV ::
                     GLenum ->
                       GLuint ->
                         GLenum ->
                           GLsizei -> GLsizei -> GLint -> GLint -> GLboolean -> Ptr j -> IO ()
glMapControlPointsNV
  = dyn_glMapControlPointsNV ptr_glMapControlPointsNV
 
{-# NOINLINE ptr_glMapControlPointsNV #-}
 
ptr_glMapControlPointsNV :: FunPtr a
ptr_glMapControlPointsNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapControlPointsNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapParameterfvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glMapParameterfvNV :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glMapParameterfvNV = dyn_glMapParameterfvNV ptr_glMapParameterfvNV
 
{-# NOINLINE ptr_glMapParameterfvNV #-}
 
ptr_glMapParameterfvNV :: FunPtr a
ptr_glMapParameterfvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapParameterivNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
glMapParameterivNV :: GLenum -> GLenum -> Ptr GLint -> IO ()
glMapParameterivNV = dyn_glMapParameterivNV ptr_glMapParameterivNV
 
{-# NOINLINE ptr_glMapParameterivNV #-}
 
ptr_glMapParameterivNV :: FunPtr a
ptr_glMapParameterivNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_evaluators"
        "glMapParameterivNV"