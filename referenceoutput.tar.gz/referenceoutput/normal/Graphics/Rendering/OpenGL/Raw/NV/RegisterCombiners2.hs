{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.RegisterCombiners2
       (gl_PER_STAGE_CONSTANTS_NV, glCombinerStageParameterfvNV,
        glGetCombinerStageParameterfvNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PER_STAGE_CONSTANTS_NV :: GLenum
gl_PER_STAGE_CONSTANTS_NV = 34101
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glCombinerStageParameterfvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glCombinerStageParameterfvNV ::
                             GLenum -> GLenum -> Ptr GLfloat -> IO ()
glCombinerStageParameterfvNV
  = dyn_glCombinerStageParameterfvNV ptr_glCombinerStageParameterfvNV
 
{-# NOINLINE ptr_glCombinerStageParameterfvNV #-}
 
ptr_glCombinerStageParameterfvNV :: FunPtr a
ptr_glCombinerStageParameterfvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_register_combiners2"
        "glCombinerStageParameterfvNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetCombinerStageParameterfvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
glGetCombinerStageParameterfvNV ::
                                GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetCombinerStageParameterfvNV
  = dyn_glGetCombinerStageParameterfvNV
      ptr_glGetCombinerStageParameterfvNV
 
{-# NOINLINE ptr_glGetCombinerStageParameterfvNV #-}
 
ptr_glGetCombinerStageParameterfvNV :: FunPtr a
ptr_glGetCombinerStageParameterfvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_register_combiners2"
        "glGetCombinerStageParameterfvNV"