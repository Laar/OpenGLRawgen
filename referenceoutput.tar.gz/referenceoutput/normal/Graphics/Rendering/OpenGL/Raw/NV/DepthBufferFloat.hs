{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.DepthBufferFloat
       (gl_DEPTH32F_STENCIL8_NV, gl_DEPTH_BUFFER_FLOAT_MODE_NV,
        gl_DEPTH_COMPONENT32F_NV, gl_FLOAT_32_UNSIGNED_INT_24_8_REV_NV,
        glClearDepthdNV, glDepthBoundsdNV, glDepthRangedNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_DEPTH32F_STENCIL8_NV :: GLenum
gl_DEPTH32F_STENCIL8_NV = 36268
 
gl_DEPTH_BUFFER_FLOAT_MODE_NV :: GLenum
gl_DEPTH_BUFFER_FLOAT_MODE_NV = 36271
 
gl_DEPTH_COMPONENT32F_NV :: GLenum
gl_DEPTH_COMPONENT32F_NV = 36267
 
gl_FLOAT_32_UNSIGNED_INT_24_8_REV_NV :: GLenum
gl_FLOAT_32_UNSIGNED_INT_24_8_REV_NV = 36269
 
foreign import CALLCONV unsafe "dynamic" dyn_glClearDepthdNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> IO ())
 
glClearDepthdNV :: GLdouble -> IO ()
glClearDepthdNV = dyn_glClearDepthdNV ptr_glClearDepthdNV
 
{-# NOINLINE ptr_glClearDepthdNV #-}
 
ptr_glClearDepthdNV :: FunPtr a
ptr_glClearDepthdNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glClearDepthdNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthBoundsdNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())
 
glDepthBoundsdNV :: GLdouble -> GLdouble -> IO ()
glDepthBoundsdNV = dyn_glDepthBoundsdNV ptr_glDepthBoundsdNV
 
{-# NOINLINE ptr_glDepthBoundsdNV #-}
 
ptr_glDepthBoundsdNV :: FunPtr a
ptr_glDepthBoundsdNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glDepthBoundsdNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangedNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())
 
glDepthRangedNV :: GLdouble -> GLdouble -> IO ()
glDepthRangedNV = dyn_glDepthRangedNV ptr_glDepthRangedNV
 
{-# NOINLINE ptr_glDepthRangedNV #-}
 
ptr_glDepthRangedNV :: FunPtr a
ptr_glDepthRangedNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_depth_buffer_float"
        "glDepthRangedNV"