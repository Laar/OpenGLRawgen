{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.PixelDataRange
       (gl_READ_PIXEL_DATA_RANGE_LENGTH_NV, gl_READ_PIXEL_DATA_RANGE_NV,
        gl_READ_PIXEL_DATA_RANGE_POINTER_NV,
        gl_WRITE_PIXEL_DATA_RANGE_LENGTH_NV, gl_WRITE_PIXEL_DATA_RANGE_NV,
        gl_WRITE_PIXEL_DATA_RANGE_POINTER_NV, glFlushPixelDataRangeNV,
        glPixelDataRangeNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_READ_PIXEL_DATA_RANGE_LENGTH_NV :: GLenum
gl_READ_PIXEL_DATA_RANGE_LENGTH_NV = 34939
 
gl_READ_PIXEL_DATA_RANGE_NV :: GLenum
gl_READ_PIXEL_DATA_RANGE_NV = 34937
 
gl_READ_PIXEL_DATA_RANGE_POINTER_NV :: GLenum
gl_READ_PIXEL_DATA_RANGE_POINTER_NV = 34941
 
gl_WRITE_PIXEL_DATA_RANGE_LENGTH_NV :: GLenum
gl_WRITE_PIXEL_DATA_RANGE_LENGTH_NV = 34938
 
gl_WRITE_PIXEL_DATA_RANGE_NV :: GLenum
gl_WRITE_PIXEL_DATA_RANGE_NV = 34936
 
gl_WRITE_PIXEL_DATA_RANGE_POINTER_NV :: GLenum
gl_WRITE_PIXEL_DATA_RANGE_POINTER_NV = 34940
 
foreign import CALLCONV unsafe "dynamic" dyn_glFlushPixelDataRangeNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
glFlushPixelDataRangeNV :: GLenum -> IO ()
glFlushPixelDataRangeNV
  = dyn_glFlushPixelDataRangeNV ptr_glFlushPixelDataRangeNV
 
{-# NOINLINE ptr_glFlushPixelDataRangeNV #-}
 
ptr_glFlushPixelDataRangeNV :: FunPtr a
ptr_glFlushPixelDataRangeNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_pixel_data_range"
        "glFlushPixelDataRangeNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPixelDataRangeNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr d -> IO ())
 
glPixelDataRangeNV :: GLenum -> GLsizei -> Ptr d -> IO ()
glPixelDataRangeNV = dyn_glPixelDataRangeNV ptr_glPixelDataRangeNV
 
{-# NOINLINE ptr_glPixelDataRangeNV #-}
 
ptr_glPixelDataRangeNV :: FunPtr a
ptr_glPixelDataRangeNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_pixel_data_range"
        "glPixelDataRangeNV"