{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.Fence
       (gl_ALL_COMPLETED_NV, gl_FENCE_CONDITION_NV, gl_FENCE_STATUS_NV,
        glDeleteFencesNV, glFinishFenceNV, glGenFencesNV, glGetFenceivNV,
        glIsFenceNV, glSetFenceNV, glTestFenceNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_ALL_COMPLETED_NV :: GLenum
gl_ALL_COMPLETED_NV = 34034
 
gl_FENCE_CONDITION_NV :: GLenum
gl_FENCE_CONDITION_NV = 34036
 
gl_FENCE_STATUS_NV :: GLenum
gl_FENCE_STATUS_NV = 34035
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteFencesNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteFencesNV :: GLsizei -> Ptr GLuint -> IO ()
glDeleteFencesNV = dyn_glDeleteFencesNV ptr_glDeleteFencesNV
 
{-# NOINLINE ptr_glDeleteFencesNV #-}
 
ptr_glDeleteFencesNV :: FunPtr a
ptr_glDeleteFencesNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glDeleteFencesNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishFenceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glFinishFenceNV :: GLuint -> IO ()
glFinishFenceNV = dyn_glFinishFenceNV ptr_glFinishFenceNV
 
{-# NOINLINE ptr_glFinishFenceNV #-}
 
ptr_glFinishFenceNV :: FunPtr a
ptr_glFinishFenceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glFinishFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenFencesNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenFencesNV :: GLsizei -> Ptr GLuint -> IO ()
glGenFencesNV = dyn_glGenFencesNV ptr_glGenFencesNV
 
{-# NOINLINE ptr_glGenFencesNV #-}
 
ptr_glGenFencesNV :: FunPtr a
ptr_glGenFencesNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glGenFencesNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFenceivNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
glGetFenceivNV :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetFenceivNV = dyn_glGetFenceivNV ptr_glGetFenceivNV
 
{-# NOINLINE ptr_glGetFenceivNV #-}
 
ptr_glGetFenceivNV :: FunPtr a
ptr_glGetFenceivNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glGetFenceivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsFenceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsFenceNV :: GLuint -> IO GLboolean
glIsFenceNV = dyn_glIsFenceNV ptr_glIsFenceNV
 
{-# NOINLINE ptr_glIsFenceNV #-}
 
ptr_glIsFenceNV :: FunPtr a
ptr_glIsFenceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glIsFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSetFenceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
glSetFenceNV :: GLuint -> GLenum -> IO ()
glSetFenceNV = dyn_glSetFenceNV ptr_glSetFenceNV
 
{-# NOINLINE ptr_glSetFenceNV #-}
 
ptr_glSetFenceNV :: FunPtr a
ptr_glSetFenceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glSetFenceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTestFenceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glTestFenceNV :: GLuint -> IO GLboolean
glTestFenceNV = dyn_glTestFenceNV ptr_glTestFenceNV
 
{-# NOINLINE ptr_glTestFenceNV #-}
 
ptr_glTestFenceNV :: FunPtr a
ptr_glTestFenceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_fence"
        "glTestFenceNV"