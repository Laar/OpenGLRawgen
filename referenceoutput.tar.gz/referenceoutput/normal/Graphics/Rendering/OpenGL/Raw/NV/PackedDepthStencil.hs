module Graphics.Rendering.OpenGL.Raw.NV.PackedDepthStencil
       (gl_DEPTH_STENCIL_NV, gl_UNSIGNED_INT_24_8_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_DEPTH_STENCIL_NV :: GLenum
gl_DEPTH_STENCIL_NV = 34041
 
gl_UNSIGNED_INT_24_8_NV :: GLenum
gl_UNSIGNED_INT_24_8_NV = 34042