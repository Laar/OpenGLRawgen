-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.MultisampleFilterHint
       (gl_MULTISAMPLE_FILTER_HINT_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MULTISAMPLE_FILTER_HINT_NV :: GLenum
gl_MULTISAMPLE_FILTER_HINT_NV = 34100