-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.DeepTexture3D
       (gl_MAX_DEEP_3D_TEXTURE_DEPTH_NV,
        gl_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_DEEP_3D_TEXTURE_DEPTH_NV :: GLenum
gl_MAX_DEEP_3D_TEXTURE_DEPTH_NV = 37073
 
gl_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV :: GLenum
gl_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV = 37072