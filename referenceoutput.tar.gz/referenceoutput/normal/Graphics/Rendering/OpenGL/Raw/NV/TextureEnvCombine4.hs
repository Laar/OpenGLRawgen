module Graphics.Rendering.OpenGL.Raw.NV.TextureEnvCombine4
       (gl_COMBINE4_NV, gl_OPERAND3_ALPHA_NV, gl_OPERAND3_RGB_NV,
        gl_SOURCE3_ALPHA_NV, gl_SOURCE3_RGB_NV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMBINE4_NV :: GLenum
gl_COMBINE4_NV = 34051
 
gl_OPERAND3_ALPHA_NV :: GLenum
gl_OPERAND3_ALPHA_NV = 34203
 
gl_OPERAND3_RGB_NV :: GLenum
gl_OPERAND3_RGB_NV = 34195
 
gl_SOURCE3_ALPHA_NV :: GLenum
gl_SOURCE3_ALPHA_NV = 34187
 
gl_SOURCE3_RGB_NV :: GLenum
gl_SOURCE3_RGB_NV = 34179