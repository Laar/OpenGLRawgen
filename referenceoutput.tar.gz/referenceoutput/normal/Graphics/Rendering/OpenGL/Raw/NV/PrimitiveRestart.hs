{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.PrimitiveRestart
       (gl_PRIMITIVE_RESTART_INDEX_NV, gl_PRIMITIVE_RESTART_NV,
        glPrimitiveRestartIndexNV, glPrimitiveRestartNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_PRIMITIVE_RESTART_INDEX_NV :: GLenum
gl_PRIMITIVE_RESTART_INDEX_NV = 34137
 
gl_PRIMITIVE_RESTART_NV :: GLenum
gl_PRIMITIVE_RESTART_NV = 34136
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPrimitiveRestartIndexNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
glPrimitiveRestartIndexNV :: GLuint -> IO ()
glPrimitiveRestartIndexNV
  = dyn_glPrimitiveRestartIndexNV ptr_glPrimitiveRestartIndexNV
 
{-# NOINLINE ptr_glPrimitiveRestartIndexNV #-}
 
ptr_glPrimitiveRestartIndexNV :: FunPtr a
ptr_glPrimitiveRestartIndexNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_primitive_restart"
        "glPrimitiveRestartIndexNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glPrimitiveRestartNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glPrimitiveRestartNV :: IO ()
glPrimitiveRestartNV
  = dyn_glPrimitiveRestartNV ptr_glPrimitiveRestartNV
 
{-# NOINLINE ptr_glPrimitiveRestartNV #-}
 
ptr_glPrimitiveRestartNV :: FunPtr a
ptr_glPrimitiveRestartNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_primitive_restart"
        "glPrimitiveRestartNV"