-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.BlendEquationAdvancedCoherent
       (gl_BLEND_ADVANCED_COHERENT_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_BLEND_ADVANCED_COHERENT_NV :: GLenum
gl_BLEND_ADVANCED_COHERENT_NV = 37509