{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.HalfFloat
       (gl_HALF_FLOAT_NV, glColor3hNV, glColor3hvNV, glColor4hNV,
        glColor4hvNV, glFogCoordhNV, glFogCoordhvNV, glMultiTexCoord1hNV,
        glMultiTexCoord1hvNV, glMultiTexCoord2hNV, glMultiTexCoord2hvNV,
        glMultiTexCoord3hNV, glMultiTexCoord3hvNV, glMultiTexCoord4hNV,
        glMultiTexCoord4hvNV, glNormal3hNV, glNormal3hvNV,
        glSecondaryColor3hNV, glSecondaryColor3hvNV, glTexCoord1hNV,
        glTexCoord1hvNV, glTexCoord2hNV, glTexCoord2hvNV, glTexCoord3hNV,
        glTexCoord3hvNV, glTexCoord4hNV, glTexCoord4hvNV, glVertex2hNV,
        glVertex2hvNV, glVertex3hNV, glVertex3hvNV, glVertex4hNV,
        glVertex4hvNV, glVertexAttrib1hNV, glVertexAttrib1hvNV,
        glVertexAttrib2hNV, glVertexAttrib2hvNV, glVertexAttrib3hNV,
        glVertexAttrib3hvNV, glVertexAttrib4hNV, glVertexAttrib4hvNV,
        glVertexAttribs1hvNV, glVertexAttribs2hvNV, glVertexAttribs3hvNV,
        glVertexAttribs4hvNV, glVertexWeighthNV, glVertexWeighthvNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_HALF_FLOAT_NV :: GLenum
gl_HALF_FLOAT_NV = 5131
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> IO ())
 
glColor3hNV :: GLhalf -> GLhalf -> GLhalf -> IO ()
glColor3hNV = dyn_glColor3hNV ptr_glColor3hNV
 
{-# NOINLINE ptr_glColor3hNV #-}
 
ptr_glColor3hNV :: FunPtr a
ptr_glColor3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glColor3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glColor3hvNV :: Ptr GLhalf -> IO ()
glColor3hvNV = dyn_glColor3hvNV ptr_glColor3hvNV
 
{-# NOINLINE ptr_glColor3hvNV #-}
 
ptr_glColor3hvNV :: FunPtr a
ptr_glColor3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glColor3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glColor4hNV :: GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ()
glColor4hNV = dyn_glColor4hNV ptr_glColor4hNV
 
{-# NOINLINE ptr_glColor4hNV #-}
 
ptr_glColor4hNV :: FunPtr a
ptr_glColor4hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glColor4hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glColor4hvNV :: Ptr GLhalf -> IO ()
glColor4hvNV = dyn_glColor4hvNV ptr_glColor4hvNV
 
{-# NOINLINE ptr_glColor4hvNV #-}
 
ptr_glColor4hvNV :: FunPtr a
ptr_glColor4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glColor4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordhNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> IO ())
 
glFogCoordhNV :: GLhalf -> IO ()
glFogCoordhNV = dyn_glFogCoordhNV ptr_glFogCoordhNV
 
{-# NOINLINE ptr_glFogCoordhNV #-}
 
ptr_glFogCoordhNV :: FunPtr a
ptr_glFogCoordhNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glFogCoordhNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordhvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glFogCoordhvNV :: Ptr GLhalf -> IO ()
glFogCoordhvNV = dyn_glFogCoordhvNV ptr_glFogCoordhvNV
 
{-# NOINLINE ptr_glFogCoordhvNV #-}
 
ptr_glFogCoordhvNV :: FunPtr a
ptr_glFogCoordhvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glFogCoordhvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord1hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLhalf -> IO ())
 
glMultiTexCoord1hNV :: GLenum -> GLhalf -> IO ()
glMultiTexCoord1hNV
  = dyn_glMultiTexCoord1hNV ptr_glMultiTexCoord1hNV
 
{-# NOINLINE ptr_glMultiTexCoord1hNV #-}
 
ptr_glMultiTexCoord1hNV :: FunPtr a
ptr_glMultiTexCoord1hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord1hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord1hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLhalf -> IO ())
 
glMultiTexCoord1hvNV :: GLenum -> Ptr GLhalf -> IO ()
glMultiTexCoord1hvNV
  = dyn_glMultiTexCoord1hvNV ptr_glMultiTexCoord1hvNV
 
{-# NOINLINE ptr_glMultiTexCoord1hvNV #-}
 
ptr_glMultiTexCoord1hvNV :: FunPtr a
ptr_glMultiTexCoord1hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord1hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord2hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLhalf -> GLhalf -> IO ())
 
glMultiTexCoord2hNV :: GLenum -> GLhalf -> GLhalf -> IO ()
glMultiTexCoord2hNV
  = dyn_glMultiTexCoord2hNV ptr_glMultiTexCoord2hNV
 
{-# NOINLINE ptr_glMultiTexCoord2hNV #-}
 
ptr_glMultiTexCoord2hNV :: FunPtr a
ptr_glMultiTexCoord2hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord2hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord2hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLhalf -> IO ())
 
glMultiTexCoord2hvNV :: GLenum -> Ptr GLhalf -> IO ()
glMultiTexCoord2hvNV
  = dyn_glMultiTexCoord2hvNV ptr_glMultiTexCoord2hvNV
 
{-# NOINLINE ptr_glMultiTexCoord2hvNV #-}
 
ptr_glMultiTexCoord2hvNV :: FunPtr a
ptr_glMultiTexCoord2hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord2hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glMultiTexCoord3hNV ::
                    GLenum -> GLhalf -> GLhalf -> GLhalf -> IO ()
glMultiTexCoord3hNV
  = dyn_glMultiTexCoord3hNV ptr_glMultiTexCoord3hNV
 
{-# NOINLINE ptr_glMultiTexCoord3hNV #-}
 
ptr_glMultiTexCoord3hNV :: FunPtr a
ptr_glMultiTexCoord3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLhalf -> IO ())
 
glMultiTexCoord3hvNV :: GLenum -> Ptr GLhalf -> IO ()
glMultiTexCoord3hvNV
  = dyn_glMultiTexCoord3hvNV ptr_glMultiTexCoord3hvNV
 
{-# NOINLINE ptr_glMultiTexCoord3hvNV #-}
 
ptr_glMultiTexCoord3hvNV :: FunPtr a
ptr_glMultiTexCoord3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord4hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glMultiTexCoord4hNV ::
                    GLenum -> GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ()
glMultiTexCoord4hNV
  = dyn_glMultiTexCoord4hNV ptr_glMultiTexCoord4hNV
 
{-# NOINLINE ptr_glMultiTexCoord4hNV #-}
 
ptr_glMultiTexCoord4hNV :: FunPtr a
ptr_glMultiTexCoord4hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord4hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoord4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLhalf -> IO ())
 
glMultiTexCoord4hvNV :: GLenum -> Ptr GLhalf -> IO ()
glMultiTexCoord4hvNV
  = dyn_glMultiTexCoord4hvNV ptr_glMultiTexCoord4hvNV
 
{-# NOINLINE ptr_glMultiTexCoord4hvNV #-}
 
ptr_glMultiTexCoord4hvNV :: FunPtr a
ptr_glMultiTexCoord4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glMultiTexCoord4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormal3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> IO ())
 
glNormal3hNV :: GLhalf -> GLhalf -> GLhalf -> IO ()
glNormal3hNV = dyn_glNormal3hNV ptr_glNormal3hNV
 
{-# NOINLINE ptr_glNormal3hNV #-}
 
ptr_glNormal3hNV :: FunPtr a
ptr_glNormal3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glNormal3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormal3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glNormal3hvNV :: Ptr GLhalf -> IO ()
glNormal3hvNV = dyn_glNormal3hvNV ptr_glNormal3hvNV
 
{-# NOINLINE ptr_glNormal3hvNV #-}
 
ptr_glNormal3hvNV :: FunPtr a
ptr_glNormal3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glNormal3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSecondaryColor3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> IO ())
 
glSecondaryColor3hNV :: GLhalf -> GLhalf -> GLhalf -> IO ()
glSecondaryColor3hNV
  = dyn_glSecondaryColor3hNV ptr_glSecondaryColor3hNV
 
{-# NOINLINE ptr_glSecondaryColor3hNV #-}
 
ptr_glSecondaryColor3hNV :: FunPtr a
ptr_glSecondaryColor3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glSecondaryColor3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glSecondaryColor3hvNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glSecondaryColor3hvNV :: Ptr GLhalf -> IO ()
glSecondaryColor3hvNV
  = dyn_glSecondaryColor3hvNV ptr_glSecondaryColor3hvNV
 
{-# NOINLINE ptr_glSecondaryColor3hvNV #-}
 
ptr_glSecondaryColor3hvNV :: FunPtr a
ptr_glSecondaryColor3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glSecondaryColor3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord1hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> IO ())
 
glTexCoord1hNV :: GLhalf -> IO ()
glTexCoord1hNV = dyn_glTexCoord1hNV ptr_glTexCoord1hNV
 
{-# NOINLINE ptr_glTexCoord1hNV #-}
 
ptr_glTexCoord1hNV :: FunPtr a
ptr_glTexCoord1hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord1hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord1hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glTexCoord1hvNV :: Ptr GLhalf -> IO ()
glTexCoord1hvNV = dyn_glTexCoord1hvNV ptr_glTexCoord1hvNV
 
{-# NOINLINE ptr_glTexCoord1hvNV #-}
 
ptr_glTexCoord1hvNV :: FunPtr a
ptr_glTexCoord1hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord1hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord2hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> IO ())
 
glTexCoord2hNV :: GLhalf -> GLhalf -> IO ()
glTexCoord2hNV = dyn_glTexCoord2hNV ptr_glTexCoord2hNV
 
{-# NOINLINE ptr_glTexCoord2hNV #-}
 
ptr_glTexCoord2hNV :: FunPtr a
ptr_glTexCoord2hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord2hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord2hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glTexCoord2hvNV :: Ptr GLhalf -> IO ()
glTexCoord2hvNV = dyn_glTexCoord2hvNV ptr_glTexCoord2hvNV
 
{-# NOINLINE ptr_glTexCoord2hvNV #-}
 
ptr_glTexCoord2hvNV :: FunPtr a
ptr_glTexCoord2hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord2hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> IO ())
 
glTexCoord3hNV :: GLhalf -> GLhalf -> GLhalf -> IO ()
glTexCoord3hNV = dyn_glTexCoord3hNV ptr_glTexCoord3hNV
 
{-# NOINLINE ptr_glTexCoord3hNV #-}
 
ptr_glTexCoord3hNV :: FunPtr a
ptr_glTexCoord3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glTexCoord3hvNV :: Ptr GLhalf -> IO ()
glTexCoord3hvNV = dyn_glTexCoord3hvNV ptr_glTexCoord3hvNV
 
{-# NOINLINE ptr_glTexCoord3hvNV #-}
 
ptr_glTexCoord3hvNV :: FunPtr a
ptr_glTexCoord3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord4hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glTexCoord4hNV :: GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ()
glTexCoord4hNV = dyn_glTexCoord4hNV ptr_glTexCoord4hNV
 
{-# NOINLINE ptr_glTexCoord4hNV #-}
 
ptr_glTexCoord4hNV :: FunPtr a
ptr_glTexCoord4hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord4hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glTexCoord4hvNV :: Ptr GLhalf -> IO ()
glTexCoord4hvNV = dyn_glTexCoord4hvNV ptr_glTexCoord4hvNV
 
{-# NOINLINE ptr_glTexCoord4hvNV #-}
 
ptr_glTexCoord4hvNV :: FunPtr a
ptr_glTexCoord4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glTexCoord4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex2hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> IO ())
 
glVertex2hNV :: GLhalf -> GLhalf -> IO ()
glVertex2hNV = dyn_glVertex2hNV ptr_glVertex2hNV
 
{-# NOINLINE ptr_glVertex2hNV #-}
 
ptr_glVertex2hNV :: FunPtr a
ptr_glVertex2hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex2hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex2hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glVertex2hvNV :: Ptr GLhalf -> IO ()
glVertex2hvNV = dyn_glVertex2hvNV ptr_glVertex2hvNV
 
{-# NOINLINE ptr_glVertex2hvNV #-}
 
ptr_glVertex2hvNV :: FunPtr a
ptr_glVertex2hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex2hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> IO ())
 
glVertex3hNV :: GLhalf -> GLhalf -> GLhalf -> IO ()
glVertex3hNV = dyn_glVertex3hNV ptr_glVertex3hNV
 
{-# NOINLINE ptr_glVertex3hNV #-}
 
ptr_glVertex3hNV :: FunPtr a
ptr_glVertex3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glVertex3hvNV :: Ptr GLhalf -> IO ()
glVertex3hvNV = dyn_glVertex3hvNV ptr_glVertex3hvNV
 
{-# NOINLINE ptr_glVertex3hvNV #-}
 
ptr_glVertex3hvNV :: FunPtr a
ptr_glVertex3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex4hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glVertex4hNV :: GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ()
glVertex4hNV = dyn_glVertex4hNV ptr_glVertex4hNV
 
{-# NOINLINE ptr_glVertex4hNV #-}
 
ptr_glVertex4hNV :: FunPtr a
ptr_glVertex4hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex4hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertex4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glVertex4hvNV :: Ptr GLhalf -> IO ()
glVertex4hvNV = dyn_glVertex4hvNV ptr_glVertex4hvNV
 
{-# NOINLINE ptr_glVertex4hvNV #-}
 
ptr_glVertex4hvNV :: FunPtr a
ptr_glVertex4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertex4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLhalf -> IO ())
 
glVertexAttrib1hNV :: GLuint -> GLhalf -> IO ()
glVertexAttrib1hNV = dyn_glVertexAttrib1hNV ptr_glVertexAttrib1hNV
 
{-# NOINLINE ptr_glVertexAttrib1hNV #-}
 
ptr_glVertexAttrib1hNV :: FunPtr a
ptr_glVertexAttrib1hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib1hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib1hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLhalf -> IO ())
 
glVertexAttrib1hvNV :: GLuint -> Ptr GLhalf -> IO ()
glVertexAttrib1hvNV
  = dyn_glVertexAttrib1hvNV ptr_glVertexAttrib1hvNV
 
{-# NOINLINE ptr_glVertexAttrib1hvNV #-}
 
ptr_glVertexAttrib1hvNV :: FunPtr a
ptr_glVertexAttrib1hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib1hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLhalf -> GLhalf -> IO ())
 
glVertexAttrib2hNV :: GLuint -> GLhalf -> GLhalf -> IO ()
glVertexAttrib2hNV = dyn_glVertexAttrib2hNV ptr_glVertexAttrib2hNV
 
{-# NOINLINE ptr_glVertexAttrib2hNV #-}
 
ptr_glVertexAttrib2hNV :: FunPtr a
ptr_glVertexAttrib2hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib2hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib2hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLhalf -> IO ())
 
glVertexAttrib2hvNV :: GLuint -> Ptr GLhalf -> IO ()
glVertexAttrib2hvNV
  = dyn_glVertexAttrib2hvNV ptr_glVertexAttrib2hvNV
 
{-# NOINLINE ptr_glVertexAttrib2hvNV #-}
 
ptr_glVertexAttrib2hvNV :: FunPtr a
ptr_glVertexAttrib2hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib2hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glVertexAttrib3hNV :: GLuint -> GLhalf -> GLhalf -> GLhalf -> IO ()
glVertexAttrib3hNV = dyn_glVertexAttrib3hNV ptr_glVertexAttrib3hNV
 
{-# NOINLINE ptr_glVertexAttrib3hNV #-}
 
ptr_glVertexAttrib3hNV :: FunPtr a
ptr_glVertexAttrib3hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib3hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLhalf -> IO ())
 
glVertexAttrib3hvNV :: GLuint -> Ptr GLhalf -> IO ()
glVertexAttrib3hvNV
  = dyn_glVertexAttrib3hvNV ptr_glVertexAttrib3hvNV
 
{-# NOINLINE ptr_glVertexAttrib3hvNV #-}
 
ptr_glVertexAttrib3hvNV :: FunPtr a
ptr_glVertexAttrib3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4hNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ())
 
glVertexAttrib4hNV ::
                   GLuint -> GLhalf -> GLhalf -> GLhalf -> GLhalf -> IO ()
glVertexAttrib4hNV = dyn_glVertexAttrib4hNV ptr_glVertexAttrib4hNV
 
{-# NOINLINE ptr_glVertexAttrib4hNV #-}
 
ptr_glVertexAttrib4hNV :: FunPtr a
ptr_glVertexAttrib4hNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib4hNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttrib4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLhalf -> IO ())
 
glVertexAttrib4hvNV :: GLuint -> Ptr GLhalf -> IO ()
glVertexAttrib4hvNV
  = dyn_glVertexAttrib4hvNV ptr_glVertexAttrib4hvNV
 
{-# NOINLINE ptr_glVertexAttrib4hvNV #-}
 
ptr_glVertexAttrib4hvNV :: FunPtr a
ptr_glVertexAttrib4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttrib4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribs1hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLhalf -> IO ())
 
glVertexAttribs1hvNV :: GLuint -> GLsizei -> Ptr GLhalf -> IO ()
glVertexAttribs1hvNV
  = dyn_glVertexAttribs1hvNV ptr_glVertexAttribs1hvNV
 
{-# NOINLINE ptr_glVertexAttribs1hvNV #-}
 
ptr_glVertexAttribs1hvNV :: FunPtr a
ptr_glVertexAttribs1hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttribs1hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribs2hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLhalf -> IO ())
 
glVertexAttribs2hvNV :: GLuint -> GLsizei -> Ptr GLhalf -> IO ()
glVertexAttribs2hvNV
  = dyn_glVertexAttribs2hvNV ptr_glVertexAttribs2hvNV
 
{-# NOINLINE ptr_glVertexAttribs2hvNV #-}
 
ptr_glVertexAttribs2hvNV :: FunPtr a
ptr_glVertexAttribs2hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttribs2hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribs3hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLhalf -> IO ())
 
glVertexAttribs3hvNV :: GLuint -> GLsizei -> Ptr GLhalf -> IO ()
glVertexAttribs3hvNV
  = dyn_glVertexAttribs3hvNV ptr_glVertexAttribs3hvNV
 
{-# NOINLINE ptr_glVertexAttribs3hvNV #-}
 
ptr_glVertexAttribs3hvNV :: FunPtr a
ptr_glVertexAttribs3hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttribs3hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribs4hvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLhalf -> IO ())
 
glVertexAttribs4hvNV :: GLuint -> GLsizei -> Ptr GLhalf -> IO ()
glVertexAttribs4hvNV
  = dyn_glVertexAttribs4hvNV ptr_glVertexAttribs4hvNV
 
{-# NOINLINE ptr_glVertexAttribs4hvNV #-}
 
ptr_glVertexAttribs4hvNV :: FunPtr a
ptr_glVertexAttribs4hvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexAttribs4hvNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexWeighthNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLhalf -> IO ())
 
glVertexWeighthNV :: GLhalf -> IO ()
glVertexWeighthNV = dyn_glVertexWeighthNV ptr_glVertexWeighthNV
 
{-# NOINLINE ptr_glVertexWeighthNV #-}
 
ptr_glVertexWeighthNV :: FunPtr a
ptr_glVertexWeighthNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexWeighthNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexWeighthvNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLhalf -> IO ())
 
glVertexWeighthvNV :: Ptr GLhalf -> IO ()
glVertexWeighthvNV = dyn_glVertexWeighthvNV ptr_glVertexWeighthvNV
 
{-# NOINLINE ptr_glVertexWeighthvNV #-}
 
ptr_glVertexWeighthvNV :: FunPtr a
ptr_glVertexWeighthvNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_half_float"
        "glVertexWeighthvNV"