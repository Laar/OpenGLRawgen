module Graphics.Rendering.OpenGL.Raw.NV.TexgenEmboss
       (gl_EMBOSS_CONSTANT_NV, gl_EMBOSS_LIGHT_NV, gl_EMBOSS_MAP_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_EMBOSS_CONSTANT_NV :: GLenum
gl_EMBOSS_CONSTANT_NV = 34142
 
gl_EMBOSS_LIGHT_NV :: GLenum
gl_EMBOSS_LIGHT_NV = 34141
 
gl_EMBOSS_MAP_NV :: GLenum
gl_EMBOSS_MAP_NV = 34143