{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.VdpauInterop
       (gl_SURFACE_MAPPED_NV, gl_SURFACE_REGISTERED_NV,
        gl_SURFACE_STATE_NV, gl_WRITE_DISCARD_NV, glVDPAUFiniNV,
        glVDPAUGetSurfaceivNV, glVDPAUInitNV, glVDPAUIsSurfaceNV,
        glVDPAUMapSurfacesNV, glVDPAURegisterOutputSurfaceNV,
        glVDPAURegisterVideoSurfaceNV, glVDPAUSurfaceAccessNV,
        glVDPAUUnmapSurfacesNV, glVDPAUUnregisterSurfaceNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_SURFACE_MAPPED_NV :: GLenum
gl_SURFACE_MAPPED_NV = 34560
 
gl_SURFACE_REGISTERED_NV :: GLenum
gl_SURFACE_REGISTERED_NV = 34557
 
gl_SURFACE_STATE_NV :: GLenum
gl_SURFACE_STATE_NV = 34539
 
gl_WRITE_DISCARD_NV :: GLenum
gl_WRITE_DISCARD_NV = 35006
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUFiniNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glVDPAUFiniNV :: IO ()
glVDPAUFiniNV = dyn_glVDPAUFiniNV ptr_glVDPAUFiniNV
 
{-# NOINLINE ptr_glVDPAUFiniNV #-}
 
ptr_glVDPAUFiniNV :: FunPtr a
ptr_glVDPAUFiniNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUFiniNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUGetSurfaceivNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLvdpauSurface ->
                    GLenum -> GLsizei -> Ptr GLsizei -> Ptr GLint -> IO ())
 
glVDPAUGetSurfaceivNV ::
                      GLvdpauSurface ->
                        GLenum -> GLsizei -> Ptr GLsizei -> Ptr GLint -> IO ()
glVDPAUGetSurfaceivNV
  = dyn_glVDPAUGetSurfaceivNV ptr_glVDPAUGetSurfaceivNV
 
{-# NOINLINE ptr_glVDPAUGetSurfaceivNV #-}
 
ptr_glVDPAUGetSurfaceivNV :: FunPtr a
ptr_glVDPAUGetSurfaceivNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUGetSurfaceivNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUInitNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr b -> Ptr c -> IO ())
 
glVDPAUInitNV :: Ptr b -> Ptr c -> IO ()
glVDPAUInitNV = dyn_glVDPAUInitNV ptr_glVDPAUInitNV
 
{-# NOINLINE ptr_glVDPAUInitNV #-}
 
ptr_glVDPAUInitNV :: FunPtr a
ptr_glVDPAUInitNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUInitNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUIsSurfaceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLvdpauSurface -> IO ())
 
glVDPAUIsSurfaceNV :: GLvdpauSurface -> IO ()
glVDPAUIsSurfaceNV = dyn_glVDPAUIsSurfaceNV ptr_glVDPAUIsSurfaceNV
 
{-# NOINLINE ptr_glVDPAUIsSurfaceNV #-}
 
ptr_glVDPAUIsSurfaceNV :: FunPtr a
ptr_glVDPAUIsSurfaceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUIsSurfaceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUMapSurfacesNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLvdpauSurface -> IO ())
 
glVDPAUMapSurfacesNV :: GLsizei -> Ptr GLvdpauSurface -> IO ()
glVDPAUMapSurfacesNV
  = dyn_glVDPAUMapSurfacesNV ptr_glVDPAUMapSurfacesNV
 
{-# NOINLINE ptr_glVDPAUMapSurfacesNV #-}
 
ptr_glVDPAUMapSurfacesNV :: FunPtr a
ptr_glVDPAUMapSurfacesNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUMapSurfacesNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVDPAURegisterOutputSurfaceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr b -> GLenum -> GLsizei -> Ptr GLuint -> IO GLintptr)
 
glVDPAURegisterOutputSurfaceNV ::
                               Ptr b -> GLenum -> GLsizei -> Ptr GLuint -> IO GLintptr
glVDPAURegisterOutputSurfaceNV
  = dyn_glVDPAURegisterOutputSurfaceNV
      ptr_glVDPAURegisterOutputSurfaceNV
 
{-# NOINLINE ptr_glVDPAURegisterOutputSurfaceNV #-}
 
ptr_glVDPAURegisterOutputSurfaceNV :: FunPtr a
ptr_glVDPAURegisterOutputSurfaceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAURegisterOutputSurfaceNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVDPAURegisterVideoSurfaceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr b -> GLenum -> GLsizei -> Ptr GLuint -> IO GLintptr)
 
glVDPAURegisterVideoSurfaceNV ::
                              Ptr b -> GLenum -> GLsizei -> Ptr GLuint -> IO GLintptr
glVDPAURegisterVideoSurfaceNV
  = dyn_glVDPAURegisterVideoSurfaceNV
      ptr_glVDPAURegisterVideoSurfaceNV
 
{-# NOINLINE ptr_glVDPAURegisterVideoSurfaceNV #-}
 
ptr_glVDPAURegisterVideoSurfaceNV :: FunPtr a
ptr_glVDPAURegisterVideoSurfaceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAURegisterVideoSurfaceNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUSurfaceAccessNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLvdpauSurface -> GLenum -> IO ())
 
glVDPAUSurfaceAccessNV :: GLvdpauSurface -> GLenum -> IO ()
glVDPAUSurfaceAccessNV
  = dyn_glVDPAUSurfaceAccessNV ptr_glVDPAUSurfaceAccessNV
 
{-# NOINLINE ptr_glVDPAUSurfaceAccessNV #-}
 
ptr_glVDPAUSurfaceAccessNV :: FunPtr a
ptr_glVDPAUSurfaceAccessNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUSurfaceAccessNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVDPAUUnmapSurfacesNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLvdpauSurface -> IO ())
 
glVDPAUUnmapSurfacesNV :: GLsizei -> Ptr GLvdpauSurface -> IO ()
glVDPAUUnmapSurfacesNV
  = dyn_glVDPAUUnmapSurfacesNV ptr_glVDPAUUnmapSurfacesNV
 
{-# NOINLINE ptr_glVDPAUUnmapSurfacesNV #-}
 
ptr_glVDPAUUnmapSurfacesNV :: FunPtr a
ptr_glVDPAUUnmapSurfacesNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUUnmapSurfacesNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glVDPAUUnregisterSurfaceNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLvdpauSurface -> IO ())
 
glVDPAUUnregisterSurfaceNV :: GLvdpauSurface -> IO ()
glVDPAUUnregisterSurfaceNV
  = dyn_glVDPAUUnregisterSurfaceNV ptr_glVDPAUUnregisterSurfaceNV
 
{-# NOINLINE ptr_glVDPAUUnregisterSurfaceNV #-}
 
ptr_glVDPAUUnregisterSurfaceNV :: FunPtr a
ptr_glVDPAUUnregisterSurfaceNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vdpau_interop"
        "glVDPAUUnregisterSurfaceNV"