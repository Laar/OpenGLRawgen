-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TextureRectangle
       (gl_MAX_RECTANGLE_TEXTURE_SIZE_NV, gl_PROXY_TEXTURE_RECTANGLE_NV,
        gl_TEXTURE_BINDING_RECTANGLE_NV, gl_TEXTURE_RECTANGLE_NV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_MAX_RECTANGLE_TEXTURE_SIZE_NV :: GLenum
gl_MAX_RECTANGLE_TEXTURE_SIZE_NV = 34040
 
gl_PROXY_TEXTURE_RECTANGLE_NV :: GLenum
gl_PROXY_TEXTURE_RECTANGLE_NV = 34039
 
gl_TEXTURE_BINDING_RECTANGLE_NV :: GLenum
gl_TEXTURE_BINDING_RECTANGLE_NV = 34038
 
gl_TEXTURE_RECTANGLE_NV :: GLenum
gl_TEXTURE_RECTANGLE_NV = 34037