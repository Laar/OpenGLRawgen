{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.BindlessMultiDrawIndirect
       (glMultiDrawArraysIndirectBindlessNV,
        glMultiDrawElementsIndirectBindlessNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawArraysIndirectBindlessNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr c -> GLsizei -> GLsizei -> GLint -> IO ())
 
glMultiDrawArraysIndirectBindlessNV ::
                                    GLenum -> Ptr c -> GLsizei -> GLsizei -> GLint -> IO ()
glMultiDrawArraysIndirectBindlessNV
  = dyn_glMultiDrawArraysIndirectBindlessNV
      ptr_glMultiDrawArraysIndirectBindlessNV
 
{-# NOINLINE ptr_glMultiDrawArraysIndirectBindlessNV #-}
 
ptr_glMultiDrawArraysIndirectBindlessNV :: FunPtr a
ptr_glMultiDrawArraysIndirectBindlessNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_multi_draw_indirect"
        "glMultiDrawArraysIndirectBindlessNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementsIndirectBindlessNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr d -> GLsizei -> GLsizei -> GLint -> IO ())
 
glMultiDrawElementsIndirectBindlessNV ::
                                      GLenum ->
                                        GLenum -> Ptr d -> GLsizei -> GLsizei -> GLint -> IO ()
glMultiDrawElementsIndirectBindlessNV
  = dyn_glMultiDrawElementsIndirectBindlessNV
      ptr_glMultiDrawElementsIndirectBindlessNV
 
{-# NOINLINE ptr_glMultiDrawElementsIndirectBindlessNV #-}
 
ptr_glMultiDrawElementsIndirectBindlessNV :: FunPtr a
ptr_glMultiDrawElementsIndirectBindlessNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_bindless_multi_draw_indirect"
        "glMultiDrawElementsIndirectBindlessNV"