{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.VertexBufferUnifiedMemory
       (gl_COLOR_ARRAY_ADDRESS_NV, gl_COLOR_ARRAY_LENGTH_NV,
        gl_DRAW_INDIRECT_ADDRESS_NV, gl_DRAW_INDIRECT_LENGTH_NV,
        gl_DRAW_INDIRECT_UNIFIED_NV, gl_EDGE_FLAG_ARRAY_ADDRESS_NV,
        gl_EDGE_FLAG_ARRAY_LENGTH_NV, gl_ELEMENT_ARRAY_ADDRESS_NV,
        gl_ELEMENT_ARRAY_LENGTH_NV, gl_ELEMENT_ARRAY_UNIFIED_NV,
        gl_FOG_COORD_ARRAY_ADDRESS_NV, gl_FOG_COORD_ARRAY_LENGTH_NV,
        gl_INDEX_ARRAY_ADDRESS_NV, gl_INDEX_ARRAY_LENGTH_NV,
        gl_NORMAL_ARRAY_ADDRESS_NV, gl_NORMAL_ARRAY_LENGTH_NV,
        gl_SECONDARY_COLOR_ARRAY_ADDRESS_NV,
        gl_SECONDARY_COLOR_ARRAY_LENGTH_NV,
        gl_TEXTURE_COORD_ARRAY_ADDRESS_NV,
        gl_TEXTURE_COORD_ARRAY_LENGTH_NV, gl_VERTEX_ARRAY_ADDRESS_NV,
        gl_VERTEX_ARRAY_LENGTH_NV, gl_VERTEX_ATTRIB_ARRAY_ADDRESS_NV,
        gl_VERTEX_ATTRIB_ARRAY_LENGTH_NV,
        gl_VERTEX_ATTRIB_ARRAY_UNIFIED_NV, glBufferAddressRangeNV,
        glColorFormatNV, glEdgeFlagFormatNV, glFogCoordFormatNV,
        glGetIntegerui64i_vNV, glIndexFormatNV, glNormalFormatNV,
        glSecondaryColorFormatNV, glTexCoordFormatNV,
        glVertexAttribFormatNV, glVertexAttribIFormatNV, glVertexFormatNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_COLOR_ARRAY_ADDRESS_NV :: GLenum
gl_COLOR_ARRAY_ADDRESS_NV = 36643
 
gl_COLOR_ARRAY_LENGTH_NV :: GLenum
gl_COLOR_ARRAY_LENGTH_NV = 36653
 
gl_DRAW_INDIRECT_ADDRESS_NV :: GLenum
gl_DRAW_INDIRECT_ADDRESS_NV = 36673
 
gl_DRAW_INDIRECT_LENGTH_NV :: GLenum
gl_DRAW_INDIRECT_LENGTH_NV = 36674
 
gl_DRAW_INDIRECT_UNIFIED_NV :: GLenum
gl_DRAW_INDIRECT_UNIFIED_NV = 36672
 
gl_EDGE_FLAG_ARRAY_ADDRESS_NV :: GLenum
gl_EDGE_FLAG_ARRAY_ADDRESS_NV = 36646
 
gl_EDGE_FLAG_ARRAY_LENGTH_NV :: GLenum
gl_EDGE_FLAG_ARRAY_LENGTH_NV = 36656
 
gl_ELEMENT_ARRAY_ADDRESS_NV :: GLenum
gl_ELEMENT_ARRAY_ADDRESS_NV = 36649
 
gl_ELEMENT_ARRAY_LENGTH_NV :: GLenum
gl_ELEMENT_ARRAY_LENGTH_NV = 36659
 
gl_ELEMENT_ARRAY_UNIFIED_NV :: GLenum
gl_ELEMENT_ARRAY_UNIFIED_NV = 36639
 
gl_FOG_COORD_ARRAY_ADDRESS_NV :: GLenum
gl_FOG_COORD_ARRAY_ADDRESS_NV = 36648
 
gl_FOG_COORD_ARRAY_LENGTH_NV :: GLenum
gl_FOG_COORD_ARRAY_LENGTH_NV = 36658
 
gl_INDEX_ARRAY_ADDRESS_NV :: GLenum
gl_INDEX_ARRAY_ADDRESS_NV = 36644
 
gl_INDEX_ARRAY_LENGTH_NV :: GLenum
gl_INDEX_ARRAY_LENGTH_NV = 36654
 
gl_NORMAL_ARRAY_ADDRESS_NV :: GLenum
gl_NORMAL_ARRAY_ADDRESS_NV = 36642
 
gl_NORMAL_ARRAY_LENGTH_NV :: GLenum
gl_NORMAL_ARRAY_LENGTH_NV = 36652
 
gl_SECONDARY_COLOR_ARRAY_ADDRESS_NV :: GLenum
gl_SECONDARY_COLOR_ARRAY_ADDRESS_NV = 36647
 
gl_SECONDARY_COLOR_ARRAY_LENGTH_NV :: GLenum
gl_SECONDARY_COLOR_ARRAY_LENGTH_NV = 36657
 
gl_TEXTURE_COORD_ARRAY_ADDRESS_NV :: GLenum
gl_TEXTURE_COORD_ARRAY_ADDRESS_NV = 36645
 
gl_TEXTURE_COORD_ARRAY_LENGTH_NV :: GLenum
gl_TEXTURE_COORD_ARRAY_LENGTH_NV = 36655
 
gl_VERTEX_ARRAY_ADDRESS_NV :: GLenum
gl_VERTEX_ARRAY_ADDRESS_NV = 36641
 
gl_VERTEX_ARRAY_LENGTH_NV :: GLenum
gl_VERTEX_ARRAY_LENGTH_NV = 36651
 
gl_VERTEX_ATTRIB_ARRAY_ADDRESS_NV :: GLenum
gl_VERTEX_ATTRIB_ARRAY_ADDRESS_NV = 36640
 
gl_VERTEX_ATTRIB_ARRAY_LENGTH_NV :: GLenum
gl_VERTEX_ATTRIB_ARRAY_LENGTH_NV = 36650
 
gl_VERTEX_ATTRIB_ARRAY_UNIFIED_NV :: GLenum
gl_VERTEX_ATTRIB_ARRAY_UNIFIED_NV = 36638
 
foreign import CALLCONV unsafe "dynamic" dyn_glBufferAddressRangeNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint64 -> GLsizeiptr -> IO ())
 
glBufferAddressRangeNV ::
                       GLenum -> GLuint -> GLuint64 -> GLsizeiptr -> IO ()
glBufferAddressRangeNV
  = dyn_glBufferAddressRangeNV ptr_glBufferAddressRangeNV
 
{-# NOINLINE ptr_glBufferAddressRangeNV #-}
 
ptr_glBufferAddressRangeNV :: FunPtr a
ptr_glBufferAddressRangeNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glBufferAddressRangeNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLsizei -> IO ())
 
glColorFormatNV :: GLint -> GLenum -> GLsizei -> IO ()
glColorFormatNV = dyn_glColorFormatNV ptr_glColorFormatNV
 
{-# NOINLINE ptr_glColorFormatNV #-}
 
ptr_glColorFormatNV :: FunPtr a
ptr_glColorFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glColorFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glEdgeFlagFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> IO ())
 
glEdgeFlagFormatNV :: GLsizei -> IO ()
glEdgeFlagFormatNV = dyn_glEdgeFlagFormatNV ptr_glEdgeFlagFormatNV
 
{-# NOINLINE ptr_glEdgeFlagFormatNV #-}
 
ptr_glEdgeFlagFormatNV :: FunPtr a
ptr_glEdgeFlagFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glEdgeFlagFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogCoordFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> IO ())
 
glFogCoordFormatNV :: GLenum -> GLsizei -> IO ()
glFogCoordFormatNV = dyn_glFogCoordFormatNV ptr_glFogCoordFormatNV
 
{-# NOINLINE ptr_glFogCoordFormatNV #-}
 
ptr_glFogCoordFormatNV :: FunPtr a
ptr_glFogCoordFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glFogCoordFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetIntegerui64i_vNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLuint64 -> IO ())
 
glGetIntegerui64i_vNV :: GLenum -> GLuint -> Ptr GLuint64 -> IO ()
glGetIntegerui64i_vNV
  = dyn_glGetIntegerui64i_vNV ptr_glGetIntegerui64i_vNV
 
{-# NOINLINE ptr_glGetIntegerui64i_vNV #-}
 
ptr_glGetIntegerui64i_vNV :: FunPtr a
ptr_glGetIntegerui64i_vNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glGetIntegerui64i_vNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> IO ())
 
glIndexFormatNV :: GLenum -> GLsizei -> IO ()
glIndexFormatNV = dyn_glIndexFormatNV ptr_glIndexFormatNV
 
{-# NOINLINE ptr_glIndexFormatNV #-}
 
ptr_glIndexFormatNV :: FunPtr a
ptr_glIndexFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glIndexFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> IO ())
 
glNormalFormatNV :: GLenum -> GLsizei -> IO ()
glNormalFormatNV = dyn_glNormalFormatNV ptr_glNormalFormatNV
 
{-# NOINLINE ptr_glNormalFormatNV #-}
 
ptr_glNormalFormatNV :: FunPtr a
ptr_glNormalFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glNormalFormatNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glSecondaryColorFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLsizei -> IO ())
 
glSecondaryColorFormatNV :: GLint -> GLenum -> GLsizei -> IO ()
glSecondaryColorFormatNV
  = dyn_glSecondaryColorFormatNV ptr_glSecondaryColorFormatNV
 
{-# NOINLINE ptr_glSecondaryColorFormatNV #-}
 
ptr_glSecondaryColorFormatNV :: FunPtr a
ptr_glSecondaryColorFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glSecondaryColorFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLsizei -> IO ())
 
glTexCoordFormatNV :: GLint -> GLenum -> GLsizei -> IO ()
glTexCoordFormatNV = dyn_glTexCoordFormatNV ptr_glTexCoordFormatNV
 
{-# NOINLINE ptr_glTexCoordFormatNV #-}
 
ptr_glTexCoordFormatNV :: FunPtr a
ptr_glTexCoordFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glTexCoordFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribFormatNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLenum -> GLboolean -> GLsizei -> IO ())
 
glVertexAttribFormatNV ::
                       GLuint -> GLint -> GLenum -> GLboolean -> GLsizei -> IO ()
glVertexAttribFormatNV
  = dyn_glVertexAttribFormatNV ptr_glVertexAttribFormatNV
 
{-# NOINLINE ptr_glVertexAttribFormatNV #-}
 
ptr_glVertexAttribFormatNV :: FunPtr a
ptr_glVertexAttribFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glVertexAttribFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribIFormatNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLenum -> GLsizei -> IO ())
 
glVertexAttribIFormatNV ::
                        GLuint -> GLint -> GLenum -> GLsizei -> IO ()
glVertexAttribIFormatNV
  = dyn_glVertexAttribIFormatNV ptr_glVertexAttribIFormatNV
 
{-# NOINLINE ptr_glVertexAttribIFormatNV #-}
 
ptr_glVertexAttribIFormatNV :: FunPtr a
ptr_glVertexAttribIFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glVertexAttribIFormatNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexFormatNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLsizei -> IO ())
 
glVertexFormatNV :: GLint -> GLenum -> GLsizei -> IO ()
glVertexFormatNV = dyn_glVertexFormatNV ptr_glVertexFormatNV
 
{-# NOINLINE ptr_glVertexFormatNV #-}
 
ptr_glVertexFormatNV :: FunPtr a
ptr_glVertexFormatNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_vertex_buffer_unified_memory"
        "glVertexFormatNV"