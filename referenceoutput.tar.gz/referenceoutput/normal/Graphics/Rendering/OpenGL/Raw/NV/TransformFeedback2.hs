{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.TransformFeedback2
       (gl_TRANSFORM_FEEDBACK_BINDING_NV,
        gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE_NV,
        gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED_NV, gl_TRANSFORM_FEEDBACK_NV,
        glBindTransformFeedbackNV, glDeleteTransformFeedbacksNV,
        glDrawTransformFeedbackNV, glGenTransformFeedbacksNV,
        glIsTransformFeedbackNV, glPauseTransformFeedbackNV,
        glResumeTransformFeedbackNV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
gl_TRANSFORM_FEEDBACK_BINDING_NV :: GLenum
gl_TRANSFORM_FEEDBACK_BINDING_NV = 36389
 
gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE_NV :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_ACTIVE_NV = 36388
 
gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED_NV :: GLenum
gl_TRANSFORM_FEEDBACK_BUFFER_PAUSED_NV = 36387
 
gl_TRANSFORM_FEEDBACK_NV :: GLenum
gl_TRANSFORM_FEEDBACK_NV = 36386
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBindTransformFeedbackNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glBindTransformFeedbackNV :: GLenum -> GLuint -> IO ()
glBindTransformFeedbackNV
  = dyn_glBindTransformFeedbackNV ptr_glBindTransformFeedbackNV
 
{-# NOINLINE ptr_glBindTransformFeedbackNV #-}
 
ptr_glBindTransformFeedbackNV :: FunPtr a
ptr_glBindTransformFeedbackNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glBindTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDeleteTransformFeedbacksNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glDeleteTransformFeedbacksNV :: GLsizei -> Ptr GLuint -> IO ()
glDeleteTransformFeedbacksNV
  = dyn_glDeleteTransformFeedbacksNV ptr_glDeleteTransformFeedbacksNV
 
{-# NOINLINE ptr_glDeleteTransformFeedbacksNV #-}
 
ptr_glDeleteTransformFeedbacksNV :: FunPtr a
ptr_glDeleteTransformFeedbacksNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glDeleteTransformFeedbacksNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawTransformFeedbackNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
glDrawTransformFeedbackNV :: GLenum -> GLuint -> IO ()
glDrawTransformFeedbackNV
  = dyn_glDrawTransformFeedbackNV ptr_glDrawTransformFeedbackNV
 
{-# NOINLINE ptr_glDrawTransformFeedbackNV #-}
 
ptr_glDrawTransformFeedbackNV :: FunPtr a
ptr_glDrawTransformFeedbackNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glDrawTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGenTransformFeedbacksNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
glGenTransformFeedbacksNV :: GLsizei -> Ptr GLuint -> IO ()
glGenTransformFeedbacksNV
  = dyn_glGenTransformFeedbacksNV ptr_glGenTransformFeedbacksNV
 
{-# NOINLINE ptr_glGenTransformFeedbacksNV #-}
 
ptr_glGenTransformFeedbacksNV :: FunPtr a
ptr_glGenTransformFeedbacksNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glGenTransformFeedbacksNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsTransformFeedbackNV
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
glIsTransformFeedbackNV :: GLuint -> IO GLboolean
glIsTransformFeedbackNV
  = dyn_glIsTransformFeedbackNV ptr_glIsTransformFeedbackNV
 
{-# NOINLINE ptr_glIsTransformFeedbackNV #-}
 
ptr_glIsTransformFeedbackNV :: FunPtr a
ptr_glIsTransformFeedbackNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glIsTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPauseTransformFeedbackNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glPauseTransformFeedbackNV :: IO ()
glPauseTransformFeedbackNV
  = dyn_glPauseTransformFeedbackNV ptr_glPauseTransformFeedbackNV
 
{-# NOINLINE ptr_glPauseTransformFeedbackNV #-}
 
ptr_glPauseTransformFeedbackNV :: FunPtr a
ptr_glPauseTransformFeedbackNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glPauseTransformFeedbackNV"
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glResumeTransformFeedbackNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glResumeTransformFeedbackNV :: IO ()
glResumeTransformFeedbackNV
  = dyn_glResumeTransformFeedbackNV ptr_glResumeTransformFeedbackNV
 
{-# NOINLINE ptr_glResumeTransformFeedbackNV #-}
 
ptr_glResumeTransformFeedbackNV :: FunPtr a
ptr_glResumeTransformFeedbackNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_transform_feedback2"
        "glResumeTransformFeedbackNV"