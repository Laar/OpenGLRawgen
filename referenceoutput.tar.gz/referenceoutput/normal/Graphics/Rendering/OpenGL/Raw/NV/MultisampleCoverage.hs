-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.MultisampleCoverage
       (gl_COLOR_SAMPLES_NV, gl_SAMPLES_ARB) where
import Graphics.Rendering.OpenGL.Raw.ARB.Multisample
       (gl_SAMPLES_ARB)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_SAMPLES_NV :: GLenum
gl_COLOR_SAMPLES_NV = 36384