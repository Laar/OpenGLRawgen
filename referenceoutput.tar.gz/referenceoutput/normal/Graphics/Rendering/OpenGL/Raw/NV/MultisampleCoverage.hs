-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.MultisampleCoverage
       (gl_COLOR_SAMPLES_NV, gl_COVERAGE_SAMPLES_NV) where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COLOR_SAMPLES_NV :: GLenum
gl_COLOR_SAMPLES_NV = 36384
 
gl_COVERAGE_SAMPLES_NV :: GLenum
gl_COVERAGE_SAMPLES_NV = 32937