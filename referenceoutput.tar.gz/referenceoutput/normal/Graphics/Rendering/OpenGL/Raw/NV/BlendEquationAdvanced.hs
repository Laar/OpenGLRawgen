{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.BlendEquationAdvanced
       (gl_BLEND_OVERLAP_NV, gl_BLEND_PREMULTIPLIED_SRC_NV, gl_BLUE_NV,
        gl_COLORBURN_NV, gl_COLORDODGE_NV, gl_CONJOINT_NV, gl_CONTRAST_NV,
        gl_DARKEN_NV, gl_DIFFERENCE_NV, gl_DISJOINT_NV, gl_DST_ATOP_NV,
        gl_DST_IN_NV, gl_DST_NV, gl_DST_OUT_NV, gl_DST_OVER_NV,
        gl_EXCLUSION_NV, gl_GREEN_NV, gl_HARDLIGHT_NV, gl_HARDMIX_NV,
        gl_HSL_COLOR_NV, gl_HSL_HUE_NV, gl_HSL_LUMINOSITY_NV,
        gl_HSL_SATURATION_NV, gl_INVERT, gl_INVERT_OVG_NV,
        gl_INVERT_RGB_NV, gl_LIGHTEN_NV, gl_LINEARBURN_NV,
        gl_LINEARDODGE_NV, gl_LINEARLIGHT_NV, gl_MINUS_CLAMPED_NV,
        gl_MINUS_NV, gl_MULTIPLY_NV, gl_OVERLAY_NV, gl_PINLIGHT_NV,
        gl_PLUS_CLAMPED_ALPHA_NV, gl_PLUS_CLAMPED_NV, gl_PLUS_DARKER_NV,
        gl_PLUS_NV, gl_RED_NV, gl_SCREEN_NV, gl_SOFTLIGHT_NV,
        gl_SRC_ATOP_NV, gl_SRC_IN_NV, gl_SRC_NV, gl_SRC_OUT_NV,
        gl_SRC_OVER_NV, gl_UNCORRELATED_NV, gl_VIVIDLIGHT_NV, gl_XOR_NV,
        gl_ZERO, glBlendBarrierNV, glBlendParameteriNV)
       where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Core.Core11
       (gl_INVERT, gl_ZERO)
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_BLEND_OVERLAP_NV :: GLenum
gl_BLEND_OVERLAP_NV = 37505
 
gl_BLEND_PREMULTIPLIED_SRC_NV :: GLenum
gl_BLEND_PREMULTIPLIED_SRC_NV = 37504
 
gl_BLUE_NV :: GLenum
gl_BLUE_NV = 6405
 
gl_COLORBURN_NV :: GLenum
gl_COLORBURN_NV = 37530
 
gl_COLORDODGE_NV :: GLenum
gl_COLORDODGE_NV = 37529
 
gl_CONJOINT_NV :: GLenum
gl_CONJOINT_NV = 37508
 
gl_CONTRAST_NV :: GLenum
gl_CONTRAST_NV = 37537
 
gl_DARKEN_NV :: GLenum
gl_DARKEN_NV = 37527
 
gl_DIFFERENCE_NV :: GLenum
gl_DIFFERENCE_NV = 37534
 
gl_DISJOINT_NV :: GLenum
gl_DISJOINT_NV = 37507
 
gl_DST_ATOP_NV :: GLenum
gl_DST_ATOP_NV = 37519
 
gl_DST_IN_NV :: GLenum
gl_DST_IN_NV = 37515
 
gl_DST_NV :: GLenum
gl_DST_NV = 37511
 
gl_DST_OUT_NV :: GLenum
gl_DST_OUT_NV = 37517
 
gl_DST_OVER_NV :: GLenum
gl_DST_OVER_NV = 37513
 
gl_EXCLUSION_NV :: GLenum
gl_EXCLUSION_NV = 37536
 
gl_GREEN_NV :: GLenum
gl_GREEN_NV = 6404
 
gl_HARDLIGHT_NV :: GLenum
gl_HARDLIGHT_NV = 37531
 
gl_HARDMIX_NV :: GLenum
gl_HARDMIX_NV = 37545
 
gl_HSL_COLOR_NV :: GLenum
gl_HSL_COLOR_NV = 37551
 
gl_HSL_HUE_NV :: GLenum
gl_HSL_HUE_NV = 37549
 
gl_HSL_LUMINOSITY_NV :: GLenum
gl_HSL_LUMINOSITY_NV = 37552
 
gl_HSL_SATURATION_NV :: GLenum
gl_HSL_SATURATION_NV = 37550
 
gl_INVERT_OVG_NV :: GLenum
gl_INVERT_OVG_NV = 37556
 
gl_INVERT_RGB_NV :: GLenum
gl_INVERT_RGB_NV = 37539
 
gl_LIGHTEN_NV :: GLenum
gl_LIGHTEN_NV = 37528
 
gl_LINEARBURN_NV :: GLenum
gl_LINEARBURN_NV = 37541
 
gl_LINEARDODGE_NV :: GLenum
gl_LINEARDODGE_NV = 37540
 
gl_LINEARLIGHT_NV :: GLenum
gl_LINEARLIGHT_NV = 37543
 
gl_MINUS_CLAMPED_NV :: GLenum
gl_MINUS_CLAMPED_NV = 37555
 
gl_MINUS_NV :: GLenum
gl_MINUS_NV = 37535
 
gl_MULTIPLY_NV :: GLenum
gl_MULTIPLY_NV = 37524
 
gl_OVERLAY_NV :: GLenum
gl_OVERLAY_NV = 37526
 
gl_PINLIGHT_NV :: GLenum
gl_PINLIGHT_NV = 37544
 
gl_PLUS_CLAMPED_ALPHA_NV :: GLenum
gl_PLUS_CLAMPED_ALPHA_NV = 37554
 
gl_PLUS_CLAMPED_NV :: GLenum
gl_PLUS_CLAMPED_NV = 37553
 
gl_PLUS_DARKER_NV :: GLenum
gl_PLUS_DARKER_NV = 37522
 
gl_PLUS_NV :: GLenum
gl_PLUS_NV = 37521
 
gl_RED_NV :: GLenum
gl_RED_NV = 6403
 
gl_SCREEN_NV :: GLenum
gl_SCREEN_NV = 37525
 
gl_SOFTLIGHT_NV :: GLenum
gl_SOFTLIGHT_NV = 37532
 
gl_SRC_ATOP_NV :: GLenum
gl_SRC_ATOP_NV = 37518
 
gl_SRC_IN_NV :: GLenum
gl_SRC_IN_NV = 37514
 
gl_SRC_NV :: GLenum
gl_SRC_NV = 37510
 
gl_SRC_OUT_NV :: GLenum
gl_SRC_OUT_NV = 37516
 
gl_SRC_OVER_NV :: GLenum
gl_SRC_OVER_NV = 37512
 
gl_UNCORRELATED_NV :: GLenum
gl_UNCORRELATED_NV = 37506
 
gl_VIVIDLIGHT_NV :: GLenum
gl_VIVIDLIGHT_NV = 37542
 
gl_XOR_NV :: GLenum
gl_XOR_NV = 5382
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendBarrierNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glBlendBarrierNV :: IO ()
glBlendBarrierNV = dyn_glBlendBarrierNV ptr_glBlendBarrierNV
 
{-# NOINLINE ptr_glBlendBarrierNV #-}
 
ptr_glBlendBarrierNV :: FunPtr a
ptr_glBlendBarrierNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_blend_equation_advanced"
        "glBlendBarrierNV"
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendParameteriNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
glBlendParameteriNV :: GLenum -> GLint -> IO ()
glBlendParameteriNV
  = dyn_glBlendParameteriNV ptr_glBlendParameteriNV
 
{-# NOINLINE ptr_glBlendParameteriNV #-}
 
ptr_glBlendParameteriNV :: FunPtr a
ptr_glBlendParameteriNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_blend_equation_advanced"
        "glBlendParameteriNV"