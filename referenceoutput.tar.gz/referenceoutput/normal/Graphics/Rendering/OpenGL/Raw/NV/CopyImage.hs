{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.CopyImage
       (glCopyImageSubDataNV) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyImageSubDataNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLuint ->
                                GLenum ->
                                  GLint ->
                                    GLint ->
                                      GLint -> GLint -> GLsizei -> GLsizei -> GLsizei -> IO ())
 
glCopyImageSubDataNV ::
                     GLuint ->
                       GLenum ->
                         GLint ->
                           GLint ->
                             GLint ->
                               GLint ->
                                 GLuint ->
                                   GLenum ->
                                     GLint ->
                                       GLint ->
                                         GLint -> GLint -> GLsizei -> GLsizei -> GLsizei -> IO ()
glCopyImageSubDataNV
  = dyn_glCopyImageSubDataNV ptr_glCopyImageSubDataNV
 
{-# NOINLINE ptr_glCopyImageSubDataNV #-}
 
ptr_glCopyImageSubDataNV :: FunPtr a
ptr_glCopyImageSubDataNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_copy_image"
        "glCopyImageSubDataNV"