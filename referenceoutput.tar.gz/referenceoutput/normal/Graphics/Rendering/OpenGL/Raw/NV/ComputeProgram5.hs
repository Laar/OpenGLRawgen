-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.ComputeProgram5
       (gl_COMPUTE_PROGRAM_NV, gl_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV)
       where
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_COMPUTE_PROGRAM_NV :: GLenum
gl_COMPUTE_PROGRAM_NV = 37115
 
gl_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV :: GLenum
gl_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV = 37116