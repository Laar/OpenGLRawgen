-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.ShaderBufferStore
       (gl_READ_WRITE, gl_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV,
        gl_WRITE_ONLY)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15
       (gl_READ_WRITE, gl_WRITE_ONLY)
import Graphics.Rendering.OpenGL.Raw.Types
 
gl_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV :: GLbitfield
gl_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV = 16