{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
-----------------------------------------
--    GENERATED MODULE DO NOT EDIT     --
-----------------------------------------
-- Any changes made to this module are --
-- discarded when generating the files --
-----------------------------------------
module Graphics.Rendering.OpenGL.Raw.NV.TextureBarrier
       (glTextureBarrierNV) where
import Foreign.C.Types
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Graphics.Rendering.OpenGL.Raw.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureBarrierNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glTextureBarrierNV :: IO ()
glTextureBarrierNV = dyn_glTextureBarrierNV ptr_glTextureBarrierNV
 
{-# NOINLINE ptr_glTextureBarrierNV #-}
 
ptr_glTextureBarrierNV :: FunPtr a
ptr_glTextureBarrierNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_texture_barrier"
        "glTextureBarrierNV"