{-# LANGUAGE CPP #-}
{-# LANGUAGE ForeignFunctionInterface #-}
module Graphics.Rendering.OpenGL.Raw.NV.TextureBarrier
       (glTextureBarrierNV) where
import Graphics.Rendering.OpenGL.Raw.Types
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
import Foreign.Ptr
import Foreign.C.Types
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureBarrierNV ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
glTextureBarrierNV :: IO ()
glTextureBarrierNV = dyn_glTextureBarrierNV ptr_glTextureBarrierNV
 
{-# NOINLINE ptr_glTextureBarrierNV #-}
 
ptr_glTextureBarrierNV :: FunPtr a
ptr_glTextureBarrierNV
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_NV_texture_barrier"
        "glTextureBarrierNV"