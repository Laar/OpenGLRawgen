{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.GREMEDY.StringMarker
       (glStringMarkerGREMEDY) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glStringMarkerGREMEDY #-}
 
ptr_glStringMarkerGREMEDY :: FunPtr a
ptr_glStringMarkerGREMEDY
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_GREMEDY_string_marker"
        "glStringMarkerGREMEDY"
 
glStringMarkerGREMEDY :: GLsizei -> Ptr a -> IO ()
glStringMarkerGREMEDY
  = dyn_glStringMarkerGREMEDY ptr_glStringMarkerGREMEDY
 
foreign import CALLCONV unsafe "dynamic" dyn_glStringMarkerGREMEDY
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr a -> IO ())