{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.GREMEDY.FrameTerminator
       (glFrameTerminatorGREMEDY) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glFrameTerminatorGREMEDY #-}
 
ptr_glFrameTerminatorGREMEDY :: FunPtr a
ptr_glFrameTerminatorGREMEDY
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_GREMEDY_frame_terminator"
        "glFrameTerminatorGREMEDY"
 
glFrameTerminatorGREMEDY :: IO ()
glFrameTerminatorGREMEDY
  = dyn_glFrameTerminatorGREMEDY ptr_glFrameTerminatorGREMEDY
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFrameTerminatorGREMEDY ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())