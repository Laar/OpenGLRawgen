module Graphics.Rendering.OpenGL.Raw.WIN
       (module Graphics.Rendering.OpenGL.Raw.WIN.SpecularFog,
        module Graphics.Rendering.OpenGL.Raw.WIN.PhongShading)
       where
import Graphics.Rendering.OpenGL.Raw.WIN.PhongShading
import Graphics.Rendering.OpenGL.Raw.WIN.SpecularFog