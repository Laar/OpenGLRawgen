{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SUNX.ConstantData
       (glFinishTextureSUNX, gl_UNPACK_CONSTANT_DATA_SUNX,
        gl_TEXTURE_CONSTANT_DATA_SUNX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glFinishTextureSUNX #-}
 
ptr_glFinishTextureSUNX :: FunPtr a
ptr_glFinishTextureSUNX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUNX_constant_data"
        "glFinishTextureSUNX"
 
glFinishTextureSUNX :: IO ()
glFinishTextureSUNX
  = dyn_glFinishTextureSUNX ptr_glFinishTextureSUNX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishTextureSUNX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
gl_UNPACK_CONSTANT_DATA_SUNX :: GLenum
gl_UNPACK_CONSTANT_DATA_SUNX = 33237
 
gl_TEXTURE_CONSTANT_DATA_SUNX :: GLenum
gl_TEXTURE_CONSTANT_DATA_SUNX = 33238