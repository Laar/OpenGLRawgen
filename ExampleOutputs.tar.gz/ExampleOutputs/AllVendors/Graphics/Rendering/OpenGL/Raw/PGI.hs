module Graphics.Rendering.OpenGL.Raw.PGI
       (module Graphics.Rendering.OpenGL.Raw.PGI.VertexHints,
        module Graphics.Rendering.OpenGL.Raw.PGI.MiscHints)
       where
import Graphics.Rendering.OpenGL.Raw.PGI.MiscHints
import Graphics.Rendering.OpenGL.Raw.PGI.VertexHints