{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.INGR.BlendFuncSeparate
       (glBlendFuncSeparateINGR) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glBlendFuncSeparateINGR #-}
 
ptr_glBlendFuncSeparateINGR :: FunPtr a
ptr_glBlendFuncSeparateINGR
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_INGR_blend_func_separate"
        "glBlendFuncSeparateINGR"
 
glBlendFuncSeparateINGR ::
                        GLenum -> GLenum -> GLenum -> GLenum -> IO ()
glBlendFuncSeparateINGR
  = dyn_glBlendFuncSeparateINGR ptr_glBlendFuncSeparateINGR
 
foreign import CALLCONV unsafe "dynamic" dyn_glBlendFuncSeparateINGR
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLenum -> IO ())