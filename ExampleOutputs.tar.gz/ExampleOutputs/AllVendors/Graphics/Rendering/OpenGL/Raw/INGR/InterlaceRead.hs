module Graphics.Rendering.OpenGL.Raw.INGR.InterlaceRead
       (gl_INTERLACE_READ_INGR) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_INTERLACE_READ_INGR :: GLenum
gl_INTERLACE_READ_INGR = 34152