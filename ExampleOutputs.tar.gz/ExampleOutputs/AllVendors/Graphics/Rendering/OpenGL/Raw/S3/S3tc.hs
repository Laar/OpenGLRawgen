module Graphics.Rendering.OpenGL.Raw.S3.S3tc
       (gl_RGB_S3TC, gl_RGBA_S3TC, gl_RGBA4_S3TC, gl_RGB4_S3TC) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_RGB_S3TC :: GLenum
gl_RGB_S3TC = 33696
 
gl_RGBA_S3TC :: GLenum
gl_RGBA_S3TC = 33698
 
gl_RGBA4_S3TC :: GLenum
gl_RGBA4_S3TC = 33699
 
gl_RGB4_S3TC :: GLenum
gl_RGB4_S3TC = 33697