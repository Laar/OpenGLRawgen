module Graphics.Rendering.OpenGL.Raw.OML.Interlace
       (gl_INTERLACE_READ_OML, gl_INTERLACE_OML) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_INTERLACE_READ_OML :: GLenum
gl_INTERLACE_READ_OML = 35201
 
gl_INTERLACE_OML :: GLenum
gl_INTERLACE_OML = 35200