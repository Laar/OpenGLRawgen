module Graphics.Rendering.OpenGL.Raw.OML.Subsample
       (gl_FORMAT_SUBSAMPLE_24_24_OML, gl_FORMAT_SUBSAMPLE_244_244_OML)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_FORMAT_SUBSAMPLE_24_24_OML :: GLenum
gl_FORMAT_SUBSAMPLE_24_24_OML = 35202
 
gl_FORMAT_SUBSAMPLE_244_244_OML :: GLenum
gl_FORMAT_SUBSAMPLE_244_244_OML = 35203