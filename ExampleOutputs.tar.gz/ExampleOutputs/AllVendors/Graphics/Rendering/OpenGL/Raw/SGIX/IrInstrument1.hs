module Graphics.Rendering.OpenGL.Raw.SGIX.IrInstrument1
       (gl_IR_INSTRUMENT1_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_IR_INSTRUMENT1_SGIX :: GLenum
gl_IR_INSTRUMENT1_SGIX = 33151