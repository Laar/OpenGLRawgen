{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.Async
       (glPollAsyncSGIX, glIsAsyncMarkerSGIX, glGenAsyncMarkersSGIX,
        glFinishAsyncSGIX, glDeleteAsyncMarkersSGIX, glAsyncMarkerSGIX,
        gl_ASYNC_MARKER_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glPollAsyncSGIX #-}
 
ptr_glPollAsyncSGIX :: FunPtr a
ptr_glPollAsyncSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glPollAsyncSGIX"
 
glPollAsyncSGIX :: Ptr GLuint -> IO GLint
glPollAsyncSGIX = dyn_glPollAsyncSGIX ptr_glPollAsyncSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glPollAsyncSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> IO GLint)
 
{-# NOINLINE ptr_glIsAsyncMarkerSGIX #-}
 
ptr_glIsAsyncMarkerSGIX :: FunPtr a
ptr_glIsAsyncMarkerSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glIsAsyncMarkerSGIX"
 
glIsAsyncMarkerSGIX :: GLuint -> IO GLboolean
glIsAsyncMarkerSGIX
  = dyn_glIsAsyncMarkerSGIX ptr_glIsAsyncMarkerSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsAsyncMarkerSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
{-# NOINLINE ptr_glGenAsyncMarkersSGIX #-}
 
ptr_glGenAsyncMarkersSGIX :: FunPtr a
ptr_glGenAsyncMarkersSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glGenAsyncMarkersSGIX"
 
glGenAsyncMarkersSGIX :: GLsizei -> IO GLuint
glGenAsyncMarkersSGIX
  = dyn_glGenAsyncMarkersSGIX ptr_glGenAsyncMarkersSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenAsyncMarkersSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> IO GLuint)
 
{-# NOINLINE ptr_glFinishAsyncSGIX #-}
 
ptr_glFinishAsyncSGIX :: FunPtr a
ptr_glFinishAsyncSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glFinishAsyncSGIX"
 
glFinishAsyncSGIX :: Ptr GLuint -> IO GLint
glFinishAsyncSGIX = dyn_glFinishAsyncSGIX ptr_glFinishAsyncSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFinishAsyncSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> IO GLint)
 
{-# NOINLINE ptr_glDeleteAsyncMarkersSGIX #-}
 
ptr_glDeleteAsyncMarkersSGIX :: FunPtr a
ptr_glDeleteAsyncMarkersSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glDeleteAsyncMarkersSGIX"
 
glDeleteAsyncMarkersSGIX :: GLuint -> GLsizei -> IO ()
glDeleteAsyncMarkersSGIX
  = dyn_glDeleteAsyncMarkersSGIX ptr_glDeleteAsyncMarkersSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDeleteAsyncMarkersSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glAsyncMarkerSGIX #-}
 
ptr_glAsyncMarkerSGIX :: FunPtr a
ptr_glAsyncMarkerSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_async"
        "glAsyncMarkerSGIX"
 
glAsyncMarkerSGIX :: GLuint -> IO ()
glAsyncMarkerSGIX = dyn_glAsyncMarkerSGIX ptr_glAsyncMarkerSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glAsyncMarkerSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
gl_ASYNC_MARKER_SGIX :: GLenum
gl_ASYNC_MARKER_SGIX = 33577