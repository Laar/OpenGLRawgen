{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.Sprite
       (glSpriteParameterivSGIX, glSpriteParameteriSGIX,
        glSpriteParameterfvSGIX, glSpriteParameterfSGIX,
        gl_SPRITE_TRANSLATION_SGIX, gl_SPRITE_SGIX,
        gl_SPRITE_OBJECT_ALIGNED_SGIX, gl_SPRITE_MODE_SGIX,
        gl_SPRITE_EYE_ALIGNED_SGIX, gl_SPRITE_AXIS_SGIX,
        gl_SPRITE_AXIAL_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glSpriteParameterivSGIX #-}
 
ptr_glSpriteParameterivSGIX :: FunPtr a
ptr_glSpriteParameterivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_sprite"
        "glSpriteParameterivSGIX"
 
glSpriteParameterivSGIX :: GLenum -> Ptr GLint -> IO ()
glSpriteParameterivSGIX
  = dyn_glSpriteParameterivSGIX ptr_glSpriteParameterivSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glSpriteParameterivSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glSpriteParameteriSGIX #-}
 
ptr_glSpriteParameteriSGIX :: FunPtr a
ptr_glSpriteParameteriSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_sprite"
        "glSpriteParameteriSGIX"
 
glSpriteParameteriSGIX :: GLenum -> GLint -> IO ()
glSpriteParameteriSGIX
  = dyn_glSpriteParameteriSGIX ptr_glSpriteParameteriSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glSpriteParameteriSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glSpriteParameterfvSGIX #-}
 
ptr_glSpriteParameterfvSGIX :: FunPtr a
ptr_glSpriteParameterfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_sprite"
        "glSpriteParameterfvSGIX"
 
glSpriteParameterfvSGIX :: GLenum -> Ptr GLfloat -> IO ()
glSpriteParameterfvSGIX
  = dyn_glSpriteParameterfvSGIX ptr_glSpriteParameterfvSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glSpriteParameterfvSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glSpriteParameterfSGIX #-}
 
ptr_glSpriteParameterfSGIX :: FunPtr a
ptr_glSpriteParameterfSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_sprite"
        "glSpriteParameterfSGIX"
 
glSpriteParameterfSGIX :: GLenum -> GLfloat -> IO ()
glSpriteParameterfSGIX
  = dyn_glSpriteParameterfSGIX ptr_glSpriteParameterfSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glSpriteParameterfSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
gl_SPRITE_TRANSLATION_SGIX :: GLenum
gl_SPRITE_TRANSLATION_SGIX = 33099
 
gl_SPRITE_SGIX :: GLenum
gl_SPRITE_SGIX = 33096
 
gl_SPRITE_OBJECT_ALIGNED_SGIX :: GLenum
gl_SPRITE_OBJECT_ALIGNED_SGIX = 33101
 
gl_SPRITE_MODE_SGIX :: GLenum
gl_SPRITE_MODE_SGIX = 33097
 
gl_SPRITE_EYE_ALIGNED_SGIX :: GLenum
gl_SPRITE_EYE_ALIGNED_SGIX = 33102
 
gl_SPRITE_AXIS_SGIX :: GLenum
gl_SPRITE_AXIS_SGIX = 33098
 
gl_SPRITE_AXIAL_SGIX :: GLenum
gl_SPRITE_AXIAL_SGIX = 33100