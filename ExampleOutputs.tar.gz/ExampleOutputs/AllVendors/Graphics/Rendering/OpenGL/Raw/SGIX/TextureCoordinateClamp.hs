module Graphics.Rendering.OpenGL.Raw.SGIX.TextureCoordinateClamp
       (gl_TEXTURE_MAX_CLAMP_T_SGIX, gl_TEXTURE_MAX_CLAMP_S_SGIX,
        gl_TEXTURE_MAX_CLAMP_R_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_MAX_CLAMP_T_SGIX :: GLenum
gl_TEXTURE_MAX_CLAMP_T_SGIX = 33642
 
gl_TEXTURE_MAX_CLAMP_S_SGIX :: GLenum
gl_TEXTURE_MAX_CLAMP_S_SGIX = 33641
 
gl_TEXTURE_MAX_CLAMP_R_SGIX :: GLenum
gl_TEXTURE_MAX_CLAMP_R_SGIX = 33643