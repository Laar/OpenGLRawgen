{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.FragmentLighting
       (glLightEnviSGIX, glGetFragmentMaterialivSGIX,
        glGetFragmentMaterialfvSGIX, glGetFragmentLightivSGIX,
        glGetFragmentLightfvSGIX, glFragmentMaterialivSGIX,
        glFragmentMaterialiSGIX, glFragmentMaterialfvSGIX,
        glFragmentMaterialfSGIX, glFragmentLightivSGIX,
        glFragmentLightiSGIX, glFragmentLightfvSGIX, glFragmentLightfSGIX,
        glFragmentLightModelivSGIX, glFragmentLightModeliSGIX,
        glFragmentLightModelfvSGIX, glFragmentLightModelfSGIX,
        glFragmentColorMaterialSGIX, gl_MAX_FRAGMENT_LIGHTS_SGIX,
        gl_MAX_ACTIVE_LIGHTS_SGIX, gl_LIGHT_ENV_MODE_SGIX,
        gl_FRAGMENT_LIGHT_MODEL_TWO_SIDE_SGIX,
        gl_FRAGMENT_LIGHT_MODEL_NORMAL_INTERPOLATION_SGIX,
        gl_FRAGMENT_LIGHT_MODEL_LOCAL_VIEWER_SGIX,
        gl_FRAGMENT_LIGHT_MODEL_AMBIENT_SGIX, gl_FRAGMENT_LIGHTING_SGIX,
        gl_FRAGMENT_LIGHT7_SGIX, gl_FRAGMENT_LIGHT6_SGIX,
        gl_FRAGMENT_LIGHT5_SGIX, gl_FRAGMENT_LIGHT4_SGIX,
        gl_FRAGMENT_LIGHT3_SGIX, gl_FRAGMENT_LIGHT2_SGIX,
        gl_FRAGMENT_LIGHT1_SGIX, gl_FRAGMENT_LIGHT0_SGIX,
        gl_FRAGMENT_COLOR_MATERIAL_SGIX,
        gl_FRAGMENT_COLOR_MATERIAL_PARAMETER_SGIX,
        gl_FRAGMENT_COLOR_MATERIAL_FACE_SGIX,
        gl_CURRENT_RASTER_NORMAL_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glLightEnviSGIX #-}
 
ptr_glLightEnviSGIX :: FunPtr a
ptr_glLightEnviSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glLightEnviSGIX"
 
glLightEnviSGIX :: GLenum -> GLint -> IO ()
glLightEnviSGIX = dyn_glLightEnviSGIX ptr_glLightEnviSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glLightEnviSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glGetFragmentMaterialivSGIX #-}
 
ptr_glGetFragmentMaterialivSGIX :: FunPtr a
ptr_glGetFragmentMaterialivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glGetFragmentMaterialivSGIX"
 
glGetFragmentMaterialivSGIX ::
                            GLenum -> GLenum -> Ptr GLint -> IO ()
glGetFragmentMaterialivSGIX
  = dyn_glGetFragmentMaterialivSGIX ptr_glGetFragmentMaterialivSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFragmentMaterialivSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetFragmentMaterialfvSGIX #-}
 
ptr_glGetFragmentMaterialfvSGIX :: FunPtr a
ptr_glGetFragmentMaterialfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glGetFragmentMaterialfvSGIX"
 
glGetFragmentMaterialfvSGIX ::
                            GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetFragmentMaterialfvSGIX
  = dyn_glGetFragmentMaterialfvSGIX ptr_glGetFragmentMaterialfvSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFragmentMaterialfvSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetFragmentLightivSGIX #-}
 
ptr_glGetFragmentLightivSGIX :: FunPtr a
ptr_glGetFragmentLightivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glGetFragmentLightivSGIX"
 
glGetFragmentLightivSGIX :: GLenum -> GLenum -> Ptr GLint -> IO ()
glGetFragmentLightivSGIX
  = dyn_glGetFragmentLightivSGIX ptr_glGetFragmentLightivSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFragmentLightivSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetFragmentLightfvSGIX #-}
 
ptr_glGetFragmentLightfvSGIX :: FunPtr a
ptr_glGetFragmentLightfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glGetFragmentLightfvSGIX"
 
glGetFragmentLightfvSGIX ::
                         GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetFragmentLightfvSGIX
  = dyn_glGetFragmentLightfvSGIX ptr_glGetFragmentLightfvSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetFragmentLightfvSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentMaterialivSGIX #-}
 
ptr_glFragmentMaterialivSGIX :: FunPtr a
ptr_glFragmentMaterialivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentMaterialivSGIX"
 
glFragmentMaterialivSGIX :: GLenum -> GLenum -> Ptr GLint -> IO ()
glFragmentMaterialivSGIX
  = dyn_glFragmentMaterialivSGIX ptr_glFragmentMaterialivSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentMaterialivSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentMaterialiSGIX #-}
 
ptr_glFragmentMaterialiSGIX :: FunPtr a
ptr_glFragmentMaterialiSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentMaterialiSGIX"
 
glFragmentMaterialiSGIX :: GLenum -> GLenum -> GLint -> IO ()
glFragmentMaterialiSGIX
  = dyn_glFragmentMaterialiSGIX ptr_glFragmentMaterialiSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentMaterialiSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentMaterialfvSGIX #-}
 
ptr_glFragmentMaterialfvSGIX :: FunPtr a
ptr_glFragmentMaterialfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentMaterialfvSGIX"
 
glFragmentMaterialfvSGIX ::
                         GLenum -> GLenum -> Ptr GLfloat -> IO ()
glFragmentMaterialfvSGIX
  = dyn_glFragmentMaterialfvSGIX ptr_glFragmentMaterialfvSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentMaterialfvSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentMaterialfSGIX #-}
 
ptr_glFragmentMaterialfSGIX :: FunPtr a
ptr_glFragmentMaterialfSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentMaterialfSGIX"
 
glFragmentMaterialfSGIX :: GLenum -> GLenum -> GLfloat -> IO ()
glFragmentMaterialfSGIX
  = dyn_glFragmentMaterialfSGIX ptr_glFragmentMaterialfSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentMaterialfSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentLightivSGIX #-}
 
ptr_glFragmentLightivSGIX :: FunPtr a
ptr_glFragmentLightivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightivSGIX"
 
glFragmentLightivSGIX :: GLenum -> GLenum -> Ptr GLint -> IO ()
glFragmentLightivSGIX
  = dyn_glFragmentLightivSGIX ptr_glFragmentLightivSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentLightivSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentLightiSGIX #-}
 
ptr_glFragmentLightiSGIX :: FunPtr a
ptr_glFragmentLightiSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightiSGIX"
 
glFragmentLightiSGIX :: GLenum -> GLenum -> GLint -> IO ()
glFragmentLightiSGIX
  = dyn_glFragmentLightiSGIX ptr_glFragmentLightiSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentLightiSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentLightfvSGIX #-}
 
ptr_glFragmentLightfvSGIX :: FunPtr a
ptr_glFragmentLightfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightfvSGIX"
 
glFragmentLightfvSGIX :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glFragmentLightfvSGIX
  = dyn_glFragmentLightfvSGIX ptr_glFragmentLightfvSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentLightfvSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentLightfSGIX #-}
 
ptr_glFragmentLightfSGIX :: FunPtr a
ptr_glFragmentLightfSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightfSGIX"
 
glFragmentLightfSGIX :: GLenum -> GLenum -> GLfloat -> IO ()
glFragmentLightfSGIX
  = dyn_glFragmentLightfSGIX ptr_glFragmentLightfSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFragmentLightfSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentLightModelivSGIX #-}
 
ptr_glFragmentLightModelivSGIX :: FunPtr a
ptr_glFragmentLightModelivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightModelivSGIX"
 
glFragmentLightModelivSGIX :: GLenum -> Ptr GLint -> IO ()
glFragmentLightModelivSGIX
  = dyn_glFragmentLightModelivSGIX ptr_glFragmentLightModelivSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentLightModelivSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentLightModeliSGIX #-}
 
ptr_glFragmentLightModeliSGIX :: FunPtr a
ptr_glFragmentLightModeliSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightModeliSGIX"
 
glFragmentLightModeliSGIX :: GLenum -> GLint -> IO ()
glFragmentLightModeliSGIX
  = dyn_glFragmentLightModeliSGIX ptr_glFragmentLightModeliSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentLightModeliSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glFragmentLightModelfvSGIX #-}
 
ptr_glFragmentLightModelfvSGIX :: FunPtr a
ptr_glFragmentLightModelfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightModelfvSGIX"
 
glFragmentLightModelfvSGIX :: GLenum -> Ptr GLfloat -> IO ()
glFragmentLightModelfvSGIX
  = dyn_glFragmentLightModelfvSGIX ptr_glFragmentLightModelfvSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentLightModelfvSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentLightModelfSGIX #-}
 
ptr_glFragmentLightModelfSGIX :: FunPtr a
ptr_glFragmentLightModelfSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentLightModelfSGIX"
 
glFragmentLightModelfSGIX :: GLenum -> GLfloat -> IO ()
glFragmentLightModelfSGIX
  = dyn_glFragmentLightModelfSGIX ptr_glFragmentLightModelfSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentLightModelfSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glFragmentColorMaterialSGIX #-}
 
ptr_glFragmentColorMaterialSGIX :: FunPtr a
ptr_glFragmentColorMaterialSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_fragment_lighting"
        "glFragmentColorMaterialSGIX"
 
glFragmentColorMaterialSGIX :: GLenum -> GLenum -> IO ()
glFragmentColorMaterialSGIX
  = dyn_glFragmentColorMaterialSGIX ptr_glFragmentColorMaterialSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFragmentColorMaterialSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> IO ())
 
gl_MAX_FRAGMENT_LIGHTS_SGIX :: GLenum
gl_MAX_FRAGMENT_LIGHTS_SGIX = 33796
 
gl_MAX_ACTIVE_LIGHTS_SGIX :: GLenum
gl_MAX_ACTIVE_LIGHTS_SGIX = 33797
 
gl_LIGHT_ENV_MODE_SGIX :: GLenum
gl_LIGHT_ENV_MODE_SGIX = 33799
 
gl_FRAGMENT_LIGHT_MODEL_TWO_SIDE_SGIX :: GLenum
gl_FRAGMENT_LIGHT_MODEL_TWO_SIDE_SGIX = 33801
 
gl_FRAGMENT_LIGHT_MODEL_NORMAL_INTERPOLATION_SGIX :: GLenum
gl_FRAGMENT_LIGHT_MODEL_NORMAL_INTERPOLATION_SGIX = 33803
 
gl_FRAGMENT_LIGHT_MODEL_LOCAL_VIEWER_SGIX :: GLenum
gl_FRAGMENT_LIGHT_MODEL_LOCAL_VIEWER_SGIX = 33800
 
gl_FRAGMENT_LIGHT_MODEL_AMBIENT_SGIX :: GLenum
gl_FRAGMENT_LIGHT_MODEL_AMBIENT_SGIX = 33802
 
gl_FRAGMENT_LIGHTING_SGIX :: GLenum
gl_FRAGMENT_LIGHTING_SGIX = 33792
 
gl_FRAGMENT_LIGHT7_SGIX :: GLenum
gl_FRAGMENT_LIGHT7_SGIX = 33811
 
gl_FRAGMENT_LIGHT6_SGIX :: GLenum
gl_FRAGMENT_LIGHT6_SGIX = 33810
 
gl_FRAGMENT_LIGHT5_SGIX :: GLenum
gl_FRAGMENT_LIGHT5_SGIX = 33809
 
gl_FRAGMENT_LIGHT4_SGIX :: GLenum
gl_FRAGMENT_LIGHT4_SGIX = 33808
 
gl_FRAGMENT_LIGHT3_SGIX :: GLenum
gl_FRAGMENT_LIGHT3_SGIX = 33807
 
gl_FRAGMENT_LIGHT2_SGIX :: GLenum
gl_FRAGMENT_LIGHT2_SGIX = 33806
 
gl_FRAGMENT_LIGHT1_SGIX :: GLenum
gl_FRAGMENT_LIGHT1_SGIX = 33805
 
gl_FRAGMENT_LIGHT0_SGIX :: GLenum
gl_FRAGMENT_LIGHT0_SGIX = 33804
 
gl_FRAGMENT_COLOR_MATERIAL_SGIX :: GLenum
gl_FRAGMENT_COLOR_MATERIAL_SGIX = 33793
 
gl_FRAGMENT_COLOR_MATERIAL_PARAMETER_SGIX :: GLenum
gl_FRAGMENT_COLOR_MATERIAL_PARAMETER_SGIX = 33795
 
gl_FRAGMENT_COLOR_MATERIAL_FACE_SGIX :: GLenum
gl_FRAGMENT_COLOR_MATERIAL_FACE_SGIX = 33794
 
gl_CURRENT_RASTER_NORMAL_SGIX :: GLenum
gl_CURRENT_RASTER_NORMAL_SGIX = 33798