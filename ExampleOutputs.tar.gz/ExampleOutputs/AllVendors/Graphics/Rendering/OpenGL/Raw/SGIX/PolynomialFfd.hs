{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.PolynomialFfd
       (glLoadIdentityDeformationMapSGIX, glDeformationMap3fSGIX,
        glDeformationMap3dSGIX, glDeformSGIX, gl_TEXTURE_DEFORMATION_SGIX,
        gl_MAX_DEFORMATION_ORDER_SGIX, gl_GEOMETRY_DEFORMATION_SGIX,
        gl_DEFORMATIONS_MASK_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glLoadIdentityDeformationMapSGIX #-}
 
ptr_glLoadIdentityDeformationMapSGIX :: FunPtr a
ptr_glLoadIdentityDeformationMapSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_polynomial_ffd"
        "glLoadIdentityDeformationMapSGIX"
 
glLoadIdentityDeformationMapSGIX :: GLbitfield -> IO ()
glLoadIdentityDeformationMapSGIX
  = dyn_glLoadIdentityDeformationMapSGIX
      ptr_glLoadIdentityDeformationMapSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glLoadIdentityDeformationMapSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
{-# NOINLINE ptr_glDeformationMap3fSGIX #-}
 
ptr_glDeformationMap3fSGIX :: FunPtr a
ptr_glDeformationMap3fSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_polynomial_ffd"
        "glDeformationMap3fSGIX"
 
glDeformationMap3fSGIX ::
                       GLenum ->
                         GLfloat ->
                           GLfloat ->
                             GLint ->
                               GLint ->
                                 GLfloat ->
                                   GLfloat ->
                                     GLint ->
                                       GLint ->
                                         GLfloat ->
                                           GLfloat -> GLint -> GLint -> Ptr GLfloat -> IO ()
glDeformationMap3fSGIX
  = dyn_glDeformationMap3fSGIX ptr_glDeformationMap3fSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeformationMap3fSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLfloat ->
                      GLfloat ->
                        GLint ->
                          GLint ->
                            GLfloat ->
                              GLfloat ->
                                GLint ->
                                  GLint ->
                                    GLfloat -> GLfloat -> GLint -> GLint -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glDeformationMap3dSGIX #-}
 
ptr_glDeformationMap3dSGIX :: FunPtr a
ptr_glDeformationMap3dSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_polynomial_ffd"
        "glDeformationMap3dSGIX"
 
glDeformationMap3dSGIX ::
                       GLenum ->
                         GLdouble ->
                           GLdouble ->
                             GLint ->
                               GLint ->
                                 GLdouble ->
                                   GLdouble ->
                                     GLint ->
                                       GLint ->
                                         GLdouble ->
                                           GLdouble -> GLint -> GLint -> Ptr GLdouble -> IO ()
glDeformationMap3dSGIX
  = dyn_glDeformationMap3dSGIX ptr_glDeformationMap3dSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeformationMap3dSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLdouble ->
                      GLdouble ->
                        GLint ->
                          GLint ->
                            GLdouble ->
                              GLdouble ->
                                GLint ->
                                  GLint ->
                                    GLdouble -> GLdouble -> GLint -> GLint -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glDeformSGIX #-}
 
ptr_glDeformSGIX :: FunPtr a
ptr_glDeformSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_polynomial_ffd"
        "glDeformSGIX"
 
glDeformSGIX :: GLbitfield -> IO ()
glDeformSGIX = dyn_glDeformSGIX ptr_glDeformSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeformSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
gl_TEXTURE_DEFORMATION_SGIX :: GLenum
gl_TEXTURE_DEFORMATION_SGIX = 33173
 
gl_MAX_DEFORMATION_ORDER_SGIX :: GLenum
gl_MAX_DEFORMATION_ORDER_SGIX = 33175
 
gl_GEOMETRY_DEFORMATION_SGIX :: GLenum
gl_GEOMETRY_DEFORMATION_SGIX = 33172
 
gl_DEFORMATIONS_MASK_SGIX :: GLenum
gl_DEFORMATIONS_MASK_SGIX = 33174