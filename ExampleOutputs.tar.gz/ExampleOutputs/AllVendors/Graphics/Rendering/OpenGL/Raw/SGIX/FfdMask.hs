module Graphics.Rendering.OpenGL.Raw.SGIX.FfdMask
       (gl_TEXTURE_DEFORMATION_BIT_SGIX, gl_GEOMETRY_DEFORMATION_BIT_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_DEFORMATION_BIT_SGIX :: GLbitfield
gl_TEXTURE_DEFORMATION_BIT_SGIX = 1
 
gl_GEOMETRY_DEFORMATION_BIT_SGIX :: GLbitfield
gl_GEOMETRY_DEFORMATION_BIT_SGIX = 2