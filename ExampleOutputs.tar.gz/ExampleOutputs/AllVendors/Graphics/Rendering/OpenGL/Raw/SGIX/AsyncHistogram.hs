module Graphics.Rendering.OpenGL.Raw.SGIX.AsyncHistogram
       (gl_MAX_ASYNC_HISTOGRAM_SGIX, gl_ASYNC_HISTOGRAM_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_MAX_ASYNC_HISTOGRAM_SGIX :: GLenum
gl_MAX_ASYNC_HISTOGRAM_SGIX = 33581
 
gl_ASYNC_HISTOGRAM_SGIX :: GLenum
gl_ASYNC_HISTOGRAM_SGIX = 33580