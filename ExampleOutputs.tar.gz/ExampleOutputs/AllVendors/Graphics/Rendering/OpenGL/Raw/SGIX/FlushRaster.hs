{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.FlushRaster
       (glFlushRasterSGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glFlushRasterSGIX #-}
 
ptr_glFlushRasterSGIX :: FunPtr a
ptr_glFlushRasterSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_flush_raster"
        "glFlushRasterSGIX"
 
glFlushRasterSGIX :: IO ()
glFlushRasterSGIX = dyn_glFlushRasterSGIX ptr_glFlushRasterSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFlushRasterSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())