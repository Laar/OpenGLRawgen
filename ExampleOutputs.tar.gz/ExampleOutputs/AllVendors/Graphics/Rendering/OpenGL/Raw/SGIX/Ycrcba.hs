module Graphics.Rendering.OpenGL.Raw.SGIX.Ycrcba
       (gl_YCRCB_SGIX, gl_YCRCBA_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_YCRCB_SGIX :: GLenum
gl_YCRCB_SGIX = 33560
 
gl_YCRCBA_SGIX :: GLenum
gl_YCRCBA_SGIX = 33561