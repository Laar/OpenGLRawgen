{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.PixelTexture
       (glPixelTexGenSGIX, gl_PIXEL_TEX_GEN_SGIX,
        gl_PIXEL_TEX_GEN_MODE_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glPixelTexGenSGIX #-}
 
ptr_glPixelTexGenSGIX :: FunPtr a
ptr_glPixelTexGenSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_pixel_texture"
        "glPixelTexGenSGIX"
 
glPixelTexGenSGIX :: GLenum -> IO ()
glPixelTexGenSGIX = dyn_glPixelTexGenSGIX ptr_glPixelTexGenSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glPixelTexGenSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
gl_PIXEL_TEX_GEN_SGIX :: GLenum
gl_PIXEL_TEX_GEN_SGIX = 33081
 
gl_PIXEL_TEX_GEN_MODE_SGIX :: GLenum
gl_PIXEL_TEX_GEN_MODE_SGIX = 33579