module Graphics.Rendering.OpenGL.Raw.SGIX.Interlace
       (gl_INTERLACE_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_INTERLACE_SGIX :: GLenum
gl_INTERLACE_SGIX = 32916