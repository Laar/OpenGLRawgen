module Graphics.Rendering.OpenGL.Raw.SGIX.BlendAlphaMinmax
       (gl_ALPHA_MIN_SGIX, gl_ALPHA_MAX_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_ALPHA_MIN_SGIX :: GLenum
gl_ALPHA_MIN_SGIX = 33568
 
gl_ALPHA_MAX_SGIX :: GLenum
gl_ALPHA_MAX_SGIX = 33569