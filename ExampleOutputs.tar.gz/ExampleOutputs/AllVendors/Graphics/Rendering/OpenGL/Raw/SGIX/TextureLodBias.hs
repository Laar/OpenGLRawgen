module Graphics.Rendering.OpenGL.Raw.SGIX.TextureLodBias
       (gl_TEXTURE_LOD_BIAS_T_SGIX, gl_TEXTURE_LOD_BIAS_S_SGIX,
        gl_TEXTURE_LOD_BIAS_R_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_LOD_BIAS_T_SGIX :: GLenum
gl_TEXTURE_LOD_BIAS_T_SGIX = 33167
 
gl_TEXTURE_LOD_BIAS_S_SGIX :: GLenum
gl_TEXTURE_LOD_BIAS_S_SGIX = 33166
 
gl_TEXTURE_LOD_BIAS_R_SGIX :: GLenum
gl_TEXTURE_LOD_BIAS_R_SGIX = 33168