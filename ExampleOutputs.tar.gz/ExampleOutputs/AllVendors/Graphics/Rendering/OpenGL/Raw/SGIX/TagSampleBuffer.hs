{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.TagSampleBuffer
       (glTagSampleBufferSGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTagSampleBufferSGIX #-}
 
ptr_glTagSampleBufferSGIX :: FunPtr a
ptr_glTagSampleBufferSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_tag_sample_buffer"
        "glTagSampleBufferSGIX"
 
glTagSampleBufferSGIX :: IO ()
glTagSampleBufferSGIX
  = dyn_glTagSampleBufferSGIX ptr_glTagSampleBufferSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glTagSampleBufferSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())