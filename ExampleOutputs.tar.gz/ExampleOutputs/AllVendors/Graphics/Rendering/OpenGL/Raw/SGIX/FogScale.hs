module Graphics.Rendering.OpenGL.Raw.SGIX.FogScale
       (gl_FOG_SCALE_VALUE_SGIX, gl_FOG_SCALE_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_FOG_SCALE_VALUE_SGIX :: GLenum
gl_FOG_SCALE_VALUE_SGIX = 33277
 
gl_FOG_SCALE_SGIX :: GLenum
gl_FOG_SCALE_SGIX = 33276