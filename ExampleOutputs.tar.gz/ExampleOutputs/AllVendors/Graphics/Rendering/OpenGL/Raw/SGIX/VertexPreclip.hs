module Graphics.Rendering.OpenGL.Raw.SGIX.VertexPreclip
       (gl_VERTEX_PRECLIP_SGIX, gl_VERTEX_PRECLIP_HINT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_VERTEX_PRECLIP_SGIX :: GLenum
gl_VERTEX_PRECLIP_SGIX = 33774
 
gl_VERTEX_PRECLIP_HINT_SGIX :: GLenum
gl_VERTEX_PRECLIP_HINT_SGIX = 33775