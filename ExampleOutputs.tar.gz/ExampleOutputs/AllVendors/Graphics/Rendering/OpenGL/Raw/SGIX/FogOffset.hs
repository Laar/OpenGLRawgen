module Graphics.Rendering.OpenGL.Raw.SGIX.FogOffset
       (gl_FOG_OFFSET_VALUE_SGIX, gl_FOG_OFFSET_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_FOG_OFFSET_VALUE_SGIX :: GLenum
gl_FOG_OFFSET_VALUE_SGIX = 33177
 
gl_FOG_OFFSET_SGIX :: GLenum
gl_FOG_OFFSET_SGIX = 33176