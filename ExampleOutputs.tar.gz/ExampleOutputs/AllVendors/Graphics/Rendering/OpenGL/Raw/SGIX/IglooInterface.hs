{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.IglooInterface
       (glIglooInterfaceSGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glIglooInterfaceSGIX #-}
 
ptr_glIglooInterfaceSGIX :: FunPtr a
ptr_glIglooInterfaceSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_igloo_interface"
        "glIglooInterfaceSGIX"
 
glIglooInterfaceSGIX :: GLenum -> Ptr a -> IO ()
glIglooInterfaceSGIX
  = dyn_glIglooInterfaceSGIX ptr_glIglooInterfaceSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glIglooInterfaceSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> IO ())