{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.Instruments
       (glStopInstrumentsSGIX, glStartInstrumentsSGIX,
        glReadInstrumentsSGIX, glPollInstrumentsSGIX,
        glInstrumentsBufferSGIX, glGetInstrumentsSGIX,
        gl_INSTRUMENT_MEASUREMENTS_SGIX, gl_INSTRUMENT_BUFFER_POINTER_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glStopInstrumentsSGIX #-}
 
ptr_glStopInstrumentsSGIX :: FunPtr a
ptr_glStopInstrumentsSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glStopInstrumentsSGIX"
 
glStopInstrumentsSGIX :: GLint -> IO ()
glStopInstrumentsSGIX
  = dyn_glStopInstrumentsSGIX ptr_glStopInstrumentsSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glStopInstrumentsSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> IO ())
 
{-# NOINLINE ptr_glStartInstrumentsSGIX #-}
 
ptr_glStartInstrumentsSGIX :: FunPtr a
ptr_glStartInstrumentsSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glStartInstrumentsSGIX"
 
glStartInstrumentsSGIX :: IO ()
glStartInstrumentsSGIX
  = dyn_glStartInstrumentsSGIX ptr_glStartInstrumentsSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glStartInstrumentsSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())
 
{-# NOINLINE ptr_glReadInstrumentsSGIX #-}
 
ptr_glReadInstrumentsSGIX :: FunPtr a
ptr_glReadInstrumentsSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glReadInstrumentsSGIX"
 
glReadInstrumentsSGIX :: GLint -> IO ()
glReadInstrumentsSGIX
  = dyn_glReadInstrumentsSGIX ptr_glReadInstrumentsSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glReadInstrumentsSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> IO ())
 
{-# NOINLINE ptr_glPollInstrumentsSGIX #-}
 
ptr_glPollInstrumentsSGIX :: FunPtr a
ptr_glPollInstrumentsSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glPollInstrumentsSGIX"
 
glPollInstrumentsSGIX :: Ptr GLint -> IO GLint
glPollInstrumentsSGIX
  = dyn_glPollInstrumentsSGIX ptr_glPollInstrumentsSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glPollInstrumentsSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLint -> IO GLint)
 
{-# NOINLINE ptr_glInstrumentsBufferSGIX #-}
 
ptr_glInstrumentsBufferSGIX :: FunPtr a
ptr_glInstrumentsBufferSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glInstrumentsBufferSGIX"
 
glInstrumentsBufferSGIX :: GLsizei -> Ptr GLint -> IO ()
glInstrumentsBufferSGIX
  = dyn_glInstrumentsBufferSGIX ptr_glInstrumentsBufferSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glInstrumentsBufferSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetInstrumentsSGIX #-}
 
ptr_glGetInstrumentsSGIX :: FunPtr a
ptr_glGetInstrumentsSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_instruments"
        "glGetInstrumentsSGIX"
 
glGetInstrumentsSGIX :: IO GLint
glGetInstrumentsSGIX
  = dyn_glGetInstrumentsSGIX ptr_glGetInstrumentsSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetInstrumentsSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (IO GLint)
 
gl_INSTRUMENT_MEASUREMENTS_SGIX :: GLenum
gl_INSTRUMENT_MEASUREMENTS_SGIX = 33153
 
gl_INSTRUMENT_BUFFER_POINTER_SGIX :: GLenum
gl_INSTRUMENT_BUFFER_POINTER_SGIX = 33152