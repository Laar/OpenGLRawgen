module Graphics.Rendering.OpenGL.Raw.SGIX.ShadowAmbient
       (gl_SHADOW_AMBIENT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_SHADOW_AMBIENT_SGIX :: GLenum
gl_SHADOW_AMBIENT_SGIX = 32959