module Graphics.Rendering.OpenGL.Raw.SGIX.CalligraphicFragment
       (gl_CALLIGRAPHIC_FRAGMENT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CALLIGRAPHIC_FRAGMENT_SGIX :: GLenum
gl_CALLIGRAPHIC_FRAGMENT_SGIX = 33155