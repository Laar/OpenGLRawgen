module Graphics.Rendering.OpenGL.Raw.SGIX.ConvolutionAccuracy
       (gl_CONVOLUTION_HINT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CONVOLUTION_HINT_SGIX :: GLenum
gl_CONVOLUTION_HINT_SGIX = 33558