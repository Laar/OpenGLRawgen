{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.Framezoom
       (glFrameZoomSGIX, gl_MAX_FRAMEZOOM_FACTOR_SGIX, gl_FRAMEZOOM_SGIX,
        gl_FRAMEZOOM_FACTOR_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glFrameZoomSGIX #-}
 
ptr_glFrameZoomSGIX :: FunPtr a
ptr_glFrameZoomSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_framezoom"
        "glFrameZoomSGIX"
 
glFrameZoomSGIX :: GLint -> IO ()
glFrameZoomSGIX = dyn_glFrameZoomSGIX ptr_glFrameZoomSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glFrameZoomSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> IO ())
 
gl_MAX_FRAMEZOOM_FACTOR_SGIX :: GLenum
gl_MAX_FRAMEZOOM_FACTOR_SGIX = 33165
 
gl_FRAMEZOOM_SGIX :: GLenum
gl_FRAMEZOOM_SGIX = 33163
 
gl_FRAMEZOOM_FACTOR_SGIX :: GLenum
gl_FRAMEZOOM_FACTOR_SGIX = 33164