module Graphics.Rendering.OpenGL.Raw.SGIX.TextureMultiBuffer
       (gl_TEXTURE_MULTI_BUFFER_HINT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_MULTI_BUFFER_HINT_SGIX :: GLenum
gl_TEXTURE_MULTI_BUFFER_HINT_SGIX = 33070