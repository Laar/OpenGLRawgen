module Graphics.Rendering.OpenGL.Raw.SGIX.Ycrcb
       (gl_YCRCB_444_SGIX, gl_YCRCB_422_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_YCRCB_444_SGIX :: GLenum
gl_YCRCB_444_SGIX = 33212
 
gl_YCRCB_422_SGIX :: GLenum
gl_YCRCB_422_SGIX = 33211