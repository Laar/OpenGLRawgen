module Graphics.Rendering.OpenGL.Raw.SGIX.ScalebiasHint
       (gl_SCALEBIAS_HINT_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_SCALEBIAS_HINT_SGIX :: GLenum
gl_SCALEBIAS_HINT_SGIX = 33570