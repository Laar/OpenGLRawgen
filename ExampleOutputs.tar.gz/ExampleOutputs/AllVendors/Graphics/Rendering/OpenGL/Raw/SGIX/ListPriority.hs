{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.ListPriority
       (glListParameterivSGIX, glListParameteriSGIX,
        glListParameterfvSGIX, glListParameterfSGIX,
        glGetListParameterivSGIX, glGetListParameterfvSGIX,
        gl_LIST_PRIORITY_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glListParameterivSGIX #-}
 
ptr_glListParameterivSGIX :: FunPtr a
ptr_glListParameterivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glListParameterivSGIX"
 
glListParameterivSGIX :: GLuint -> GLenum -> Ptr GLint -> IO ()
glListParameterivSGIX
  = dyn_glListParameterivSGIX ptr_glListParameterivSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glListParameterivSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glListParameteriSGIX #-}
 
ptr_glListParameteriSGIX :: FunPtr a
ptr_glListParameteriSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glListParameteriSGIX"
 
glListParameteriSGIX :: GLuint -> GLenum -> GLint -> IO ()
glListParameteriSGIX
  = dyn_glListParameteriSGIX ptr_glListParameteriSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glListParameteriSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glListParameterfvSGIX #-}
 
ptr_glListParameterfvSGIX :: FunPtr a
ptr_glListParameterfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glListParameterfvSGIX"
 
glListParameterfvSGIX :: GLuint -> GLenum -> Ptr GLfloat -> IO ()
glListParameterfvSGIX
  = dyn_glListParameterfvSGIX ptr_glListParameterfvSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glListParameterfvSGIX
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glListParameterfSGIX #-}
 
ptr_glListParameterfSGIX :: FunPtr a
ptr_glListParameterfSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glListParameterfSGIX"
 
glListParameterfSGIX :: GLuint -> GLenum -> GLfloat -> IO ()
glListParameterfSGIX
  = dyn_glListParameterfSGIX ptr_glListParameterfSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glListParameterfSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetListParameterivSGIX #-}
 
ptr_glGetListParameterivSGIX :: FunPtr a
ptr_glGetListParameterivSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glGetListParameterivSGIX"
 
glGetListParameterivSGIX :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetListParameterivSGIX
  = dyn_glGetListParameterivSGIX ptr_glGetListParameterivSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetListParameterivSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetListParameterfvSGIX #-}
 
ptr_glGetListParameterfvSGIX :: FunPtr a
ptr_glGetListParameterfvSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_list_priority"
        "glGetListParameterfvSGIX"
 
glGetListParameterfvSGIX ::
                         GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetListParameterfvSGIX
  = dyn_glGetListParameterfvSGIX ptr_glGetListParameterfvSGIX
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetListParameterfvSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
gl_LIST_PRIORITY_SGIX :: GLenum
gl_LIST_PRIORITY_SGIX = 33154