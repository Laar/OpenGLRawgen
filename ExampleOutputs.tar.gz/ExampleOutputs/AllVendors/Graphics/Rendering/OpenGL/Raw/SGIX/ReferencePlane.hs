{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIX.ReferencePlane
       (glReferencePlaneSGIX, gl_REFERENCE_PLANE_SGIX,
        gl_REFERENCE_PLANE_EQUATION_SGIX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glReferencePlaneSGIX #-}
 
ptr_glReferencePlaneSGIX :: FunPtr a
ptr_glReferencePlaneSGIX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIX_reference_plane"
        "glReferencePlaneSGIX"
 
glReferencePlaneSGIX :: Ptr GLdouble -> IO ()
glReferencePlaneSGIX
  = dyn_glReferencePlaneSGIX ptr_glReferencePlaneSGIX
 
foreign import CALLCONV unsafe "dynamic" dyn_glReferencePlaneSGIX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
gl_REFERENCE_PLANE_SGIX :: GLenum
gl_REFERENCE_PLANE_SGIX = 33149
 
gl_REFERENCE_PLANE_EQUATION_SGIX :: GLenum
gl_REFERENCE_PLANE_EQUATION_SGIX = 33150