module Graphics.Rendering.OpenGL.Raw.SGIX.TextureAddEnv
       (gl_TEXTURE_ENV_BIAS_SGIX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_ENV_BIAS_SGIX :: GLenum
gl_TEXTURE_ENV_BIAS_SGIX = 32958