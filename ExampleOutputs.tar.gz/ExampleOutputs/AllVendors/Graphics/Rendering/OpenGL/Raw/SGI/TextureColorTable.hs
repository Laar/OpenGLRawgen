module Graphics.Rendering.OpenGL.Raw.SGI.TextureColorTable
       (gl_TEXTURE_COLOR_TABLE_SGI, gl_PROXY_TEXTURE_COLOR_TABLE_SGI)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_COLOR_TABLE_SGI :: GLenum
gl_TEXTURE_COLOR_TABLE_SGI = 32956
 
gl_PROXY_TEXTURE_COLOR_TABLE_SGI :: GLenum
gl_PROXY_TEXTURE_COLOR_TABLE_SGI = 32957