{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGI.ColorTable
       (glGetColorTableSGI, glGetColorTableParameterivSGI,
        glGetColorTableParameterfvSGI, glCopyColorTableSGI,
        glColorTableSGI, glColorTableParameterivSGI,
        glColorTableParameterfvSGI,
        gl_PROXY_POST_CONVOLUTION_COLOR_TABLE_SGI,
        gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE_SGI,
        gl_PROXY_COLOR_TABLE_SGI, gl_POST_CONVOLUTION_COLOR_TABLE_SGI,
        gl_POST_COLOR_MATRIX_COLOR_TABLE_SGI, gl_COLOR_TABLE_WIDTH_SGI,
        gl_COLOR_TABLE_SGI, gl_COLOR_TABLE_SCALE_SGI,
        gl_COLOR_TABLE_RED_SIZE_SGI, gl_COLOR_TABLE_LUMINANCE_SIZE_SGI,
        gl_COLOR_TABLE_INTENSITY_SIZE_SGI, gl_COLOR_TABLE_GREEN_SIZE_SGI,
        gl_COLOR_TABLE_FORMAT_SGI, gl_COLOR_TABLE_BLUE_SIZE_SGI,
        gl_COLOR_TABLE_BIAS_SGI, gl_COLOR_TABLE_ALPHA_SIZE_SGI)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetColorTableSGI #-}
 
ptr_glGetColorTableSGI :: FunPtr a
ptr_glGetColorTableSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glGetColorTableSGI"
 
glGetColorTableSGI :: GLenum -> GLenum -> GLenum -> Ptr a -> IO ()
glGetColorTableSGI = dyn_glGetColorTableSGI ptr_glGetColorTableSGI
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetColorTableSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> Ptr a -> IO ())
 
{-# NOINLINE ptr_glGetColorTableParameterivSGI #-}
 
ptr_glGetColorTableParameterivSGI :: FunPtr a
ptr_glGetColorTableParameterivSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glGetColorTableParameterivSGI"
 
glGetColorTableParameterivSGI ::
                              GLenum -> GLenum -> Ptr GLint -> IO ()
glGetColorTableParameterivSGI
  = dyn_glGetColorTableParameterivSGI
      ptr_glGetColorTableParameterivSGI
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetColorTableParameterivSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetColorTableParameterfvSGI #-}
 
ptr_glGetColorTableParameterfvSGI :: FunPtr a
ptr_glGetColorTableParameterfvSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glGetColorTableParameterfvSGI"
 
glGetColorTableParameterfvSGI ::
                              GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetColorTableParameterfvSGI
  = dyn_glGetColorTableParameterfvSGI
      ptr_glGetColorTableParameterfvSGI
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetColorTableParameterfvSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glCopyColorTableSGI #-}
 
ptr_glCopyColorTableSGI :: FunPtr a
ptr_glCopyColorTableSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glCopyColorTableSGI"
 
glCopyColorTableSGI ::
                    GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ()
glCopyColorTableSGI
  = dyn_glCopyColorTableSGI ptr_glCopyColorTableSGI
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyColorTableSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> GLint -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glColorTableSGI #-}
 
ptr_glColorTableSGI :: FunPtr a
ptr_glColorTableSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glColorTableSGI"
 
glColorTableSGI ::
                GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr a -> IO ()
glColorTableSGI = dyn_glColorTableSGI ptr_glColorTableSGI
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorTableSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> GLenum -> GLenum -> Ptr a -> IO ())
 
{-# NOINLINE ptr_glColorTableParameterivSGI #-}
 
ptr_glColorTableParameterivSGI :: FunPtr a
ptr_glColorTableParameterivSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glColorTableParameterivSGI"
 
glColorTableParameterivSGI ::
                           GLenum -> GLenum -> Ptr GLint -> IO ()
glColorTableParameterivSGI
  = dyn_glColorTableParameterivSGI ptr_glColorTableParameterivSGI
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glColorTableParameterivSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glColorTableParameterfvSGI #-}
 
ptr_glColorTableParameterfvSGI :: FunPtr a
ptr_glColorTableParameterfvSGI
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGI_color_table"
        "glColorTableParameterfvSGI"
 
glColorTableParameterfvSGI ::
                           GLenum -> GLenum -> Ptr GLfloat -> IO ()
glColorTableParameterfvSGI
  = dyn_glColorTableParameterfvSGI ptr_glColorTableParameterfvSGI
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glColorTableParameterfvSGI ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
gl_PROXY_POST_CONVOLUTION_COLOR_TABLE_SGI :: GLenum
gl_PROXY_POST_CONVOLUTION_COLOR_TABLE_SGI = 32980
 
gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE_SGI :: GLenum
gl_PROXY_POST_COLOR_MATRIX_COLOR_TABLE_SGI = 32981
 
gl_PROXY_COLOR_TABLE_SGI :: GLenum
gl_PROXY_COLOR_TABLE_SGI = 32979
 
gl_POST_CONVOLUTION_COLOR_TABLE_SGI :: GLenum
gl_POST_CONVOLUTION_COLOR_TABLE_SGI = 32977
 
gl_POST_COLOR_MATRIX_COLOR_TABLE_SGI :: GLenum
gl_POST_COLOR_MATRIX_COLOR_TABLE_SGI = 32978
 
gl_COLOR_TABLE_WIDTH_SGI :: GLenum
gl_COLOR_TABLE_WIDTH_SGI = 32985
 
gl_COLOR_TABLE_SGI :: GLenum
gl_COLOR_TABLE_SGI = 32976
 
gl_COLOR_TABLE_SCALE_SGI :: GLenum
gl_COLOR_TABLE_SCALE_SGI = 32982
 
gl_COLOR_TABLE_RED_SIZE_SGI :: GLenum
gl_COLOR_TABLE_RED_SIZE_SGI = 32986
 
gl_COLOR_TABLE_LUMINANCE_SIZE_SGI :: GLenum
gl_COLOR_TABLE_LUMINANCE_SIZE_SGI = 32990
 
gl_COLOR_TABLE_INTENSITY_SIZE_SGI :: GLenum
gl_COLOR_TABLE_INTENSITY_SIZE_SGI = 32991
 
gl_COLOR_TABLE_GREEN_SIZE_SGI :: GLenum
gl_COLOR_TABLE_GREEN_SIZE_SGI = 32987
 
gl_COLOR_TABLE_FORMAT_SGI :: GLenum
gl_COLOR_TABLE_FORMAT_SGI = 32984
 
gl_COLOR_TABLE_BLUE_SIZE_SGI :: GLenum
gl_COLOR_TABLE_BLUE_SIZE_SGI = 32988
 
gl_COLOR_TABLE_BIAS_SGI :: GLenum
gl_COLOR_TABLE_BIAS_SGI = 32983
 
gl_COLOR_TABLE_ALPHA_SIZE_SGI :: GLenum
gl_COLOR_TABLE_ALPHA_SIZE_SGI = 32989