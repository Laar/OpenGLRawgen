module Graphics.Rendering.OpenGL.Raw.HP.ConvolutionBorderModes
       (gl_REPLICATE_BORDER_HP, gl_IGNORE_BORDER_HP,
        gl_CONVOLUTION_BORDER_COLOR_HP, gl_CONSTANT_BORDER_HP)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_REPLICATE_BORDER_HP :: GLenum
gl_REPLICATE_BORDER_HP = 33107
 
gl_IGNORE_BORDER_HP :: GLenum
gl_IGNORE_BORDER_HP = 33104
 
gl_CONVOLUTION_BORDER_COLOR_HP :: GLenum
gl_CONVOLUTION_BORDER_COLOR_HP = 33108
 
gl_CONSTANT_BORDER_HP :: GLenum
gl_CONSTANT_BORDER_HP = 33105