module Graphics.Rendering.OpenGL.Raw.HP.OcclusionTest
       (gl_OCCLUSION_TEST_RESULT_HP, gl_OCCLUSION_TEST_HP) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_OCCLUSION_TEST_RESULT_HP :: GLenum
gl_OCCLUSION_TEST_RESULT_HP = 33126
 
gl_OCCLUSION_TEST_HP :: GLenum
gl_OCCLUSION_TEST_HP = 33125