module Graphics.Rendering.OpenGL.Raw.HP.TextureLighting
       (gl_TEXTURE_PRE_SPECULAR_HP, gl_TEXTURE_POST_SPECULAR_HP,
        gl_TEXTURE_LIGHTING_MODE_HP)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TEXTURE_PRE_SPECULAR_HP :: GLenum
gl_TEXTURE_PRE_SPECULAR_HP = 33129
 
gl_TEXTURE_POST_SPECULAR_HP :: GLenum
gl_TEXTURE_POST_SPECULAR_HP = 33128
 
gl_TEXTURE_LIGHTING_MODE_HP :: GLenum
gl_TEXTURE_LIGHTING_MODE_HP = 33127