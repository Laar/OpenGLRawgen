{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.HP.ImageTransform
       (glImageTransformParameterivHP, glImageTransformParameteriHP,
        glImageTransformParameterfvHP, glImageTransformParameterfHP,
        glGetImageTransformParameterivHP, glGetImageTransformParameterfvHP,
        gl_PROXY_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP,
        gl_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP, gl_IMAGE_TRANSLATE_Y_HP,
        gl_IMAGE_TRANSLATE_X_HP, gl_IMAGE_TRANSFORM_2D_HP,
        gl_IMAGE_SCALE_Y_HP, gl_IMAGE_SCALE_X_HP,
        gl_IMAGE_ROTATE_ORIGIN_Y_HP, gl_IMAGE_ROTATE_ORIGIN_X_HP,
        gl_IMAGE_ROTATE_ANGLE_HP, gl_IMAGE_MIN_FILTER_HP,
        gl_IMAGE_MAG_FILTER_HP, gl_IMAGE_CUBIC_WEIGHT_HP, gl_CUBIC_HP,
        gl_AVERAGE_HP)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glImageTransformParameterivHP #-}
 
ptr_glImageTransformParameterivHP :: FunPtr a
ptr_glImageTransformParameterivHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glImageTransformParameterivHP"
 
glImageTransformParameterivHP ::
                              GLenum -> GLenum -> Ptr GLint -> IO ()
glImageTransformParameterivHP
  = dyn_glImageTransformParameterivHP
      ptr_glImageTransformParameterivHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glImageTransformParameterivHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glImageTransformParameteriHP #-}
 
ptr_glImageTransformParameteriHP :: FunPtr a
ptr_glImageTransformParameteriHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glImageTransformParameteriHP"
 
glImageTransformParameteriHP :: GLenum -> GLenum -> GLint -> IO ()
glImageTransformParameteriHP
  = dyn_glImageTransformParameteriHP ptr_glImageTransformParameteriHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glImageTransformParameteriHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glImageTransformParameterfvHP #-}
 
ptr_glImageTransformParameterfvHP :: FunPtr a
ptr_glImageTransformParameterfvHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glImageTransformParameterfvHP"
 
glImageTransformParameterfvHP ::
                              GLenum -> GLenum -> Ptr GLfloat -> IO ()
glImageTransformParameterfvHP
  = dyn_glImageTransformParameterfvHP
      ptr_glImageTransformParameterfvHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glImageTransformParameterfvHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glImageTransformParameterfHP #-}
 
ptr_glImageTransformParameterfHP :: FunPtr a
ptr_glImageTransformParameterfHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glImageTransformParameterfHP"
 
glImageTransformParameterfHP ::
                             GLenum -> GLenum -> GLfloat -> IO ()
glImageTransformParameterfHP
  = dyn_glImageTransformParameterfHP ptr_glImageTransformParameterfHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glImageTransformParameterfHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetImageTransformParameterivHP #-}
 
ptr_glGetImageTransformParameterivHP :: FunPtr a
ptr_glGetImageTransformParameterivHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glGetImageTransformParameterivHP"
 
glGetImageTransformParameterivHP ::
                                 GLenum -> GLenum -> Ptr GLint -> IO ()
glGetImageTransformParameterivHP
  = dyn_glGetImageTransformParameterivHP
      ptr_glGetImageTransformParameterivHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetImageTransformParameterivHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetImageTransformParameterfvHP #-}
 
ptr_glGetImageTransformParameterfvHP :: FunPtr a
ptr_glGetImageTransformParameterfvHP
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_HP_image_transform"
        "glGetImageTransformParameterfvHP"
 
glGetImageTransformParameterfvHP ::
                                 GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetImageTransformParameterfvHP
  = dyn_glGetImageTransformParameterfvHP
      ptr_glGetImageTransformParameterfvHP
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetImageTransformParameterfvHP ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
gl_PROXY_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP :: GLenum
gl_PROXY_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP = 33123
 
gl_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP :: GLenum
gl_POST_IMAGE_TRANSFORM_COLOR_TABLE_HP = 33122
 
gl_IMAGE_TRANSLATE_Y_HP :: GLenum
gl_IMAGE_TRANSLATE_Y_HP = 33112
 
gl_IMAGE_TRANSLATE_X_HP :: GLenum
gl_IMAGE_TRANSLATE_X_HP = 33111
 
gl_IMAGE_TRANSFORM_2D_HP :: GLenum
gl_IMAGE_TRANSFORM_2D_HP = 33121
 
gl_IMAGE_SCALE_Y_HP :: GLenum
gl_IMAGE_SCALE_Y_HP = 33110
 
gl_IMAGE_SCALE_X_HP :: GLenum
gl_IMAGE_SCALE_X_HP = 33109
 
gl_IMAGE_ROTATE_ORIGIN_Y_HP :: GLenum
gl_IMAGE_ROTATE_ORIGIN_Y_HP = 33115
 
gl_IMAGE_ROTATE_ORIGIN_X_HP :: GLenum
gl_IMAGE_ROTATE_ORIGIN_X_HP = 33114
 
gl_IMAGE_ROTATE_ANGLE_HP :: GLenum
gl_IMAGE_ROTATE_ANGLE_HP = 33113
 
gl_IMAGE_MIN_FILTER_HP :: GLenum
gl_IMAGE_MIN_FILTER_HP = 33117
 
gl_IMAGE_MAG_FILTER_HP :: GLenum
gl_IMAGE_MAG_FILTER_HP = 33116
 
gl_IMAGE_CUBIC_WEIGHT_HP :: GLenum
gl_IMAGE_CUBIC_WEIGHT_HP = 33118
 
gl_CUBIC_HP :: GLenum
gl_CUBIC_HP = 33119
 
gl_AVERAGE_HP :: GLenum
gl_AVERAGE_HP = 33120