module Graphics.Rendering.OpenGL.Raw.REND.ScreenCoordinates
       (gl_SCREEN_COORDINATES_REND, gl_INVERTED_SCREEN_W_REND) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_SCREEN_COORDINATES_REND :: GLenum
gl_SCREEN_COORDINATES_REND = 33936
 
gl_INVERTED_SCREEN_W_REND :: GLenum
gl_INVERTED_SCREEN_W_REND = 33937