module Graphics.Rendering.OpenGL.Raw.ATI.PixelFormatFloat
       (gl_TYPE_RGBA_FLOAT_ATI, gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_TYPE_RGBA_FLOAT_ATI :: GLenum
gl_TYPE_RGBA_FLOAT_ATI = 34848
 
gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI :: GLenum
gl_COLOR_CLEAR_UNCLAMPED_VALUE_ATI = 34869