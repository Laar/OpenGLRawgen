module Graphics.Rendering.OpenGL.Raw.S3
       (module Graphics.Rendering.OpenGL.Raw.S3.S3tc) where
import Graphics.Rendering.OpenGL.Raw.S3.S3tc