{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SUN.TriangleList
       (glReplacementCodeusvSUN, glReplacementCodeusSUN,
        glReplacementCodeuivSUN, glReplacementCodeuiSUN,
        glReplacementCodeubvSUN, glReplacementCodeubSUN,
        glReplacementCodePointerSUN, gl_TRIANGLE_LIST_SUN, gl_RESTART_SUN,
        gl_REPLACE_OLDEST_SUN, gl_REPLACE_MIDDLE_SUN,
        gl_REPLACEMENT_CODE_SUN, gl_REPLACEMENT_CODE_ARRAY_TYPE_SUN,
        gl_REPLACEMENT_CODE_ARRAY_SUN,
        gl_REPLACEMENT_CODE_ARRAY_STRIDE_SUN,
        gl_REPLACEMENT_CODE_ARRAY_POINTER_SUN, gl_R1UI_V3F_SUN,
        gl_R1UI_T2F_V3F_SUN, gl_R1UI_T2F_N3F_V3F_SUN,
        gl_R1UI_T2F_C4F_N3F_V3F_SUN, gl_R1UI_N3F_V3F_SUN,
        gl_R1UI_C4UB_V3F_SUN, gl_R1UI_C4F_N3F_V3F_SUN, gl_R1UI_C3F_V3F_SUN)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glReplacementCodeusvSUN #-}
 
ptr_glReplacementCodeusvSUN :: FunPtr a
ptr_glReplacementCodeusvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeusvSUN"
 
glReplacementCodeusvSUN :: Ptr GLushort -> IO ()
glReplacementCodeusvSUN
  = dyn_glReplacementCodeusvSUN ptr_glReplacementCodeusvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeusvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLushort -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeusSUN #-}
 
ptr_glReplacementCodeusSUN :: FunPtr a
ptr_glReplacementCodeusSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeusSUN"
 
glReplacementCodeusSUN :: GLushort -> IO ()
glReplacementCodeusSUN
  = dyn_glReplacementCodeusSUN ptr_glReplacementCodeusSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeusSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLushort -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuivSUN #-}
 
ptr_glReplacementCodeuivSUN :: FunPtr a
ptr_glReplacementCodeuivSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeuivSUN"
 
glReplacementCodeuivSUN :: Ptr GLuint -> IO ()
glReplacementCodeuivSUN
  = dyn_glReplacementCodeuivSUN ptr_glReplacementCodeuivSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeuivSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiSUN #-}
 
ptr_glReplacementCodeuiSUN :: FunPtr a
ptr_glReplacementCodeuiSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeuiSUN"
 
glReplacementCodeuiSUN :: GLuint -> IO ()
glReplacementCodeuiSUN
  = dyn_glReplacementCodeuiSUN ptr_glReplacementCodeuiSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeuiSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeubvSUN #-}
 
ptr_glReplacementCodeubvSUN :: FunPtr a
ptr_glReplacementCodeubvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeubvSUN"
 
glReplacementCodeubvSUN :: Ptr GLubyte -> IO ()
glReplacementCodeubvSUN
  = dyn_glReplacementCodeubvSUN ptr_glReplacementCodeubvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeubvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLubyte -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeubSUN #-}
 
ptr_glReplacementCodeubSUN :: FunPtr a
ptr_glReplacementCodeubSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodeubSUN"
 
glReplacementCodeubSUN :: GLubyte -> IO ()
glReplacementCodeubSUN
  = dyn_glReplacementCodeubSUN ptr_glReplacementCodeubSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glReplacementCodeubSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLubyte -> IO ())
 
{-# NOINLINE ptr_glReplacementCodePointerSUN #-}
 
ptr_glReplacementCodePointerSUN :: FunPtr a
ptr_glReplacementCodePointerSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_triangle_list"
        "glReplacementCodePointerSUN"
 
glReplacementCodePointerSUN ::
                            GLenum -> GLsizei -> Ptr (Ptr a) -> IO ()
glReplacementCodePointerSUN
  = dyn_glReplacementCodePointerSUN ptr_glReplacementCodePointerSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodePointerSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr (Ptr a) -> IO ())
 
gl_TRIANGLE_LIST_SUN :: GLenum
gl_TRIANGLE_LIST_SUN = 33239
 
gl_RESTART_SUN :: GLenum
gl_RESTART_SUN = 1
 
gl_REPLACE_OLDEST_SUN :: GLenum
gl_REPLACE_OLDEST_SUN = 3
 
gl_REPLACE_MIDDLE_SUN :: GLenum
gl_REPLACE_MIDDLE_SUN = 2
 
gl_REPLACEMENT_CODE_SUN :: GLenum
gl_REPLACEMENT_CODE_SUN = 33240
 
gl_REPLACEMENT_CODE_ARRAY_TYPE_SUN :: GLenum
gl_REPLACEMENT_CODE_ARRAY_TYPE_SUN = 34241
 
gl_REPLACEMENT_CODE_ARRAY_SUN :: GLenum
gl_REPLACEMENT_CODE_ARRAY_SUN = 34240
 
gl_REPLACEMENT_CODE_ARRAY_STRIDE_SUN :: GLenum
gl_REPLACEMENT_CODE_ARRAY_STRIDE_SUN = 34242
 
gl_REPLACEMENT_CODE_ARRAY_POINTER_SUN :: GLenum
gl_REPLACEMENT_CODE_ARRAY_POINTER_SUN = 34243
 
gl_R1UI_V3F_SUN :: GLenum
gl_R1UI_V3F_SUN = 34244
 
gl_R1UI_T2F_V3F_SUN :: GLenum
gl_R1UI_T2F_V3F_SUN = 34249
 
gl_R1UI_T2F_N3F_V3F_SUN :: GLenum
gl_R1UI_T2F_N3F_V3F_SUN = 34250
 
gl_R1UI_T2F_C4F_N3F_V3F_SUN :: GLenum
gl_R1UI_T2F_C4F_N3F_V3F_SUN = 34251
 
gl_R1UI_N3F_V3F_SUN :: GLenum
gl_R1UI_N3F_V3F_SUN = 34247
 
gl_R1UI_C4UB_V3F_SUN :: GLenum
gl_R1UI_C4UB_V3F_SUN = 34245
 
gl_R1UI_C4F_N3F_V3F_SUN :: GLenum
gl_R1UI_C4F_N3F_V3F_SUN = 34248
 
gl_R1UI_C3F_V3F_SUN :: GLenum
gl_R1UI_C3F_V3F_SUN = 34246