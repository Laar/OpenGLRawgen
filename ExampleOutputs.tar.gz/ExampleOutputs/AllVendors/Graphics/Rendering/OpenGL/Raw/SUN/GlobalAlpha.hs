{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SUN.GlobalAlpha
       (glGlobalAlphaFactorusSUN, glGlobalAlphaFactoruiSUN,
        glGlobalAlphaFactorubSUN, glGlobalAlphaFactorsSUN,
        glGlobalAlphaFactoriSUN, glGlobalAlphaFactorfSUN,
        glGlobalAlphaFactordSUN, glGlobalAlphaFactorbSUN,
        gl_GLOBAL_ALPHA_SUN, gl_GLOBAL_ALPHA_FACTOR_SUN)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGlobalAlphaFactorusSUN #-}
 
ptr_glGlobalAlphaFactorusSUN :: FunPtr a
ptr_glGlobalAlphaFactorusSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactorusSUN"
 
glGlobalAlphaFactorusSUN :: GLushort -> IO ()
glGlobalAlphaFactorusSUN
  = dyn_glGlobalAlphaFactorusSUN ptr_glGlobalAlphaFactorusSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGlobalAlphaFactorusSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLushort -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactoruiSUN #-}
 
ptr_glGlobalAlphaFactoruiSUN :: FunPtr a
ptr_glGlobalAlphaFactoruiSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactoruiSUN"
 
glGlobalAlphaFactoruiSUN :: GLuint -> IO ()
glGlobalAlphaFactoruiSUN
  = dyn_glGlobalAlphaFactoruiSUN ptr_glGlobalAlphaFactoruiSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGlobalAlphaFactoruiSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactorubSUN #-}
 
ptr_glGlobalAlphaFactorubSUN :: FunPtr a
ptr_glGlobalAlphaFactorubSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactorubSUN"
 
glGlobalAlphaFactorubSUN :: GLubyte -> IO ()
glGlobalAlphaFactorubSUN
  = dyn_glGlobalAlphaFactorubSUN ptr_glGlobalAlphaFactorubSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGlobalAlphaFactorubSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLubyte -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactorsSUN #-}
 
ptr_glGlobalAlphaFactorsSUN :: FunPtr a
ptr_glGlobalAlphaFactorsSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactorsSUN"
 
glGlobalAlphaFactorsSUN :: GLshort -> IO ()
glGlobalAlphaFactorsSUN
  = dyn_glGlobalAlphaFactorsSUN ptr_glGlobalAlphaFactorsSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glGlobalAlphaFactorsSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLshort -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactoriSUN #-}
 
ptr_glGlobalAlphaFactoriSUN :: FunPtr a
ptr_glGlobalAlphaFactoriSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactoriSUN"
 
glGlobalAlphaFactoriSUN :: GLint -> IO ()
glGlobalAlphaFactoriSUN
  = dyn_glGlobalAlphaFactoriSUN ptr_glGlobalAlphaFactoriSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glGlobalAlphaFactoriSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactorfSUN #-}
 
ptr_glGlobalAlphaFactorfSUN :: FunPtr a
ptr_glGlobalAlphaFactorfSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactorfSUN"
 
glGlobalAlphaFactorfSUN :: GLfloat -> IO ()
glGlobalAlphaFactorfSUN
  = dyn_glGlobalAlphaFactorfSUN ptr_glGlobalAlphaFactorfSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glGlobalAlphaFactorfSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactordSUN #-}
 
ptr_glGlobalAlphaFactordSUN :: FunPtr a
ptr_glGlobalAlphaFactordSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactordSUN"
 
glGlobalAlphaFactordSUN :: GLdouble -> IO ()
glGlobalAlphaFactordSUN
  = dyn_glGlobalAlphaFactordSUN ptr_glGlobalAlphaFactordSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glGlobalAlphaFactordSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> IO ())
 
{-# NOINLINE ptr_glGlobalAlphaFactorbSUN #-}
 
ptr_glGlobalAlphaFactorbSUN :: FunPtr a
ptr_glGlobalAlphaFactorbSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_global_alpha"
        "glGlobalAlphaFactorbSUN"
 
glGlobalAlphaFactorbSUN :: GLbyte -> IO ()
glGlobalAlphaFactorbSUN
  = dyn_glGlobalAlphaFactorbSUN ptr_glGlobalAlphaFactorbSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glGlobalAlphaFactorbSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbyte -> IO ())
 
gl_GLOBAL_ALPHA_SUN :: GLenum
gl_GLOBAL_ALPHA_SUN = 33241
 
gl_GLOBAL_ALPHA_FACTOR_SUN :: GLenum
gl_GLOBAL_ALPHA_FACTOR_SUN = 33242