{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SUN.MeshArray
       (glDrawMeshArraysSUN, gl_TRIANGLE_MESH_SUN, gl_QUAD_MESH_SUN) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glDrawMeshArraysSUN #-}
 
ptr_glDrawMeshArraysSUN :: FunPtr a
ptr_glDrawMeshArraysSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_mesh_array"
        "glDrawMeshArraysSUN"
 
glDrawMeshArraysSUN ::
                    GLenum -> GLint -> GLsizei -> GLsizei -> IO ()
glDrawMeshArraysSUN
  = dyn_glDrawMeshArraysSUN ptr_glDrawMeshArraysSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawMeshArraysSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> GLsizei -> IO ())
 
gl_TRIANGLE_MESH_SUN :: GLenum
gl_TRIANGLE_MESH_SUN = 34325
 
gl_QUAD_MESH_SUN :: GLenum
gl_QUAD_MESH_SUN = 34324