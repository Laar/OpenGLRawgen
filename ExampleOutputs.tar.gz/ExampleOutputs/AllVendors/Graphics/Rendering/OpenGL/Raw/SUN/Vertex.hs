{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SUN.Vertex
       (glTexCoord4fVertex4fvSUN, glTexCoord4fVertex4fSUN,
        glTexCoord4fColor4fNormal3fVertex4fvSUN,
        glTexCoord4fColor4fNormal3fVertex4fSUN, glTexCoord2fVertex3fvSUN,
        glTexCoord2fVertex3fSUN, glTexCoord2fNormal3fVertex3fvSUN,
        glTexCoord2fNormal3fVertex3fSUN, glTexCoord2fColor4ubVertex3fvSUN,
        glTexCoord2fColor4ubVertex3fSUN,
        glTexCoord2fColor4fNormal3fVertex3fvSUN,
        glTexCoord2fColor4fNormal3fVertex3fSUN,
        glTexCoord2fColor3fVertex3fvSUN, glTexCoord2fColor3fVertex3fSUN,
        glReplacementCodeuiVertex3fvSUN, glReplacementCodeuiVertex3fSUN,
        glReplacementCodeuiTexCoord2fVertex3fvSUN,
        glReplacementCodeuiTexCoord2fVertex3fSUN,
        glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN,
        glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN,
        glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN,
        glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN,
        glReplacementCodeuiNormal3fVertex3fvSUN,
        glReplacementCodeuiNormal3fVertex3fSUN,
        glReplacementCodeuiColor4ubVertex3fvSUN,
        glReplacementCodeuiColor4ubVertex3fSUN,
        glReplacementCodeuiColor4fNormal3fVertex3fvSUN,
        glReplacementCodeuiColor4fNormal3fVertex3fSUN,
        glReplacementCodeuiColor3fVertex3fvSUN,
        glReplacementCodeuiColor3fVertex3fSUN, glNormal3fVertex3fvSUN,
        glNormal3fVertex3fSUN, glColor4ubVertex3fvSUN,
        glColor4ubVertex3fSUN, glColor4ubVertex2fvSUN,
        glColor4ubVertex2fSUN, glColor4fNormal3fVertex3fvSUN,
        glColor4fNormal3fVertex3fSUN, glColor3fVertex3fvSUN,
        glColor3fVertex3fSUN)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTexCoord4fVertex4fvSUN #-}
 
ptr_glTexCoord4fVertex4fvSUN :: FunPtr a
ptr_glTexCoord4fVertex4fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord4fVertex4fvSUN"
 
glTexCoord4fVertex4fvSUN :: Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord4fVertex4fvSUN
  = dyn_glTexCoord4fVertex4fvSUN ptr_glTexCoord4fVertex4fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord4fVertex4fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord4fVertex4fSUN #-}
 
ptr_glTexCoord4fVertex4fSUN :: FunPtr a
ptr_glTexCoord4fVertex4fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord4fVertex4fSUN"
 
glTexCoord4fVertex4fSUN ::
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord4fVertex4fSUN
  = dyn_glTexCoord4fVertex4fSUN ptr_glTexCoord4fVertex4fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord4fVertex4fSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord4fColor4fNormal3fVertex4fvSUN #-}
 
ptr_glTexCoord4fColor4fNormal3fVertex4fvSUN :: FunPtr a
ptr_glTexCoord4fColor4fNormal3fVertex4fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord4fColor4fNormal3fVertex4fvSUN"
 
glTexCoord4fColor4fNormal3fVertex4fvSUN ::
                                        Ptr GLfloat ->
                                          Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord4fColor4fNormal3fVertex4fvSUN
  = dyn_glTexCoord4fColor4fNormal3fVertex4fvSUN
      ptr_glTexCoord4fColor4fNormal3fVertex4fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord4fColor4fNormal3fVertex4fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord4fColor4fNormal3fVertex4fSUN #-}
 
ptr_glTexCoord4fColor4fNormal3fVertex4fSUN :: FunPtr a
ptr_glTexCoord4fColor4fNormal3fVertex4fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord4fColor4fNormal3fVertex4fSUN"
 
glTexCoord4fColor4fNormal3fVertex4fSUN ::
                                       GLfloat ->
                                         GLfloat ->
                                           GLfloat ->
                                             GLfloat ->
                                               GLfloat ->
                                                 GLfloat ->
                                                   GLfloat ->
                                                     GLfloat ->
                                                       GLfloat ->
                                                         GLfloat ->
                                                           GLfloat ->
                                                             GLfloat ->
                                                               GLfloat ->
                                                                 GLfloat -> GLfloat -> IO ()
glTexCoord4fColor4fNormal3fVertex4fSUN
  = dyn_glTexCoord4fColor4fNormal3fVertex4fSUN
      ptr_glTexCoord4fColor4fNormal3fVertex4fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord4fColor4fNormal3fVertex4fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat ->
                                GLfloat ->
                                  GLfloat ->
                                    GLfloat ->
                                      GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fVertex3fvSUN #-}
 
ptr_glTexCoord2fVertex3fvSUN :: FunPtr a
ptr_glTexCoord2fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fVertex3fvSUN"
 
glTexCoord2fVertex3fvSUN :: Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord2fVertex3fvSUN
  = dyn_glTexCoord2fVertex3fvSUN ptr_glTexCoord2fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fVertex3fSUN #-}
 
ptr_glTexCoord2fVertex3fSUN :: FunPtr a
ptr_glTexCoord2fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fVertex3fSUN"
 
glTexCoord2fVertex3fSUN ::
                        GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord2fVertex3fSUN
  = dyn_glTexCoord2fVertex3fSUN ptr_glTexCoord2fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoord2fVertex3fSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fNormal3fVertex3fvSUN #-}
 
ptr_glTexCoord2fNormal3fVertex3fvSUN :: FunPtr a
ptr_glTexCoord2fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fNormal3fVertex3fvSUN"
 
glTexCoord2fNormal3fVertex3fvSUN ::
                                 Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord2fNormal3fVertex3fvSUN
  = dyn_glTexCoord2fNormal3fVertex3fvSUN
      ptr_glTexCoord2fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fNormal3fVertex3fSUN #-}
 
ptr_glTexCoord2fNormal3fVertex3fSUN :: FunPtr a
ptr_glTexCoord2fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fNormal3fVertex3fSUN"
 
glTexCoord2fNormal3fVertex3fSUN ::
                                GLfloat ->
                                  GLfloat ->
                                    GLfloat ->
                                      GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord2fNormal3fVertex3fSUN
  = dyn_glTexCoord2fNormal3fVertex3fSUN
      ptr_glTexCoord2fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor4ubVertex3fvSUN #-}
 
ptr_glTexCoord2fColor4ubVertex3fvSUN :: FunPtr a
ptr_glTexCoord2fColor4ubVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor4ubVertex3fvSUN"
 
glTexCoord2fColor4ubVertex3fvSUN ::
                                 Ptr GLfloat -> Ptr GLubyte -> Ptr GLfloat -> IO ()
glTexCoord2fColor4ubVertex3fvSUN
  = dyn_glTexCoord2fColor4ubVertex3fvSUN
      ptr_glTexCoord2fColor4ubVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor4ubVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLubyte -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor4ubVertex3fSUN #-}
 
ptr_glTexCoord2fColor4ubVertex3fSUN :: FunPtr a
ptr_glTexCoord2fColor4ubVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor4ubVertex3fSUN"
 
glTexCoord2fColor4ubVertex3fSUN ::
                                GLfloat ->
                                  GLfloat ->
                                    GLubyte ->
                                      GLubyte ->
                                        GLubyte -> GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord2fColor4ubVertex3fSUN
  = dyn_glTexCoord2fColor4ubVertex3fSUN
      ptr_glTexCoord2fColor4ubVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor4ubVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLubyte ->
                        GLubyte ->
                          GLubyte -> GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor4fNormal3fVertex3fvSUN #-}
 
ptr_glTexCoord2fColor4fNormal3fVertex3fvSUN :: FunPtr a
ptr_glTexCoord2fColor4fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor4fNormal3fVertex3fvSUN"
 
glTexCoord2fColor4fNormal3fVertex3fvSUN ::
                                        Ptr GLfloat ->
                                          Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord2fColor4fNormal3fVertex3fvSUN
  = dyn_glTexCoord2fColor4fNormal3fVertex3fvSUN
      ptr_glTexCoord2fColor4fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor4fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor4fNormal3fVertex3fSUN #-}
 
ptr_glTexCoord2fColor4fNormal3fVertex3fSUN :: FunPtr a
ptr_glTexCoord2fColor4fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor4fNormal3fVertex3fSUN"
 
glTexCoord2fColor4fNormal3fVertex3fSUN ::
                                       GLfloat ->
                                         GLfloat ->
                                           GLfloat ->
                                             GLfloat ->
                                               GLfloat ->
                                                 GLfloat ->
                                                   GLfloat ->
                                                     GLfloat ->
                                                       GLfloat ->
                                                         GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord2fColor4fNormal3fVertex3fSUN
  = dyn_glTexCoord2fColor4fNormal3fVertex3fSUN
      ptr_glTexCoord2fColor4fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor4fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat ->
                                GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor3fVertex3fvSUN #-}
 
ptr_glTexCoord2fColor3fVertex3fvSUN :: FunPtr a
ptr_glTexCoord2fColor3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor3fVertex3fvSUN"
 
glTexCoord2fColor3fVertex3fvSUN ::
                                Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glTexCoord2fColor3fVertex3fvSUN
  = dyn_glTexCoord2fColor3fVertex3fvSUN
      ptr_glTexCoord2fColor3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glTexCoord2fColor3fVertex3fSUN #-}
 
ptr_glTexCoord2fColor3fVertex3fSUN :: FunPtr a
ptr_glTexCoord2fColor3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glTexCoord2fColor3fVertex3fSUN"
 
glTexCoord2fColor3fVertex3fSUN ::
                               GLfloat ->
                                 GLfloat ->
                                   GLfloat ->
                                     GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glTexCoord2fColor3fVertex3fSUN
  = dyn_glTexCoord2fColor3fVertex3fSUN
      ptr_glTexCoord2fColor3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoord2fColor3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiVertex3fvSUN #-}
 
ptr_glReplacementCodeuiVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiVertex3fvSUN"
 
glReplacementCodeuiVertex3fvSUN ::
                                Ptr GLuint -> Ptr GLfloat -> IO ()
glReplacementCodeuiVertex3fvSUN
  = dyn_glReplacementCodeuiVertex3fvSUN
      ptr_glReplacementCodeuiVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiVertex3fSUN #-}
 
ptr_glReplacementCodeuiVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiVertex3fSUN"
 
glReplacementCodeuiVertex3fSUN ::
                               GLuint -> GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiVertex3fSUN
  = dyn_glReplacementCodeuiVertex3fSUN
      ptr_glReplacementCodeuiVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fVertex3fvSUN #-}
 
ptr_glReplacementCodeuiTexCoord2fVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiTexCoord2fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fVertex3fvSUN"
 
glReplacementCodeuiTexCoord2fVertex3fvSUN ::
                                          Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiTexCoord2fVertex3fvSUN
  = dyn_glReplacementCodeuiTexCoord2fVertex3fvSUN
      ptr_glReplacementCodeuiTexCoord2fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fVertex3fSUN #-}
 
ptr_glReplacementCodeuiTexCoord2fVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiTexCoord2fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fVertex3fSUN"
 
glReplacementCodeuiTexCoord2fVertex3fSUN ::
                                         GLuint ->
                                           GLfloat ->
                                             GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiTexCoord2fVertex3fSUN
  = dyn_glReplacementCodeuiTexCoord2fVertex3fSUN
      ptr_glReplacementCodeuiTexCoord2fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN
             #-}
 
ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN"
 
glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN ::
                                                  Ptr GLuint ->
                                                    Ptr GLfloat ->
                                                      Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN
  = dyn_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN
      ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN
             #-}
 
ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN"
 
glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN ::
                                                 GLuint ->
                                                   GLfloat ->
                                                     GLfloat ->
                                                       GLfloat ->
                                                         GLfloat ->
                                                           GLfloat ->
                                                             GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN
  = dyn_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN
      ptr_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN
             #-}
 
ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN ::
                                                             FunPtr a
ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN"
 
glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN ::
                                                         Ptr GLuint ->
                                                           Ptr GLfloat ->
                                                             Ptr GLfloat ->
                                                               Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN
  = dyn_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN
      ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint ->
                    Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN
             #-}
 
ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN ::
                                                            FunPtr a
ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN"
 
glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN ::
                                                        GLuint ->
                                                          GLfloat ->
                                                            GLfloat ->
                                                              GLfloat ->
                                                                GLfloat ->
                                                                  GLfloat ->
                                                                    GLfloat ->
                                                                      GLfloat ->
                                                                        GLfloat ->
                                                                          GLfloat ->
                                                                            GLfloat ->
                                                                              GLfloat ->
                                                                                GLfloat -> IO ()
glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN
  = dyn_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN
      ptr_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat ->
                                GLfloat ->
                                  GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiNormal3fVertex3fvSUN #-}
 
ptr_glReplacementCodeuiNormal3fVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiNormal3fVertex3fvSUN"
 
glReplacementCodeuiNormal3fVertex3fvSUN ::
                                        Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiNormal3fVertex3fvSUN
  = dyn_glReplacementCodeuiNormal3fVertex3fvSUN
      ptr_glReplacementCodeuiNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiNormal3fVertex3fSUN #-}
 
ptr_glReplacementCodeuiNormal3fVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiNormal3fVertex3fSUN"
 
glReplacementCodeuiNormal3fVertex3fSUN ::
                                       GLuint ->
                                         GLfloat ->
                                           GLfloat ->
                                             GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiNormal3fVertex3fSUN
  = dyn_glReplacementCodeuiNormal3fVertex3fSUN
      ptr_glReplacementCodeuiNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat ->
                      GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor4ubVertex3fvSUN #-}
 
ptr_glReplacementCodeuiColor4ubVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiColor4ubVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor4ubVertex3fvSUN"
 
glReplacementCodeuiColor4ubVertex3fvSUN ::
                                        Ptr GLuint -> Ptr GLubyte -> Ptr GLfloat -> IO ()
glReplacementCodeuiColor4ubVertex3fvSUN
  = dyn_glReplacementCodeuiColor4ubVertex3fvSUN
      ptr_glReplacementCodeuiColor4ubVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor4ubVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLubyte -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor4ubVertex3fSUN #-}
 
ptr_glReplacementCodeuiColor4ubVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiColor4ubVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor4ubVertex3fSUN"
 
glReplacementCodeuiColor4ubVertex3fSUN ::
                                       GLuint ->
                                         GLubyte ->
                                           GLubyte ->
                                             GLubyte ->
                                               GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiColor4ubVertex3fSUN
  = dyn_glReplacementCodeuiColor4ubVertex3fSUN
      ptr_glReplacementCodeuiColor4ubVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor4ubVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLubyte ->
                      GLubyte ->
                        GLubyte -> GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor4fNormal3fVertex3fvSUN #-}
 
ptr_glReplacementCodeuiColor4fNormal3fVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiColor4fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor4fNormal3fVertex3fvSUN"
 
glReplacementCodeuiColor4fNormal3fVertex3fvSUN ::
                                               Ptr GLuint ->
                                                 Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiColor4fNormal3fVertex3fvSUN
  = dyn_glReplacementCodeuiColor4fNormal3fVertex3fvSUN
      ptr_glReplacementCodeuiColor4fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor4fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor4fNormal3fVertex3fSUN #-}
 
ptr_glReplacementCodeuiColor4fNormal3fVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiColor4fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor4fNormal3fVertex3fSUN"
 
glReplacementCodeuiColor4fNormal3fVertex3fSUN ::
                                              GLuint ->
                                                GLfloat ->
                                                  GLfloat ->
                                                    GLfloat ->
                                                      GLfloat ->
                                                        GLfloat ->
                                                          GLfloat ->
                                                            GLfloat ->
                                                              GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiColor4fNormal3fVertex3fSUN
  = dyn_glReplacementCodeuiColor4fNormal3fVertex3fSUN
      ptr_glReplacementCodeuiColor4fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor4fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat ->
                              GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor3fVertex3fvSUN #-}
 
ptr_glReplacementCodeuiColor3fVertex3fvSUN :: FunPtr a
ptr_glReplacementCodeuiColor3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor3fVertex3fvSUN"
 
glReplacementCodeuiColor3fVertex3fvSUN ::
                                       Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glReplacementCodeuiColor3fVertex3fvSUN
  = dyn_glReplacementCodeuiColor3fVertex3fvSUN
      ptr_glReplacementCodeuiColor3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLuint -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glReplacementCodeuiColor3fVertex3fSUN #-}
 
ptr_glReplacementCodeuiColor3fVertex3fSUN :: FunPtr a
ptr_glReplacementCodeuiColor3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glReplacementCodeuiColor3fVertex3fSUN"
 
glReplacementCodeuiColor3fVertex3fSUN ::
                                      GLuint ->
                                        GLfloat ->
                                          GLfloat ->
                                            GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glReplacementCodeuiColor3fVertex3fSUN
  = dyn_glReplacementCodeuiColor3fVertex3fSUN
      ptr_glReplacementCodeuiColor3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glReplacementCodeuiColor3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLfloat ->
                      GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glNormal3fVertex3fvSUN #-}
 
ptr_glNormal3fVertex3fvSUN :: FunPtr a
ptr_glNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glNormal3fVertex3fvSUN"
 
glNormal3fVertex3fvSUN :: Ptr GLfloat -> Ptr GLfloat -> IO ()
glNormal3fVertex3fvSUN
  = dyn_glNormal3fVertex3fvSUN ptr_glNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormal3fVertex3fvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glNormal3fVertex3fSUN #-}
 
ptr_glNormal3fVertex3fSUN :: FunPtr a
ptr_glNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glNormal3fVertex3fSUN"
 
glNormal3fVertex3fSUN ::
                      GLfloat ->
                        GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glNormal3fVertex3fSUN
  = dyn_glNormal3fVertex3fSUN ptr_glNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormal3fVertex3fSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4ubVertex3fvSUN #-}
 
ptr_glColor4ubVertex3fvSUN :: FunPtr a
ptr_glColor4ubVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4ubVertex3fvSUN"
 
glColor4ubVertex3fvSUN :: Ptr GLubyte -> Ptr GLfloat -> IO ()
glColor4ubVertex3fvSUN
  = dyn_glColor4ubVertex3fvSUN ptr_glColor4ubVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4ubVertex3fvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLubyte -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4ubVertex3fSUN #-}
 
ptr_glColor4ubVertex3fSUN :: FunPtr a
ptr_glColor4ubVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4ubVertex3fSUN"
 
glColor4ubVertex3fSUN ::
                      GLubyte ->
                        GLubyte ->
                          GLubyte -> GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ()
glColor4ubVertex3fSUN
  = dyn_glColor4ubVertex3fSUN ptr_glColor4ubVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4ubVertex3fSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLubyte ->
                    GLubyte ->
                      GLubyte -> GLubyte -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4ubVertex2fvSUN #-}
 
ptr_glColor4ubVertex2fvSUN :: FunPtr a
ptr_glColor4ubVertex2fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4ubVertex2fvSUN"
 
glColor4ubVertex2fvSUN :: Ptr GLubyte -> Ptr GLfloat -> IO ()
glColor4ubVertex2fvSUN
  = dyn_glColor4ubVertex2fvSUN ptr_glColor4ubVertex2fvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4ubVertex2fvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLubyte -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4ubVertex2fSUN #-}
 
ptr_glColor4ubVertex2fSUN :: FunPtr a
ptr_glColor4ubVertex2fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4ubVertex2fSUN"
 
glColor4ubVertex2fSUN ::
                      GLubyte ->
                        GLubyte -> GLubyte -> GLubyte -> GLfloat -> GLfloat -> IO ()
glColor4ubVertex2fSUN
  = dyn_glColor4ubVertex2fSUN ptr_glColor4ubVertex2fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor4ubVertex2fSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLubyte ->
                    GLubyte -> GLubyte -> GLubyte -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4fNormal3fVertex3fvSUN #-}
 
ptr_glColor4fNormal3fVertex3fvSUN :: FunPtr a
ptr_glColor4fNormal3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4fNormal3fVertex3fvSUN"
 
glColor4fNormal3fVertex3fvSUN ::
                              Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ()
glColor4fNormal3fVertex3fvSUN
  = dyn_glColor4fNormal3fVertex3fvSUN
      ptr_glColor4fNormal3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glColor4fNormal3fVertex3fvSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor4fNormal3fVertex3fSUN #-}
 
ptr_glColor4fNormal3fVertex3fSUN :: FunPtr a
ptr_glColor4fNormal3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor4fNormal3fVertex3fSUN"
 
glColor4fNormal3fVertex3fSUN ::
                             GLfloat ->
                               GLfloat ->
                                 GLfloat ->
                                   GLfloat ->
                                     GLfloat ->
                                       GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glColor4fNormal3fVertex3fSUN
  = dyn_glColor4fNormal3fVertex3fSUN ptr_glColor4fNormal3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glColor4fNormal3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat ->
                      GLfloat ->
                        GLfloat ->
                          GLfloat ->
                            GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor3fVertex3fvSUN #-}
 
ptr_glColor3fVertex3fvSUN :: FunPtr a
ptr_glColor3fVertex3fvSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor3fVertex3fvSUN"
 
glColor3fVertex3fvSUN :: Ptr GLfloat -> Ptr GLfloat -> IO ()
glColor3fVertex3fvSUN
  = dyn_glColor3fVertex3fvSUN ptr_glColor3fVertex3fvSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor3fVertex3fvSUN
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glColor3fVertex3fSUN #-}
 
ptr_glColor3fVertex3fSUN :: FunPtr a
ptr_glColor3fVertex3fSUN
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SUN_vertex"
        "glColor3fVertex3fSUN"
 
glColor3fVertex3fSUN ::
                     GLfloat ->
                       GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glColor3fVertex3fSUN
  = dyn_glColor3fVertex3fSUN ptr_glColor3fVertex3fSUN
 
foreign import CALLCONV unsafe "dynamic" dyn_glColor3fVertex3fSUN ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat ->
                    GLfloat -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())