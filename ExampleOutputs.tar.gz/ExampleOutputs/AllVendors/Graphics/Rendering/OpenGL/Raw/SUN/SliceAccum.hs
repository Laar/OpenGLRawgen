module Graphics.Rendering.OpenGL.Raw.SUN.SliceAccum
       (gl_SLICE_ACCUM_SUN) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_SLICE_ACCUM_SUN :: GLenum
gl_SLICE_ACCUM_SUN = 34252