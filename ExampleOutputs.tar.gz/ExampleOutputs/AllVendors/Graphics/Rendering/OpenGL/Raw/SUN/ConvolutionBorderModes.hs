module Graphics.Rendering.OpenGL.Raw.SUN.ConvolutionBorderModes
       (gl_WRAP_BORDER_SUN) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_WRAP_BORDER_SUN :: GLenum
gl_WRAP_BORDER_SUN = 33236