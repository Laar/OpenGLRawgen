module Graphics.Rendering.OpenGL.Raw.WIN.SpecularFog
       (gl_FOG_SPECULAR_TEXTURE_WIN) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_FOG_SPECULAR_TEXTURE_WIN :: GLenum
gl_FOG_SPECULAR_TEXTURE_WIN = 33004