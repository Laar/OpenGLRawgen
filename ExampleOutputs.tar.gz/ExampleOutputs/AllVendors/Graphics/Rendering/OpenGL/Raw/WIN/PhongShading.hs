module Graphics.Rendering.OpenGL.Raw.WIN.PhongShading
       (gl_PHONG_WIN, gl_PHONG_HINT_WIN) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_PHONG_WIN :: GLenum
gl_PHONG_WIN = 33002
 
gl_PHONG_HINT_WIN :: GLenum
gl_PHONG_HINT_WIN = 33003