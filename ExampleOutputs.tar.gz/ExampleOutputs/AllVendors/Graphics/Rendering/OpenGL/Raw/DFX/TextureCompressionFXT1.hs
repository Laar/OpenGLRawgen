module Graphics.Rendering.OpenGL.Raw.DFX.TextureCompressionFXT1
       (gl_COMPRESSED_RGB_FXT1_3DFX, gl_COMPRESSED_RGBA_FXT1_3DFX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_COMPRESSED_RGB_FXT1_3DFX :: GLenum
gl_COMPRESSED_RGB_FXT1_3DFX = 34480
 
gl_COMPRESSED_RGBA_FXT1_3DFX :: GLenum
gl_COMPRESSED_RGBA_FXT1_3DFX = 34481