module Graphics.Rendering.OpenGL.Raw.DFX.Multisample
       (gl_SAMPLE_BUFFERS_3DFX, gl_SAMPLES_3DFX, gl_MULTISAMPLE_BIT_3DFX,
        gl_MULTISAMPLE_3DFX)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_SAMPLE_BUFFERS_3DFX :: GLenum
gl_SAMPLE_BUFFERS_3DFX = 34483
 
gl_SAMPLES_3DFX :: GLenum
gl_SAMPLES_3DFX = 34484
 
gl_MULTISAMPLE_BIT_3DFX :: GLbitfield
gl_MULTISAMPLE_BIT_3DFX = 536870912
 
gl_MULTISAMPLE_3DFX :: GLenum
gl_MULTISAMPLE_3DFX = 34482