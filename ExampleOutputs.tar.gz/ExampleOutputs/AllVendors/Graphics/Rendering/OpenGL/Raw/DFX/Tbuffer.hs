{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.DFX.Tbuffer
       (glTbufferMask3DFX) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTbufferMask3DFX #-}
 
ptr_glTbufferMask3DFX :: FunPtr a
ptr_glTbufferMask3DFX
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_3DFX_tbuffer"
        "glTbufferMask3DFX"
 
glTbufferMask3DFX :: GLuint -> IO ()
glTbufferMask3DFX = dyn_glTbufferMask3DFX ptr_glTbufferMask3DFX
 
foreign import CALLCONV unsafe "dynamic" dyn_glTbufferMask3DFX ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO ())