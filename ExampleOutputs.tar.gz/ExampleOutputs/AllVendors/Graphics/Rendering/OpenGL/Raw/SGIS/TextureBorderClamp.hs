module Graphics.Rendering.OpenGL.Raw.SGIS.TextureBorderClamp
       (gl_CLAMP_TO_BORDER_SGIS) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CLAMP_TO_BORDER_SGIS :: GLenum
gl_CLAMP_TO_BORDER_SGIS = 33069