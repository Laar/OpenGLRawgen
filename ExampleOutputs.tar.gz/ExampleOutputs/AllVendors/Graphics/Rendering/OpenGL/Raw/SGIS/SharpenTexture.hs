{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.SharpenTexture
       (glSharpenTexFuncSGIS, glGetSharpenTexFuncSGIS,
        gl_SHARPEN_TEXTURE_FUNC_POINTS_SGIS, gl_LINEAR_SHARPEN_SGIS,
        gl_LINEAR_SHARPEN_COLOR_SGIS, gl_LINEAR_SHARPEN_ALPHA_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glSharpenTexFuncSGIS #-}
 
ptr_glSharpenTexFuncSGIS :: FunPtr a
ptr_glSharpenTexFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_sharpen_texture"
        "glSharpenTexFuncSGIS"
 
glSharpenTexFuncSGIS :: GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glSharpenTexFuncSGIS
  = dyn_glSharpenTexFuncSGIS ptr_glSharpenTexFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glSharpenTexFuncSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetSharpenTexFuncSGIS #-}
 
ptr_glGetSharpenTexFuncSGIS :: FunPtr a
ptr_glGetSharpenTexFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_sharpen_texture"
        "glGetSharpenTexFuncSGIS"
 
glGetSharpenTexFuncSGIS :: GLenum -> Ptr GLfloat -> IO ()
glGetSharpenTexFuncSGIS
  = dyn_glGetSharpenTexFuncSGIS ptr_glGetSharpenTexFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSharpenTexFuncSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
gl_SHARPEN_TEXTURE_FUNC_POINTS_SGIS :: GLenum
gl_SHARPEN_TEXTURE_FUNC_POINTS_SGIS = 32944
 
gl_LINEAR_SHARPEN_SGIS :: GLenum
gl_LINEAR_SHARPEN_SGIS = 32941
 
gl_LINEAR_SHARPEN_COLOR_SGIS :: GLenum
gl_LINEAR_SHARPEN_COLOR_SGIS = 32943
 
gl_LINEAR_SHARPEN_ALPHA_SGIS :: GLenum
gl_LINEAR_SHARPEN_ALPHA_SGIS = 32942