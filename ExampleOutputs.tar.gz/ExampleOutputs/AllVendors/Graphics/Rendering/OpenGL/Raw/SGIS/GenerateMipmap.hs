module Graphics.Rendering.OpenGL.Raw.SGIS.GenerateMipmap
       (gl_GENERATE_MIPMAP_SGIS, gl_GENERATE_MIPMAP_HINT_SGIS) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_GENERATE_MIPMAP_SGIS :: GLenum
gl_GENERATE_MIPMAP_SGIS = 33169
 
gl_GENERATE_MIPMAP_HINT_SGIS :: GLenum
gl_GENERATE_MIPMAP_HINT_SGIS = 33170