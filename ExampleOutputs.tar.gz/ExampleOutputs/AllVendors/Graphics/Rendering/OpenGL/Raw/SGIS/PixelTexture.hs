{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.PixelTexture
       (glPixelTexGenParameterivSGIS, glPixelTexGenParameteriSGIS,
        glPixelTexGenParameterfvSGIS, glPixelTexGenParameterfSGIS,
        glGetPixelTexGenParameterivSGIS, glGetPixelTexGenParameterfvSGIS,
        gl_PIXEL_TEXTURE_SGIS, gl_PIXEL_GROUP_COLOR_SGIS,
        gl_PIXEL_FRAGMENT_RGB_SOURCE_SGIS,
        gl_PIXEL_FRAGMENT_ALPHA_SOURCE_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glPixelTexGenParameterivSGIS #-}
 
ptr_glPixelTexGenParameterivSGIS :: FunPtr a
ptr_glPixelTexGenParameterivSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glPixelTexGenParameterivSGIS"
 
glPixelTexGenParameterivSGIS :: GLenum -> Ptr GLint -> IO ()
glPixelTexGenParameterivSGIS
  = dyn_glPixelTexGenParameterivSGIS ptr_glPixelTexGenParameterivSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPixelTexGenParameterivSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glPixelTexGenParameteriSGIS #-}
 
ptr_glPixelTexGenParameteriSGIS :: FunPtr a
ptr_glPixelTexGenParameteriSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glPixelTexGenParameteriSGIS"
 
glPixelTexGenParameteriSGIS :: GLenum -> GLint -> IO ()
glPixelTexGenParameteriSGIS
  = dyn_glPixelTexGenParameteriSGIS ptr_glPixelTexGenParameteriSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPixelTexGenParameteriSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glPixelTexGenParameterfvSGIS #-}
 
ptr_glPixelTexGenParameterfvSGIS :: FunPtr a
ptr_glPixelTexGenParameterfvSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glPixelTexGenParameterfvSGIS"
 
glPixelTexGenParameterfvSGIS :: GLenum -> Ptr GLfloat -> IO ()
glPixelTexGenParameterfvSGIS
  = dyn_glPixelTexGenParameterfvSGIS ptr_glPixelTexGenParameterfvSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPixelTexGenParameterfvSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glPixelTexGenParameterfSGIS #-}
 
ptr_glPixelTexGenParameterfSGIS :: FunPtr a
ptr_glPixelTexGenParameterfSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glPixelTexGenParameterfSGIS"
 
glPixelTexGenParameterfSGIS :: GLenum -> GLfloat -> IO ()
glPixelTexGenParameterfSGIS
  = dyn_glPixelTexGenParameterfSGIS ptr_glPixelTexGenParameterfSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glPixelTexGenParameterfSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetPixelTexGenParameterivSGIS #-}
 
ptr_glGetPixelTexGenParameterivSGIS :: FunPtr a
ptr_glGetPixelTexGenParameterivSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glGetPixelTexGenParameterivSGIS"
 
glGetPixelTexGenParameterivSGIS :: GLenum -> Ptr GLint -> IO ()
glGetPixelTexGenParameterivSGIS
  = dyn_glGetPixelTexGenParameterivSGIS
      ptr_glGetPixelTexGenParameterivSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPixelTexGenParameterivSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetPixelTexGenParameterfvSGIS #-}
 
ptr_glGetPixelTexGenParameterfvSGIS :: FunPtr a
ptr_glGetPixelTexGenParameterfvSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_pixel_texture"
        "glGetPixelTexGenParameterfvSGIS"
 
glGetPixelTexGenParameterfvSGIS :: GLenum -> Ptr GLfloat -> IO ()
glGetPixelTexGenParameterfvSGIS
  = dyn_glGetPixelTexGenParameterfvSGIS
      ptr_glGetPixelTexGenParameterfvSGIS
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetPixelTexGenParameterfvSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
gl_PIXEL_TEXTURE_SGIS :: GLenum
gl_PIXEL_TEXTURE_SGIS = 33619
 
gl_PIXEL_GROUP_COLOR_SGIS :: GLenum
gl_PIXEL_GROUP_COLOR_SGIS = 33622
 
gl_PIXEL_FRAGMENT_RGB_SOURCE_SGIS :: GLenum
gl_PIXEL_FRAGMENT_RGB_SOURCE_SGIS = 33620
 
gl_PIXEL_FRAGMENT_ALPHA_SOURCE_SGIS :: GLenum
gl_PIXEL_FRAGMENT_ALPHA_SOURCE_SGIS = 33621