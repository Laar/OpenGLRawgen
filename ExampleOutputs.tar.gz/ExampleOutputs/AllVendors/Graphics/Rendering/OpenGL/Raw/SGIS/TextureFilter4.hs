{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.TextureFilter4
       (glTexFilterFuncSGIS, glGetTexFilterFuncSGIS,
        gl_TEXTURE_FILTER4_SIZE_SGIS, gl_FILTER4_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTexFilterFuncSGIS #-}
 
ptr_glTexFilterFuncSGIS :: FunPtr a
ptr_glTexFilterFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_texture_filter4"
        "glTexFilterFuncSGIS"
 
glTexFilterFuncSGIS ::
                    GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glTexFilterFuncSGIS
  = dyn_glTexFilterFuncSGIS ptr_glTexFilterFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexFilterFuncSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetTexFilterFuncSGIS #-}
 
ptr_glGetTexFilterFuncSGIS :: FunPtr a
ptr_glGetTexFilterFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_texture_filter4"
        "glGetTexFilterFuncSGIS"
 
glGetTexFilterFuncSGIS :: GLenum -> GLenum -> Ptr GLfloat -> IO ()
glGetTexFilterFuncSGIS
  = dyn_glGetTexFilterFuncSGIS ptr_glGetTexFilterFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetTexFilterFuncSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLfloat -> IO ())
 
gl_TEXTURE_FILTER4_SIZE_SGIS :: GLenum
gl_TEXTURE_FILTER4_SIZE_SGIS = 33095
 
gl_FILTER4_SGIS :: GLenum
gl_FILTER4_SGIS = 33094