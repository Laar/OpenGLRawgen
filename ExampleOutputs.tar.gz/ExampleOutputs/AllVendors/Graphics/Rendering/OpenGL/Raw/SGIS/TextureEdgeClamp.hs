module Graphics.Rendering.OpenGL.Raw.SGIS.TextureEdgeClamp
       (gl_CLAMP_TO_EDGE_SGIS) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CLAMP_TO_EDGE_SGIS :: GLenum
gl_CLAMP_TO_EDGE_SGIS = 33071