{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.DetailTexture
       (glGetDetailTexFuncSGIS, glDetailTexFuncSGIS,
        gl_LINEAR_DETAIL_SGIS, gl_LINEAR_DETAIL_COLOR_SGIS,
        gl_LINEAR_DETAIL_ALPHA_SGIS, gl_DETAIL_TEXTURE_MODE_SGIS,
        gl_DETAIL_TEXTURE_LEVEL_SGIS, gl_DETAIL_TEXTURE_FUNC_POINTS_SGIS,
        gl_DETAIL_TEXTURE_2D_SGIS, gl_DETAIL_TEXTURE_2D_BINDING_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetDetailTexFuncSGIS #-}
 
ptr_glGetDetailTexFuncSGIS :: FunPtr a
ptr_glGetDetailTexFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_detail_texture"
        "glGetDetailTexFuncSGIS"
 
glGetDetailTexFuncSGIS :: GLenum -> Ptr GLfloat -> IO ()
glGetDetailTexFuncSGIS
  = dyn_glGetDetailTexFuncSGIS ptr_glGetDetailTexFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDetailTexFuncSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glDetailTexFuncSGIS #-}
 
ptr_glDetailTexFuncSGIS :: FunPtr a
ptr_glDetailTexFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_detail_texture"
        "glDetailTexFuncSGIS"
 
glDetailTexFuncSGIS :: GLenum -> GLsizei -> Ptr GLfloat -> IO ()
glDetailTexFuncSGIS
  = dyn_glDetailTexFuncSGIS ptr_glDetailTexFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glDetailTexFuncSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLfloat -> IO ())
 
gl_LINEAR_DETAIL_SGIS :: GLenum
gl_LINEAR_DETAIL_SGIS = 32919
 
gl_LINEAR_DETAIL_COLOR_SGIS :: GLenum
gl_LINEAR_DETAIL_COLOR_SGIS = 32921
 
gl_LINEAR_DETAIL_ALPHA_SGIS :: GLenum
gl_LINEAR_DETAIL_ALPHA_SGIS = 32920
 
gl_DETAIL_TEXTURE_MODE_SGIS :: GLenum
gl_DETAIL_TEXTURE_MODE_SGIS = 32923
 
gl_DETAIL_TEXTURE_LEVEL_SGIS :: GLenum
gl_DETAIL_TEXTURE_LEVEL_SGIS = 32922
 
gl_DETAIL_TEXTURE_FUNC_POINTS_SGIS :: GLenum
gl_DETAIL_TEXTURE_FUNC_POINTS_SGIS = 32924
 
gl_DETAIL_TEXTURE_2D_SGIS :: GLenum
gl_DETAIL_TEXTURE_2D_SGIS = 32917
 
gl_DETAIL_TEXTURE_2D_BINDING_SGIS :: GLenum
gl_DETAIL_TEXTURE_2D_BINDING_SGIS = 32918