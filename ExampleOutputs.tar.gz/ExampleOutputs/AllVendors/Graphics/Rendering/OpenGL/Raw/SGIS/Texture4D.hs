{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.Texture4D
       (glTexSubImage4DSGIS, glTexImage4DSGIS,
        gl_UNPACK_SKIP_VOLUMES_SGIS, gl_UNPACK_IMAGE_DEPTH_SGIS,
        gl_TEXTURE_WRAP_Q_SGIS, gl_TEXTURE_4D_SGIS,
        gl_TEXTURE_4D_BINDING_SGIS, gl_TEXTURE_4DSIZE_SGIS,
        gl_PROXY_TEXTURE_4D_SGIS, gl_PACK_SKIP_VOLUMES_SGIS,
        gl_PACK_IMAGE_DEPTH_SGIS, gl_MAX_4D_TEXTURE_SIZE_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTexSubImage4DSGIS #-}
 
ptr_glTexSubImage4DSGIS :: FunPtr a
ptr_glTexSubImage4DSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_texture4D"
        "glTexSubImage4DSGIS"
 
glTexSubImage4DSGIS ::
                    GLenum ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLint ->
                                GLsizei ->
                                  GLsizei ->
                                    GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr a -> IO ()
glTexSubImage4DSGIS
  = dyn_glTexSubImage4DSGIS ptr_glTexSubImage4DSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexSubImage4DSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLint ->
                        GLint ->
                          GLint ->
                            GLint ->
                              GLsizei ->
                                GLsizei ->
                                  GLsizei -> GLsizei -> GLenum -> GLenum -> Ptr a -> IO ())
 
{-# NOINLINE ptr_glTexImage4DSGIS #-}
 
ptr_glTexImage4DSGIS :: FunPtr a
ptr_glTexImage4DSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_texture4D"
        "glTexImage4DSGIS"
 
glTexImage4DSGIS ::
                 GLenum ->
                   GLint ->
                     GLenum ->
                       GLsizei ->
                         GLsizei ->
                           GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr a -> IO ()
glTexImage4DSGIS = dyn_glTexImage4DSGIS ptr_glTexImage4DSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexImage4DSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLint ->
                      GLenum ->
                        GLsizei ->
                          GLsizei ->
                            GLsizei -> GLsizei -> GLint -> GLenum -> GLenum -> Ptr a -> IO ())
 
gl_UNPACK_SKIP_VOLUMES_SGIS :: GLenum
gl_UNPACK_SKIP_VOLUMES_SGIS = 33074
 
gl_UNPACK_IMAGE_DEPTH_SGIS :: GLenum
gl_UNPACK_IMAGE_DEPTH_SGIS = 33075
 
gl_TEXTURE_WRAP_Q_SGIS :: GLenum
gl_TEXTURE_WRAP_Q_SGIS = 33079
 
gl_TEXTURE_4D_SGIS :: GLenum
gl_TEXTURE_4D_SGIS = 33076
 
gl_TEXTURE_4D_BINDING_SGIS :: GLenum
gl_TEXTURE_4D_BINDING_SGIS = 33103
 
gl_TEXTURE_4DSIZE_SGIS :: GLenum
gl_TEXTURE_4DSIZE_SGIS = 33078
 
gl_PROXY_TEXTURE_4D_SGIS :: GLenum
gl_PROXY_TEXTURE_4D_SGIS = 33077
 
gl_PACK_SKIP_VOLUMES_SGIS :: GLenum
gl_PACK_SKIP_VOLUMES_SGIS = 33072
 
gl_PACK_IMAGE_DEPTH_SGIS :: GLenum
gl_PACK_IMAGE_DEPTH_SGIS = 33073
 
gl_MAX_4D_TEXTURE_SIZE_SGIS :: GLenum
gl_MAX_4D_TEXTURE_SIZE_SGIS = 33080