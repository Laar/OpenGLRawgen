{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.PointParameters
       (glPointParameterfvSGIS, glPointParameterfSGIS,
        gl_POINT_SIZE_MIN_SGIS, gl_POINT_SIZE_MAX_SGIS,
        gl_POINT_FADE_THRESHOLD_SIZE_SGIS, gl_DISTANCE_ATTENUATION_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glPointParameterfvSGIS #-}
 
ptr_glPointParameterfvSGIS :: FunPtr a
ptr_glPointParameterfvSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_point_parameters"
        "glPointParameterfvSGIS"
 
glPointParameterfvSGIS :: GLenum -> Ptr GLfloat -> IO ()
glPointParameterfvSGIS
  = dyn_glPointParameterfvSGIS ptr_glPointParameterfvSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterfvSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glPointParameterfSGIS #-}
 
ptr_glPointParameterfSGIS :: FunPtr a
ptr_glPointParameterfSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_point_parameters"
        "glPointParameterfSGIS"
 
glPointParameterfSGIS :: GLenum -> GLfloat -> IO ()
glPointParameterfSGIS
  = dyn_glPointParameterfSGIS ptr_glPointParameterfSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glPointParameterfSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLfloat -> IO ())
 
gl_POINT_SIZE_MIN_SGIS :: GLenum
gl_POINT_SIZE_MIN_SGIS = 33062
 
gl_POINT_SIZE_MAX_SGIS :: GLenum
gl_POINT_SIZE_MAX_SGIS = 33063
 
gl_POINT_FADE_THRESHOLD_SIZE_SGIS :: GLenum
gl_POINT_FADE_THRESHOLD_SIZE_SGIS = 33064
 
gl_DISTANCE_ATTENUATION_SGIS :: GLenum
gl_DISTANCE_ATTENUATION_SGIS = 33065