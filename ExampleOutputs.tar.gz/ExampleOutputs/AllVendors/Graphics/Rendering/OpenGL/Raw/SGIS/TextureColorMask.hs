{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.TextureColorMask
       (glTextureColorMaskSGIS, gl_TEXTURE_COLOR_WRITEMASK_SGIS) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTextureColorMaskSGIS #-}
 
ptr_glTextureColorMaskSGIS :: FunPtr a
ptr_glTextureColorMaskSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_texture_color_mask"
        "glTextureColorMaskSGIS"
 
glTextureColorMaskSGIS ::
                       GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ()
glTextureColorMaskSGIS
  = dyn_glTextureColorMaskSGIS ptr_glTextureColorMaskSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureColorMaskSGIS
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLboolean -> GLboolean -> GLboolean -> GLboolean -> IO ())
 
gl_TEXTURE_COLOR_WRITEMASK_SGIS :: GLenum
gl_TEXTURE_COLOR_WRITEMASK_SGIS = 33263