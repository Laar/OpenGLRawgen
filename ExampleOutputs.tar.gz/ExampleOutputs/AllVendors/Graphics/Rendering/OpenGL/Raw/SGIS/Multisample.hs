{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.Multisample
       (glSamplePatternSGIS, glSampleMaskSGIS, gl_SAMPLE_PATTERN_SGIS,
        gl_SAMPLE_MASK_VALUE_SGIS, gl_SAMPLE_MASK_SGIS,
        gl_SAMPLE_MASK_INVERT_SGIS, gl_SAMPLE_BUFFERS_SGIS,
        gl_SAMPLE_ALPHA_TO_ONE_SGIS, gl_SAMPLE_ALPHA_TO_MASK_SGIS,
        gl_SAMPLES_SGIS, gl_MULTISAMPLE_SGIS, gl_4PASS_3_SGIS,
        gl_4PASS_2_SGIS, gl_4PASS_1_SGIS, gl_4PASS_0_SGIS, gl_2PASS_1_SGIS,
        gl_2PASS_0_SGIS, gl_1PASS_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glSamplePatternSGIS #-}
 
ptr_glSamplePatternSGIS :: FunPtr a
ptr_glSamplePatternSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_multisample"
        "glSamplePatternSGIS"
 
glSamplePatternSGIS :: GLenum -> IO ()
glSamplePatternSGIS
  = dyn_glSamplePatternSGIS ptr_glSamplePatternSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplePatternSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())
 
{-# NOINLINE ptr_glSampleMaskSGIS #-}
 
ptr_glSampleMaskSGIS :: FunPtr a
ptr_glSampleMaskSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_multisample"
        "glSampleMaskSGIS"
 
glSampleMaskSGIS :: GLclampf -> GLboolean -> IO ()
glSampleMaskSGIS = dyn_glSampleMaskSGIS ptr_glSampleMaskSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glSampleMaskSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLclampf -> GLboolean -> IO ())
 
gl_SAMPLE_PATTERN_SGIS :: GLenum
gl_SAMPLE_PATTERN_SGIS = 32940
 
gl_SAMPLE_MASK_VALUE_SGIS :: GLenum
gl_SAMPLE_MASK_VALUE_SGIS = 32938
 
gl_SAMPLE_MASK_SGIS :: GLenum
gl_SAMPLE_MASK_SGIS = 32928
 
gl_SAMPLE_MASK_INVERT_SGIS :: GLenum
gl_SAMPLE_MASK_INVERT_SGIS = 32939
 
gl_SAMPLE_BUFFERS_SGIS :: GLenum
gl_SAMPLE_BUFFERS_SGIS = 32936
 
gl_SAMPLE_ALPHA_TO_ONE_SGIS :: GLenum
gl_SAMPLE_ALPHA_TO_ONE_SGIS = 32927
 
gl_SAMPLE_ALPHA_TO_MASK_SGIS :: GLenum
gl_SAMPLE_ALPHA_TO_MASK_SGIS = 32926
 
gl_SAMPLES_SGIS :: GLenum
gl_SAMPLES_SGIS = 32937
 
gl_MULTISAMPLE_SGIS :: GLenum
gl_MULTISAMPLE_SGIS = 32925
 
gl_4PASS_3_SGIS :: GLenum
gl_4PASS_3_SGIS = 32935
 
gl_4PASS_2_SGIS :: GLenum
gl_4PASS_2_SGIS = 32934
 
gl_4PASS_1_SGIS :: GLenum
gl_4PASS_1_SGIS = 32933
 
gl_4PASS_0_SGIS :: GLenum
gl_4PASS_0_SGIS = 32932
 
gl_2PASS_1_SGIS :: GLenum
gl_2PASS_1_SGIS = 32931
 
gl_2PASS_0_SGIS :: GLenum
gl_2PASS_0_SGIS = 32930
 
gl_1PASS_SGIS :: GLenum
gl_1PASS_SGIS = 32929