{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.SGIS.FogFunction
       (glGetFogFuncSGIS, glFogFuncSGIS, gl_MAX_FOG_FUNC_POINTS_SGIS,
        gl_FOG_FUNC_SGIS, gl_FOG_FUNC_POINTS_SGIS)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetFogFuncSGIS #-}
 
ptr_glGetFogFuncSGIS :: FunPtr a
ptr_glGetFogFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_fog_function"
        "glGetFogFuncSGIS"
 
glGetFogFuncSGIS :: Ptr GLfloat -> IO ()
glGetFogFuncSGIS = dyn_glGetFogFuncSGIS ptr_glGetFogFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFogFuncSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glFogFuncSGIS #-}
 
ptr_glFogFuncSGIS :: FunPtr a
ptr_glFogFuncSGIS
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_SGIS_fog_function"
        "glFogFuncSGIS"
 
glFogFuncSGIS :: GLsizei -> Ptr GLfloat -> IO ()
glFogFuncSGIS = dyn_glFogFuncSGIS ptr_glFogFuncSGIS
 
foreign import CALLCONV unsafe "dynamic" dyn_glFogFuncSGIS ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLfloat -> IO ())
 
gl_MAX_FOG_FUNC_POINTS_SGIS :: GLenum
gl_MAX_FOG_FUNC_POINTS_SGIS = 33068
 
gl_FOG_FUNC_SGIS :: GLenum
gl_FOG_FUNC_SGIS = 33066
 
gl_FOG_FUNC_POINTS_SGIS :: GLenum
gl_FOG_FUNC_POINTS_SGIS = 33067