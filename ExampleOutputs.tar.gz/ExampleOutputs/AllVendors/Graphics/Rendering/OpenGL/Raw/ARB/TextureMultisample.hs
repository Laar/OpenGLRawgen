{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TextureMultisample
       (glTexImage3DMultisample, glTexImage2DMultisample, glSampleMaski,
        glGetMultisamplefv, gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE, gl_TEXTURE_SAMPLES,
        gl_TEXTURE_FIXED_SAMPLE_LOCATIONS,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE, gl_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_2D_MULTISAMPLE, gl_SAMPLE_POSITION,
        gl_SAMPLE_MASK_VALUE, gl_SAMPLE_MASK,
        gl_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_SAMPLER_2D_MULTISAMPLE,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE, gl_MAX_SAMPLE_MASK_WORDS,
        gl_MAX_INTEGER_SAMPLES, gl_MAX_DEPTH_TEXTURE_SAMPLES,
        gl_MAX_COLOR_TEXTURE_SAMPLES, gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_INT_SAMPLER_2D_MULTISAMPLE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE, gl_TEXTURE_SAMPLES,
        gl_TEXTURE_FIXED_SAMPLE_LOCATIONS,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_BINDING_2D_MULTISAMPLE, gl_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_TEXTURE_2D_MULTISAMPLE, gl_SAMPLE_POSITION,
        gl_SAMPLE_MASK_VALUE, gl_SAMPLE_MASK,
        gl_SAMPLER_2D_MULTISAMPLE_ARRAY, gl_SAMPLER_2D_MULTISAMPLE,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY,
        gl_PROXY_TEXTURE_2D_MULTISAMPLE, gl_MAX_SAMPLE_MASK_WORDS,
        gl_MAX_INTEGER_SAMPLES, gl_MAX_DEPTH_TEXTURE_SAMPLES,
        gl_MAX_COLOR_TEXTURE_SAMPLES, gl_INT_SAMPLER_2D_MULTISAMPLE_ARRAY,
        gl_INT_SAMPLER_2D_MULTISAMPLE)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTexImage3DMultisample #-}
 
ptr_glTexImage3DMultisample :: FunPtr a
ptr_glTexImage3DMultisample
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_multisample"
        "glTexImage3DMultisample"
 
glTexImage3DMultisample ::
                        GLenum ->
                          GLsizei ->
                            GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTexImage3DMultisample
  = dyn_glTexImage3DMultisample ptr_glTexImage3DMultisample
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexImage3DMultisample
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei ->
                      GLint -> GLsizei -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
{-# NOINLINE ptr_glTexImage2DMultisample #-}
 
ptr_glTexImage2DMultisample :: FunPtr a
ptr_glTexImage2DMultisample
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_multisample"
        "glTexImage2DMultisample"
 
glTexImage2DMultisample ::
                        GLenum ->
                          GLsizei -> GLint -> GLsizei -> GLsizei -> GLboolean -> IO ()
glTexImage2DMultisample
  = dyn_glTexImage2DMultisample ptr_glTexImage2DMultisample
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexImage2DMultisample
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei -> GLint -> GLsizei -> GLsizei -> GLboolean -> IO ())
 
{-# NOINLINE ptr_glSampleMaski #-}
 
ptr_glSampleMaski :: FunPtr a
ptr_glSampleMaski
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_multisample"
        "glSampleMaski"
 
glSampleMaski :: GLuint -> GLbitfield -> IO ()
glSampleMaski = dyn_glSampleMaski ptr_glSampleMaski
 
foreign import CALLCONV unsafe "dynamic" dyn_glSampleMaski ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLbitfield -> IO ())
 
{-# NOINLINE ptr_glGetMultisamplefv #-}
 
ptr_glGetMultisamplefv :: FunPtr a
ptr_glGetMultisamplefv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_multisample"
        "glGetMultisamplefv"
 
glGetMultisamplefv :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetMultisamplefv = dyn_glGetMultisamplefv ptr_glGetMultisamplefv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetMultisamplefv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())