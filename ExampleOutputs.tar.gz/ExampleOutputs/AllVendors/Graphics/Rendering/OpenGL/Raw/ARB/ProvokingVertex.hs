{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ProvokingVertex
       (glProvokingVertex, gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION,
        gl_PROVOKING_VERTEX, gl_LAST_VERTEX_CONVENTION,
        gl_FIRST_VERTEX_CONVENTION)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION, gl_PROVOKING_VERTEX,
        gl_LAST_VERTEX_CONVENTION, gl_FIRST_VERTEX_CONVENTION)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glProvokingVertex #-}
 
ptr_glProvokingVertex :: FunPtr a
ptr_glProvokingVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_provoking_vertex"
        "glProvokingVertex"
 
glProvokingVertex :: GLenum -> IO ()
glProvokingVertex = dyn_glProvokingVertex ptr_glProvokingVertex
 
foreign import CALLCONV unsafe "dynamic" dyn_glProvokingVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> IO ())