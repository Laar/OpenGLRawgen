module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferAlignment
       (gl_MIN_MAP_BUFFER_ALIGNMENT) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_MIN_MAP_BUFFER_ALIGNMENT)