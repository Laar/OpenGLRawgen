{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedback3
       (glGetQueryIndexediv, glEndQueryIndexed,
        glDrawTransformFeedbackStream, glBeginQueryIndexed,
        gl_MAX_VERTEX_STREAMS, gl_MAX_TRANSFORM_FEEDBACK_BUFFERS)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_MAX_VERTEX_STREAMS, gl_MAX_TRANSFORM_FEEDBACK_BUFFERS)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetQueryIndexediv #-}
 
ptr_glGetQueryIndexediv :: FunPtr a
ptr_glGetQueryIndexediv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback3"
        "glGetQueryIndexediv"
 
glGetQueryIndexediv ::
                    GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetQueryIndexediv
  = dyn_glGetQueryIndexediv ptr_glGetQueryIndexediv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryIndexediv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glEndQueryIndexed #-}
 
ptr_glEndQueryIndexed :: FunPtr a
ptr_glEndQueryIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback3"
        "glEndQueryIndexed"
 
glEndQueryIndexed :: GLenum -> GLuint -> IO ()
glEndQueryIndexed = dyn_glEndQueryIndexed ptr_glEndQueryIndexed
 
foreign import CALLCONV unsafe "dynamic" dyn_glEndQueryIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glDrawTransformFeedbackStream #-}
 
ptr_glDrawTransformFeedbackStream :: FunPtr a
ptr_glDrawTransformFeedbackStream
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback3"
        "glDrawTransformFeedbackStream"
 
glDrawTransformFeedbackStream ::
                              GLenum -> GLuint -> GLuint -> IO ()
glDrawTransformFeedbackStream
  = dyn_glDrawTransformFeedbackStream
      ptr_glDrawTransformFeedbackStream
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawTransformFeedbackStream ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> IO ())
 
{-# NOINLINE ptr_glBeginQueryIndexed #-}
 
ptr_glBeginQueryIndexed :: FunPtr a
ptr_glBeginQueryIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback3"
        "glBeginQueryIndexed"
 
glBeginQueryIndexed :: GLenum -> GLuint -> GLuint -> IO ()
glBeginQueryIndexed
  = dyn_glBeginQueryIndexed ptr_glBeginQueryIndexed
 
foreign import CALLCONV unsafe "dynamic" dyn_glBeginQueryIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> IO ())