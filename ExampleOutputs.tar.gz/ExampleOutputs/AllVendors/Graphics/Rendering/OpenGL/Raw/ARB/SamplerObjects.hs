{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.SamplerObjects
       (glSamplerParameteriv, glSamplerParameteri, glSamplerParameterfv,
        glSamplerParameterf, glSamplerParameterIuiv, glSamplerParameterIiv,
        glIsSampler, glGetSamplerParameteriv, glGetSamplerParameterfv,
        glGetSamplerParameterIuiv, glGetSamplerParameterIiv, glGenSamplers,
        glDeleteSamplers, glBindSampler, gl_SAMPLER_BINDING)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_SAMPLER_BINDING)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glSamplerParameteriv #-}
 
ptr_glSamplerParameteriv :: FunPtr a
ptr_glSamplerParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameteriv"
 
glSamplerParameteriv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glSamplerParameteriv
  = dyn_glSamplerParameteriv ptr_glSamplerParameteriv
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameteriv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glSamplerParameteri #-}
 
ptr_glSamplerParameteri :: FunPtr a
ptr_glSamplerParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameteri"
 
glSamplerParameteri :: GLuint -> GLenum -> GLint -> IO ()
glSamplerParameteri
  = dyn_glSamplerParameteri ptr_glSamplerParameteri
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glSamplerParameterfv #-}
 
ptr_glSamplerParameterfv :: FunPtr a
ptr_glSamplerParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameterfv"
 
glSamplerParameterfv :: GLuint -> GLenum -> Ptr GLfloat -> IO ()
glSamplerParameterfv
  = dyn_glSamplerParameterfv ptr_glSamplerParameterfv
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameterfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glSamplerParameterf #-}
 
ptr_glSamplerParameterf :: FunPtr a
ptr_glSamplerParameterf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameterf"
 
glSamplerParameterf :: GLuint -> GLenum -> GLfloat -> IO ()
glSamplerParameterf
  = dyn_glSamplerParameterf ptr_glSamplerParameterf
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameterf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glSamplerParameterIuiv #-}
 
ptr_glSamplerParameterIuiv :: FunPtr a
ptr_glSamplerParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameterIuiv"
 
glSamplerParameterIuiv :: GLuint -> GLenum -> Ptr GLuint -> IO ()
glSamplerParameterIuiv
  = dyn_glSamplerParameterIuiv ptr_glSamplerParameterIuiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameterIuiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glSamplerParameterIiv #-}
 
ptr_glSamplerParameterIiv :: FunPtr a
ptr_glSamplerParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glSamplerParameterIiv"
 
glSamplerParameterIiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glSamplerParameterIiv
  = dyn_glSamplerParameterIiv ptr_glSamplerParameterIiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glSamplerParameterIiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glIsSampler #-}
 
ptr_glIsSampler :: FunPtr a
ptr_glIsSampler
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glIsSampler"
 
glIsSampler :: GLuint -> IO GLboolean
glIsSampler = dyn_glIsSampler ptr_glIsSampler
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsSampler ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> IO GLboolean)
 
{-# NOINLINE ptr_glGetSamplerParameteriv #-}
 
ptr_glGetSamplerParameteriv :: FunPtr a
ptr_glGetSamplerParameteriv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glGetSamplerParameteriv"
 
glGetSamplerParameteriv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetSamplerParameteriv
  = dyn_glGetSamplerParameteriv ptr_glGetSamplerParameteriv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSamplerParameteriv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetSamplerParameterfv #-}
 
ptr_glGetSamplerParameterfv :: FunPtr a
ptr_glGetSamplerParameterfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glGetSamplerParameterfv"
 
glGetSamplerParameterfv :: GLuint -> GLenum -> Ptr GLfloat -> IO ()
glGetSamplerParameterfv
  = dyn_glGetSamplerParameterfv ptr_glGetSamplerParameterfv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSamplerParameterfv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetSamplerParameterIuiv #-}
 
ptr_glGetSamplerParameterIuiv :: FunPtr a
ptr_glGetSamplerParameterIuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glGetSamplerParameterIuiv"
 
glGetSamplerParameterIuiv ::
                          GLuint -> GLenum -> Ptr GLuint -> IO ()
glGetSamplerParameterIuiv
  = dyn_glGetSamplerParameterIuiv ptr_glGetSamplerParameterIuiv
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetSamplerParameterIuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glGetSamplerParameterIiv #-}
 
ptr_glGetSamplerParameterIiv :: FunPtr a
ptr_glGetSamplerParameterIiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glGetSamplerParameterIiv"
 
glGetSamplerParameterIiv :: GLuint -> GLenum -> Ptr GLint -> IO ()
glGetSamplerParameterIiv
  = dyn_glGetSamplerParameterIiv ptr_glGetSamplerParameterIiv
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetSamplerParameterIiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGenSamplers #-}
 
ptr_glGenSamplers :: FunPtr a
ptr_glGenSamplers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glGenSamplers"
 
glGenSamplers :: GLsizei -> Ptr GLuint -> IO ()
glGenSamplers = dyn_glGenSamplers ptr_glGenSamplers
 
foreign import CALLCONV unsafe "dynamic" dyn_glGenSamplers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glDeleteSamplers #-}
 
ptr_glDeleteSamplers :: FunPtr a
ptr_glDeleteSamplers
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glDeleteSamplers"
 
glDeleteSamplers :: GLsizei -> Ptr GLuint -> IO ()
glDeleteSamplers = dyn_glDeleteSamplers ptr_glDeleteSamplers
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteSamplers ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsizei -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glBindSampler #-}
 
ptr_glBindSampler :: FunPtr a
ptr_glBindSampler
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sampler_objects"
        "glBindSampler"
 
glBindSampler :: GLuint -> GLuint -> IO ()
glBindSampler = dyn_glBindSampler ptr_glBindSampler
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindSampler ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())