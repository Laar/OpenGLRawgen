{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.DrawElementsBaseVertex
       (glMultiDrawElementsBaseVertex, glDrawRangeElementsBaseVertex,
        glDrawElementsInstancedBaseVertex, glDrawElementsBaseVertex)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glMultiDrawElementsBaseVertex #-}
 
ptr_glMultiDrawElementsBaseVertex :: FunPtr a
ptr_glMultiDrawElementsBaseVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_elements_base_vertex"
        "glMultiDrawElementsBaseVertex"
 
glMultiDrawElementsBaseVertex ::
                              GLenum ->
                                Ptr GLsizei ->
                                  GLenum -> Ptr (Ptr a) -> GLsizei -> Ptr GLint -> IO ()
glMultiDrawElementsBaseVertex
  = dyn_glMultiDrawElementsBaseVertex
      ptr_glMultiDrawElementsBaseVertex
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiDrawElementsBaseVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    Ptr GLsizei ->
                      GLenum -> Ptr (Ptr a) -> GLsizei -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glDrawRangeElementsBaseVertex #-}
 
ptr_glDrawRangeElementsBaseVertex :: FunPtr a
ptr_glDrawRangeElementsBaseVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_elements_base_vertex"
        "glDrawRangeElementsBaseVertex"
 
glDrawRangeElementsBaseVertex ::
                              GLenum ->
                                GLuint -> GLuint -> GLsizei -> GLenum -> Ptr a -> GLint -> IO ()
glDrawRangeElementsBaseVertex
  = dyn_glDrawRangeElementsBaseVertex
      ptr_glDrawRangeElementsBaseVertex
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawRangeElementsBaseVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLuint -> GLuint -> GLsizei -> GLenum -> Ptr a -> GLint -> IO ())
 
{-# NOINLINE ptr_glDrawElementsInstancedBaseVertex #-}
 
ptr_glDrawElementsInstancedBaseVertex :: FunPtr a
ptr_glDrawElementsInstancedBaseVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_elements_base_vertex"
        "glDrawElementsInstancedBaseVertex"
 
glDrawElementsInstancedBaseVertex ::
                                  GLenum -> GLsizei -> GLenum -> Ptr a -> GLsizei -> GLint -> IO ()
glDrawElementsInstancedBaseVertex
  = dyn_glDrawElementsInstancedBaseVertex
      ptr_glDrawElementsInstancedBaseVertex
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawElementsInstancedBaseVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> Ptr a -> GLsizei -> GLint -> IO ())
 
{-# NOINLINE ptr_glDrawElementsBaseVertex #-}
 
ptr_glDrawElementsBaseVertex :: FunPtr a
ptr_glDrawElementsBaseVertex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_elements_base_vertex"
        "glDrawElementsBaseVertex"
 
glDrawElementsBaseVertex ::
                         GLenum -> GLsizei -> GLenum -> Ptr a -> GLint -> IO ()
glDrawElementsBaseVertex
  = dyn_glDrawElementsBaseVertex ptr_glDrawElementsBaseVertex
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawElementsBaseVertex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> Ptr a -> GLint -> IO ())