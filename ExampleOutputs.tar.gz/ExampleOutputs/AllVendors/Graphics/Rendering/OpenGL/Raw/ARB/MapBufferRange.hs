{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.MapBufferRange
       (glMapBufferRange, glFlushMappedBufferRange, gl_MAP_WRITE_BIT,
        gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_READ_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_FLUSH_EXPLICIT_BIT)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core30
       (gl_MAP_WRITE_BIT, gl_MAP_UNSYNCHRONIZED_BIT, gl_MAP_READ_BIT,
        gl_MAP_INVALIDATE_RANGE_BIT, gl_MAP_INVALIDATE_BUFFER_BIT,
        gl_MAP_FLUSH_EXPLICIT_BIT)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glMapBufferRange #-}
 
ptr_glMapBufferRange :: FunPtr a
ptr_glMapBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_map_buffer_range"
        "glMapBufferRange"
 
glMapBufferRange ::
                 GLenum -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a)
glMapBufferRange = dyn_glMapBufferRange ptr_glMapBufferRange
 
foreign import CALLCONV unsafe "dynamic" dyn_glMapBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> GLbitfield -> IO (Ptr a))
 
{-# NOINLINE ptr_glFlushMappedBufferRange #-}
 
ptr_glFlushMappedBufferRange :: FunPtr a
ptr_glFlushMappedBufferRange
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_map_buffer_range"
        "glFlushMappedBufferRange"
 
glFlushMappedBufferRange ::
                         GLenum -> GLintptr -> GLsizeiptr -> IO ()
glFlushMappedBufferRange
  = dyn_glFlushMappedBufferRange ptr_glFlushMappedBufferRange
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFlushMappedBufferRange ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLintptr -> GLsizeiptr -> IO ())