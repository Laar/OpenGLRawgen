{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.UniformBufferObject
       (glUniformBlockBinding, glGetUniformIndices,
        glGetUniformBlockIndex, glGetActiveUniformsiv,
        glGetActiveUniformName, glGetActiveUniformBlockiv,
        glGetActiveUniformBlockName, gl_UNIFORM_TYPE, gl_UNIFORM_SIZE,
        gl_UNIFORM_OFFSET, gl_UNIFORM_NAME_LENGTH,
        gl_UNIFORM_MATRIX_STRIDE, gl_UNIFORM_IS_ROW_MAJOR,
        gl_UNIFORM_BUFFER_START, gl_UNIFORM_BUFFER_SIZE,
        gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT, gl_UNIFORM_BUFFER_BINDING,
        gl_UNIFORM_BUFFER, gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER,
        gl_UNIFORM_BLOCK_NAME_LENGTH, gl_UNIFORM_BLOCK_INDEX,
        gl_UNIFORM_BLOCK_DATA_SIZE, gl_UNIFORM_BLOCK_BINDING,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS, gl_UNIFORM_ARRAY_STRIDE,
        gl_MAX_VERTEX_UNIFORM_BLOCKS, gl_MAX_UNIFORM_BUFFER_BINDINGS,
        gl_MAX_UNIFORM_BLOCK_SIZE, gl_MAX_GEOMETRY_UNIFORM_BLOCKS,
        gl_MAX_FRAGMENT_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS, gl_INVALID_INDEX,
        gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH, gl_ACTIVE_UNIFORM_BLOCKS)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_TYPE, gl_UNIFORM_SIZE, gl_UNIFORM_OFFSET,
        gl_UNIFORM_NAME_LENGTH, gl_UNIFORM_MATRIX_STRIDE,
        gl_UNIFORM_IS_ROW_MAJOR, gl_UNIFORM_BUFFER_START,
        gl_UNIFORM_BUFFER_SIZE, gl_UNIFORM_BUFFER_OFFSET_ALIGNMENT,
        gl_UNIFORM_BUFFER_BINDING, gl_UNIFORM_BUFFER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER,
        gl_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER,
        gl_UNIFORM_BLOCK_NAME_LENGTH, gl_UNIFORM_BLOCK_INDEX,
        gl_UNIFORM_BLOCK_DATA_SIZE, gl_UNIFORM_BLOCK_BINDING,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES,
        gl_UNIFORM_BLOCK_ACTIVE_UNIFORMS, gl_UNIFORM_ARRAY_STRIDE,
        gl_MAX_VERTEX_UNIFORM_BLOCKS, gl_MAX_UNIFORM_BUFFER_BINDINGS,
        gl_MAX_UNIFORM_BLOCK_SIZE, gl_MAX_GEOMETRY_UNIFORM_BLOCKS,
        gl_MAX_FRAGMENT_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_UNIFORM_BLOCKS,
        gl_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS,
        gl_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS, gl_INVALID_INDEX,
        gl_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH, gl_ACTIVE_UNIFORM_BLOCKS)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glUniformBlockBinding #-}
 
ptr_glUniformBlockBinding :: FunPtr a
ptr_glUniformBlockBinding
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glUniformBlockBinding"
 
glUniformBlockBinding :: GLuint -> GLuint -> GLuint -> IO ()
glUniformBlockBinding
  = dyn_glUniformBlockBinding ptr_glUniformBlockBinding
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformBlockBinding
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> IO ())
 
{-# NOINLINE ptr_glGetUniformIndices #-}
 
ptr_glGetUniformIndices :: FunPtr a
ptr_glGetUniformIndices
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetUniformIndices"
 
glGetUniformIndices ::
                    GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLuint -> IO ()
glGetUniformIndices
  = dyn_glGetUniformIndices ptr_glGetUniformIndices
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformIndices ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr (Ptr GLchar) -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glGetUniformBlockIndex #-}
 
ptr_glGetUniformBlockIndex :: FunPtr a
ptr_glGetUniformBlockIndex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetUniformBlockIndex"
 
glGetUniformBlockIndex :: GLuint -> Ptr GLchar -> IO GLuint
glGetUniformBlockIndex
  = dyn_glGetUniformBlockIndex ptr_glGetUniformBlockIndex
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformBlockIndex
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLchar -> IO GLuint)
 
{-# NOINLINE ptr_glGetActiveUniformsiv #-}
 
ptr_glGetActiveUniformsiv :: FunPtr a
ptr_glGetActiveUniformsiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetActiveUniformsiv"
 
glGetActiveUniformsiv ::
                      GLuint -> GLsizei -> Ptr GLuint -> GLenum -> Ptr GLint -> IO ()
glGetActiveUniformsiv
  = dyn_glGetActiveUniformsiv ptr_glGetActiveUniformsiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetActiveUniformsiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetActiveUniformName #-}
 
ptr_glGetActiveUniformName :: FunPtr a
ptr_glGetActiveUniformName
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetActiveUniformName"
 
glGetActiveUniformName ::
                       GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetActiveUniformName
  = dyn_glGetActiveUniformName ptr_glGetActiveUniformName
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetActiveUniformName
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
{-# NOINLINE ptr_glGetActiveUniformBlockiv #-}
 
ptr_glGetActiveUniformBlockiv :: FunPtr a
ptr_glGetActiveUniformBlockiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetActiveUniformBlockiv"
 
glGetActiveUniformBlockiv ::
                          GLuint -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetActiveUniformBlockiv
  = dyn_glGetActiveUniformBlockiv ptr_glGetActiveUniformBlockiv
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetActiveUniformBlockiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetActiveUniformBlockName #-}
 
ptr_glGetActiveUniformBlockName :: FunPtr a
ptr_glGetActiveUniformBlockName
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_uniform_buffer_object"
        "glGetActiveUniformBlockName"
 
glGetActiveUniformBlockName ::
                            GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetActiveUniformBlockName
  = dyn_glGetActiveUniformBlockName ptr_glGetActiveUniformBlockName
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetActiveUniformBlockName ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())