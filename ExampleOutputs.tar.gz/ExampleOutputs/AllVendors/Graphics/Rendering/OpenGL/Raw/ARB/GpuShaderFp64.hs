{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.GpuShaderFp64
       (glUniformMatrix4x3dv, glUniformMatrix4x2dv, glUniformMatrix4dv,
        glUniformMatrix3x4dv, glUniformMatrix3x2dv, glUniformMatrix3dv,
        glUniformMatrix2x4dv, glUniformMatrix2x3dv, glUniformMatrix2dv,
        glUniform4dv, glUniform4d, glUniform3dv, glUniform3d, glUniform2dv,
        glUniform2d, glUniform1dv, glUniform1d, glGetUniformdv,
        gl_DOUBLE_VEC4, gl_DOUBLE_VEC3, gl_DOUBLE_VEC2, gl_DOUBLE_MAT4x3,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4, gl_DOUBLE_MAT3x4,
        gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3, gl_DOUBLE_MAT2x4,
        gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2, gl_DOUBLE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_DOUBLE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DOUBLE_VEC4, gl_DOUBLE_VEC3, gl_DOUBLE_VEC2, gl_DOUBLE_MAT4x3,
        gl_DOUBLE_MAT4x2, gl_DOUBLE_MAT4, gl_DOUBLE_MAT3x4,
        gl_DOUBLE_MAT3x2, gl_DOUBLE_MAT3, gl_DOUBLE_MAT2x4,
        gl_DOUBLE_MAT2x3, gl_DOUBLE_MAT2)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glUniformMatrix4x3dv #-}
 
ptr_glUniformMatrix4x3dv :: FunPtr a
ptr_glUniformMatrix4x3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix4x3dv"
 
glUniformMatrix4x3dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix4x3dv
  = dyn_glUniformMatrix4x3dv ptr_glUniformMatrix4x3dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix4x3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix4x2dv #-}
 
ptr_glUniformMatrix4x2dv :: FunPtr a
ptr_glUniformMatrix4x2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix4x2dv"
 
glUniformMatrix4x2dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix4x2dv
  = dyn_glUniformMatrix4x2dv ptr_glUniformMatrix4x2dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix4x2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix4dv #-}
 
ptr_glUniformMatrix4dv :: FunPtr a
ptr_glUniformMatrix4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix4dv"
 
glUniformMatrix4dv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix4dv = dyn_glUniformMatrix4dv ptr_glUniformMatrix4dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix3x4dv #-}
 
ptr_glUniformMatrix3x4dv :: FunPtr a
ptr_glUniformMatrix3x4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix3x4dv"
 
glUniformMatrix3x4dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix3x4dv
  = dyn_glUniformMatrix3x4dv ptr_glUniformMatrix3x4dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix3x4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix3x2dv #-}
 
ptr_glUniformMatrix3x2dv :: FunPtr a
ptr_glUniformMatrix3x2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix3x2dv"
 
glUniformMatrix3x2dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix3x2dv
  = dyn_glUniformMatrix3x2dv ptr_glUniformMatrix3x2dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix3x2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix3dv #-}
 
ptr_glUniformMatrix3dv :: FunPtr a
ptr_glUniformMatrix3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix3dv"
 
glUniformMatrix3dv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix3dv = dyn_glUniformMatrix3dv ptr_glUniformMatrix3dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix2x4dv #-}
 
ptr_glUniformMatrix2x4dv :: FunPtr a
ptr_glUniformMatrix2x4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix2x4dv"
 
glUniformMatrix2x4dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix2x4dv
  = dyn_glUniformMatrix2x4dv ptr_glUniformMatrix2x4dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix2x4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix2x3dv #-}
 
ptr_glUniformMatrix2x3dv :: FunPtr a
ptr_glUniformMatrix2x3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix2x3dv"
 
glUniformMatrix2x3dv ::
                     GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix2x3dv
  = dyn_glUniformMatrix2x3dv ptr_glUniformMatrix2x3dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix2x3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniformMatrix2dv #-}
 
ptr_glUniformMatrix2dv :: FunPtr a
ptr_glUniformMatrix2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniformMatrix2dv"
 
glUniformMatrix2dv ::
                   GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ()
glUniformMatrix2dv = dyn_glUniformMatrix2dv ptr_glUniformMatrix2dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformMatrix2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> GLboolean -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform4dv #-}
 
ptr_glUniform4dv :: FunPtr a
ptr_glUniform4dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform4dv"
 
glUniform4dv :: GLint -> GLsizei -> Ptr GLdouble -> IO ()
glUniform4dv = dyn_glUniform4dv ptr_glUniform4dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform4d #-}
 
ptr_glUniform4d :: FunPtr a
ptr_glUniform4d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform4d"
 
glUniform4d ::
            GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glUniform4d = dyn_glUniform4d ptr_glUniform4d
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform4d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform3dv #-}
 
ptr_glUniform3dv :: FunPtr a
ptr_glUniform3dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform3dv"
 
glUniform3dv :: GLint -> GLsizei -> Ptr GLdouble -> IO ()
glUniform3dv = dyn_glUniform3dv ptr_glUniform3dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform3d #-}
 
ptr_glUniform3d :: FunPtr a
ptr_glUniform3d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform3d"
 
glUniform3d :: GLint -> GLdouble -> GLdouble -> GLdouble -> IO ()
glUniform3d = dyn_glUniform3d ptr_glUniform3d
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform3d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform2dv #-}
 
ptr_glUniform2dv :: FunPtr a
ptr_glUniform2dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform2dv"
 
glUniform2dv :: GLint -> GLsizei -> Ptr GLdouble -> IO ()
glUniform2dv = dyn_glUniform2dv ptr_glUniform2dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform2d #-}
 
ptr_glUniform2d :: FunPtr a
ptr_glUniform2d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform2d"
 
glUniform2d :: GLint -> GLdouble -> GLdouble -> IO ()
glUniform2d = dyn_glUniform2d ptr_glUniform2d
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform2d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLdouble -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform1dv #-}
 
ptr_glUniform1dv :: FunPtr a
ptr_glUniform1dv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform1dv"
 
glUniform1dv :: GLint -> GLsizei -> Ptr GLdouble -> IO ()
glUniform1dv = dyn_glUniform1dv ptr_glUniform1dv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1dv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLsizei -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glUniform1d #-}
 
ptr_glUniform1d :: FunPtr a
ptr_glUniform1d
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glUniform1d"
 
glUniform1d :: GLint -> GLdouble -> IO ()
glUniform1d = dyn_glUniform1d ptr_glUniform1d
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniform1d ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glGetUniformdv #-}
 
ptr_glGetUniformdv :: FunPtr a
ptr_glGetUniformdv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_gpu_shader_fp64"
        "glGetUniformdv"
 
glGetUniformdv :: GLuint -> GLint -> Ptr GLdouble -> IO ()
glGetUniformdv = dyn_glGetUniformdv ptr_glGetUniformdv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetUniformdv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> Ptr GLdouble -> IO ())