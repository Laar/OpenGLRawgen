{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.Sync
       (glWaitSync, glIsSync, glGetSynciv, glGetInteger64v, glFenceSync,
        glDeleteSync, glClientWaitSync, gl_WAIT_FAILED, gl_UNSIGNALED,
        gl_TIMEOUT_IGNORED, gl_TIMEOUT_EXPIRED, gl_SYNC_STATUS,
        gl_SYNC_GPU_COMMANDS_COMPLETE, gl_SYNC_FLUSH_COMMANDS_BIT,
        gl_SYNC_FLAGS, gl_SYNC_FENCE, gl_SYNC_CONDITION, gl_SIGNALED,
        gl_OBJECT_TYPE, gl_MAX_SERVER_WAIT_TIMEOUT, gl_CONDITION_SATISFIED,
        gl_ALREADY_SIGNALED)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_WAIT_FAILED, gl_UNSIGNALED, gl_TIMEOUT_IGNORED,
        gl_TIMEOUT_EXPIRED, gl_SYNC_STATUS, gl_SYNC_GPU_COMMANDS_COMPLETE,
        gl_SYNC_FLUSH_COMMANDS_BIT, gl_SYNC_FLAGS, gl_SYNC_FENCE,
        gl_SYNC_CONDITION, gl_SIGNALED, gl_OBJECT_TYPE,
        gl_MAX_SERVER_WAIT_TIMEOUT, gl_CONDITION_SATISFIED,
        gl_ALREADY_SIGNALED)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glWaitSync #-}
 
ptr_glWaitSync :: FunPtr a
ptr_glWaitSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glWaitSync"
 
glWaitSync :: GLsync -> GLbitfield -> GLuint64 -> IO ()
glWaitSync = dyn_glWaitSync ptr_glWaitSync
 
foreign import CALLCONV unsafe "dynamic" dyn_glWaitSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsync -> GLbitfield -> GLuint64 -> IO ())
 
{-# NOINLINE ptr_glIsSync #-}
 
ptr_glIsSync :: FunPtr a
ptr_glIsSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glIsSync"
 
glIsSync :: GLsync -> IO GLboolean
glIsSync = dyn_glIsSync ptr_glIsSync
 
foreign import CALLCONV unsafe "dynamic" dyn_glIsSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsync -> IO GLboolean)
 
{-# NOINLINE ptr_glGetSynciv #-}
 
ptr_glGetSynciv :: FunPtr a
ptr_glGetSynciv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glGetSynciv"
 
glGetSynciv ::
            GLsync -> GLenum -> GLsizei -> Ptr GLsizei -> Ptr GLint -> IO ()
glGetSynciv = dyn_glGetSynciv ptr_glGetSynciv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSynciv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsync -> GLenum -> GLsizei -> Ptr GLsizei -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetInteger64v #-}
 
ptr_glGetInteger64v :: FunPtr a
ptr_glGetInteger64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glGetInteger64v"
 
glGetInteger64v :: GLenum -> Ptr GLint64 -> IO ()
glGetInteger64v = dyn_glGetInteger64v ptr_glGetInteger64v
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetInteger64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLint64 -> IO ())
 
{-# NOINLINE ptr_glFenceSync #-}
 
ptr_glFenceSync :: FunPtr a
ptr_glFenceSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glFenceSync"
 
glFenceSync :: GLenum -> GLbitfield -> IO GLsync
glFenceSync = dyn_glFenceSync ptr_glFenceSync
 
foreign import CALLCONV unsafe "dynamic" dyn_glFenceSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLbitfield -> IO GLsync)
 
{-# NOINLINE ptr_glDeleteSync #-}
 
ptr_glDeleteSync :: FunPtr a
ptr_glDeleteSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glDeleteSync"
 
glDeleteSync :: GLsync -> IO ()
glDeleteSync = dyn_glDeleteSync ptr_glDeleteSync
 
foreign import CALLCONV unsafe "dynamic" dyn_glDeleteSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsync -> IO ())
 
{-# NOINLINE ptr_glClientWaitSync #-}
 
ptr_glClientWaitSync :: FunPtr a
ptr_glClientWaitSync
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_sync"
        "glClientWaitSync"
 
glClientWaitSync :: GLsync -> GLbitfield -> GLuint64 -> IO GLenum
glClientWaitSync = dyn_glClientWaitSync ptr_glClientWaitSync
 
foreign import CALLCONV unsafe "dynamic" dyn_glClientWaitSync ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLsync -> GLbitfield -> GLuint64 -> IO GLenum)