{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.InternalformatQuery
       (glGetInternalformativ, gl_NUM_SAMPLE_COUNTS) where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_NUM_SAMPLE_COUNTS)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetInternalformativ #-}
 
ptr_glGetInternalformativ :: FunPtr a
ptr_glGetInternalformativ
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_internalformat_query"
        "glGetInternalformativ"
 
glGetInternalformativ ::
                      GLenum -> GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ()
glGetInternalformativ
  = dyn_glGetInternalformativ ptr_glGetInternalformativ
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetInternalformativ
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLenum -> GLsizei -> Ptr GLint -> IO ())