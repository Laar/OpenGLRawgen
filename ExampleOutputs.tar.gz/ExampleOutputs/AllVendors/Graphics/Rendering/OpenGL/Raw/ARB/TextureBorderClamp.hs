module Graphics.Rendering.OpenGL.Raw.ARB.TextureBorderClamp
       (gl_CLAMP_TO_BORDER_ARB) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CLAMP_TO_BORDER_ARB :: GLenum
gl_CLAMP_TO_BORDER_ARB = 33069