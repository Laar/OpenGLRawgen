{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.MESA.ResizeBuffers
       (glResizeBuffersMESA) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glResizeBuffersMESA #-}
 
ptr_glResizeBuffersMESA :: FunPtr a
ptr_glResizeBuffersMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_resize_buffers"
        "glResizeBuffersMESA"
 
glResizeBuffersMESA :: IO ()
glResizeBuffersMESA
  = dyn_glResizeBuffersMESA ptr_glResizeBuffersMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glResizeBuffersMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker (IO ())