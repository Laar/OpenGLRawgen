module Graphics.Rendering.OpenGL.Raw.MESA.YcbcrTexture
       (gl_YCBCR_MESA, gl_UNSIGNED_SHORT_8_8_REV_MESA,
        gl_UNSIGNED_SHORT_8_8_MESA)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_YCBCR_MESA :: GLenum
gl_YCBCR_MESA = 34647
 
gl_UNSIGNED_SHORT_8_8_REV_MESA :: GLenum
gl_UNSIGNED_SHORT_8_8_REV_MESA = 34235
 
gl_UNSIGNED_SHORT_8_8_MESA :: GLenum
gl_UNSIGNED_SHORT_8_8_MESA = 34234