module Graphics.Rendering.OpenGL.Raw.MESA.PackInvert
       (gl_PACK_INVERT_MESA) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_PACK_INVERT_MESA :: GLenum
gl_PACK_INVERT_MESA = 34648