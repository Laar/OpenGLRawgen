{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.MESA.WindowPos
       (glWindowPos4svMESA, glWindowPos4sMESA, glWindowPos4ivMESA,
        glWindowPos4iMESA, glWindowPos4fvMESA, glWindowPos4fMESA,
        glWindowPos4dvMESA, glWindowPos4dMESA, glWindowPos3svMESA,
        glWindowPos3sMESA, glWindowPos3ivMESA, glWindowPos3iMESA,
        glWindowPos3fvMESA, glWindowPos3fMESA, glWindowPos3dvMESA,
        glWindowPos3dMESA, glWindowPos2svMESA, glWindowPos2sMESA,
        glWindowPos2ivMESA, glWindowPos2iMESA, glWindowPos2fvMESA,
        glWindowPos2fMESA, glWindowPos2dvMESA, glWindowPos2dMESA)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glWindowPos4svMESA #-}
 
ptr_glWindowPos4svMESA :: FunPtr a
ptr_glWindowPos4svMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4svMESA"
 
glWindowPos4svMESA :: Ptr GLshort -> IO ()
glWindowPos4svMESA = dyn_glWindowPos4svMESA ptr_glWindowPos4svMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4svMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos4sMESA #-}
 
ptr_glWindowPos4sMESA :: FunPtr a
ptr_glWindowPos4sMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4sMESA"
 
glWindowPos4sMESA ::
                  GLshort -> GLshort -> GLshort -> GLshort -> IO ()
glWindowPos4sMESA = dyn_glWindowPos4sMESA ptr_glWindowPos4sMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4sMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLshort -> GLshort -> GLshort -> GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos4ivMESA #-}
 
ptr_glWindowPos4ivMESA :: FunPtr a
ptr_glWindowPos4ivMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4ivMESA"
 
glWindowPos4ivMESA :: Ptr GLint -> IO ()
glWindowPos4ivMESA = dyn_glWindowPos4ivMESA ptr_glWindowPos4ivMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4ivMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos4iMESA #-}
 
ptr_glWindowPos4iMESA :: FunPtr a
ptr_glWindowPos4iMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4iMESA"
 
glWindowPos4iMESA :: GLint -> GLint -> GLint -> GLint -> IO ()
glWindowPos4iMESA = dyn_glWindowPos4iMESA ptr_glWindowPos4iMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4iMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLint -> GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos4fvMESA #-}
 
ptr_glWindowPos4fvMESA :: FunPtr a
ptr_glWindowPos4fvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4fvMESA"
 
glWindowPos4fvMESA :: Ptr GLfloat -> IO ()
glWindowPos4fvMESA = dyn_glWindowPos4fvMESA ptr_glWindowPos4fvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4fvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos4fMESA #-}
 
ptr_glWindowPos4fMESA :: FunPtr a
ptr_glWindowPos4fMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4fMESA"
 
glWindowPos4fMESA ::
                  GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glWindowPos4fMESA = dyn_glWindowPos4fMESA ptr_glWindowPos4fMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4fMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos4dvMESA #-}
 
ptr_glWindowPos4dvMESA :: FunPtr a
ptr_glWindowPos4dvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4dvMESA"
 
glWindowPos4dvMESA :: Ptr GLdouble -> IO ()
glWindowPos4dvMESA = dyn_glWindowPos4dvMESA ptr_glWindowPos4dvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4dvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glWindowPos4dMESA #-}
 
ptr_glWindowPos4dMESA :: FunPtr a
ptr_glWindowPos4dMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos4dMESA"
 
glWindowPos4dMESA ::
                  GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ()
glWindowPos4dMESA = dyn_glWindowPos4dMESA ptr_glWindowPos4dMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos4dMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> GLdouble -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glWindowPos3svMESA #-}
 
ptr_glWindowPos3svMESA :: FunPtr a
ptr_glWindowPos3svMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3svMESA"
 
glWindowPos3svMESA :: Ptr GLshort -> IO ()
glWindowPos3svMESA = dyn_glWindowPos3svMESA ptr_glWindowPos3svMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3svMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos3sMESA #-}
 
ptr_glWindowPos3sMESA :: FunPtr a
ptr_glWindowPos3sMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3sMESA"
 
glWindowPos3sMESA :: GLshort -> GLshort -> GLshort -> IO ()
glWindowPos3sMESA = dyn_glWindowPos3sMESA ptr_glWindowPos3sMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3sMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLshort -> GLshort -> GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos3ivMESA #-}
 
ptr_glWindowPos3ivMESA :: FunPtr a
ptr_glWindowPos3ivMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3ivMESA"
 
glWindowPos3ivMESA :: Ptr GLint -> IO ()
glWindowPos3ivMESA = dyn_glWindowPos3ivMESA ptr_glWindowPos3ivMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3ivMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos3iMESA #-}
 
ptr_glWindowPos3iMESA :: FunPtr a
ptr_glWindowPos3iMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3iMESA"
 
glWindowPos3iMESA :: GLint -> GLint -> GLint -> IO ()
glWindowPos3iMESA = dyn_glWindowPos3iMESA ptr_glWindowPos3iMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3iMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos3fvMESA #-}
 
ptr_glWindowPos3fvMESA :: FunPtr a
ptr_glWindowPos3fvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3fvMESA"
 
glWindowPos3fvMESA :: Ptr GLfloat -> IO ()
glWindowPos3fvMESA = dyn_glWindowPos3fvMESA ptr_glWindowPos3fvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3fvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos3fMESA #-}
 
ptr_glWindowPos3fMESA :: FunPtr a
ptr_glWindowPos3fMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3fMESA"
 
glWindowPos3fMESA :: GLfloat -> GLfloat -> GLfloat -> IO ()
glWindowPos3fMESA = dyn_glWindowPos3fMESA ptr_glWindowPos3fMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3fMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos3dvMESA #-}
 
ptr_glWindowPos3dvMESA :: FunPtr a
ptr_glWindowPos3dvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3dvMESA"
 
glWindowPos3dvMESA :: Ptr GLdouble -> IO ()
glWindowPos3dvMESA = dyn_glWindowPos3dvMESA ptr_glWindowPos3dvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3dvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glWindowPos3dMESA #-}
 
ptr_glWindowPos3dMESA :: FunPtr a
ptr_glWindowPos3dMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos3dMESA"
 
glWindowPos3dMESA :: GLdouble -> GLdouble -> GLdouble -> IO ()
glWindowPos3dMESA = dyn_glWindowPos3dMESA ptr_glWindowPos3dMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos3dMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> GLdouble -> IO ())
 
{-# NOINLINE ptr_glWindowPos2svMESA #-}
 
ptr_glWindowPos2svMESA :: FunPtr a
ptr_glWindowPos2svMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2svMESA"
 
glWindowPos2svMESA :: Ptr GLshort -> IO ()
glWindowPos2svMESA = dyn_glWindowPos2svMESA ptr_glWindowPos2svMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2svMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos2sMESA #-}
 
ptr_glWindowPos2sMESA :: FunPtr a
ptr_glWindowPos2sMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2sMESA"
 
glWindowPos2sMESA :: GLshort -> GLshort -> IO ()
glWindowPos2sMESA = dyn_glWindowPos2sMESA ptr_glWindowPos2sMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2sMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLshort -> GLshort -> IO ())
 
{-# NOINLINE ptr_glWindowPos2ivMESA #-}
 
ptr_glWindowPos2ivMESA :: FunPtr a
ptr_glWindowPos2ivMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2ivMESA"
 
glWindowPos2ivMESA :: Ptr GLint -> IO ()
glWindowPos2ivMESA = dyn_glWindowPos2ivMESA ptr_glWindowPos2ivMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2ivMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos2iMESA #-}
 
ptr_glWindowPos2iMESA :: FunPtr a
ptr_glWindowPos2iMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2iMESA"
 
glWindowPos2iMESA :: GLint -> GLint -> IO ()
glWindowPos2iMESA = dyn_glWindowPos2iMESA ptr_glWindowPos2iMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2iMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLint -> IO ())
 
{-# NOINLINE ptr_glWindowPos2fvMESA #-}
 
ptr_glWindowPos2fvMESA :: FunPtr a
ptr_glWindowPos2fvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2fvMESA"
 
glWindowPos2fvMESA :: Ptr GLfloat -> IO ()
glWindowPos2fvMESA = dyn_glWindowPos2fvMESA ptr_glWindowPos2fvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2fvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos2fMESA #-}
 
ptr_glWindowPos2fMESA :: FunPtr a
ptr_glWindowPos2fMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2fMESA"
 
glWindowPos2fMESA :: GLfloat -> GLfloat -> IO ()
glWindowPos2fMESA = dyn_glWindowPos2fMESA ptr_glWindowPos2fMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2fMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glWindowPos2dvMESA #-}
 
ptr_glWindowPos2dvMESA :: FunPtr a
ptr_glWindowPos2dvMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2dvMESA"
 
glWindowPos2dvMESA :: Ptr GLdouble -> IO ()
glWindowPos2dvMESA = dyn_glWindowPos2dvMESA ptr_glWindowPos2dvMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2dvMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glWindowPos2dMESA #-}
 
ptr_glWindowPos2dMESA :: FunPtr a
ptr_glWindowPos2dMESA
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_MESA_window_pos"
        "glWindowPos2dMESA"
 
glWindowPos2dMESA :: GLdouble -> GLdouble -> IO ()
glWindowPos2dMESA = dyn_glWindowPos2dMESA ptr_glWindowPos2dMESA
 
foreign import CALLCONV unsafe "dynamic" dyn_glWindowPos2dMESA ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLdouble -> GLdouble -> IO ())