{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.IBM.VertexArrayLists
       (glVertexPointerListIBM, glTexCoordPointerListIBM,
        glSecondaryColorPointerListIBM, glNormalPointerListIBM,
        glIndexPointerListIBM, glFogCoordPointerListIBM,
        glEdgeFlagPointerListIBM, glColorPointerListIBM,
        gl_VERTEX_ARRAY_LIST_STRIDE_IBM, gl_VERTEX_ARRAY_LIST_IBM,
        gl_TEXTURE_COORD_ARRAY_LIST_STRIDE_IBM,
        gl_TEXTURE_COORD_ARRAY_LIST_IBM,
        gl_SECONDARY_COLOR_ARRAY_LIST_STRIDE_IBM,
        gl_SECONDARY_COLOR_ARRAY_LIST_IBM, gl_NORMAL_ARRAY_LIST_STRIDE_IBM,
        gl_NORMAL_ARRAY_LIST_IBM, gl_INDEX_ARRAY_LIST_STRIDE_IBM,
        gl_INDEX_ARRAY_LIST_IBM, gl_FOG_COORDINATE_ARRAY_LIST_STRIDE_IBM,
        gl_FOG_COORDINATE_ARRAY_LIST_IBM,
        gl_EDGE_FLAG_ARRAY_LIST_STRIDE_IBM, gl_EDGE_FLAG_ARRAY_LIST_IBM,
        gl_COLOR_ARRAY_LIST_STRIDE_IBM, gl_COLOR_ARRAY_LIST_IBM)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glVertexPointerListIBM #-}
 
ptr_glVertexPointerListIBM :: FunPtr a
ptr_glVertexPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glVertexPointerListIBM"
 
glVertexPointerListIBM ::
                       GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glVertexPointerListIBM
  = dyn_glVertexPointerListIBM ptr_glVertexPointerListIBM
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexPointerListIBM
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glTexCoordPointerListIBM #-}
 
ptr_glTexCoordPointerListIBM :: FunPtr a
ptr_glTexCoordPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glTexCoordPointerListIBM"
 
glTexCoordPointerListIBM ::
                         GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glTexCoordPointerListIBM
  = dyn_glTexCoordPointerListIBM ptr_glTexCoordPointerListIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glTexCoordPointerListIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glSecondaryColorPointerListIBM #-}
 
ptr_glSecondaryColorPointerListIBM :: FunPtr a
ptr_glSecondaryColorPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glSecondaryColorPointerListIBM"
 
glSecondaryColorPointerListIBM ::
                               GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glSecondaryColorPointerListIBM
  = dyn_glSecondaryColorPointerListIBM
      ptr_glSecondaryColorPointerListIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glSecondaryColorPointerListIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glNormalPointerListIBM #-}
 
ptr_glNormalPointerListIBM :: FunPtr a
ptr_glNormalPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glNormalPointerListIBM"
 
glNormalPointerListIBM ::
                       GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glNormalPointerListIBM
  = dyn_glNormalPointerListIBM ptr_glNormalPointerListIBM
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalPointerListIBM
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glIndexPointerListIBM #-}
 
ptr_glIndexPointerListIBM :: FunPtr a
ptr_glIndexPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glIndexPointerListIBM"
 
glIndexPointerListIBM ::
                      GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glIndexPointerListIBM
  = dyn_glIndexPointerListIBM ptr_glIndexPointerListIBM
 
foreign import CALLCONV unsafe "dynamic" dyn_glIndexPointerListIBM
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glFogCoordPointerListIBM #-}
 
ptr_glFogCoordPointerListIBM :: FunPtr a
ptr_glFogCoordPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glFogCoordPointerListIBM"
 
glFogCoordPointerListIBM ::
                         GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glFogCoordPointerListIBM
  = dyn_glFogCoordPointerListIBM ptr_glFogCoordPointerListIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glFogCoordPointerListIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
{-# NOINLINE ptr_glEdgeFlagPointerListIBM #-}
 
ptr_glEdgeFlagPointerListIBM :: FunPtr a
ptr_glEdgeFlagPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glEdgeFlagPointerListIBM"
 
glEdgeFlagPointerListIBM ::
                         GLint -> Ptr (Ptr GLboolean) -> GLint -> IO ()
glEdgeFlagPointerListIBM
  = dyn_glEdgeFlagPointerListIBM ptr_glEdgeFlagPointerListIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glEdgeFlagPointerListIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> Ptr (Ptr GLboolean) -> GLint -> IO ())
 
{-# NOINLINE ptr_glColorPointerListIBM #-}
 
ptr_glColorPointerListIBM :: FunPtr a
ptr_glColorPointerListIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_vertex_array_lists"
        "glColorPointerListIBM"
 
glColorPointerListIBM ::
                      GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ()
glColorPointerListIBM
  = dyn_glColorPointerListIBM ptr_glColorPointerListIBM
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorPointerListIBM
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLint -> GLenum -> GLint -> Ptr (Ptr a) -> GLint -> IO ())
 
gl_VERTEX_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_VERTEX_ARRAY_LIST_STRIDE_IBM = 103080
 
gl_VERTEX_ARRAY_LIST_IBM :: GLenum
gl_VERTEX_ARRAY_LIST_IBM = 103070
 
gl_TEXTURE_COORD_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_TEXTURE_COORD_ARRAY_LIST_STRIDE_IBM = 103084
 
gl_TEXTURE_COORD_ARRAY_LIST_IBM :: GLenum
gl_TEXTURE_COORD_ARRAY_LIST_IBM = 103074
 
gl_SECONDARY_COLOR_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_SECONDARY_COLOR_ARRAY_LIST_STRIDE_IBM = 103087
 
gl_SECONDARY_COLOR_ARRAY_LIST_IBM :: GLenum
gl_SECONDARY_COLOR_ARRAY_LIST_IBM = 103077
 
gl_NORMAL_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_NORMAL_ARRAY_LIST_STRIDE_IBM = 103081
 
gl_NORMAL_ARRAY_LIST_IBM :: GLenum
gl_NORMAL_ARRAY_LIST_IBM = 103071
 
gl_INDEX_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_INDEX_ARRAY_LIST_STRIDE_IBM = 103083
 
gl_INDEX_ARRAY_LIST_IBM :: GLenum
gl_INDEX_ARRAY_LIST_IBM = 103073
 
gl_FOG_COORDINATE_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_FOG_COORDINATE_ARRAY_LIST_STRIDE_IBM = 103086
 
gl_FOG_COORDINATE_ARRAY_LIST_IBM :: GLenum
gl_FOG_COORDINATE_ARRAY_LIST_IBM = 103076
 
gl_EDGE_FLAG_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_EDGE_FLAG_ARRAY_LIST_STRIDE_IBM = 103085
 
gl_EDGE_FLAG_ARRAY_LIST_IBM :: GLenum
gl_EDGE_FLAG_ARRAY_LIST_IBM = 103075
 
gl_COLOR_ARRAY_LIST_STRIDE_IBM :: GLenum
gl_COLOR_ARRAY_LIST_STRIDE_IBM = 103082
 
gl_COLOR_ARRAY_LIST_IBM :: GLenum
gl_COLOR_ARRAY_LIST_IBM = 103072