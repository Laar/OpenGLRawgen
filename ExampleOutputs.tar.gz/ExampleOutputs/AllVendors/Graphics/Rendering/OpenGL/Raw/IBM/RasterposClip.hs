module Graphics.Rendering.OpenGL.Raw.IBM.RasterposClip
       (gl_RASTER_POSITION_UNCLIPPED_IBM) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_RASTER_POSITION_UNCLIPPED_IBM :: GLenum
gl_RASTER_POSITION_UNCLIPPED_IBM = 103010