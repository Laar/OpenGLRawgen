module Graphics.Rendering.OpenGL.Raw.IBM.CullVertex
       (gl_CULL_VERTEX_IBM) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_CULL_VERTEX_IBM :: GLenum
gl_CULL_VERTEX_IBM = 103050