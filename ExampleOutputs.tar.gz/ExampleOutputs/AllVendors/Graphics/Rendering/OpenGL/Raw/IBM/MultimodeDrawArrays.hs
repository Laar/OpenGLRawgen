{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.IBM.MultimodeDrawArrays
       (glMultiModeDrawElementsIBM, glMultiModeDrawArraysIBM) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glMultiModeDrawElementsIBM #-}
 
ptr_glMultiModeDrawElementsIBM :: FunPtr a
ptr_glMultiModeDrawElementsIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_multimode_draw_arrays"
        "glMultiModeDrawElementsIBM"
 
glMultiModeDrawElementsIBM ::
                           Ptr GLenum ->
                             Ptr GLsizei -> GLenum -> Ptr (Ptr b) -> GLsizei -> GLint -> IO ()
glMultiModeDrawElementsIBM
  = dyn_glMultiModeDrawElementsIBM ptr_glMultiModeDrawElementsIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiModeDrawElementsIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLenum ->
                    Ptr GLsizei -> GLenum -> Ptr (Ptr b) -> GLsizei -> GLint -> IO ())
 
{-# NOINLINE ptr_glMultiModeDrawArraysIBM #-}
 
ptr_glMultiModeDrawArraysIBM :: FunPtr a
ptr_glMultiModeDrawArraysIBM
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_IBM_multimode_draw_arrays"
        "glMultiModeDrawArraysIBM"
 
glMultiModeDrawArraysIBM ::
                         Ptr GLenum -> Ptr GLint -> Ptr GLsizei -> GLsizei -> GLint -> IO ()
glMultiModeDrawArraysIBM
  = dyn_glMultiModeDrawArraysIBM ptr_glMultiModeDrawArraysIBM
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glMultiModeDrawArraysIBM ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (Ptr GLenum ->
                    Ptr GLint -> Ptr GLsizei -> GLsizei -> GLint -> IO ())