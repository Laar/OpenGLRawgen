module Graphics.Rendering.OpenGL.Raw.IBM.TextureMirroredRepeat
       (gl_MIRRORED_REPEAT_IBM) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_MIRRORED_REPEAT_IBM :: GLenum
gl_MIRRORED_REPEAT_IBM = 33648