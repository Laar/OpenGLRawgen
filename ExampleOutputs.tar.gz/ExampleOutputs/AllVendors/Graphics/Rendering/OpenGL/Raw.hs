module Graphics.Rendering.OpenGL.Raw
       (module Graphics.Rendering.OpenGL.Raw.Core.Core42) where
import Graphics.Rendering.OpenGL.Raw.Core.Core42