{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.GetProgramBinary
       (glProgramParameteri, glProgramBinary, glGetProgramBinary,
        gl_PROGRAM_BINARY_RETRIEVABLE_HINT, gl_PROGRAM_BINARY_LENGTH,
        gl_PROGRAM_BINARY_FORMATS, gl_NUM_PROGRAM_BINARY_FORMATS)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_PROGRAM_BINARY_RETRIEVABLE_HINT, gl_PROGRAM_BINARY_LENGTH,
        gl_PROGRAM_BINARY_FORMATS, gl_NUM_PROGRAM_BINARY_FORMATS)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glProgramParameteri #-}
 
ptr_glProgramParameteri :: FunPtr a
ptr_glProgramParameteri
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_get_program_binary"
        "glProgramParameteri"
 
glProgramParameteri :: GLuint -> GLenum -> GLint -> IO ()
glProgramParameteri
  = dyn_glProgramParameteri ptr_glProgramParameteri
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramParameteri ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLint -> IO ())
 
{-# NOINLINE ptr_glProgramBinary #-}
 
ptr_glProgramBinary :: FunPtr a
ptr_glProgramBinary
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_get_program_binary"
        "glProgramBinary"
 
glProgramBinary :: GLuint -> GLenum -> Ptr a -> GLsizei -> IO ()
glProgramBinary = dyn_glProgramBinary ptr_glProgramBinary
 
foreign import CALLCONV unsafe "dynamic" dyn_glProgramBinary ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr a -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glGetProgramBinary #-}
 
ptr_glGetProgramBinary :: FunPtr a
ptr_glGetProgramBinary
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_get_program_binary"
        "glGetProgramBinary"
 
glGetProgramBinary ::
                   GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr a -> IO ()
glGetProgramBinary = dyn_glGetProgramBinary ptr_glGetProgramBinary
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramBinary ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLenum -> Ptr a -> IO ())