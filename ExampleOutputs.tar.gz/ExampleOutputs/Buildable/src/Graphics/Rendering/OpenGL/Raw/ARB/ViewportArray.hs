{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ViewportArray
       (glViewportIndexedfv, glViewportIndexedf, glViewportArrayv,
        glScissorIndexedv, glScissorIndexed, glScissorArrayv,
        glGetFloati_v, glGetDoublei_v, glDepthRangeIndexed,
        glDepthRangeArrayv, gl_VIEWPORT_SUBPIXEL_BITS,
        gl_VIEWPORT_INDEX_PROVOKING_VERTEX, gl_VIEWPORT_BOUNDS_RANGE,
        gl_VIEWPORT, gl_UNDEFINED_VERTEX, gl_SCISSOR_TEST, gl_SCISSOR_BOX,
        gl_PROVOKING_VERTEX, gl_MAX_VIEWPORTS, gl_LAYER_PROVOKING_VERTEX,
        gl_LAST_VERTEX_CONVENTION, gl_FIRST_VERTEX_CONVENTION,
        gl_DEPTH_RANGE)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core11
       (gl_VIEWPORT, gl_SCISSOR_TEST, gl_SCISSOR_BOX, gl_DEPTH_RANGE)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core32
       (gl_PROVOKING_VERTEX, gl_LAST_VERTEX_CONVENTION,
        gl_FIRST_VERTEX_CONVENTION)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core41
       (gl_VIEWPORT_SUBPIXEL_BITS, gl_VIEWPORT_INDEX_PROVOKING_VERTEX,
        gl_VIEWPORT_BOUNDS_RANGE, gl_UNDEFINED_VERTEX, gl_MAX_VIEWPORTS,
        gl_LAYER_PROVOKING_VERTEX)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glViewportIndexedfv #-}
 
ptr_glViewportIndexedfv :: FunPtr a
ptr_glViewportIndexedfv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glViewportIndexedfv"
 
glViewportIndexedfv :: GLuint -> Ptr GLfloat -> IO ()
glViewportIndexedfv
  = dyn_glViewportIndexedfv ptr_glViewportIndexedfv
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportIndexedfv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glViewportIndexedf #-}
 
ptr_glViewportIndexedf :: FunPtr a
ptr_glViewportIndexedf
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glViewportIndexedf"
 
glViewportIndexedf ::
                   GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ()
glViewportIndexedf = dyn_glViewportIndexedf ptr_glViewportIndexedf
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportIndexedf ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLfloat -> GLfloat -> GLfloat -> GLfloat -> IO ())
 
{-# NOINLINE ptr_glViewportArrayv #-}
 
ptr_glViewportArrayv :: FunPtr a
ptr_glViewportArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glViewportArrayv"
 
glViewportArrayv :: GLuint -> GLsizei -> Ptr GLfloat -> IO ()
glViewportArrayv = dyn_glViewportArrayv ptr_glViewportArrayv
 
foreign import CALLCONV unsafe "dynamic" dyn_glViewportArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glScissorIndexedv #-}
 
ptr_glScissorIndexedv :: FunPtr a
ptr_glScissorIndexedv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glScissorIndexedv"
 
glScissorIndexedv :: GLuint -> Ptr GLint -> IO ()
glScissorIndexedv = dyn_glScissorIndexedv ptr_glScissorIndexedv
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorIndexedv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glScissorIndexed #-}
 
ptr_glScissorIndexed :: FunPtr a
ptr_glScissorIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glScissorIndexed"
 
glScissorIndexed ::
                 GLuint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ()
glScissorIndexed = dyn_glScissorIndexed ptr_glScissorIndexed
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLint -> GLint -> GLsizei -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glScissorArrayv #-}
 
ptr_glScissorArrayv :: FunPtr a
ptr_glScissorArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glScissorArrayv"
 
glScissorArrayv :: GLuint -> GLsizei -> Ptr GLint -> IO ()
glScissorArrayv = dyn_glScissorArrayv ptr_glScissorArrayv
 
foreign import CALLCONV unsafe "dynamic" dyn_glScissorArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetFloati_v #-}
 
ptr_glGetFloati_v :: FunPtr a
ptr_glGetFloati_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glGetFloati_v"
 
glGetFloati_v :: GLenum -> GLuint -> Ptr GLfloat -> IO ()
glGetFloati_v = dyn_glGetFloati_v ptr_glGetFloati_v
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFloati_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLfloat -> IO ())
 
{-# NOINLINE ptr_glGetDoublei_v #-}
 
ptr_glGetDoublei_v :: FunPtr a
ptr_glGetDoublei_v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glGetDoublei_v"
 
glGetDoublei_v :: GLenum -> GLuint -> Ptr GLdouble -> IO ()
glGetDoublei_v = dyn_glGetDoublei_v ptr_glGetDoublei_v
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetDoublei_v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> Ptr GLdouble -> IO ())
 
{-# NOINLINE ptr_glDepthRangeIndexed #-}
 
ptr_glDepthRangeIndexed :: FunPtr a
ptr_glDepthRangeIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glDepthRangeIndexed"
 
glDepthRangeIndexed :: GLuint -> GLclampd -> GLclampd -> IO ()
glDepthRangeIndexed
  = dyn_glDepthRangeIndexed ptr_glDepthRangeIndexed
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangeIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLclampd -> GLclampd -> IO ())
 
{-# NOINLINE ptr_glDepthRangeArrayv #-}
 
ptr_glDepthRangeArrayv :: FunPtr a
ptr_glDepthRangeArrayv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_viewport_array"
        "glDepthRangeArrayv"
 
glDepthRangeArrayv :: GLuint -> GLsizei -> Ptr GLclampd -> IO ()
glDepthRangeArrayv = dyn_glDepthRangeArrayv ptr_glDepthRangeArrayv
 
foreign import CALLCONV unsafe "dynamic" dyn_glDepthRangeArrayv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLsizei -> Ptr GLclampd -> IO ())