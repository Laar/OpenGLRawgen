{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ShaderImageLoadStore
       (glMemoryBarrier, glBindImageTexture,
        gl_VERTEX_ATTRIB_ARRAY_BARRIER_BIT,
        gl_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY, gl_UNSIGNED_INT_IMAGE_CUBE,
        gl_UNSIGNED_INT_IMAGE_BUFFER, gl_UNSIGNED_INT_IMAGE_3D,
        gl_UNSIGNED_INT_IMAGE_2D_RECT,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_IMAGE_2D_ARRAY, gl_UNSIGNED_INT_IMAGE_2D,
        gl_UNSIGNED_INT_IMAGE_1D_ARRAY, gl_UNSIGNED_INT_IMAGE_1D,
        gl_UNIFORM_BARRIER_BIT, gl_TRANSFORM_FEEDBACK_BARRIER_BIT,
        gl_TEXTURE_UPDATE_BARRIER_BIT, gl_TEXTURE_FETCH_BARRIER_BIT,
        gl_SHADER_IMAGE_ACCESS_BARRIER_BIT, gl_PIXEL_BUFFER_BARRIER_BIT,
        gl_MAX_VERTEX_IMAGE_UNIFORMS,
        gl_MAX_TESS_EVALUATION_IMAGE_UNIFORMS,
        gl_MAX_TESS_CONTROL_IMAGE_UNIFORMS, gl_MAX_IMAGE_UNITS,
        gl_MAX_IMAGE_SAMPLES, gl_MAX_GEOMETRY_IMAGE_UNIFORMS,
        gl_MAX_FRAGMENT_IMAGE_UNIFORMS,
        gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS,
        gl_MAX_COMBINED_IMAGE_UNIFORMS, gl_INT_IMAGE_CUBE_MAP_ARRAY,
        gl_INT_IMAGE_CUBE, gl_INT_IMAGE_BUFFER, gl_INT_IMAGE_3D,
        gl_INT_IMAGE_2D_RECT, gl_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_INT_IMAGE_2D_MULTISAMPLE, gl_INT_IMAGE_2D_ARRAY,
        gl_INT_IMAGE_2D, gl_INT_IMAGE_1D_ARRAY, gl_INT_IMAGE_1D,
        gl_IMAGE_FORMAT_COMPATIBILITY_TYPE,
        gl_IMAGE_FORMAT_COMPATIBILITY_BY_SIZE,
        gl_IMAGE_FORMAT_COMPATIBILITY_BY_CLASS, gl_IMAGE_CUBE_MAP_ARRAY,
        gl_IMAGE_CUBE, gl_IMAGE_BUFFER, gl_IMAGE_BINDING_NAME,
        gl_IMAGE_BINDING_LEVEL, gl_IMAGE_BINDING_LAYERED,
        gl_IMAGE_BINDING_LAYER, gl_IMAGE_BINDING_FORMAT,
        gl_IMAGE_BINDING_ACCESS, gl_IMAGE_3D, gl_IMAGE_2D_RECT,
        gl_IMAGE_2D_MULTISAMPLE_ARRAY, gl_IMAGE_2D_MULTISAMPLE,
        gl_IMAGE_2D_ARRAY, gl_IMAGE_2D, gl_IMAGE_1D_ARRAY, gl_IMAGE_1D,
        gl_FRAMEBUFFER_BARRIER_BIT, gl_ELEMENT_ARRAY_BARRIER_BIT,
        gl_COMMAND_BARRIER_BIT, gl_BUFFER_UPDATE_BARRIER_BIT,
        gl_ATOMIC_COUNTER_BARRIER_BIT, gl_ALL_BARRIER_BITS)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_VERTEX_ATTRIB_ARRAY_BARRIER_BIT,
        gl_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY, gl_UNSIGNED_INT_IMAGE_CUBE,
        gl_UNSIGNED_INT_IMAGE_BUFFER, gl_UNSIGNED_INT_IMAGE_3D,
        gl_UNSIGNED_INT_IMAGE_2D_RECT,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE,
        gl_UNSIGNED_INT_IMAGE_2D_ARRAY, gl_UNSIGNED_INT_IMAGE_2D,
        gl_UNSIGNED_INT_IMAGE_1D_ARRAY, gl_UNSIGNED_INT_IMAGE_1D,
        gl_UNIFORM_BARRIER_BIT, gl_TRANSFORM_FEEDBACK_BARRIER_BIT,
        gl_TEXTURE_UPDATE_BARRIER_BIT, gl_TEXTURE_FETCH_BARRIER_BIT,
        gl_SHADER_IMAGE_ACCESS_BARRIER_BIT, gl_PIXEL_BUFFER_BARRIER_BIT,
        gl_MAX_VERTEX_IMAGE_UNIFORMS,
        gl_MAX_TESS_EVALUATION_IMAGE_UNIFORMS,
        gl_MAX_TESS_CONTROL_IMAGE_UNIFORMS, gl_MAX_IMAGE_UNITS,
        gl_MAX_IMAGE_SAMPLES, gl_MAX_GEOMETRY_IMAGE_UNIFORMS,
        gl_MAX_FRAGMENT_IMAGE_UNIFORMS,
        gl_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS,
        gl_MAX_COMBINED_IMAGE_UNIFORMS, gl_INT_IMAGE_CUBE_MAP_ARRAY,
        gl_INT_IMAGE_CUBE, gl_INT_IMAGE_BUFFER, gl_INT_IMAGE_3D,
        gl_INT_IMAGE_2D_RECT, gl_INT_IMAGE_2D_MULTISAMPLE_ARRAY,
        gl_INT_IMAGE_2D_MULTISAMPLE, gl_INT_IMAGE_2D_ARRAY,
        gl_INT_IMAGE_2D, gl_INT_IMAGE_1D_ARRAY, gl_INT_IMAGE_1D,
        gl_IMAGE_FORMAT_COMPATIBILITY_TYPE,
        gl_IMAGE_FORMAT_COMPATIBILITY_BY_SIZE,
        gl_IMAGE_FORMAT_COMPATIBILITY_BY_CLASS, gl_IMAGE_CUBE_MAP_ARRAY,
        gl_IMAGE_CUBE, gl_IMAGE_BUFFER, gl_IMAGE_BINDING_NAME,
        gl_IMAGE_BINDING_LEVEL, gl_IMAGE_BINDING_LAYERED,
        gl_IMAGE_BINDING_LAYER, gl_IMAGE_BINDING_FORMAT,
        gl_IMAGE_BINDING_ACCESS, gl_IMAGE_3D, gl_IMAGE_2D_RECT,
        gl_IMAGE_2D_MULTISAMPLE_ARRAY, gl_IMAGE_2D_MULTISAMPLE,
        gl_IMAGE_2D_ARRAY, gl_IMAGE_2D, gl_IMAGE_1D_ARRAY, gl_IMAGE_1D,
        gl_FRAMEBUFFER_BARRIER_BIT, gl_ELEMENT_ARRAY_BARRIER_BIT,
        gl_COMMAND_BARRIER_BIT, gl_BUFFER_UPDATE_BARRIER_BIT,
        gl_ATOMIC_COUNTER_BARRIER_BIT, gl_ALL_BARRIER_BITS)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glMemoryBarrier #-}
 
ptr_glMemoryBarrier :: FunPtr a
ptr_glMemoryBarrier
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_image_load_store"
        "glMemoryBarrier"
 
glMemoryBarrier :: GLbitfield -> IO ()
glMemoryBarrier = dyn_glMemoryBarrier ptr_glMemoryBarrier
 
foreign import CALLCONV unsafe "dynamic" dyn_glMemoryBarrier ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLbitfield -> IO ())
 
{-# NOINLINE ptr_glBindImageTexture #-}
 
ptr_glBindImageTexture :: FunPtr a
ptr_glBindImageTexture
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_image_load_store"
        "glBindImageTexture"
 
glBindImageTexture ::
                   GLuint ->
                     GLuint -> GLint -> GLboolean -> GLint -> GLenum -> GLenum -> IO ()
glBindImageTexture = dyn_glBindImageTexture ptr_glBindImageTexture
 
foreign import CALLCONV unsafe "dynamic" dyn_glBindImageTexture ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLuint -> GLint -> GLboolean -> GLint -> GLenum -> GLenum -> IO ())