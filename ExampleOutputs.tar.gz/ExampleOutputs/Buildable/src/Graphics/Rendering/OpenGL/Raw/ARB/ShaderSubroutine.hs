{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.ShaderSubroutine
       (glUniformSubroutinesuiv, glGetUniformSubroutineuiv,
        glGetSubroutineUniformLocation, glGetSubroutineIndex,
        glGetProgramStageiv, glGetActiveSubroutineUniformiv,
        glGetActiveSubroutineUniformName, glGetActiveSubroutineName,
        gl_UNIFORM_SIZE, gl_UNIFORM_NAME_LENGTH,
        gl_NUM_COMPATIBLE_SUBROUTINES, gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_MAX_SUBROUTINES, gl_COMPATIBLE_SUBROUTINES,
        gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_ACTIVE_SUBROUTINE_UNIFORMS, gl_ACTIVE_SUBROUTINE_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINES)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_NUM_COMPATIBLE_SUBROUTINES,
        gl_MAX_SUBROUTINE_UNIFORM_LOCATIONS, gl_MAX_SUBROUTINES,
        gl_COMPATIBLE_SUBROUTINES, gl_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS,
        gl_ACTIVE_SUBROUTINE_UNIFORMS, gl_ACTIVE_SUBROUTINE_MAX_LENGTH,
        gl_ACTIVE_SUBROUTINES)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_UNIFORM_SIZE, gl_UNIFORM_NAME_LENGTH)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glUniformSubroutinesuiv #-}
 
ptr_glUniformSubroutinesuiv :: FunPtr a
ptr_glUniformSubroutinesuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glUniformSubroutinesuiv"
 
glUniformSubroutinesuiv :: GLenum -> GLsizei -> Ptr GLuint -> IO ()
glUniformSubroutinesuiv
  = dyn_glUniformSubroutinesuiv ptr_glUniformSubroutinesuiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glUniformSubroutinesuiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glGetUniformSubroutineuiv #-}
 
ptr_glGetUniformSubroutineuiv :: FunPtr a
ptr_glGetUniformSubroutineuiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetUniformSubroutineuiv"
 
glGetUniformSubroutineuiv :: GLenum -> GLint -> Ptr GLuint -> IO ()
glGetUniformSubroutineuiv
  = dyn_glGetUniformSubroutineuiv ptr_glGetUniformSubroutineuiv
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetUniformSubroutineuiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glGetSubroutineUniformLocation #-}
 
ptr_glGetSubroutineUniformLocation :: FunPtr a
ptr_glGetSubroutineUniformLocation
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetSubroutineUniformLocation"
 
glGetSubroutineUniformLocation ::
                               GLuint -> GLenum -> Ptr GLchar -> IO GLint
glGetSubroutineUniformLocation
  = dyn_glGetSubroutineUniformLocation
      ptr_glGetSubroutineUniformLocation
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetSubroutineUniformLocation ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLchar -> IO GLint)
 
{-# NOINLINE ptr_glGetSubroutineIndex #-}
 
ptr_glGetSubroutineIndex :: FunPtr a
ptr_glGetSubroutineIndex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetSubroutineIndex"
 
glGetSubroutineIndex :: GLuint -> GLenum -> Ptr GLchar -> IO GLuint
glGetSubroutineIndex
  = dyn_glGetSubroutineIndex ptr_glGetSubroutineIndex
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetSubroutineIndex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLchar -> IO GLuint)
 
{-# NOINLINE ptr_glGetProgramStageiv #-}
 
ptr_glGetProgramStageiv :: FunPtr a
ptr_glGetProgramStageiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetProgramStageiv"
 
glGetProgramStageiv ::
                    GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ()
glGetProgramStageiv
  = dyn_glGetProgramStageiv ptr_glGetProgramStageiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetProgramStageiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetActiveSubroutineUniformiv #-}
 
ptr_glGetActiveSubroutineUniformiv :: FunPtr a
ptr_glGetActiveSubroutineUniformiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetActiveSubroutineUniformiv"
 
glGetActiveSubroutineUniformiv ::
                               GLuint -> GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ()
glGetActiveSubroutineUniformiv
  = dyn_glGetActiveSubroutineUniformiv
      ptr_glGetActiveSubroutineUniformiv
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetActiveSubroutineUniformiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLuint -> GLenum -> Ptr GLint -> IO ())
 
{-# NOINLINE ptr_glGetActiveSubroutineUniformName #-}
 
ptr_glGetActiveSubroutineUniformName :: FunPtr a
ptr_glGetActiveSubroutineUniformName
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetActiveSubroutineUniformName"
 
glGetActiveSubroutineUniformName ::
                                 GLuint ->
                                   GLenum -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetActiveSubroutineUniformName
  = dyn_glGetActiveSubroutineUniformName
      ptr_glGetActiveSubroutineUniformName
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetActiveSubroutineUniformName ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())
 
{-# NOINLINE ptr_glGetActiveSubroutineName #-}
 
ptr_glGetActiveSubroutineName :: FunPtr a
ptr_glGetActiveSubroutineName
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_shader_subroutine"
        "glGetActiveSubroutineName"
 
glGetActiveSubroutineName ::
                          GLuint ->
                            GLenum -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ()
glGetActiveSubroutineName
  = dyn_glGetActiveSubroutineName ptr_glGetActiveSubroutineName
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glGetActiveSubroutineName ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLuint -> GLsizei -> Ptr GLsizei -> Ptr GLchar -> IO ())