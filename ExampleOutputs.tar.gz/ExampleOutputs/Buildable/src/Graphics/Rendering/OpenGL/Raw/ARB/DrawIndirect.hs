{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.DrawIndirect
       (glDrawElementsIndirect, glDrawArraysIndirect,
        gl_DRAW_INDIRECT_BUFFER_BINDING, gl_DRAW_INDIRECT_BUFFER)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core40
       (gl_DRAW_INDIRECT_BUFFER_BINDING, gl_DRAW_INDIRECT_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glDrawElementsIndirect #-}
 
ptr_glDrawElementsIndirect :: FunPtr a
ptr_glDrawElementsIndirect
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_indirect"
        "glDrawElementsIndirect"
 
glDrawElementsIndirect :: GLenum -> GLenum -> Ptr a -> IO ()
glDrawElementsIndirect
  = dyn_glDrawElementsIndirect ptr_glDrawElementsIndirect
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawElementsIndirect
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr a -> IO ())
 
{-# NOINLINE ptr_glDrawArraysIndirect #-}
 
ptr_glDrawArraysIndirect :: FunPtr a
ptr_glDrawArraysIndirect
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_draw_indirect"
        "glDrawArraysIndirect"
 
glDrawArraysIndirect :: GLenum -> Ptr a -> IO ()
glDrawArraysIndirect
  = dyn_glDrawArraysIndirect ptr_glDrawArraysIndirect
 
foreign import CALLCONV unsafe "dynamic" dyn_glDrawArraysIndirect ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr a -> IO ())