{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.CopyBuffer
       (glCopyBufferSubData, gl_COPY_WRITE_BUFFER, gl_COPY_READ_BUFFER)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core31
       (gl_COPY_WRITE_BUFFER, gl_COPY_READ_BUFFER)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glCopyBufferSubData #-}
 
ptr_glCopyBufferSubData :: FunPtr a
ptr_glCopyBufferSubData
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_copy_buffer"
        "glCopyBufferSubData"
 
glCopyBufferSubData ::
                    GLenum -> GLenum -> GLintptr -> GLintptr -> GLsizeiptr -> IO ()
glCopyBufferSubData
  = dyn_glCopyBufferSubData ptr_glCopyBufferSubData
 
foreign import CALLCONV unsafe "dynamic" dyn_glCopyBufferSubData ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLintptr -> GLintptr -> GLsizeiptr -> IO ())