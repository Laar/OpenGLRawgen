module Graphics.Rendering.OpenGL.Raw.Core31
       (module Graphics.Rendering.OpenGL.Raw.Core.Core31) where
import Graphics.Rendering.OpenGL.Raw.Core.Core31