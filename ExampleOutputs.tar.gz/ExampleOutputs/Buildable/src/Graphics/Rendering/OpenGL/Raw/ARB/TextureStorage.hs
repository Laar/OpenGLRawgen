{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TextureStorage
       (glTextureStorage3DEXT, glTextureStorage2DEXT,
        glTextureStorage1DEXT, glTexStorage3D, glTexStorage2D,
        glTexStorage1D, gl_TEXTURE_IMMUTABLE_FORMAT)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core42
       (gl_TEXTURE_IMMUTABLE_FORMAT)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glTextureStorage3DEXT #-}
 
ptr_glTextureStorage3DEXT :: FunPtr a
ptr_glTextureStorage3DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTextureStorage3DEXT"
 
glTextureStorage3DEXT ::
                      GLuint ->
                        GLenum ->
                          GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ()
glTextureStorage3DEXT
  = dyn_glTextureStorage3DEXT ptr_glTextureStorage3DEXT
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage3DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum ->
                      GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glTextureStorage2DEXT #-}
 
ptr_glTextureStorage2DEXT :: FunPtr a
ptr_glTextureStorage2DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTextureStorage2DEXT"
 
glTextureStorage2DEXT ::
                      GLuint ->
                        GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glTextureStorage2DEXT
  = dyn_glTextureStorage2DEXT ptr_glTextureStorage2DEXT
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage2DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint ->
                    GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glTextureStorage1DEXT #-}
 
ptr_glTextureStorage1DEXT :: FunPtr a
ptr_glTextureStorage1DEXT
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTextureStorage1DEXT"
 
glTextureStorage1DEXT ::
                      GLuint -> GLenum -> GLsizei -> GLenum -> GLsizei -> IO ()
glTextureStorage1DEXT
  = dyn_glTextureStorage1DEXT ptr_glTextureStorage1DEXT
 
foreign import CALLCONV unsafe "dynamic" dyn_glTextureStorage1DEXT
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLsizei -> GLenum -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glTexStorage3D #-}
 
ptr_glTexStorage3D :: FunPtr a
ptr_glTexStorage3D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTexStorage3D"
 
glTexStorage3D ::
               GLenum ->
                 GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ()
glTexStorage3D = dyn_glTexStorage3D ptr_glTexStorage3D
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexStorage3D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei -> GLenum -> GLsizei -> GLsizei -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glTexStorage2D #-}
 
ptr_glTexStorage2D :: FunPtr a
ptr_glTexStorage2D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTexStorage2D"
 
glTexStorage2D ::
               GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ()
glTexStorage2D = dyn_glTexStorage2D ptr_glTexStorage2D
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexStorage2D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> GLsizei -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glTexStorage1D #-}
 
ptr_glTexStorage1D :: FunPtr a
ptr_glTexStorage1D
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_texture_storage"
        "glTexStorage1D"
 
glTexStorage1D :: GLenum -> GLsizei -> GLenum -> GLsizei -> IO ()
glTexStorage1D = dyn_glTexStorage1D ptr_glTexStorage1D
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexStorage1D ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLsizei -> GLenum -> GLsizei -> IO ())