{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.BaseInstance
       (glDrawElementsInstancedBaseVertexBaseInstance,
        glDrawElementsInstancedBaseInstance,
        glDrawArraysInstancedBaseInstance)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glDrawElementsInstancedBaseVertexBaseInstance #-}
 
ptr_glDrawElementsInstancedBaseVertexBaseInstance :: FunPtr a
ptr_glDrawElementsInstancedBaseVertexBaseInstance
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_base_instance"
        "glDrawElementsInstancedBaseVertexBaseInstance"
 
glDrawElementsInstancedBaseVertexBaseInstance ::
                                              GLenum ->
                                                GLsizei ->
                                                  GLenum ->
                                                    Ptr (Ptr a) ->
                                                      GLsizei -> GLint -> GLuint -> IO ()
glDrawElementsInstancedBaseVertexBaseInstance
  = dyn_glDrawElementsInstancedBaseVertexBaseInstance
      ptr_glDrawElementsInstancedBaseVertexBaseInstance
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawElementsInstancedBaseVertexBaseInstance ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei ->
                      GLenum -> Ptr (Ptr a) -> GLsizei -> GLint -> GLuint -> IO ())
 
{-# NOINLINE ptr_glDrawElementsInstancedBaseInstance #-}
 
ptr_glDrawElementsInstancedBaseInstance :: FunPtr a
ptr_glDrawElementsInstancedBaseInstance
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_base_instance"
        "glDrawElementsInstancedBaseInstance"
 
glDrawElementsInstancedBaseInstance ::
                                    GLenum ->
                                      GLsizei -> GLenum -> Ptr (Ptr a) -> GLsizei -> GLuint -> IO ()
glDrawElementsInstancedBaseInstance
  = dyn_glDrawElementsInstancedBaseInstance
      ptr_glDrawElementsInstancedBaseInstance
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawElementsInstancedBaseInstance ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum ->
                    GLsizei -> GLenum -> Ptr (Ptr a) -> GLsizei -> GLuint -> IO ())
 
{-# NOINLINE ptr_glDrawArraysInstancedBaseInstance #-}
 
ptr_glDrawArraysInstancedBaseInstance :: FunPtr a
ptr_glDrawArraysInstancedBaseInstance
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_base_instance"
        "glDrawArraysInstancedBaseInstance"
 
glDrawArraysInstancedBaseInstance ::
                                  GLenum -> GLint -> GLsizei -> GLsizei -> GLuint -> IO ()
glDrawArraysInstancedBaseInstance
  = dyn_glDrawArraysInstancedBaseInstance
      ptr_glDrawArraysInstancedBaseInstance
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawArraysInstancedBaseInstance ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLint -> GLsizei -> GLsizei -> GLuint -> IO ())