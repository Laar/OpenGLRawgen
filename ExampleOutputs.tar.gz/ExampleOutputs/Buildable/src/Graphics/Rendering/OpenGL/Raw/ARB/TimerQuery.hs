{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TimerQuery
       (glQueryCounter, glGetQueryObjectui64v, glGetQueryObjecti64v,
        gl_TIME_ELAPSED, gl_TIMESTAMP)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_TIME_ELAPSED, gl_TIMESTAMP)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glQueryCounter #-}
 
ptr_glQueryCounter :: FunPtr a
ptr_glQueryCounter
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_timer_query"
        "glQueryCounter"
 
glQueryCounter :: GLuint -> GLenum -> IO ()
glQueryCounter = dyn_glQueryCounter ptr_glQueryCounter
 
foreign import CALLCONV unsafe "dynamic" dyn_glQueryCounter ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> IO ())
 
{-# NOINLINE ptr_glGetQueryObjectui64v #-}
 
ptr_glGetQueryObjectui64v :: FunPtr a
ptr_glGetQueryObjectui64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_timer_query"
        "glGetQueryObjectui64v"
 
glGetQueryObjectui64v :: GLuint -> GLenum -> Ptr GLuint64 -> IO ()
glGetQueryObjectui64v
  = dyn_glGetQueryObjectui64v ptr_glGetQueryObjectui64v
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjectui64v
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLuint64 -> IO ())
 
{-# NOINLINE ptr_glGetQueryObjecti64v #-}
 
ptr_glGetQueryObjecti64v :: FunPtr a
ptr_glGetQueryObjecti64v
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_timer_query"
        "glGetQueryObjecti64v"
 
glGetQueryObjecti64v :: GLuint -> GLenum -> Ptr GLint64 -> IO ()
glGetQueryObjecti64v
  = dyn_glGetQueryObjecti64v ptr_glGetQueryObjecti64v
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetQueryObjecti64v ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> Ptr GLint64 -> IO ())