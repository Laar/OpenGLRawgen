module Graphics.Rendering.OpenGL.Raw.NV.CopyDepthToColor
       (gl_DEPTH_STENCIL_TO_RGBA_NV, gl_DEPTH_STENCIL_TO_BGRA_NV) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_DEPTH_STENCIL_TO_RGBA_NV :: GLenum
gl_DEPTH_STENCIL_TO_RGBA_NV = 34926
 
gl_DEPTH_STENCIL_TO_BGRA_NV :: GLenum
gl_DEPTH_STENCIL_TO_BGRA_NV = 34927