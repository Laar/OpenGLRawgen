{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.TransformFeedbackInstanced
       (glDrawTransformFeedbackStreamInstanced,
        glDrawTransformFeedbackInstanced)
       where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glDrawTransformFeedbackStreamInstanced #-}
 
ptr_glDrawTransformFeedbackStreamInstanced :: FunPtr a
ptr_glDrawTransformFeedbackStreamInstanced
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback_instanced"
        "glDrawTransformFeedbackStreamInstanced"
 
glDrawTransformFeedbackStreamInstanced ::
                                       GLenum -> GLuint -> GLuint -> GLsizei -> IO ()
glDrawTransformFeedbackStreamInstanced
  = dyn_glDrawTransformFeedbackStreamInstanced
      ptr_glDrawTransformFeedbackStreamInstanced
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawTransformFeedbackStreamInstanced ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLuint -> GLsizei -> IO ())
 
{-# NOINLINE ptr_glDrawTransformFeedbackInstanced #-}
 
ptr_glDrawTransformFeedbackInstanced :: FunPtr a
ptr_glDrawTransformFeedbackInstanced
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_transform_feedback_instanced"
        "glDrawTransformFeedbackInstanced"
 
glDrawTransformFeedbackInstanced ::
                                 GLenum -> GLuint -> GLsizei -> IO ()
glDrawTransformFeedbackInstanced
  = dyn_glDrawTransformFeedbackInstanced
      ptr_glDrawTransformFeedbackInstanced
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glDrawTransformFeedbackInstanced ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> GLsizei -> IO ())