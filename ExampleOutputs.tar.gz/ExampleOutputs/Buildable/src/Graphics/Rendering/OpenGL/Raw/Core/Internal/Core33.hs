{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (glVertexAttribDivisor, gl_VERTEX_ATTRIB_ARRAY_DIVISOR,
        gl_UNSIGNED_INT_2_10_10_10_REV, gl_TIME_ELAPSED, gl_TIMESTAMP,
        gl_TEXTURE_SWIZZLE_RGBA, gl_TEXTURE_SWIZZLE_R,
        gl_TEXTURE_SWIZZLE_G, gl_TEXTURE_SWIZZLE_B, gl_TEXTURE_SWIZZLE_A,
        gl_SRC1_COLOR, gl_SRC1_ALPHA, gl_SAMPLER_BINDING, gl_RGB10_A2UI,
        gl_ONE_MINUS_SRC1_COLOR, gl_ONE_MINUS_SRC1_ALPHA,
        gl_MAX_DUAL_SOURCE_DRAW_BUFFERS, gl_INT_2_10_10_10_REV,
        gl_ANY_SAMPLES_PASSED)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15Compatibility
       (gl_SRC1_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_UNSIGNED_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glVertexAttribDivisor #-}
 
ptr_glVertexAttribDivisor :: FunPtr a
ptr_glVertexAttribDivisor
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_VERSION_3_3"
        "glVertexAttribDivisor"
 
glVertexAttribDivisor :: GLuint -> GLuint -> IO ()
glVertexAttribDivisor
  = dyn_glVertexAttribDivisor ptr_glVertexAttribDivisor
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribDivisor
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> IO ())
 
gl_VERTEX_ATTRIB_ARRAY_DIVISOR :: GLenum
gl_VERTEX_ATTRIB_ARRAY_DIVISOR = 35070
 
gl_TIME_ELAPSED :: GLenum
gl_TIME_ELAPSED = 35007
 
gl_TIMESTAMP :: GLenum
gl_TIMESTAMP = 36392
 
gl_TEXTURE_SWIZZLE_RGBA :: GLenum
gl_TEXTURE_SWIZZLE_RGBA = 36422
 
gl_TEXTURE_SWIZZLE_R :: GLenum
gl_TEXTURE_SWIZZLE_R = 36418
 
gl_TEXTURE_SWIZZLE_G :: GLenum
gl_TEXTURE_SWIZZLE_G = 36419
 
gl_TEXTURE_SWIZZLE_B :: GLenum
gl_TEXTURE_SWIZZLE_B = 36420
 
gl_TEXTURE_SWIZZLE_A :: GLenum
gl_TEXTURE_SWIZZLE_A = 36421
 
gl_SRC1_COLOR :: GLenum
gl_SRC1_COLOR = 35065
 
gl_SAMPLER_BINDING :: GLenum
gl_SAMPLER_BINDING = 35097
 
gl_RGB10_A2UI :: GLenum
gl_RGB10_A2UI = 36975
 
gl_ONE_MINUS_SRC1_COLOR :: GLenum
gl_ONE_MINUS_SRC1_COLOR = 35066
 
gl_ONE_MINUS_SRC1_ALPHA :: GLenum
gl_ONE_MINUS_SRC1_ALPHA = 35067
 
gl_MAX_DUAL_SOURCE_DRAW_BUFFERS :: GLenum
gl_MAX_DUAL_SOURCE_DRAW_BUFFERS = 35068
 
gl_INT_2_10_10_10_REV :: GLenum
gl_INT_2_10_10_10_REV = 36255
 
gl_ANY_SAMPLES_PASSED :: GLenum
gl_ANY_SAMPLES_PASSED = 35887