{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.VertexType2101010Rev
       (glVertexP4uiv, glVertexP4ui, glVertexP3uiv, glVertexP3ui,
        glVertexP2uiv, glVertexP2ui, glVertexAttribP4uiv,
        glVertexAttribP4ui, glVertexAttribP3uiv, glVertexAttribP3ui,
        glVertexAttribP2uiv, glVertexAttribP2ui, glVertexAttribP1uiv,
        glVertexAttribP1ui, glTexCoordP4uiv, glTexCoordP4ui,
        glTexCoordP3uiv, glTexCoordP3ui, glTexCoordP2uiv, glTexCoordP2ui,
        glTexCoordP1uiv, glTexCoordP1ui, glSecondaryColorP3uiv,
        glSecondaryColorP3ui, glNormalP3uiv, glNormalP3ui,
        glMultiTexCoordP4uiv, glMultiTexCoordP4ui, glMultiTexCoordP3uiv,
        glMultiTexCoordP3ui, glMultiTexCoordP2uiv, glMultiTexCoordP2ui,
        glMultiTexCoordP1uiv, glMultiTexCoordP1ui, glColorP4uiv,
        glColorP4ui, glColorP3uiv, glColorP3ui,
        gl_UNSIGNED_INT_2_10_10_10_REV, gl_INT_2_10_10_10_REV)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core12
       (gl_UNSIGNED_INT_2_10_10_10_REV)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glVertexP4uiv #-}
 
ptr_glVertexP4uiv :: FunPtr a
ptr_glVertexP4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP4uiv"
 
glVertexP4uiv :: GLenum -> Ptr GLuint -> IO ()
glVertexP4uiv = dyn_glVertexP4uiv ptr_glVertexP4uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexP4ui #-}
 
ptr_glVertexP4ui :: FunPtr a
ptr_glVertexP4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP4ui"
 
glVertexP4ui :: GLenum -> GLuint -> IO ()
glVertexP4ui = dyn_glVertexP4ui ptr_glVertexP4ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexP3uiv #-}
 
ptr_glVertexP3uiv :: FunPtr a
ptr_glVertexP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP3uiv"
 
glVertexP3uiv :: GLenum -> Ptr GLuint -> IO ()
glVertexP3uiv = dyn_glVertexP3uiv ptr_glVertexP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexP3ui #-}
 
ptr_glVertexP3ui :: FunPtr a
ptr_glVertexP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP3ui"
 
glVertexP3ui :: GLenum -> GLuint -> IO ()
glVertexP3ui = dyn_glVertexP3ui ptr_glVertexP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexP2uiv #-}
 
ptr_glVertexP2uiv :: FunPtr a
ptr_glVertexP2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP2uiv"
 
glVertexP2uiv :: GLenum -> Ptr GLuint -> IO ()
glVertexP2uiv = dyn_glVertexP2uiv ptr_glVertexP2uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexP2ui #-}
 
ptr_glVertexP2ui :: FunPtr a
ptr_glVertexP2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexP2ui"
 
glVertexP2ui :: GLenum -> GLuint -> IO ()
glVertexP2ui = dyn_glVertexP2ui ptr_glVertexP2ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexP2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP4uiv #-}
 
ptr_glVertexAttribP4uiv :: FunPtr a
ptr_glVertexAttribP4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP4uiv"
 
glVertexAttribP4uiv ::
                    GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ()
glVertexAttribP4uiv
  = dyn_glVertexAttribP4uiv ptr_glVertexAttribP4uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP4ui #-}
 
ptr_glVertexAttribP4ui :: FunPtr a
ptr_glVertexAttribP4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP4ui"
 
glVertexAttribP4ui ::
                   GLuint -> GLenum -> GLboolean -> GLuint -> IO ()
glVertexAttribP4ui = dyn_glVertexAttribP4ui ptr_glVertexAttribP4ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP3uiv #-}
 
ptr_glVertexAttribP3uiv :: FunPtr a
ptr_glVertexAttribP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP3uiv"
 
glVertexAttribP3uiv ::
                    GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ()
glVertexAttribP3uiv
  = dyn_glVertexAttribP3uiv ptr_glVertexAttribP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP3ui #-}
 
ptr_glVertexAttribP3ui :: FunPtr a
ptr_glVertexAttribP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP3ui"
 
glVertexAttribP3ui ::
                   GLuint -> GLenum -> GLboolean -> GLuint -> IO ()
glVertexAttribP3ui = dyn_glVertexAttribP3ui ptr_glVertexAttribP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP2uiv #-}
 
ptr_glVertexAttribP2uiv :: FunPtr a
ptr_glVertexAttribP2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP2uiv"
 
glVertexAttribP2uiv ::
                    GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ()
glVertexAttribP2uiv
  = dyn_glVertexAttribP2uiv ptr_glVertexAttribP2uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP2ui #-}
 
ptr_glVertexAttribP2ui :: FunPtr a
ptr_glVertexAttribP2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP2ui"
 
glVertexAttribP2ui ::
                   GLuint -> GLenum -> GLboolean -> GLuint -> IO ()
glVertexAttribP2ui = dyn_glVertexAttribP2ui ptr_glVertexAttribP2ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP1uiv #-}
 
ptr_glVertexAttribP1uiv :: FunPtr a
ptr_glVertexAttribP1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP1uiv"
 
glVertexAttribP1uiv ::
                    GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ()
glVertexAttribP1uiv
  = dyn_glVertexAttribP1uiv ptr_glVertexAttribP1uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glVertexAttribP1ui #-}
 
ptr_glVertexAttribP1ui :: FunPtr a
ptr_glVertexAttribP1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glVertexAttribP1ui"
 
glVertexAttribP1ui ::
                   GLuint -> GLenum -> GLboolean -> GLuint -> IO ()
glVertexAttribP1ui = dyn_glVertexAttribP1ui ptr_glVertexAttribP1ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glVertexAttribP1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLenum -> GLboolean -> GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP4uiv #-}
 
ptr_glTexCoordP4uiv :: FunPtr a
ptr_glTexCoordP4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP4uiv"
 
glTexCoordP4uiv :: GLenum -> Ptr GLuint -> IO ()
glTexCoordP4uiv = dyn_glTexCoordP4uiv ptr_glTexCoordP4uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP4ui #-}
 
ptr_glTexCoordP4ui :: FunPtr a
ptr_glTexCoordP4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP4ui"
 
glTexCoordP4ui :: GLenum -> GLuint -> IO ()
glTexCoordP4ui = dyn_glTexCoordP4ui ptr_glTexCoordP4ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP3uiv #-}
 
ptr_glTexCoordP3uiv :: FunPtr a
ptr_glTexCoordP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP3uiv"
 
glTexCoordP3uiv :: GLenum -> Ptr GLuint -> IO ()
glTexCoordP3uiv = dyn_glTexCoordP3uiv ptr_glTexCoordP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP3ui #-}
 
ptr_glTexCoordP3ui :: FunPtr a
ptr_glTexCoordP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP3ui"
 
glTexCoordP3ui :: GLenum -> GLuint -> IO ()
glTexCoordP3ui = dyn_glTexCoordP3ui ptr_glTexCoordP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP2uiv #-}
 
ptr_glTexCoordP2uiv :: FunPtr a
ptr_glTexCoordP2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP2uiv"
 
glTexCoordP2uiv :: GLenum -> Ptr GLuint -> IO ()
glTexCoordP2uiv = dyn_glTexCoordP2uiv ptr_glTexCoordP2uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP2ui #-}
 
ptr_glTexCoordP2ui :: FunPtr a
ptr_glTexCoordP2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP2ui"
 
glTexCoordP2ui :: GLenum -> GLuint -> IO ()
glTexCoordP2ui = dyn_glTexCoordP2ui ptr_glTexCoordP2ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP1uiv #-}
 
ptr_glTexCoordP1uiv :: FunPtr a
ptr_glTexCoordP1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP1uiv"
 
glTexCoordP1uiv :: GLenum -> Ptr GLuint -> IO ()
glTexCoordP1uiv = dyn_glTexCoordP1uiv ptr_glTexCoordP1uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glTexCoordP1ui #-}
 
ptr_glTexCoordP1ui :: FunPtr a
ptr_glTexCoordP1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glTexCoordP1ui"
 
glTexCoordP1ui :: GLenum -> GLuint -> IO ()
glTexCoordP1ui = dyn_glTexCoordP1ui ptr_glTexCoordP1ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glTexCoordP1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glSecondaryColorP3uiv #-}
 
ptr_glSecondaryColorP3uiv :: FunPtr a
ptr_glSecondaryColorP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glSecondaryColorP3uiv"
 
glSecondaryColorP3uiv :: GLenum -> Ptr GLuint -> IO ()
glSecondaryColorP3uiv
  = dyn_glSecondaryColorP3uiv ptr_glSecondaryColorP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glSecondaryColorP3uiv
               ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glSecondaryColorP3ui #-}
 
ptr_glSecondaryColorP3ui :: FunPtr a
ptr_glSecondaryColorP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glSecondaryColorP3ui"
 
glSecondaryColorP3ui :: GLenum -> GLuint -> IO ()
glSecondaryColorP3ui
  = dyn_glSecondaryColorP3ui ptr_glSecondaryColorP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glSecondaryColorP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glNormalP3uiv #-}
 
ptr_glNormalP3uiv :: FunPtr a
ptr_glNormalP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glNormalP3uiv"
 
glNormalP3uiv :: GLenum -> Ptr GLuint -> IO ()
glNormalP3uiv = dyn_glNormalP3uiv ptr_glNormalP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glNormalP3ui #-}
 
ptr_glNormalP3ui :: FunPtr a
ptr_glNormalP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glNormalP3ui"
 
glNormalP3ui :: GLenum -> GLuint -> IO ()
glNormalP3ui = dyn_glNormalP3ui ptr_glNormalP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glNormalP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP4uiv #-}
 
ptr_glMultiTexCoordP4uiv :: FunPtr a
ptr_glMultiTexCoordP4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP4uiv"
 
glMultiTexCoordP4uiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glMultiTexCoordP4uiv
  = dyn_glMultiTexCoordP4uiv ptr_glMultiTexCoordP4uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP4ui #-}
 
ptr_glMultiTexCoordP4ui :: FunPtr a
ptr_glMultiTexCoordP4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP4ui"
 
glMultiTexCoordP4ui :: GLenum -> GLenum -> GLuint -> IO ()
glMultiTexCoordP4ui
  = dyn_glMultiTexCoordP4ui ptr_glMultiTexCoordP4ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP3uiv #-}
 
ptr_glMultiTexCoordP3uiv :: FunPtr a
ptr_glMultiTexCoordP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP3uiv"
 
glMultiTexCoordP3uiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glMultiTexCoordP3uiv
  = dyn_glMultiTexCoordP3uiv ptr_glMultiTexCoordP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP3ui #-}
 
ptr_glMultiTexCoordP3ui :: FunPtr a
ptr_glMultiTexCoordP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP3ui"
 
glMultiTexCoordP3ui :: GLenum -> GLenum -> GLuint -> IO ()
glMultiTexCoordP3ui
  = dyn_glMultiTexCoordP3ui ptr_glMultiTexCoordP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP2uiv #-}
 
ptr_glMultiTexCoordP2uiv :: FunPtr a
ptr_glMultiTexCoordP2uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP2uiv"
 
glMultiTexCoordP2uiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glMultiTexCoordP2uiv
  = dyn_glMultiTexCoordP2uiv ptr_glMultiTexCoordP2uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP2uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP2ui #-}
 
ptr_glMultiTexCoordP2ui :: FunPtr a
ptr_glMultiTexCoordP2ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP2ui"
 
glMultiTexCoordP2ui :: GLenum -> GLenum -> GLuint -> IO ()
glMultiTexCoordP2ui
  = dyn_glMultiTexCoordP2ui ptr_glMultiTexCoordP2ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP2ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP1uiv #-}
 
ptr_glMultiTexCoordP1uiv :: FunPtr a
ptr_glMultiTexCoordP1uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP1uiv"
 
glMultiTexCoordP1uiv :: GLenum -> GLenum -> Ptr GLuint -> IO ()
glMultiTexCoordP1uiv
  = dyn_glMultiTexCoordP1uiv ptr_glMultiTexCoordP1uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP1uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glMultiTexCoordP1ui #-}
 
ptr_glMultiTexCoordP1ui :: FunPtr a
ptr_glMultiTexCoordP1ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glMultiTexCoordP1ui"
 
glMultiTexCoordP1ui :: GLenum -> GLenum -> GLuint -> IO ()
glMultiTexCoordP1ui
  = dyn_glMultiTexCoordP1ui ptr_glMultiTexCoordP1ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glMultiTexCoordP1ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glColorP4uiv #-}
 
ptr_glColorP4uiv :: FunPtr a
ptr_glColorP4uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glColorP4uiv"
 
glColorP4uiv :: GLenum -> Ptr GLuint -> IO ()
glColorP4uiv = dyn_glColorP4uiv ptr_glColorP4uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorP4uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glColorP4ui #-}
 
ptr_glColorP4ui :: FunPtr a
ptr_glColorP4ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glColorP4ui"
 
glColorP4ui :: GLenum -> GLuint -> IO ()
glColorP4ui = dyn_glColorP4ui ptr_glColorP4ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorP4ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())
 
{-# NOINLINE ptr_glColorP3uiv #-}
 
ptr_glColorP3uiv :: FunPtr a
ptr_glColorP3uiv
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glColorP3uiv"
 
glColorP3uiv :: GLenum -> Ptr GLuint -> IO ()
glColorP3uiv = dyn_glColorP3uiv ptr_glColorP3uiv
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorP3uiv ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> Ptr GLuint -> IO ())
 
{-# NOINLINE ptr_glColorP3ui #-}
 
ptr_glColorP3ui :: FunPtr a
ptr_glColorP3ui
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_vertex_type_2_10_10_10_rev"
        "glColorP3ui"
 
glColorP3ui :: GLenum -> GLuint -> IO ()
glColorP3ui = dyn_glColorP3ui ptr_glColorP3ui
 
foreign import CALLCONV unsafe "dynamic" dyn_glColorP3ui ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLenum -> GLuint -> IO ())