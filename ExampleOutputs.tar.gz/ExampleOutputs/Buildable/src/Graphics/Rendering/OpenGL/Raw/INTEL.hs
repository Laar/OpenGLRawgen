module Graphics.Rendering.OpenGL.Raw.INTEL
       (module Graphics.Rendering.OpenGL.Raw.INTEL.ParallelArrays) where
import Graphics.Rendering.OpenGL.Raw.INTEL.ParallelArrays