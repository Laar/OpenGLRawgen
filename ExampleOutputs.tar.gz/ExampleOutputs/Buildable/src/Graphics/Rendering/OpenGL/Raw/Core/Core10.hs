module Graphics.Rendering.OpenGL.Raw.Core.Core10
       (module Graphics.Rendering.OpenGL.Raw.Types,
        module Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core10
import Graphics.Rendering.OpenGL.Raw.Types