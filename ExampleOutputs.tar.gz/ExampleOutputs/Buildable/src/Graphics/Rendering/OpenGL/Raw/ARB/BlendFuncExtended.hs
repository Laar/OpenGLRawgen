{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE CPP #-}
module Graphics.Rendering.OpenGL.Raw.ARB.BlendFuncExtended
       (glGetFragDataIndex, glBindFragDataLocationIndexed, gl_SRC1_COLOR,
        gl_SRC1_ALPHA, gl_ONE_MINUS_SRC1_COLOR, gl_ONE_MINUS_SRC1_ALPHA,
        gl_MAX_DUAL_SOURCE_DRAW_BUFFERS)
       where
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core33
       (gl_SRC1_COLOR, gl_ONE_MINUS_SRC1_COLOR, gl_ONE_MINUS_SRC1_ALPHA,
        gl_MAX_DUAL_SOURCE_DRAW_BUFFERS)
import Graphics.Rendering.OpenGL.Raw.Core.Internal.Core15Compatibility
       (gl_SRC1_ALPHA)
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
import Foreign.Ptr
import Graphics.Rendering.OpenGL.Raw.Internal.Extensions
 
{-# NOINLINE ptr_glGetFragDataIndex #-}
 
ptr_glGetFragDataIndex :: FunPtr a
ptr_glGetFragDataIndex
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_blend_func_extended"
        "glGetFragDataIndex"
 
glGetFragDataIndex :: GLuint -> Ptr GLchar -> IO GLint
glGetFragDataIndex = dyn_glGetFragDataIndex ptr_glGetFragDataIndex
 
foreign import CALLCONV unsafe "dynamic" dyn_glGetFragDataIndex ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> Ptr GLchar -> IO GLint)
 
{-# NOINLINE ptr_glBindFragDataLocationIndexed #-}
 
ptr_glBindFragDataLocationIndexed :: FunPtr a
ptr_glBindFragDataLocationIndexed
  = unsafePerformIO $
      Graphics.Rendering.OpenGL.Raw.Internal.Extensions.getExtensionEntry
        "GL_ARB_blend_func_extended"
        "glBindFragDataLocationIndexed"
 
glBindFragDataLocationIndexed ::
                              GLuint -> GLuint -> GLuint -> Ptr GLchar -> IO ()
glBindFragDataLocationIndexed
  = dyn_glBindFragDataLocationIndexed
      ptr_glBindFragDataLocationIndexed
 
foreign import CALLCONV unsafe "dynamic"
               dyn_glBindFragDataLocationIndexed ::
               Graphics.Rendering.OpenGL.Raw.Internal.Extensions.Invoker
                 (GLuint -> GLuint -> GLuint -> Ptr GLchar -> IO ())