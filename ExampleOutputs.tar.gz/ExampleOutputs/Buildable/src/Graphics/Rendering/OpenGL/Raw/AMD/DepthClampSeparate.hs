module Graphics.Rendering.OpenGL.Raw.AMD.DepthClampSeparate
       (gl_DEPTH_CLAMP_NEAR_AMD, gl_DEPTH_CLAMP_FAR_AMD) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_DEPTH_CLAMP_NEAR_AMD :: GLenum
gl_DEPTH_CLAMP_NEAR_AMD = 36894
 
gl_DEPTH_CLAMP_FAR_AMD :: GLenum
gl_DEPTH_CLAMP_FAR_AMD = 36895