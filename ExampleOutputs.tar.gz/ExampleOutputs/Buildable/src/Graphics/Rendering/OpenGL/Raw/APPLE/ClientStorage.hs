module Graphics.Rendering.OpenGL.Raw.APPLE.ClientStorage
       (gl_UNPACK_CLIENT_STORAGE_APPLE) where
import Graphics.Rendering.OpenGL.Raw.Internal.TypesInternal
 
gl_UNPACK_CLIENT_STORAGE_APPLE :: GLenum
gl_UNPACK_CLIENT_STORAGE_APPLE = 34226